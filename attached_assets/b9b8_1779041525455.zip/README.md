# B9b.8 — AntiGhosting Pipeline page (frontend only)

View-only listing page for anti_ghosting prospects. Modeled on
context-pipeline.tsx, trimmed of action buttons that need backend
endpoints I haven't seen yet.

## What ships in this batch

1. New page: `artifacts/dashboard/src/pages/anti-ghosting-pipeline.tsx`
2. App.tsx wiring: import + `<Route path="/anti-ghosting/pipeline">`

Includes a Cycle pill that's unique to AntiGhosting (shows current
cycle and prior cycle count). All other action buttons are dropped;
they ship in later batches (B9b.9-11).

## What does NOT ship in this batch

The backend endpoint `GET /api/anti-ghosting/followups` is NOT included.
The page will show "Failed to load follow-ups" until I ship the
backend in B9b.8.1. That's expected — this batch validates the
frontend renders and the route is wired up.

## How to apply

```
unzip b9b8.zip -d b9b8/ && python3 b9b8/scripts/apply-b9b8.py
cd artifacts/dashboard && pnpm run build && cd -
# restart the dashboard workflow
```

Then navigate to https://doctrine-followupv-2.replit.app/anti-ghosting/pipeline
and confirm the page renders (error card is the expected state).

## For B9b.8.1 (backend)

Paste me back this output so I can ship the endpoint with correct
imports:

```
head -50 artifacts/api-server/src/routes/context.ts
echo "=== /followups handler ==="
grep -n -A 80 'router\.get.*"/followups"' artifacts/api-server/src/routes/context.ts | head -100
echo "=== anti-ghosting.ts head + tail ==="
head -30 artifacts/api-server/src/routes/anti-ghosting.ts
echo "..."
tail -20 artifacts/api-server/src/routes/anti-ghosting.ts
```
