#!/usr/bin/env node
/**
 * apply-batch7j.mjs — Phase 7j (polish: hide empty vertical + stats consistency).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Two small concerns bundled:
 *
 *   #2 — Hide the vertical badge in the Context Email Inspector when
 *        the value is empty. The 7g backend intentionally returns
 *        `vertical: ""` for context (no vertical inference). Without
 *        this fix the UI renders an empty <Badge> in the email row
 *        and an "Vertical: " row + "Reason: " row in the detection
 *        panel — both with empty values.
 *
 *   #5 — Add `drafted_followups` to /api/stats (doctrine). The context
 *        /api/stats already returns this field. Doctrine's response
 *        omits it. Two dashboard consumers (dashboard.tsx,
 *        pipeline.tsx) pull /api/stats; making both surfaces return
 *        the same shape simplifies the wire format.
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src DASH_BASE=artifacts/dashboard/src \
 *     node apply-batch7j.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const log  = (msg) => console.log(`[apply-batch7j] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7j] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const ctxInspectorPath = join(DASH_BASE, "pages", "context-inspector.tsx");
const doctrineRoutePath = join(API_BASE, "routes", "doctrine.ts");

// ============================================================
// Concern #2 — Hide empty vertical badge in /context/inspector
// ============================================================
log("Step 1: Hide empty vertical badge (email row)...");

strReplace(
  ctxInspectorPath,
  `              <div className="ml-auto flex items-center gap-1.5">
                <Badge variant="outline">{vertLabel}</Badge>`,
  `              <div className="ml-auto flex items-center gap-1.5">
                {/* Phase 7j: hide empty vertical badge — context emails carry no vertical. */}
                {vertLabel && <Badge variant="outline">{vertLabel}</Badge>}`,
  "ctx-inspector: gate vertical badge on vertLabel",
  `Phase 7j: hide empty vertical badge — context emails carry no vertical.`
);

log("Step 2: Hide empty Vertical/Reason rows (detection panel)...");

strReplace(
  ctxInspectorPath,
  `                    <div className="flex justify-between">
                      <span style={{ color: "var(--text-secondary)" }}>Vertical</span>
                      <span style={{ color: "var(--text-primary)" }}>{vertLabel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span style={{ color: "var(--text-secondary)" }}>Reason</span>
                      <span className="text-[12px]" style={{ color: "var(--text-secondary)" }}>{email.detection.verticalReason}</span>
                    </div>`,
  `                    {/* Phase 7j: detection panel hides Vertical/Reason rows when vertical inference is empty. */}
                    {vertLabel && (
                      <>
                        <div className="flex justify-between">
                          <span style={{ color: "var(--text-secondary)" }}>Vertical</span>
                          <span style={{ color: "var(--text-primary)" }}>{vertLabel}</span>
                        </div>
                        <div className="flex justify-between">
                          <span style={{ color: "var(--text-secondary)" }}>Reason</span>
                          <span className="text-[12px]" style={{ color: "var(--text-secondary)" }}>{email.detection.verticalReason}</span>
                        </div>
                      </>
                    )}`,
  "ctx-inspector: gate Vertical/Reason rows on vertLabel",
  `Phase 7j: detection panel hides Vertical/Reason rows when vertical inference is empty.`
);

// ============================================================
// Concern #5 — Add drafted_followups to doctrine /api/stats
// ============================================================
log("Step 3: Add drafted_followups to doctrine /api/stats SELECT (filtered branch)...");

// The doctrine /stats handler has TWO followup queries (one with userId
// filter, one without). Both need draftedFollowups added. Each branch
// has the same .select shape but with a slightly different .where, so
// the SELECT block alone isn't unique — anchor on the surrounding
// .where to disambiguate.

strReplace(
  doctrineRoutePath,
  `      ? db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId, userIdFilter)))`,
  `      ? db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
          // Phase 7j: drafted_followups added so doctrine /api/stats matches the context shape.
          draftedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'drafted' then 1 else 0 end)\`,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId, userIdFilter)))`,
  "doctrine.ts: add draftedFollowups to filtered SELECT",
  `// Phase 7j: drafted_followups added so doctrine /api/stats matches the context shape.`
);

log("Step 4: Add drafted_followups to doctrine /api/stats SELECT (unfiltered branch)...");

strReplace(
  doctrineRoutePath,
  `      : db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
        })`,
  `      : db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
          // Phase 7j (unfiltered branch): drafted_followups parity with context.
          draftedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'drafted' then 1 else 0 end)\`,
        })`,
  "doctrine.ts: add draftedFollowups to unfiltered SELECT",
  `// Phase 7j (unfiltered branch): drafted_followups parity with context.`
);

log("Step 5: Add drafted_followups to doctrine /api/stats response...");

strReplace(
  doctrineRoutePath,
  `    res.json({
      total_sent: Number(ps?.totalSent) || 0,
      unreplied: Number(ps?.unreplied) || 0,
      replied: Number(ps?.replied) || 0,
      queued_followups: Number(fs?.queuedFollowups) || 0,
      sent_followups: Number(fs?.sentFollowups) || 0,
    });`,
  `    res.json({
      total_sent: Number(ps?.totalSent) || 0,
      unreplied: Number(ps?.unreplied) || 0,
      replied: Number(ps?.replied) || 0,
      queued_followups: Number(fs?.queuedFollowups) || 0,
      sent_followups: Number(fs?.sentFollowups) || 0,
      // Phase 7j: drafted_followups added for shape parity with /api/context/stats.
      drafted_followups: Number(fs?.draftedFollowups) || 0,
    });`,
  "doctrine.ts: add drafted_followups to response",
  `// Phase 7j: drafted_followups added for shape parity with /api/context/stats.`
);

// ============================================================
// Self-verify
// ============================================================
log("Step 6: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// #2 — vertical hide
expectInFile(ctxInspectorPath, `Phase 7j: hide empty vertical badge — context emails carry no vertical.`, "V1 vertical badge gated comment");
expectInFile(ctxInspectorPath, `{vertLabel && <Badge variant="outline">{vertLabel}</Badge>}`, "V2 vertical badge wrapped in vertLabel guard");
expectInFile(ctxInspectorPath, `Phase 7j: detection panel hides Vertical/Reason rows when vertical inference is empty.`, "V3 detection panel gated comment");
expectInFile(ctxInspectorPath, `{vertLabel && (
                      <>`, "V4 detection panel wrapped in vertLabel guard");

// Old unconditional renders should be gone
expectNotInFile(ctxInspectorPath, `              <div className="ml-auto flex items-center gap-1.5">
                <Badge variant="outline">{vertLabel}</Badge>`, "V5 unconditional badge render gone");

// #5 — drafted_followups on doctrine
expectInFile(doctrineRoutePath, `// Phase 7j: drafted_followups added so doctrine /api/stats matches the context shape.`, "V6 doctrine SELECT comment (filtered)");
expectInFile(doctrineRoutePath, `// Phase 7j (unfiltered branch): drafted_followups parity with context.`, "V7 doctrine SELECT comment (unfiltered)");
expectInFile(doctrineRoutePath, `// Phase 7j: drafted_followups added for shape parity with /api/context/stats.`, "V8 doctrine response comment");
expectInFile(doctrineRoutePath, `drafted_followups: Number(fs?.draftedFollowups) || 0,`, "V9 doctrine response field");
// Both SELECT branches should have draftedFollowups now (count >= 2)
{
  const src = readFileOrFail(doctrineRoutePath);
  const count = (src.match(/draftedFollowups: sql<number>/g) || []).length;
  if (count < 2) fail(`V10 expected ≥2 draftedFollowups SELECTs, got ${count}`);
  log(`  [OK] V10 draftedFollowups present in both SELECT branches (${count} occurrences)`);
}

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7j patch applied. Empty vertical badge + Vertical/Reason");
log("rows hidden in /context/inspector. /api/stats (doctrine) now");
log("returns drafted_followups for shape parity with /api/context/stats.");
log("================================================================");
