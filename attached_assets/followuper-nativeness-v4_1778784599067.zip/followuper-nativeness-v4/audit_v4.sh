#!/usr/bin/env bash
# Followuper v4 nativeness layer — 5-round godlike audit.
# Verifies the v4 patch surface against the v3 baseline snapshot, end to end.
#
# Usage:
#   bash audit_v4.sh
#
# Layout expected:
#   /home/claude/followuper_v4/build/snapshot     pristine v3 source
#   /home/claude/followuper_v4/build/payload      v4 module + tests + patches
#   /home/claude/followuper_v4/build/audit_work   built per-run by this script

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SNAPSHOT="${SCRIPT_DIR}/snapshot"
PAYLOAD="${SCRIPT_DIR}/payload"
WORK="${SCRIPT_DIR}/audit_work"
PATCHER="${PAYLOAD}/patches/apply_patches.py"

PASS=0
FAIL=0
WARN=0

ok()   { echo "    [PASS]  $*"; PASS=$((PASS + 1)); }
fail() { echo "    [FAIL]  $*"; FAIL=$((FAIL + 1)); }
warn() { echo "    [WARN]  $*"; WARN=$((WARN + 1)); }

fresh_work_tree() {
    rm -rf "$WORK"
    mkdir -p "$WORK"
    cp -r "$SNAPSHOT/api-server" "$WORK/"
    cp "$SNAPSHOT/api-server-package.json" "$WORK/api-server/package.json"
    # Strip workspace:* deps so npm install succeeds in the isolated tree
    ( cd "$WORK/api-server" && node -e "
        const pkg = JSON.parse(require('fs').readFileSync('package.json','utf8'));
        for (const dep of Object.keys(pkg.dependencies || {})) { if (pkg.dependencies[dep].startsWith('workspace:')) delete pkg.dependencies[dep]; }
        for (const dep of Object.keys(pkg.devDependencies || {})) { if (pkg.devDependencies[dep].startsWith('workspace:')) delete pkg.devDependencies[dep]; }
        require('fs').writeFileSync('package.json', JSON.stringify(pkg, null, 2));
    " >/dev/null 2>&1
      # Reuse node_modules from a prior install if present
      if [[ -d "${SCRIPT_DIR}/test_apply/api-server/node_modules" ]]; then
          cp -r "${SCRIPT_DIR}/test_apply/api-server/node_modules" .
      else
          npm install --silent 2>&1 | tail -1
      fi
    )
}

# ============================================================================
# ROUND 1 — Patch correctness
# ============================================================================
echo
echo "=== ROUND 1 — Patch correctness ==="

fresh_work_tree

# 1a. Fresh apply
OUTPUT=$(cd "$WORK" && python3 "$PATCHER" 2>&1)
COUNT_OK=$(echo "$OUTPUT" | grep -c "\[  OK  \]")
COUNT_SKIP=$(echo "$OUTPUT" | grep -c "\[ SKIP \]")
COUNT_FAIL=$(echo "$OUTPUT" | grep -c "\[ FAIL \]")
if [[ "$COUNT_OK" == "11" && "$COUNT_FAIL" == "0" ]]; then
    ok "Fresh apply: 11/11 OK, 0 SKIP, 0 FAIL"
else
    fail "Fresh apply mismatch: $COUNT_OK OK / $COUNT_SKIP SKIP / $COUNT_FAIL FAIL"
fi

# 1b. Re-apply idempotent
OUTPUT2=$(cd "$WORK" && python3 "$PATCHER" 2>&1)
COUNT_OK2=$(echo "$OUTPUT2" | grep -c "\[  OK  \]")
COUNT_SKIP2=$(echo "$OUTPUT2" | grep -c "\[ SKIP \]")
COUNT_FAIL2=$(echo "$OUTPUT2" | grep -c "\[ FAIL \]")
if [[ "$COUNT_OK2" == "0" && "$COUNT_SKIP2" == "11" && "$COUNT_FAIL2" == "0" ]]; then
    ok "Re-apply idempotent: 11/11 SKIP, 0 OK, 0 FAIL"
else
    fail "Re-apply not idempotent: $COUNT_OK2 OK / $COUNT_SKIP2 SKIP / $COUNT_FAIL2 FAIL"
fi

# 1c. Backups byte-identical to snapshot
for f in \
    "api-server/lib/languageNativeness.ts" \
    "api-server/lib/doctrineLint.ts" \
    "api-server/services/followupPrompts.ts" \
    "api-server/tests/test-nativeness-v3.ts"; do
    backup="$WORK/$f.v3_backup"
    base="$SNAPSHOT/$f"
    if [[ -f "$backup" ]] && cmp -s "$backup" "$base"; then
        ok "Backup $f.v3_backup is byte-identical to snapshot baseline"
    else
        fail "Backup $f.v3_backup missing or differs from baseline"
    fi
done

# 1d. Installed nativenessV4.ts and test-nativeness-v4.ts byte-identical to payload
for f in \
    "api-server/lib/nativenessV4.ts" \
    "api-server/tests/test-nativeness-v4.ts"; do
    if cmp -s "$WORK/$f" "$PAYLOAD/$f"; then
        ok "Installed $f is byte-identical to payload"
    else
        fail "Installed $f differs from payload"
    fi
done

# 1e. v4 markers present in patched files
declare -A MARKERS=(
    ["api-server/lib/languageNativeness.ts"]="buildNativenessBlockV4(languageTag)"
    ["api-server/lib/doctrineLint.ts"]="findAllNativenessViolationsV4(body, languageTag)"
    ["api-server/services/followupPrompts.ts"]="13. PRODUCTION-FAILURE PATTERN CHECKLIST"
)
for f in "${!MARKERS[@]}"; do
    marker="${MARKERS[$f]}"
    if grep -qF "$marker" "$WORK/$f"; then
        ok "$f contains v4 marker: ${marker:0:60}..."
    else
        fail "$f missing v4 marker: $marker"
    fi
done

# 1f. doctrineLint emits translationese
if grep -qF "TRANSLATIONESE-PATTERN" "$WORK/api-server/lib/doctrineLint.ts"; then
    ok "doctrineLint.ts emits TRANSLATIONESE-PATTERN issues"
else
    fail "doctrineLint.ts missing TRANSLATIONESE-PATTERN emission"
fi

# 1g. Missing-anchor scenario fails loudly
TMPDIR=$(mktemp -d)
cp -r "$SNAPSHOT/api-server" "$TMPDIR/"
echo "// no anchors here" > "$TMPDIR/api-server/lib/languageNativeness.ts"
if cd "$TMPDIR" && python3 "$PATCHER" > /dev/null 2>&1; then
    fail "Missing-anchor scenario should have failed but exited 0"
else
    ok "Missing-anchor scenario fails loudly (as designed)"
fi
rm -rf "$TMPDIR"


# ============================================================================
# ROUND 2 — Behavioral (test runner + production samples)
# ============================================================================
echo
echo "=== ROUND 2 — Behavioral (test runner + production samples) ==="

cd "$WORK/api-server"

# 2a. v3 test suite still passes
V3_OUT=$(npx tsx tests/test-nativeness-v3.ts 2>&1)
V3_PASS=$(echo "$V3_OUT" | grep -oE "^# pass [0-9]+" | grep -oE "[0-9]+")
V3_FAIL=$(echo "$V3_OUT" | grep -oE "^# fail [0-9]+" | grep -oE "[0-9]+")
if [[ "$V3_PASS" == "67" && "$V3_FAIL" == "0" ]]; then
    ok "v3 test suite: 67/67 pass (no regression)"
else
    fail "v3 regression: $V3_PASS pass / $V3_FAIL fail"
fi

# 2b. v4 test suite passes
V4_OUT=$(npx tsx tests/test-nativeness-v4.ts 2>&1)
V4_TESTS=$(echo "$V4_OUT" | grep -oE "^# tests [0-9]+" | grep -oE "[0-9]+")
V4_PASS=$(echo "$V4_OUT" | grep -oE "^# pass [0-9]+" | grep -oE "[0-9]+")
V4_FAIL=$(echo "$V4_OUT" | grep -oE "^# fail [0-9]+" | grep -oE "[0-9]+")
if [[ -n "$V4_TESTS" && "$V4_PASS" == "$V4_TESTS" && "$V4_FAIL" == "0" ]]; then
    ok "v4 test suite: $V4_PASS/$V4_TESTS pass"
else
    fail "v4 suite: $V4_PASS pass / $V4_FAIL fail (of $V4_TESTS)"
fi

# 2c. Production samples — Image-2 BAD PT fires translationese
HITS=$(npx tsx -e "
import { findTranslationese } from './lib/nativenessV4';
const t = \`Olá Vinicius,
Apps de investimento no Brasil disputam o primeiro aporte via PIX como evento norte com o gancho de 150% do CDI.
A forma como trabalhamos é rodar uma campanha mobile. O ponto específico aqui é que ajustamos a mistura de editores contra a persistência do segundo aporte.
Faz sentido comparar um piloto contra o CPA atual da XP?\`;
console.log(findTranslationese(t, 'pt').length);
" 2>&1)
if [[ "$HITS" =~ ^[0-9]+$ ]] && [[ "$HITS" -ge 5 ]]; then
    ok "Image-2 BAD PT fires $HITS translationese hits (>= 5 expected)"
else
    fail "Image-2 BAD PT only fires $HITS translationese hits"
fi

# 2d. Denise GOOD PT passes clean
HASANY=$(npx tsx -e "
import { findAllNativenessViolationsV4, hasAnyViolationV4 } from './lib/nativenessV4';
const t = \`Olá, Natan. Como vai?
Sabemos que a disputa por usuários qualificados está acirrada.
Considerando que entregamos 400 contas/dia, acredito que temos insumos relevantes.
Operamos campanhas mobile em múltiplos canais.
Acredito que pode fazer sentido avaliarmos um piloto. Você está disponível para falarmos?\`;
console.log(hasAnyViolationV4(findAllNativenessViolationsV4(t, 'pt')));
" 2>&1)
if [[ "$HASANY" == "false" ]]; then
    ok "Denise's GOOD PT email passes clean (hasAnyViolationV4=false)"
else
    fail "Denise's GOOD PT triggers violations: $HASANY"
fi

# 2e. Image-1 BAD Thai fires greeting-name
TH_HIT=$(npx tsx -e "
import { findGreetingNameAdaptationIssues } from './lib/nativenessV4';
console.log(findGreetingNameAdaptationIssues('เรียน Tareep,\nผู้ให้บริการ...', 'th').join(','));
" 2>&1)
if [[ "$TH_HIT" == "Tareep" ]]; then
    ok "Image-1 BAD Thai fires greeting-name: [Tareep]"
else
    fail "Image-1 BAD Thai greeting-name detection failed: $TH_HIT"
fi

# 2f. Coverage counts
COUNTS=$(npx tsx -e "
import { TRANSLATIONESE_PATTERNS, NATIVE_STYLE_GUIDES, NATIVE_ENGLISH_LOANWORDS } from './lib/nativenessV4';
let total = 0; for (const arr of Object.values(TRANSLATIONESE_PATTERNS)) total += arr.length;
console.log(Object.keys(TRANSLATIONESE_PATTERNS).length + '|' + total + '|' + Object.keys(NATIVE_STYLE_GUIDES).length + '|' + Object.keys(NATIVE_ENGLISH_LOANWORDS).length);
" 2>&1 | tail -1)
IFS='|' read -r TR_LANGS TR_TOTAL NS_LANGS LW_LANGS <<<"$COUNTS"
if [[ "$TR_LANGS" -ge 22 && "$TR_TOTAL" -ge 150 ]]; then
    ok "Translationese coverage: $TR_LANGS languages, $TR_TOTAL total patterns"
else
    fail "Translationese coverage low: $TR_LANGS langs, $TR_TOTAL patterns"
fi
if [[ "$NS_LANGS" -eq 35 ]]; then
    ok "Native-style guide covers $NS_LANGS languages (35 expected)"
else
    fail "Native-style guide covers $NS_LANGS languages (35 expected)"
fi
if [[ "$LW_LANGS" -ge 8 ]]; then
    ok "Native English loanwords cover $LW_LANGS languages (>= 8 expected)"
else
    fail "Native English loanwords cover only $LW_LANGS languages"
fi


# ============================================================================
# ROUND 3 — Runtime (typecheck + imports)
# ============================================================================
echo
echo "=== ROUND 3 — Runtime (typecheck + imports) ==="

for f in \
    "lib/nativenessV4.ts" \
    "lib/languageNativeness.ts" \
    "lib/doctrineLint.ts" \
    "services/followupPrompts.ts"; do
    TC=$(npx tsc --noEmit --target es2022 --module esnext --moduleResolution bundler --strict --skipLibCheck "$f" 2>&1)
    if [[ -z "$TC" ]]; then
        ok "TypeScript typecheck: $f"
    else
        fail "Typecheck errors in $f:"
        echo "$TC" | head -5
    fi
done

# v4 module imports + all public exports present
EXPORTS_OK=$(npx tsx -e "
import {
  LATIN_DIACRITIC_LANGS, NATIVE_ENGLISH_LOANWORDS, TRANSLATIONESE_PATTERNS,
  NATIVE_STYLE_GUIDES, findTranslationese, findGreetingNameAdaptationIssues,
  findAllNativenessViolationsV4, hasAnyViolationV4, buildNativenessBlockV4,
  buildCriticNativeStyleBlockV4
} from './lib/nativenessV4';
console.log('OK');
" 2>&1 | tail -1)
if [[ "$EXPORTS_OK" == "OK" ]]; then
    ok "nativenessV4 module: imports + all 10 public exports present"
else
    fail "v4 module export error: $EXPORTS_OK"
fi


# ============================================================================
# ROUND 4 — End-to-end wiring (call sites)
# ============================================================================
echo
echo "=== ROUND 4 — End-to-end wiring (call sites) ==="

# 4a. languageNativeness forwards to v4
if grep -q "return buildNativenessBlockV4(languageTag)" lib/languageNativeness.ts; then
    ok "languageNativeness buildNativenessBlock forwards to v4"
else
    fail "languageNativeness still forwards to v3 only"
fi
if grep -q "buildCriticNativeStyleBlockV4(languageTag)" lib/languageNativeness.ts; then
    ok "languageNativeness buildCriticNativenessBlock concatenates v3 + v4"
else
    fail "languageNativeness buildCriticNativenessBlock not extended"
fi

# 4b. doctrineLint uses v4 aggregator
if grep -q "findAllNativenessViolationsV4(body, languageTag)" lib/doctrineLint.ts; then
    ok "doctrineLint uses v4 aggregator"
else
    fail "doctrineLint not switched to v4"
fi

# 4c. doctrineLint emits translationese
if grep -q "TRANSLATIONESE-PATTERN" lib/doctrineLint.ts; then
    ok "doctrineLint emits translationese lint violations"
else
    fail "doctrineLint missing translationese emission"
fi

# 4d. followupPrompts has criteria 11+12+13
if grep -q "11. TRANSLATIONESE PATTERNS" services/followupPrompts.ts \
   && grep -q "12. NATIVE-STRUCTURE SCAFFOLD" services/followupPrompts.ts \
   && grep -q "13. PRODUCTION-FAILURE PATTERN CHECKLIST" services/followupPrompts.ts; then
    ok "followupPrompts has criteria 11 (translationese) + 12 (structure) + 13 (production-failure)"
else
    fail "followupPrompts missing v4 critic criteria"
fi

# 4e. Criterion 13 has all 8 sub-criteria
SUB_COUNT=0
for sub in "13a\." "13b\." "13c\." "13d\." "13e\." "13f\." "13g\." "13h\."; do
    if grep -q "$sub" services/followupPrompts.ts; then
        SUB_COUNT=$((SUB_COUNT + 1))
    fi
done
if [[ "$SUB_COUNT" == "8" ]]; then
    ok "Criterion 13 has all 8 sub-criteria (13a-13h)"
else
    fail "Criterion 13 missing sub-criteria — found $SUB_COUNT, expected 8"
fi

# 4f. Criterion 13 references >= 14 languages
LANG_COUNT=$(node -e "
const src = require('fs').readFileSync('services/followupPrompts.ts','utf8');
const start = src.indexOf('13. PRODUCTION-FAILURE PATTERN CHECKLIST');
const section = src.slice(start);
const langs = ['pt','es','it','fr','de','ru','ja','zh','ko','ar','he','hi','th','vi'];
console.log(langs.filter(c => section.includes(c+':') || section.includes(c+'-')).length);
")
if [[ "$LANG_COUNT" -ge 14 ]]; then
    ok "Criterion 13 references $LANG_COUNT languages (>= 14 expected)"
else
    fail "Criterion 13 references only $LANG_COUNT languages"
fi

# 4g. v4 prompt block stacks correctly on v3 (writer)
STACK=$(npx tsx -e "
import { buildNativenessBlock } from './lib/languageNativeness';
import { buildNativenessBlockV3 } from './lib/nativenessV3';
const v3 = buildNativenessBlockV3('pt');
const v4 = buildNativenessBlock('pt');
console.log(v4.startsWith(v3) ? 'OK' : 'FAIL');
console.log(v4.includes('NATIVE STYLE GUIDE') ? 'OK' : 'FAIL');
console.log(v4.includes('TRANSLATIONESE BAN') ? 'OK' : 'FAIL');
console.log(v4.includes('UNIVERSAL NAME ADAPTATION') ? 'OK' : 'FAIL');
" 2>&1)
STACK_OK=$(echo "$STACK" | grep -c "^OK$")
if [[ "$STACK_OK" == "4" ]]; then
    ok "v4 prompt block stacks correctly on v3 (all 3 v4 sections present)"
else
    fail "v4 prompt block stacking issue:"
    echo "$STACK" | head -6
fi


# ============================================================================
# ROUND 5 — Regression (line deltas + rollback + contracts)
# ============================================================================
echo
echo "=== ROUND 5 — Regression (line deltas + rollback + contracts) ==="

# 5a. Line deltas are reasonable
for pair in \
    "api-server/lib/languageNativeness.ts|30" \
    "api-server/lib/doctrineLint.ts|40" \
    "api-server/services/followupPrompts.ts|50" \
    "api-server/tests/test-nativeness-v3.ts|30"; do
    file="${pair%%|*}"
    max_delta="${pair#*|}"
    base_lines=$(wc -l < "$SNAPSHOT/$file")
    new_lines=$(wc -l < "$WORK/$file")
    delta=$((new_lines - base_lines))
    if [[ "$delta" -le "$max_delta" ]]; then
        ok "$file line delta: +$delta (max +$max_delta)"
    else
        warn "$file line delta unusually large: +$delta (max expected +$max_delta)"
    fi
done

# 5b. nativenessV3.ts byte-identical to snapshot (v4 must be purely additive)
if cmp -s "$WORK/api-server/lib/nativenessV3.ts" "$SNAPSHOT/api-server/lib/nativenessV3.ts"; then
    ok "nativenessV3.ts is byte-identical to snapshot (v4 is purely additive)"
else
    fail "nativenessV3.ts was modified — v4 should be additive only"
fi

# 5c. ViolationReport contract: v4 aggregator preserves v3 keys
KEYS=$(npx tsx -e "
import { findAllNativenessViolationsV4 } from './lib/nativenessV4';
const r = findAllNativenessViolationsV4('test', 'pt');
console.log(Object.keys(r).sort().join(','));
" 2>&1 | tail -1)
EXPECTED="forbidden_phrases,forbidden_singletons,greeting_name_adaptation,latin_token_runs,translationese,untransliterated_greeting_name,x_not_y"
if [[ "$KEYS" == "$EXPECTED" ]]; then
    ok "ViolationReport contract: all v3 keys preserved in v4 aggregator + 2 new keys"
else
    fail "ViolationReport keys mismatch — got: $KEYS"
fi

# 5d. Rollback restores byte-identical snapshot
ROLLBACK_DIR=$(mktemp -d)
cp -r "$WORK/api-server" "$ROLLBACK_DIR/"
( cd "$ROLLBACK_DIR/api-server"
  # Restore each .v3_backup to its original
  find . -name "*.v3_backup" -type f | while read backup; do
      orig="${backup%.v3_backup}"
      cp "$backup" "$orig"
      rm "$backup"
  done
  # Remove v4 module + v4 tests (the newly installed files)
  rm -f lib/nativenessV4.ts tests/test-nativeness-v4.ts
)
# Compare rollback result against pristine snapshot (excluding node_modules + package.json which we stripped)
DIFF_OUT=$(diff -r \
    --exclude=node_modules \
    --exclude=package.json \
    --exclude=package-lock.json \
    "$ROLLBACK_DIR/api-server" "$SNAPSHOT/api-server" 2>&1)
if [[ -z "$DIFF_OUT" ]]; then
    ok "Rollback restores api-server to byte-identical snapshot"
else
    fail "Rollback differs from snapshot:"
    echo "$DIFF_OUT" | head -8
fi
rm -rf "$ROLLBACK_DIR"

# 5e. Critic criteria count: 10 preserved + 3 added = 13 total
ORIG_CATS=$(grep -cE "^[0-9]+\. (META LANGUAGE|FOLLOWUP ACK|LANGUAGE MATCH|LANGUAGE NATURALNESS|CONCISENESS|RELEVANCE|DIFFERENTIATION|TONE|DOCTRINE COMPLIANCE|UNTRANSLITERATED GREETING NAME)" "$SNAPSHOT/api-server/services/followupPrompts.ts" || true)
# Note: the Followuper critic criteria list is in a different format. Count occurrences of "N. " at start of line
# Use a more permissive count
ORIG_CRITERIA=$(grep -cE "^[0-9]+\\. [A-Z]" "$SNAPSHOT/api-server/services/followupPrompts.ts" || true)
NEW_CRITERIA=$(grep -cE "^[0-9]+\\. [A-Z]" "$WORK/api-server/services/followupPrompts.ts" || true)
# Should add 3 net criteria (11, 12, 13)
DELTA=$((NEW_CRITERIA - ORIG_CRITERIA))
if [[ "$DELTA" == "3" ]]; then
    ok "Critic criteria: 10 preserved + 3 added = 13 total"
else
    warn "Critic criteria delta: +$DELTA (expected +3) — orig=$ORIG_CRITERIA, new=$NEW_CRITERIA"
fi

# 5f. v3 test count stable
V3_FINAL=$(npx tsx tests/test-nativeness-v3.ts 2>&1 | grep -oE "^# tests [0-9]+" | grep -oE "[0-9]+")
if [[ "$V3_FINAL" == "67" ]]; then
    ok "v3 test count stable: 67 tests"
else
    warn "v3 test count drift: $V3_FINAL"
fi


# ============================================================================
# Summary
# ============================================================================
echo
echo "================================================================"
echo "AUDIT SUMMARY"
echo "  PASS: $PASS"
echo "  FAIL: $FAIL"
echo "  WARN: $WARN"
echo "================================================================"
if [[ "$FAIL" == "0" ]]; then
    echo "Status: GO-FOR-SHIP"
    exit 0
else
    echo "Status: BLOCKED — investigate FAIL items above"
    exit 1
fi
