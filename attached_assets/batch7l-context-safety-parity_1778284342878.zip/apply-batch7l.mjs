#!/usr/bin/env node
/**
 * apply-batch7l.mjs — Phase 7l (context safety parity with doctrine).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Two gaps to close, both in routes/context.ts:
 *
 * Gap A (defense-in-depth on UPDATE WHERE clauses)
 *   Three UPDATE sites in context.ts don't gate on SCOPE in their
 *   WHERE clause. The doctrine equivalents do (e.g.,
 *   .where(and(SCOPE_DOCTRINE, eq(id, prospectId)))). Functionally
 *   safe today (prospect IDs are globally unique), but the doctrine
 *   pattern is more defensive — robust against future schema changes,
 *   ID-injection bugs, or callers bypassing the route layer.
 *   The three sites:
 *     - /prospect/:id/pause    UPDATE followup_paused=true
 *     - /prospect/:id/resume   UPDATE followup_paused=false
 *     - /prospect/pause-bulk   UPDATE followup_paused=true (bulk)
 *
 * Gap B (resume parity — immediately queue next stage)
 *   The doctrine /prospect/:id/resume re-queues stalled drafts AND,
 *   if no active follow-up exists, immediately computes the next
 *   stage and inserts it queued. The context resume only re-queues
 *   stalled drafts. Result: a resumed context campaign sits idle
 *   until the next 15-min autoQueue cron tick. Cron does eventually
 *   catch up — no data corruption — but the UX lag is real and
 *   doctrine doesn't have it.
 *
 * Files touched:
 *   - routes/context.ts: import additions + 3 UPDATE WHERE rewrites + 1 handler restructure
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src node apply-batch7l.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[apply-batch7l] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7l] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const ctxPath = join(API_BASE, "routes", "context.ts");

// ============================================================
// Step 1: Add timingEngine import for Gap B
// ============================================================
log("Step 1: Add computeNextStageScheduledAt + UserTimingSettings imports...");

strReplace(
  ctxPath,
  `import { getGmailForUser } from "../services/gmailClient";
import { logger } from "../lib/logger";`,
  `import { getGmailForUser } from "../services/gmailClient";
import { logger } from "../lib/logger";
// Phase 7l: timingEngine helpers for /prospect/:id/resume parity with doctrine.
import { computeNextStageScheduledAt } from "../services/timingEngine";
import type { UserTimingSettings } from "../services/timingEngine";`,
  "context.ts: timingEngine imports",
  `// Phase 7l: timingEngine helpers for /prospect/:id/resume parity with doctrine.`
);

// ============================================================
// Step 2: Gap A — /prospect/:id/pause UPDATE gates on SCOPE
// ============================================================
log("Step 2: Gap A — /prospect/:id/pause UPDATE → SCOPE-gated...");

strReplace(
  ctxPath,
  `    await db.update(prospectsTable).set({ followupPaused: true }).where(eq(prospectsTable.id, prospectId));

    const { cancelActiveFollowupsForProspects } = await import("../services/scheduler");`,
  `    // Phase 7l Gap A: SCOPE in WHERE makes this a single atomic op
    // that cannot affect doctrine prospects even if prospectId resolution
    // were ever bypassed. Defense-in-depth.
    await db.update(prospectsTable).set({ followupPaused: true }).where(and(SCOPE, eq(prospectsTable.id, prospectId)));

    const { cancelActiveFollowupsForProspects } = await import("../services/scheduler");`,
  "context.ts: pause UPDATE SCOPE-gated",
  `// Phase 7l Gap A: SCOPE in WHERE makes this a single atomic op`
);

// ============================================================
// Step 3: Gap A — /prospect/pause-bulk UPDATE gates on SCOPE
// ============================================================
log("Step 3: Gap A — /prospect/pause-bulk UPDATE → SCOPE-gated...");

strReplace(
  ctxPath,
  `    await db.update(prospectsTable).set({ followupPaused: true }).where(inArray(prospectsTable.id, contextIds));`,
  `    // Phase 7l Gap A: contextIds was already SCOPE-filtered by the prior SELECT,
    // so the SCOPE here is genuinely redundant — but it future-proofs against a
    // refactor that swaps contextIds for ids by accident.
    await db.update(prospectsTable).set({ followupPaused: true }).where(and(SCOPE, inArray(prospectsTable.id, contextIds)));`,
  "context.ts: pause-bulk UPDATE SCOPE-gated",
  `// Phase 7l Gap A: contextIds was already SCOPE-filtered by the prior SELECT,`
);

// ============================================================
// Step 4: Gap A + B combined — replace the entire /prospect/:id/resume handler
// ============================================================
log("Step 4: Gap A + B — /prospect/:id/resume restructured (SCOPE-gated UPDATE + immediate next-stage queue)...");

strReplace(
  ctxPath,
  `router.post("/prospect/:id/resume", async (req: Request, res: Response) => {
  const prospectId = parseInt(req.params.id);
  if (isNaN(prospectId)) { res.status(400).json({ error: "Invalid prospect ID" }); return; }

  try {
    const prospect = await loadContextProspect(prospectId);
    if (!prospect) { res.status(404).json({ error: "Context prospect not found" }); return; }
    if (prospect.replied) { res.status(400).json({ error: "Prospect already replied" }); return; }

    await db.update(prospectsTable).set({ followupPaused: false }).where(eq(prospectsTable.id, prospectId));

    const { requeueStalledDraftForProspect } = await import("../services/scheduler");
    const stalledRequeue = await requeueStalledDraftForProspect(prospectId);

    res.json({
      success: true,
      resumed: 1,
      stalled_requeued: stalledRequeue.requeued,
      stalled_stage: stalledRequeue.stage,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});`,
  `router.post("/prospect/:id/resume", async (req: Request, res: Response) => {
  const prospectId = parseInt(req.params.id);
  if (isNaN(prospectId)) { res.status(400).json({ error: "Invalid prospect ID" }); return; }

  try {
    const prospect = await loadContextProspect(prospectId);
    if (!prospect) { res.status(404).json({ error: "Context prospect not found" }); return; }
    if (prospect.replied) { res.status(400).json({ error: "Prospect already replied" }); return; }

    // Phase 7l Gap A: SCOPE-gated UPDATE for the same defense-in-depth reason
    // as /prospect/:id/pause and /prospect/pause-bulk.
    await db.update(prospectsTable).set({ followupPaused: false }).where(and(SCOPE, eq(prospectsTable.id, prospectId)));

    const { requeueStalledDraftForProspect } = await import("../services/scheduler");
    const stalledRequeue = await requeueStalledDraftForProspect(prospectId);

    // Phase 7l Gap B: parity with doctrine /prospect/:id/resume — if a stalled
    // draft was re-queued, that's the queued stage. Otherwise, if no active
    // follow-up exists, immediately compute the next stage and insert it
    // queued. Without this, a resumed context campaign sits idle until the
    // next 15-min autoQueue cron tick (cron does catch up — no data
    // corruption — but the UX lag is real).
    const user = prospect.userId
      ? (await db.select().from(usersTable).where(eq(usersTable.id, prospect.userId)).limit(1))[0]
      : null;
    const maxFollowups = getFollowupCap(user?.maxFollowups);

    const existingFollowups = await db
      .select({ stage: followupsTable.stage, status: followupsTable.status, sentAt: followupsTable.sentAt })
      .from(followupsTable)
      .where(eq(followupsTable.prospectId, prospectId));

    const sentRows = existingFollowups.filter((f) => f.status === "sent");
    const sentStages = sentRows.map((f) => f.stage);
    const activeStages = existingFollowups.filter((f) => ["queued", "generating", "pending_approval", "drafted"].includes(f.status));

    let queued_stage: number | null = null;
    if (stalledRequeue.requeued) {
      queued_stage = stalledRequeue.stage;
    } else if (activeStages.length === 0) {
      const nextStage = sentStages.length > 0 ? Math.max(...sentStages) + 1 : 1;
      if (maxFollowups === null || nextStage <= maxFollowups) {
        const userSettings: UserTimingSettings | undefined = user ? {
          stageTiming: user.stageTiming,
          draftStageTiming: user.draftStageTiming,
          sendDays: user.sendDays,
          sendHourStart: user.sendHourStart,
          sendHourEnd: user.sendHourEnd,
        } : undefined;
        const lastSentAt = sentRows.length > 0
          ? sentRows.reduce((a, b) => (a.stage > b.stage ? a : b)).sentAt
          : null;
        const scheduledAt = computeNextStageScheduledAt({
          stage: nextStage,
          initialSentAt: prospect.sentAt,
          lastFollowupSentAt: lastSentAt,
          userSettings,
          mode: user?.followupMode === "draft_in_gmail" ? "draft_in_gmail" : "auto_send",
        });

        try {
          await db.insert(followupsTable).values({
            prospectId,
            stage: nextStage,
            scheduledAt,
            status: "queued",
          });
          queued_stage = nextStage;
        } catch {
          // Race against a concurrent insert (autoQueue cron tick + this resume
          // landing within the same window) — uq_followups_prospect_stage will
          // reject the duplicate. Cron's row stands; nothing to do here.
        }
      }
    }

    res.json({
      success: true,
      resumed: 1,
      stalled_requeued: stalledRequeue.requeued,
      stalled_stage: stalledRequeue.stage,
      queued_stage,
      max_followups: maxFollowups ?? 0,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});`,
  "context.ts: /prospect/:id/resume — Gap A + B combined",
  `// Phase 7l Gap B: parity with doctrine /prospect/:id/resume — if a stalled`
);

// ============================================================
// Step 5: Self-verify
// ============================================================
log("Step 5: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Imports
expectInFile(ctxPath, `import { computeNextStageScheduledAt } from "../services/timingEngine";`, "V1 computeNextStageScheduledAt imported");
expectInFile(ctxPath, `import type { UserTimingSettings } from "../services/timingEngine";`, "V2 UserTimingSettings type imported");

// Gap A — pause
expectInFile(ctxPath, `// Phase 7l Gap A: SCOPE in WHERE makes this a single atomic op`, "V3 pause Gap A comment");
expectInFile(ctxPath, `set({ followupPaused: true }).where(and(SCOPE, eq(prospectsTable.id, prospectId)));`, "V4 pause WHERE includes SCOPE");

// Gap A — pause-bulk
expectInFile(ctxPath, `// Phase 7l Gap A: contextIds was already SCOPE-filtered by the prior SELECT,`, "V5 pause-bulk Gap A comment");
expectInFile(ctxPath, `set({ followupPaused: true }).where(and(SCOPE, inArray(prospectsTable.id, contextIds)));`, "V6 pause-bulk WHERE includes SCOPE");

// Gap A — resume (UPDATE)
expectInFile(ctxPath, `// Phase 7l Gap A: SCOPE-gated UPDATE for the same defense-in-depth reason`, "V7 resume Gap A comment");
expectInFile(ctxPath, `set({ followupPaused: false }).where(and(SCOPE, eq(prospectsTable.id, prospectId)));`, "V8 resume WHERE includes SCOPE");

// Gap B — resume queues next stage
expectInFile(ctxPath, `// Phase 7l Gap B: parity with doctrine /prospect/:id/resume`, "V9 resume Gap B comment");
expectInFile(ctxPath, `const maxFollowups = getFollowupCap(user?.maxFollowups);`, "V10 resume reads max_followups");
expectInFile(ctxPath, `const scheduledAt = computeNextStageScheduledAt({`, "V11 resume computes scheduledAt");
expectInFile(ctxPath, `queued_stage = nextStage;`, "V12 resume sets queued_stage");
expectInFile(ctxPath, `queued_stage,
      max_followups: maxFollowups ?? 0,`, "V13 resume returns queued_stage + max_followups");

// Old unconditional UPDATE patterns gone
expectNotInFile(ctxPath, `set({ followupPaused: true }).where(eq(prospectsTable.id, prospectId));`, "V14 old pause unconditional UPDATE gone");
expectNotInFile(ctxPath, `set({ followupPaused: false }).where(eq(prospectsTable.id, prospectId));`, "V15 old resume unconditional UPDATE gone");
expectNotInFile(ctxPath, `set({ followupPaused: true }).where(inArray(prospectsTable.id, contextIds));`, "V16 old pause-bulk unconditional UPDATE gone");

// Sanity: existing structure preserved
expectInFile(ctxPath, `const stalledRequeue = await requeueStalledDraftForProspect(prospectId);`, "V17 stalled re-queue path preserved");
expectInFile(ctxPath, `stalled_requeued: stalledRequeue.requeued,`, "V18 stalled_requeued response field preserved");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7l patch applied.");
log("  Gap A: 3 UPDATE WHERE clauses in routes/context.ts now gate on");
log("         SCOPE inline (defense-in-depth parity with doctrine).");
log("  Gap B: /prospect/:id/resume now immediately queues the next");
log("         stage if no active follow-up exists, matching doctrine");
log("         resume behavior. UX lag (up to 15 min) eliminated.");
log("================================================================");
