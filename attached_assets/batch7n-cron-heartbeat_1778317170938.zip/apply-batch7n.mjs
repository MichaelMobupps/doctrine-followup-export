#!/usr/bin/env node
/**
 * apply-batch7n.mjs — Phase 7n (cron heartbeat).
 *
 * Idempotent. Sentinel-based str_replace + writeFileSync for new files.
 *
 * Adds a cron_heartbeats table + recordHeartbeat helper + wraps each
 * cron tick in cron.ts with timing capture and a heartbeat write.
 * Gives ops a direct query for "did cron fire at <time>?" regardless
 * of whether the tick had work to do.
 *
 * Files created/modified:
 *   - lib/db/src/schema/cron-heartbeats.ts          (NEW)
 *   - lib/db/src/schema/index.ts                    (MODIFY: add export)
 *   - artifacts/api-server/src/lib/cronHeartbeat.ts (NEW)
 *   - artifacts/api-server/src/cron.ts              (MODIFY: import + 5 tick wraps)
 *
 * Wraps these 5 ticks:
 *   1. sync_and_autoqueue   (every 15 min)
 *   2. process_due          (at minutes 5, 20, 35, 50)
 *   3. draft_stall_watcher  (daily at 00:30 UTC)
 *   4. fast_tick            (every 3 min)
 *   5. weekly_digest        (Tuesday 00:00 UTC)
 *
 * Each wrap captures: tickName, durationMs, outcome (ok/partial/error),
 * details (counts, errors, etc). Existing logger.info calls preserved.
 *
 * Heartbeat write itself is wrapped in try/catch in the helper, so a
 * DB hiccup never propagates and kills cron work.
 *
 * IMPORTANT: a CREATE TABLE migration is also bundled. Run it once
 * before restarting api-server. Without the migration, the heartbeat
 * INSERT fails (caught silently) and the cron still works fine — but
 * no rows accumulate in cron_heartbeats.
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src DB_BASE=lib/db/src \
 *     node apply-batch7n.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join, dirname } from "path";
import { mkdirSync } from "fs";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DB_BASE  = process.env.DB_BASE  || "lib/db/src";

const log  = (msg) => console.log(`[apply-batch7n] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7n] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

function writeNewFile(path, content, label, sentinel) {
  if (!sentinel) fail(`writeNewFile called without sentinel for "${label}"`);
  if (!content.includes(sentinel)) fail(`Sentinel for "${label}" not in content`);

  if (existsSync(path)) {
    const existing = readFileSync(path, "utf-8");
    if (existing.includes(sentinel)) {
      log(`  [=] ${label} (already exists with sentinel)`);
      return "skipped";
    }
    fail(`File already exists at ${path} but sentinel absent — manual review needed`);
  }

  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content);
  log(`  [+] ${label}`);
  return "applied";
}

const schemaPath       = join(DB_BASE, "schema", "cron-heartbeats.ts");
const schemaIndexPath  = join(DB_BASE, "schema", "index.ts");
const helperPath       = join(API_BASE, "lib", "cronHeartbeat.ts");
const cronPath         = join(API_BASE, "cron.ts");

// ============================================================
// Step 1: Drizzle schema for cron_heartbeats
// ============================================================
log("Step 1: Drizzle schema (lib/db/src/schema/cron-heartbeats.ts)...");

const schemaSrc = `// Phase 7n: cron heartbeat schema.
// One row per cron tick. tickName ∈ {sync_and_autoqueue, process_due,
// draft_stall_watcher, fast_tick, weekly_digest}. outcome ∈ {ok,
// partial, error}. details holds per-tick counts/errors as jsonb.
import { pgTable, serial, text, integer, timestamp, jsonb } from "drizzle-orm/pg-core";

export const cronHeartbeatsTable = pgTable("cron_heartbeats", {
  id: serial("id").primaryKey(),
  tickName: text("tick_name").notNull(),
  firedAt: timestamp("fired_at", { withTimezone: true }).notNull().defaultNow(),
  outcome: text("outcome").notNull(),
  durationMs: integer("duration_ms").notNull().default(0),
  details: jsonb("details"),
});
`;

writeNewFile(
  schemaPath,
  schemaSrc,
  "schema/cron-heartbeats.ts",
  `// Phase 7n: cron heartbeat schema.`
);

// ============================================================
// Step 2: schema barrel exports new table
// ============================================================
log("Step 2: schema/index.ts — export cron-heartbeats...");

strReplace(
  schemaIndexPath,
  `export * from "./oauth-nonces";`,
  `export * from "./oauth-nonces";
// Phase 7n: cron heartbeat table for liveness observability.
export * from "./cron-heartbeats";`,
  "schema/index.ts: export cron-heartbeats",
  `// Phase 7n: cron heartbeat table for liveness observability.`
);

// ============================================================
// Step 3: recordHeartbeat helper
// ============================================================
log("Step 3: lib/cronHeartbeat.ts (helper)...");

const helperSrc = `// Phase 7n: recordHeartbeat helper. One row per cron tick.
// Wrapped in try/catch so a DB hiccup on heartbeat-recording can
// never kill the actual cron work — heartbeats are observability
// only.
import { db, cronHeartbeatsTable } from "@workspace/db";
import { logger } from "./logger";

export type CronOutcome = "ok" | "partial" | "error";

export async function recordHeartbeat(args: {
  tickName: string;
  durationMs: number;
  outcome: CronOutcome;
  details?: Record<string, unknown>;
}): Promise<void> {
  try {
    await db.insert(cronHeartbeatsTable).values({
      tickName: args.tickName,
      durationMs: args.durationMs,
      outcome: args.outcome,
      details: args.details ?? null,
    });
  } catch (err) {
    logger.error({ err, tickName: args.tickName }, "Failed to record cron heartbeat");
  }
}
`;

writeNewFile(
  helperPath,
  helperSrc,
  "lib/cronHeartbeat.ts",
  `// Phase 7n: recordHeartbeat helper.`
);

// ============================================================
// Step 4: cron.ts — import the helper
// ============================================================
log("Step 4: cron.ts — add recordHeartbeat import...");

strReplace(
  cronPath,
  `import { logger } from "./lib/logger";`,
  `import { logger } from "./lib/logger";
// Phase 7n: per-tick heartbeat recording for cron-firing observability.
import { recordHeartbeat } from "./lib/cronHeartbeat";`,
  "cron.ts: import recordHeartbeat",
  `// Phase 7n: per-tick heartbeat recording for cron-firing observability.`
);

// ============================================================
// Step 5: Wrap sync_and_autoqueue (every 15 min)
// ============================================================
log("Step 5: Wrap sync_and_autoqueue tick...");

strReplace(
  cronPath,
  `  // Gmail sync + auto-queue every 15 minutes.
  cron.schedule("*/15 * * * *", async () => {
    logger.info("Running Gmail sync...");
    try {
      const result = await syncEmails();
      logger.info(
        { synced: result.synced, repliesDetected: result.repliesDetected },
        "Sync done",
      );
    } catch (err) {
      logger.error({ err }, "Sync error");
    }

    try {
      const autoQueued = await autoQueueAllCampaigns();
      if (autoQueued > 0) {
        logger.info({ autoQueued }, "Auto-queued follow-up stages");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue error");
    }
  });`,
  `  // Gmail sync + auto-queue every 15 minutes.
  // Phase 7n: heartbeat tickName="sync_and_autoqueue".
  cron.schedule("*/15 * * * *", async () => {
    const startedAt = Date.now();
    let outcome: "ok" | "partial" | "error" = "ok";
    const details: Record<string, unknown> = {};
    try {
      logger.info("Running Gmail sync...");
      try {
        const result = await syncEmails();
        details.synced = result.synced;
        details.repliesDetected = result.repliesDetected;
        logger.info(
          { synced: result.synced, repliesDetected: result.repliesDetected },
          "Sync done",
        );
      } catch (err) {
        outcome = "partial";
        details.syncError = err instanceof Error ? err.message : String(err);
        logger.error({ err }, "Sync error");
      }

      try {
        const autoQueued = await autoQueueAllCampaigns();
        details.autoQueued = autoQueued;
        if (autoQueued > 0) {
          logger.info({ autoQueued }, "Auto-queued follow-up stages");
        }
      } catch (err) {
        outcome = "partial";
        details.autoQueueError = err instanceof Error ? err.message : String(err);
        logger.error({ err }, "Auto-queue error");
      }
    } catch (err) {
      outcome = "error";
      details.wrapperError = err instanceof Error ? err.message : String(err);
      logger.error({ err }, "sync_and_autoqueue wrapper error");
    } finally {
      await recordHeartbeat({
        tickName: "sync_and_autoqueue",
        durationMs: Date.now() - startedAt,
        outcome,
        details,
      });
    }
  });`,
  "cron.ts: wrap sync_and_autoqueue",
  `// Phase 7n: heartbeat tickName="sync_and_autoqueue".`
);

// ============================================================
// Step 6: Wrap process_due (5, 20, 35, 50)
// ============================================================
log("Step 6: Wrap process_due tick...");

strReplace(
  cronPath,
  `  // Process due follow-ups four times per hour on the main tick.
  cron.schedule("5,20,35,50 * * * *", async () => {
    logger.info("Processing due follow-ups...");
    try {
      const result = await processDueFollowups();
      logger.info(
        { sent: result.sent, drafted: result.drafted, failed: result.failed },
        "Follow-up processing done",
      );
    } catch (err) {
      logger.error({ err }, "Scheduler error");
    }
  });`,
  `  // Process due follow-ups four times per hour on the main tick.
  // Phase 7n: heartbeat tickName="process_due".
  cron.schedule("5,20,35,50 * * * *", async () => {
    const startedAt = Date.now();
    let outcome: "ok" | "partial" | "error" = "ok";
    const details: Record<string, unknown> = {};
    try {
      logger.info("Processing due follow-ups...");
      const result = await processDueFollowups();
      details.processed = result.processed;
      details.sent = result.sent;
      details.drafted = result.drafted;
      details.failed = result.failed;
      logger.info(
        { sent: result.sent, drafted: result.drafted, failed: result.failed },
        "Follow-up processing done",
      );
    } catch (err) {
      outcome = "error";
      details.error = err instanceof Error ? err.message : String(err);
      logger.error({ err }, "Scheduler error");
    } finally {
      await recordHeartbeat({
        tickName: "process_due",
        durationMs: Date.now() - startedAt,
        outcome,
        details,
      });
    }
  });`,
  "cron.ts: wrap process_due",
  `// Phase 7n: heartbeat tickName="process_due".`
);

// ============================================================
// Step 7: Wrap draft_stall_watcher (daily 00:30)
// ============================================================
log("Step 7: Wrap draft_stall_watcher tick...");

strReplace(
  cronPath,
  `  // Daily stall watcher: draft-mode follow-ups that sit unsent for 30 days
  // pause the prospect and move the row to stalled_awaiting_manual_send.
  cron.schedule("30 0 * * *", async () => {
    logger.info("Running draft-mode stall watcher...");
    try {
      const stalled = await stallDraftedFollowups();
      if (stalled > 0) {
        logger.info({ stalled }, "Stalled stale Gmail draft follow-ups");
      }
    } catch (err) {
      logger.error({ err }, "Draft stall watcher error");
    }
  });`,
  `  // Daily stall watcher: draft-mode follow-ups that sit unsent for 30 days
  // pause the prospect and move the row to stalled_awaiting_manual_send.
  // Phase 7n: heartbeat tickName="draft_stall_watcher".
  cron.schedule("30 0 * * *", async () => {
    const startedAt = Date.now();
    let outcome: "ok" | "partial" | "error" = "ok";
    const details: Record<string, unknown> = {};
    try {
      logger.info("Running draft-mode stall watcher...");
      const stalled = await stallDraftedFollowups();
      details.stalled = stalled;
      if (stalled > 0) {
        logger.info({ stalled }, "Stalled stale Gmail draft follow-ups");
      }
    } catch (err) {
      outcome = "error";
      details.error = err instanceof Error ? err.message : String(err);
      logger.error({ err }, "Draft stall watcher error");
    } finally {
      await recordHeartbeat({
        tickName: "draft_stall_watcher",
        durationMs: Date.now() - startedAt,
        outcome,
        details,
      });
    }
  });`,
  "cron.ts: wrap draft_stall_watcher",
  `// Phase 7n: heartbeat tickName="draft_stall_watcher".`
);

// ============================================================
// Step 8: Wrap fast_tick (every 3 min)
// ============================================================
log("Step 8: Wrap fast_tick...");

strReplace(
  cronPath,
  `  cron.schedule("*/3 * * * *", async () => {
    try {
      const result = await processDueFollowups();
      if (result.sent > 0 || result.drafted > 0 || result.processed > 0) {
        logger.info(
          { sent: result.sent, drafted: result.drafted, failed: result.failed },
          "Fast-tick processed follow-ups",
        );
      }
    } catch (err) {
      logger.error({ err }, "Fast-tick error");
    }
  });`,
  `  // Phase 7n: heartbeat tickName="fast_tick".
  cron.schedule("*/3 * * * *", async () => {
    const startedAt = Date.now();
    let outcome: "ok" | "partial" | "error" = "ok";
    const details: Record<string, unknown> = {};
    try {
      const result = await processDueFollowups();
      details.processed = result.processed;
      details.sent = result.sent;
      details.drafted = result.drafted;
      details.failed = result.failed;
      if (result.sent > 0 || result.drafted > 0 || result.processed > 0) {
        logger.info(
          { sent: result.sent, drafted: result.drafted, failed: result.failed },
          "Fast-tick processed follow-ups",
        );
      }
    } catch (err) {
      outcome = "error";
      details.error = err instanceof Error ? err.message : String(err);
      logger.error({ err }, "Fast-tick error");
    } finally {
      await recordHeartbeat({
        tickName: "fast_tick",
        durationMs: Date.now() - startedAt,
        outcome,
        details,
      });
    }
  });`,
  "cron.ts: wrap fast_tick",
  `// Phase 7n: heartbeat tickName="fast_tick".`
);

// ============================================================
// Step 9: Wrap weekly_digest (Tue 00:00 UTC)
// ============================================================
log("Step 9: Wrap weekly_digest tick...");

strReplace(
  cronPath,
  `  cron.schedule("0 0 * * 2", async () => {
    logger.info("Running weekly digest...");
    try {
      const result = await runWeeklyDigest();
      logger.info(
        { considered: result.considered, sent: result.sent, skipped: result.skipped, failed: result.failed },
        "Weekly digest done",
      );
    } catch (err) {
      logger.error({ err }, "Weekly digest error");
    }
  }, { timezone: "UTC" });`,
  `  // Phase 7n: heartbeat tickName="weekly_digest".
  cron.schedule("0 0 * * 2", async () => {
    const startedAt = Date.now();
    let outcome: "ok" | "partial" | "error" = "ok";
    const details: Record<string, unknown> = {};
    try {
      logger.info("Running weekly digest...");
      const result = await runWeeklyDigest();
      details.considered = result.considered;
      details.sent = result.sent;
      details.skipped = result.skipped;
      details.failed = result.failed;
      logger.info(
        { considered: result.considered, sent: result.sent, skipped: result.skipped, failed: result.failed },
        "Weekly digest done",
      );
    } catch (err) {
      outcome = "error";
      details.error = err instanceof Error ? err.message : String(err);
      logger.error({ err }, "Weekly digest error");
    } finally {
      await recordHeartbeat({
        tickName: "weekly_digest",
        durationMs: Date.now() - startedAt,
        outcome,
        details,
      });
    }
  }, { timezone: "UTC" });`,
  "cron.ts: wrap weekly_digest",
  `// Phase 7n: heartbeat tickName="weekly_digest".`
);

// ============================================================
// Step 10: Self-verify
// ============================================================
log("Step 10: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

// Schema
expectInFile(schemaPath, `// Phase 7n: cron heartbeat schema.`, "V1 schema file header");
expectInFile(schemaPath, `export const cronHeartbeatsTable = pgTable("cron_heartbeats"`, "V2 cronHeartbeatsTable export");
expectInFile(schemaPath, `tickName: text("tick_name").notNull(),`, "V3 tick_name column");
expectInFile(schemaPath, `firedAt: timestamp("fired_at", { withTimezone: true }).notNull().defaultNow(),`, "V4 fired_at column");
expectInFile(schemaPath, `details: jsonb("details"),`, "V5 details column");

// Schema barrel
expectInFile(schemaIndexPath, `export * from "./cron-heartbeats";`, "V6 schema barrel exports cron-heartbeats");

// Helper
expectInFile(helperPath, `// Phase 7n: recordHeartbeat helper.`, "V7 helper header");
expectInFile(helperPath, `export async function recordHeartbeat(args: {`, "V8 recordHeartbeat exported");
expectInFile(helperPath, `await db.insert(cronHeartbeatsTable).values({`, "V9 helper inserts into cronHeartbeatsTable");
expectInFile(helperPath, `} catch (err) {`, "V10 helper catches errors");

// cron.ts import + wraps
expectInFile(cronPath, `import { recordHeartbeat } from "./lib/cronHeartbeat";`, "V11 cron.ts imports recordHeartbeat");
expectInFile(cronPath, `tickName: "sync_and_autoqueue",`, "V12 sync_and_autoqueue heartbeat");
expectInFile(cronPath, `tickName: "process_due",`, "V13 process_due heartbeat");
expectInFile(cronPath, `tickName: "draft_stall_watcher",`, "V14 draft_stall_watcher heartbeat");
expectInFile(cronPath, `tickName: "fast_tick",`, "V15 fast_tick heartbeat");
expectInFile(cronPath, `tickName: "weekly_digest",`, "V16 weekly_digest heartbeat");

// Each wrap captures startedAt
{
  const src = readFileOrFail(cronPath);
  const startedAtCount = (src.match(/const startedAt = Date\.now\(\);/g) || []).length;
  if (startedAtCount !== 5) fail(`V17 expected 5 startedAt captures, got ${startedAtCount}`);
  log(`  [OK] V17 startedAt captured in all 5 ticks (${startedAtCount} occurrences)`);

  const recordCount = (src.match(/await recordHeartbeat\(\{/g) || []).length;
  if (recordCount !== 5) fail(`V18 expected 5 recordHeartbeat calls, got ${recordCount}`);
  log(`  [OK] V18 recordHeartbeat called in all 5 ticks (${recordCount} occurrences)`);

  const finallyCount = (src.match(/\} finally \{/g) || []).length;
  if (finallyCount !== 5) fail(`V19 expected 5 finally blocks, got ${finallyCount}`);
  log(`  [OK] V19 finally block in all 5 ticks (${finallyCount} occurrences)`);
}

// Existing logic preserved
expectInFile(cronPath, `await syncEmails();`, "V20 syncEmails call preserved");
expectInFile(cronPath, `await autoQueueAllCampaigns();`, "V21 autoQueueAllCampaigns call preserved");
expectInFile(cronPath, `await stallDraftedFollowups();`, "V22 stallDraftedFollowups call preserved");
expectInFile(cronPath, `await runWeeklyDigest();`, "V23 runWeeklyDigest call preserved");
expectInFile(cronPath, `Cron jobs active:`, "V24 boot log preserved");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7n patch applied.");
log("");
log("REMAINING STEP: run the migration SQL once before restart:");
log("  psql \\\"$DATABASE_URL\\\" -f migrate-batch7n.sql");
log("");
log("After that, every cron tick writes one row to cron_heartbeats.");
log("Query liveness: SELECT tick_name, fired_at, outcome, details");
log("                FROM cron_heartbeats");
log("                ORDER BY fired_at DESC LIMIT 20;");
log("================================================================");
