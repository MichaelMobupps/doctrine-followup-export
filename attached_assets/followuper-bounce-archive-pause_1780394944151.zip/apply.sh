#!/usr/bin/env bash
# =====================================================================
# apply.sh — Bounce auto-pause + global pause + 14-day archival
# Doctrine Follow-up app. Run from the Replit shell:
#
#     bash apply.sh
#
# Expects apply.sh and payload.zip to sit in the same directory (the
# Replit workspace root). Order: unzip -> backup -> copy -> typecheck
# gate -> tests gate -> build -> mirror -> success. Halts on any gate
# failure and leaves a backup with restore instructions.
#
# Restart + Republish are a SEPARATE step after this script succeeds.
# =====================================================================

WORKSPACE="${WORKSPACE:-/home/runner/workspace}"
HERE="$(cd "$(dirname "$0")" && pwd)"
STAGE="$HERE/_apply_staging"
STAMP="$(date '+%Y%m%d-%H%M%S')"
BACKUP="$WORKSPACE/_apply_backup_$STAMP"

halt() {
  echo ""
  echo "HALTED: $1"
  echo "No mirror ran. Source files in artifacts/ and lib/ were already copied."
  echo "To restore the pre-apply versions:"
  echo "    cp -rf \"$BACKUP\"/* \"$WORKSPACE\"/"
  echo "Backup kept at: $BACKUP"
  exit 1
}

echo "==> Workspace: $WORKSPACE"
[ -d "$WORKSPACE" ] || { echo "Workspace not found: $WORKSPACE"; exit 1; }
[ -f "$HERE/payload.zip" ] || { echo "payload.zip not found next to apply.sh"; exit 1; }

# 1. Unzip payload via python zipfile (no unzip binary assumed).
echo "==> 1/7 Unzipping payload"
rm -rf "$STAGE"
mkdir -p "$STAGE"
python3 -c "import zipfile; zipfile.ZipFile('$HERE/payload.zip').extractall('$STAGE')" \
  || { echo "Unzip failed"; exit 1; }

# Build the list of destination relpaths from the staging tree.
RELPATHS="$(cd "$STAGE" && find . -type f | sed 's|^\./||')"
echo "    $(echo "$RELPATHS" | wc -l) files staged"

# 2. Backup existing targets (preserving paths).
echo "==> 2/7 Backing up current targets to $BACKUP"
mkdir -p "$BACKUP"
while IFS= read -r rel; do
  src="$WORKSPACE/$rel"
  if [ -f "$src" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -f "$src" "$BACKUP/$rel"
  fi
done <<< "$RELPATHS"

# 3. Copy staged files into the workspace (explicit cp per file).
echo "==> 3/7 Copying files into workspace"
while IFS= read -r rel; do
  mkdir -p "$WORKSPACE/$(dirname "$rel")"
  cp -f "$STAGE/$rel" "$WORKSPACE/$rel"
  echo "    + $rel"
done <<< "$RELPATHS"

cd "$WORKSPACE"

# 4. Typecheck gate (api-server tsc -b, then dashboard tsc --noEmit).
echo "==> 4/7 Typecheck gate: api-server"
pnpm --filter @workspace/api-server run typecheck || halt "api-server typecheck failed"
echo "==> 4/7 Typecheck gate: dashboard"
pnpm --filter @workspace/dashboard run typecheck || halt "dashboard typecheck failed"

# 5. Tests gate (Node test runner via tsx over the whole tests dir).
echo "==> 5/7 Tests gate: api-server"
pnpm --filter @workspace/api-server exec tsx --test tests/*.ts 2>&1 | tail -20
TEST_RC="${PIPESTATUS[0]}"
[ "$TEST_RC" = "0" ] || halt "tests failed (rc=$TEST_RC)"

# 6. Build (dashboard first so the SPA is rebuilt, then api-server bundle).
echo "==> 6/7 Build: dashboard"
pnpm --filter @workspace/dashboard run build || halt "dashboard build failed"
echo "==> 6/7 Build: api-server"
pnpm --filter @workspace/api-server run build || halt "api-server build failed"

# 7. Mirror artifacts -> source-code (only after all gates pass).
echo "==> 7/7 Mirror: source-code/sync.sh"
bash "$WORKSPACE/source-code/sync.sh" || echo "WARNING: sync.sh returned non-zero (mirror only; deploy is unaffected)"

echo ""
echo "SUCCESS. All gates passed and the mirror is refreshed."
echo "Backup of the previous files is at: $BACKUP"
echo ""
echo "NEXT (separate step): Restart the workflow, then Republish the deployment."
