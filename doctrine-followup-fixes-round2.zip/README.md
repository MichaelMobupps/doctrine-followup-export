# Doctrine Follow-up — round 2 (critic fallback, auto-pause sweeps, cleanup)

Apply this **after** round 1 (it stacks on top of those changes). Same runner.

## Run it (Replit)

```bash
cd /home/runner/workspace && rm -rf _fixes2 && python3 -c "import zipfile; zipfile.ZipFile('doctrine-followup-fixes-round2.zip').extractall('_fixes2')" && bash _fixes2/apply-fixes.sh --dry-run
```

If the dry run reports both patches `APPLICABLE`, apply for real:

```bash
cd /home/runner/workspace && bash _fixes2/apply-fixes.sh
```

`--no-gates` to skip typecheck/test/build. Idempotent; all-or-nothing preflight;
applies from the workspace root (repo-safe).

## What's in it

1. **Critic provider reengineered — Gemini default, smart Sonnet fallback, no
   parallel.** `CRITIC_PROVIDER` now defaults to `gemini`. The doctrine critic
   runs on Gemini; if Gemini is at full capacity or unavailable it falls back to
   Sonnet **for that draft only** — never both, never in parallel (the old
   `shadow` mode is removed). A **circuit breaker** (3 consecutive Gemini
   failures → open 60s → one probe → close on success) means a Gemini outage
   routes straight to Sonnet instead of stalling every draft on Gemini's own
   retry budget. `CRITIC_PROVIDER=anthropic` is kept as an escape hatch to force
   Sonnet only. New hermetic test `test-circuit-breaker.ts` (5 cases).
   - Note: this governs the **doctrine** critic (the highest-volume one).
     Context and anti-ghosting critics already run on Sonnet directly.

2. **Auto-pause sweeps — "more than 3 follow-ups OR older than 30 days, any
   user."** The 30-day sweep already existed (`campaign_expired_30d`, daily
   00:15). Added a companion **over-cap sweep** (daily 00:20,
   `pause_reason='over_followup_cap'`) that pauses any active campaign which has
   already **sent** more follow-ups than the cap. It is **cycle-aware**: it
   flags a campaign only if a single cycle exceeded the cap, so anti-ghosting
   renewals (which re-use stage numbers across cycles) are not falsely paused.
   Both sweeps backfill the existing backlog on their first daily run.

3. **Pipeline now shows WHY a campaign is paused.** Instead of a generic
   "Paused", the row reads "Paused — expired (30d)", "Paused — over 3-follow-up
   cap", "Paused — killed", or "Paused — company replied". This is how you spot
   which old campaigns the sweeps stopped, at a glance.

4. **Data cleanup.** A startup migration clamps stored `users.max_followups`
   into 1–3 (`UPDATE ... WHERE max_followups > 3 OR < 1`), so the stored data
   matches the cap instead of relying on read-time clamping. Idempotent.

## Files

Modified (6): `services/criticProvider.ts`, `services/scheduler.ts`, `cron.ts`,
`lib/startupMigrations.ts`, `scripts/smoke-critic.ts`, `dashboard/pages/pipeline.tsx`.

New (2): `api-server/lib/circuitBreaker.ts`, `api-server/tests/test-circuit-breaker.ts`.

## Operational notes

- After applying + restart, the over-cap and 30-day sweeps run in the daily
  00:15–00:20 UTC window and pause the backlog. To pause the backlog sooner you
  can wait for that window, or ask and I'll add an admin "run sweeps now" button.
- Confirm `GEMINI_API_KEY` is set (it is, per your activity log). If it weren't,
  the critic would safely fall back to Sonnet.
- The active-first sort, COMPANY filter, and company-kill remain doctrine-only
  (round 1). Say the word to port them to context / anti-ghosting pipelines.
