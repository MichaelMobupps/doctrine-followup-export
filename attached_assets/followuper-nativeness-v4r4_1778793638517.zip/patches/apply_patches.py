#!/usr/bin/env python3
"""
apply_patches.py — Followuper v4 Round-4 (verb-fronted lead-with detector).

TypeScript twin of Prospector v4 Round-4. Adds the VERB-FRONTED-LEAD-WITH
detector to nativenessV4.ts, closing the gap exposed by Denise's XP
feedback.

Operations:
  1. NewFile api-server/tests/test-nativeness-v4-round4.ts
  2. Patch nativenessV4.ts: insert constant + function before findAllNativenessViolationsV4
  3. Patch nativenessV4.ts: add verb_fronted_lead_with field to NativenessV4Report interface
  4. Patch nativenessV4.ts: wire into findAllNativenessViolationsV4 return
  5. Patch nativenessV4.ts: wire into hasAnyViolationV4
"""

import shutil
import sys
from pathlib import Path


class Op:
    def __init__(self, name, path):
        self.name = name
        self.path = path
    def apply(self, root): raise NotImplementedError


class NewFile(Op):
    def __init__(self, name, path, content):
        super().__init__(name, path)
        self.content = content

    def apply(self, root):
        target = root / self.path
        if target.exists():
            existing = target.read_text(encoding="utf-8")
            if existing == self.content:
                return ("SKIP", f"{self.path} already installed (byte-identical)")
            return ("FAIL", f"{self.path} exists but differs from payload")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(self.content, encoding="utf-8")
        return ("OK", f"{self.path} installed ({len(self.content)} bytes)")


class Patch(Op):
    def __init__(self, name, path, anchor, marker, new_text, expected_count=1):
        super().__init__(name, path)
        self.anchor = anchor
        self.marker = marker
        self.new_text = new_text
        self.expected_count = expected_count

    def apply(self, root):
        target = root / self.path
        if not target.exists():
            return ("FAIL", f"{self.path} not found")
        text = target.read_text(encoding="utf-8")
        actual = text.count(self.marker)
        if actual >= self.expected_count:
            return ("SKIP", f"{self.path}: marker present {actual}x (>= {self.expected_count})")
        if self.anchor not in text:
            return ("FAIL", f"{self.path}: anchor not found AND marker count {actual} < {self.expected_count}")
        backup = target.with_suffix(target.suffix + ".v4r4_backup")
        if not backup.exists():
            shutil.copy2(target, backup)
        new_text = text.replace(self.anchor, self.new_text, 1)
        target.write_text(new_text, encoding="utf-8")
        return ("OK", f"{self.path}: anchor patched (marker now {new_text.count(self.marker)}x)")


SCRIPT_DIR = Path(__file__).resolve().parent
PAYLOAD_DIR = SCRIPT_DIR.parent
_TEST_FILE = (PAYLOAD_DIR / "api-server" / "tests" / "test-nativeness-v4-round4.ts").read_text(encoding="utf-8")
_AUTOFIX_SRC = (PAYLOAD_DIR / "api-server" / "lib" / "discourseMarkerAutofix.ts").read_text(encoding="utf-8")
_AUTOFIX_TEST = (PAYLOAD_DIR / "api-server" / "tests" / "test-discourse-autofix-v4r4.ts").read_text(encoding="utf-8")


# ============================================================================
# Op 2 — Insert detector block before findAllNativenessViolationsV4
# ============================================================================

DETECTOR_ANCHOR = """export function findAllNativenessViolationsV4("""

DETECTOR_NEW = """// ============================================================================
// v4 Round-4: VERB-FRONTED LEAD-WITH DETECTOR
// ============================================================================
// Catches "X lead with A, B, C" where X is a creative/strategy noun. This is
// a verb-fronted English calque that LLMs reliably produce when translating
// business copy. Native business writers delay the lead-verb to AFTER the
// description ("Creatives like X, Y, Z would lead the strategy").
//
// Coverage: EN, PT, PT-BR, ES, FR, IT. DE/JA/ZH/KO have different word order
// so the pattern does not transfer cleanly.

export const VERB_FRONTED_LEAD_WITH_PATTERNS: Record<string, RegExp[]> = {
  en: [
    /\\b(creatives?|ads?|ad\\s+sets?|campaigns?|assets?|strategy|strategies|concepts?|content|messaging|creative\\s+pods?)\\b(?:\\s+\\w+){0,3}\\s+(?:would\\s+|will\\s+|could\\s+|should\\s+|might\\s+)?(?:lead|leads|leading|led)\\s+with\\b[^.\\n]{0,80},[^.\\n]{0,80}[,.]/gi,
  ],
  pt: [
    /\\b(criativos?|an[uú]ncios?|estrat[eé]gias?|campanhas?|conceitos?|conte[uú]dos?|pe[cç]as?)\\b(?:\\s+\\w+){0,3}\\s+(?:lideraria(?:m)?|lideram?|liderar[aá](?:o|i?am)?|vai[oõ]?\\s+liderar|v[ãa]o\\s+liderar)\\s+com\\b[^.\\n]{0,80},[^.\\n]{0,80}/gi,
  ],
  es: [
    /\\b(creativos?|anuncios?|estrategias?|campa[ñn]as?|conceptos?|contenidos?|piezas?)\\b(?:\\s+\\w+){0,3}\\s+(?:liderar[ií]a(?:n)?|lidera(?:n|r[aá]n)?|liderar[aá](?:n)?)\\s+con\\b[^.\\n]{0,80},[^.\\n]{0,80}/gi,
  ],
  fr: [
    /\\b(cr[eé]atifs?|annonces?|strat[eé]gies?|campagnes?|concepts?|contenus?)\\b(?:\\s+\\w+){0,3}\\s+(?:m[eè]ner(?:ait|aient|ont|a)?|m[eè]nent|conduisent|dirigent)\\s+avec\\b[^.\\n]{0,80},[^.\\n]{0,80}/gi,
  ],
  it: [
    /\\b(creativi|annunci|strategie|campagne|concetti|contenuti)\\b(?:\\s+\\w+){0,3}\\s+(?:guidereb(?:be|bero)|guidano|guideranno|conducono)\\s+con\\b[^.\\n]{0,80},[^.\\n]{0,80}/gi,
  ],
};
// pt-BR shares pt patterns
VERB_FRONTED_LEAD_WITH_PATTERNS["pt-BR"] = VERB_FRONTED_LEAD_WITH_PATTERNS["pt"];


export function findVerbFrontedLeadWith(text: string, lang: string): string[] {
  if (!text) return [];
  const langN = normalizeLanguageCode(lang);
  let patterns = VERB_FRONTED_LEAD_WITH_PATTERNS[langN];
  if (!patterns) {
    const base = langN.includes("-") ? langN.split("-")[0] : langN;
    patterns = VERB_FRONTED_LEAD_WITH_PATTERNS[base];
  }
  if (!patterns) return [];
  const seen: string[] = [];
  for (const pat of patterns) {
    pat.lastIndex = 0;
    let m: RegExpExecArray | null;
    while ((m = pat.exec(text)) !== null) {
      let phrase = m[0].trim();
      if (phrase.length > 200) phrase = phrase.substring(0, 200) + "...";
      if (!seen.includes(phrase)) seen.push(phrase);
      // Guard against zero-length matches
      if (m.index === pat.lastIndex) pat.lastIndex++;
    }
  }
  return seen;
}


export function findAllNativenessViolationsV4("""

DETECTOR_MARKER = "v4 Round-4: VERB-FRONTED LEAD-WITH DETECTOR"


# ============================================================================
# Op 3 — Add field to NativenessV4Report interface
# ============================================================================

INTERFACE_ANCHOR = """  non_reflexive_romance_verbs: NonReflexiveHit[];
}"""

INTERFACE_NEW = """  non_reflexive_romance_verbs: NonReflexiveHit[];
  // v4 Round-4 detector
  verb_fronted_lead_with: string[];
}"""

INTERFACE_MARKER = "// v4 Round-4 detector\n  verb_fronted_lead_with"


# ============================================================================
# Op 4 — Wire into findAllNativenessViolationsV4 return
# ============================================================================

RETURN_ANCHOR = """    non_reflexive_romance_verbs: findNonReflexiveRomanceVerbs(text, lang),
  };
}"""

RETURN_NEW = """    non_reflexive_romance_verbs: findNonReflexiveRomanceVerbs(text, lang),
    // v4 Round-4 detector
    verb_fronted_lead_with: findVerbFrontedLeadWith(text, lang),
  };
}"""

RETURN_MARKER = "// v4 Round-4 detector\n    verb_fronted_lead_with: findVerbFrontedLeadWith"


# ============================================================================
# Op 5 — Wire into hasAnyViolationV4
# ============================================================================

VIOL_ANCHOR = """  if (report.non_reflexive_romance_verbs.length > 0) return true;
  return false;
}"""

VIOL_NEW = """  if (report.non_reflexive_romance_verbs.length > 0) return true;
  // v4 Round-4
  if (report.verb_fronted_lead_with.length > 0) return true;
  return false;
}"""

VIOL_MARKER = "// v4 Round-4\n  if (report.verb_fronted_lead_with"


# ============================================================================
# Op 6 — Extend v4 baseline test's expected-keys list to include verb_fronted_lead_with
# ============================================================================

TEST_ANCHOR = """  const expected = [
    "forbidden_phrases", "forbidden_singletons", "greeting_name_adaptation",
    "latin_token_runs",
    // v4 Round-2 keys
    "non_reflexive_romance_verbs", "repeating_discourse_markers",
    "semicolon_no_connector",
    "translationese", "untransliterated_greeting_name", "x_not_y",
  ];"""

TEST_NEW = """  const expected = [
    "forbidden_phrases", "forbidden_singletons", "greeting_name_adaptation",
    "latin_token_runs",
    // v4 Round-2 keys
    "non_reflexive_romance_verbs", "repeating_discourse_markers",
    "semicolon_no_connector",
    "translationese", "untransliterated_greeting_name",
    // v4 Round-4 key
    "verb_fronted_lead_with",
    "x_not_y",
  ];"""

TEST_MARKER = '"verb_fronted_lead_with",'


OPS = [
    NewFile(
        name="install discourseMarkerAutofix.ts module",
        path="api-server/lib/discourseMarkerAutofix.ts",
        content=_AUTOFIX_SRC,
    ),
    NewFile(
        name="install discourse autofix test suite",
        path="api-server/tests/test-discourse-autofix-v4r4.ts",
        content=_AUTOFIX_TEST,
    ),
    NewFile(
        name="install v4r4 test suite",
        path="api-server/tests/test-nativeness-v4-round4.ts",
        content=_TEST_FILE,
    ),
    Patch(
        name="nativenessV4: install VERB-FRONTED-LEAD-WITH detector block",
        path="api-server/lib/nativenessV4.ts",
        anchor=DETECTOR_ANCHOR,
        marker=DETECTOR_MARKER,
        new_text=DETECTOR_NEW,
    ),
    Patch(
        name="nativenessV4: extend NativenessV4Report interface",
        path="api-server/lib/nativenessV4.ts",
        anchor=INTERFACE_ANCHOR,
        marker=INTERFACE_MARKER,
        new_text=INTERFACE_NEW,
    ),
    Patch(
        name="nativenessV4: wire detector into report return",
        path="api-server/lib/nativenessV4.ts",
        anchor=RETURN_ANCHOR,
        marker=RETURN_MARKER,
        new_text=RETURN_NEW,
    ),
    Patch(
        name="nativenessV4: wire detector into hasAnyViolationV4",
        path="api-server/lib/nativenessV4.ts",
        anchor=VIOL_ANCHOR,
        marker=VIOL_MARKER,
        new_text=VIOL_NEW,
    ),
    Patch(
        name="test-nativeness-v4: extend expected-keys list for v4r4 key",
        path="api-server/tests/test-nativeness-v4.ts",
        anchor=TEST_ANCHOR,
        marker=TEST_MARKER,
        new_text=TEST_NEW,
    ),
]


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    print(f"Followuper v4 Round-4 — applying {len(OPS)} operations")
    print(f"Target root: {root}\n")
    counts = {"OK": 0, "SKIP": 0, "FAIL": 0}
    for op in OPS:
        try:
            status, msg = op.apply(root)
        except Exception as exc:
            status, msg = ("FAIL", f"{type(exc).__name__}: {exc}")
        counts[status] = counts.get(status, 0) + 1
        sigil = {"OK": "  OK  ", "SKIP": " SKIP ", "FAIL": " FAIL "}[status]
        print(f"[{sigil}] {op.name}")
        print(f"         {msg}")
    print(f"\nSummary: {counts['OK']} OK, {counts['SKIP']} SKIP, {counts['FAIL']} FAIL")
    if counts["FAIL"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
