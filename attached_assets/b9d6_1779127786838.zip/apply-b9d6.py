#!/usr/bin/env python3
"""
B9d.6 - Card hover lift + Modal spring physics + bigger radii.

Two anchors, both in components/ui.tsx:

  A1: Card component
        - rounded-lg \u2192 rounded-xl (12px radius, modern fintech feel)
        - subtle hover lift: -1px translate + shadow-sm \u2192 shadow-md
        - 300ms ease-out transition for natural motion
        - lift is conservative so static info-cards don't feel oddly
          interactive, but visible on hover

  A2: Modal entrance/exit
        - rounded-lg \u2192 rounded-xl (matches Card)
        - linear duration:0.15 \u2192 spring physics (stiffness 350, damping 28)
        - adds scale 0.96 \u2192 1 on entrance (subtle pop)
        - keeps existing opacity + y translate motion

No new dependencies. Pure framer-motion (already imported) + Tailwind.
Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: Card - bigger radius + hover lift
# Anchor on the post-B9d.3 Card definition (with shadow-sm).
# ====================================================================
A1_OLD = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("rounded-lg shadow-sm", className)}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...props}
  />
);'''

A1_NEW = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + always-on subtle hover lift for modern fintech feel.
export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "rounded-xl shadow-sm",
      "transition-[transform,box-shadow] duration-300 ease-out",
      "hover:shadow-md hover:-translate-y-px",
      className
    )}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...props}
  />
);'''


# ====================================================================
# A2: Modal entrance/exit - spring physics + scale-in + rounded-xl
# Anchor on the existing motion.div block for the modal content panel.
# ====================================================================
A2_OLD = '''            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.15 }}
              className="w-full max-w-lg overflow-hidden rounded-lg p-5 pointer-events-auto"'''

A2_NEW = '''            {/* B9d.6: spring physics + scale-in for premium modal entrance */}
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 10 }}
              transition={{ type: "spring", stiffness: 350, damping: 28 }}
              className="w-full max-w-lg overflow-hidden rounded-xl p-5 pointer-events-auto"'''


def main():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: Card rounded-xl + hover lift",
        marker="B9d.6: rounded-xl + always-on subtle hover lift",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: Modal spring physics + scale-in",
        marker="B9d.6: spring physics + scale-in",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")

    print()
    print("B9d.6 card lift + modal spring applied.")


if __name__ == "__main__":
    main()
