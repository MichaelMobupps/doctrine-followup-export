#!/usr/bin/env node
/**
 * audit-batch7g.mjs — Beautiful-Squidward audit for Phase 7g.
 * 3 rounds × 9 passes per round. Backend only.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DB_BASE  = process.env.DB_BASE  || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7g] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7g] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const inspectorRouteSrc = read(join(API_BASE, "routes", "email-inspector.ts"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: imports for inspector
  log(`-- PASS 1: imports --`);
  pass(`googleapis import`, /import \{ google, gmail_v1 \} from "googleapis";/.test(ctxRouteSrc));
  pass(`getGmailForUser import`, /import \{ getGmailForUser \} from "\.\.\/services\/gmailClient";/.test(ctxRouteSrc));
  pass(`Phase 7g imports comment`, /Phase 7g: googleapis \+ getGmailForUser imports for \/gmail\/sent-emails\./.test(ctxRouteSrc));

  // PASS 2: inlined helpers
  log(`-- PASS 2: helpers --`);
  pass(`getLegacyGmail signature`, /function getLegacyGmail\(\): gmail_v1\.Gmail \{/.test(ctxRouteSrc));
  pass(`getLegacyGmail uses GOOGLE_REFRESH_TOKEN`, /auth\.setCredentials\(\{ refresh_token: process\.env\.GOOGLE_REFRESH_TOKEN \}\);/.test(ctxRouteSrc));
  pass(`getGmailForRequest signature`, /async function getGmailForRequest\(req: Request\): Promise<\{ gmail: gmail_v1\.Gmail; senderEmail: string \}>/.test(ctxRouteSrc));
  pass(`getGmailForRequest uses isConnected`, /users\[0\]\.googleRefreshToken && users\[0\]\.isConnected/.test(ctxRouteSrc));
  pass(`extractEmail helper`, /function extractEmail\(headerValue: string\): string \{/.test(ctxRouteSrc));
  pass(`extractName helper`, /function extractName\(headerValue: string\): string \{/.test(ctxRouteSrc));
  pass(`isWithinSyncWindow helper`, /function isWithinSyncWindow\(timestamp: number\): boolean \{/.test(ctxRouteSrc));
  pass(`60-day window literal`, /sixtyDaysAgo\.setDate\(sixtyDaysAgo\.getDate\(\) - 60\);/.test(ctxRouteSrc));

  // PASS 3: handler signature + per-user label resolution
  log(`-- PASS 3: handler + label resolution --`);
  pass(`Route declared`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`Reads userId for labels`, /const userIdForLabels = req\.query\.userId \? parseInt\(req\.query\.userId as string\) : null;/.test(ctxRouteSrc));
  pass(`Default label fallback "Context Followuper"`, /let contextLabelStr = "Context Followuper";/.test(ctxRouteSrc));
  pass(`Reads contextLabel from users table`, /\.select\(\{ contextLabel: usersTable\.contextLabel \}\)\s*\.from\(usersTable\)/.test(ctxRouteSrc));
  pass(`Splits comma-separated labels`, /contextLabelStr\.split\(","\)\.map\(\(l\) => l\.trim\(\)\)\.filter\(Boolean\);/.test(ctxRouteSrc));
  pass(`Matches label by equality OR prefix slash`, /nameLower === cl\.toLowerCase\(\) \|\| nameLower\.startsWith\(cl\.toLowerCase\(\) \+ "\/"\)/.test(ctxRouteSrc));

  // PASS 4: per-email computation
  log(`-- PASS 4: per-email computation --`);
  pass(`hasContextLabel computed from labelIds`, /const hasContextLabel = labelIds\.some\(\(id\) => contextLabelIds\.includes\(id\)\);/.test(ctxRouteSrc));
  pass(`matchedContextLabels computed`, /const matchedContextLabels = labelIds\s*\n\s*\.filter\(\(id\) => contextLabelIds\.includes\(id\)\)/.test(ctxRouteSrc));
  pass(`wouldBePickedUp uses hasContextLabel`, /const wouldBePickedUp = hasContextLabel && isSentByMe && withinSyncWindow;/.test(ctxRouteSrc));
  pass(`Missing label reason text says "context"`, /if \(!hasContextLabel\) reasons\.push\("Missing context label"\);/.test(ctxRouteSrc));
  pass(`Outside sync window reason`, /if \(!withinSyncWindow\) reasons\.push\("Outside 60-day sync window"\);/.test(ctxRouteSrc));
  pass(`Email object exposes hasContextLabel`, /\bhasContextLabel,\s*\n\s*matchedContextLabels,/.test(ctxRouteSrc));

  // PASS 5: vertical inference skipped
  log(`-- PASS 5: vertical inference skipped --`);
  pass(`Phase 7g comment about skipping verticals`, /Phase 7g: vertical inference skipped for context/.test(ctxRouteSrc));
  pass(`vertical: ""`, /vertical: "",/.test(ctxRouteSrc));
  pass(`subVertical: ""`, /subVertical: "",/.test(ctxRouteSrc));
  pass(`verticalReason: ""`, /verticalReason: "",/.test(ctxRouteSrc));
  pass(`No inferVertical call`, !/\binferVertical\b/.test(ctxRouteSrc));

  // PASS 6: DB cross-reference scoped to context
  log(`-- PASS 6: DB cross-reference --`);
  pass(`messageId DB query gated on SCOPE`, /\.where\(and\(SCOPE, inArray\(prospectsTable\.gmailMessageId, messageIds\)\)\);/.test(ctxRouteSrc));
  pass(`threadId DB query gated on SCOPE`, /\.where\(and\(SCOPE, inArray\(prospectsTable\.gmailThreadId, threadIds\)\)\);/.test(ctxRouteSrc));
  pass(`enrichedEmails sets inDatabase`, /inDatabase: !!dbRecord,/.test(ctxRouteSrc));
  pass(`matchType reflects message vs thread`, /const matchType = directMatch \? "message" : threadMatch \? "thread" : null;/.test(ctxRouteSrc));

  // PASS 7: response shape
  log(`-- PASS 7: response shape --`);
  pass(`Returns emails + meta`, /res\.json\(\{\s*\n\s*emails: enrichedEmails,\s*\n\s*meta: \{/.test(ctxRouteSrc));
  pass(`meta.total computed`, /total: enrichedEmails\.length,/.test(ctxRouteSrc));
  pass(`meta.withContextLabel computed`, /withContextLabel: enrichedEmails\.filter\(\(e\) => e\.hasContextLabel\)\.length,/.test(ctxRouteSrc));
  pass(`meta.inDatabase computed`, /inDatabase: enrichedEmails\.filter\(\(e\) => e\.inDatabase\)\.length,/.test(ctxRouteSrc));
  pass(`meta.wouldBePickedUp computed`, /wouldBePickedUp: enrichedEmails\.filter\(\(e\) => e\.detection\.wouldBePickedUp\)\.length,/.test(ctxRouteSrc));
  pass(`meta exposes contextLabelIds`, /contextLabelIds,\s*\n\s*contextLabels,/.test(ctxRouteSrc));

  // PASS 8: doctrine inspector NOT regressed
  log(`-- PASS 8: doctrine inspector unchanged --`);
  pass(`/api/gmail/sent-emails still in email-inspector.ts`, /router\.get\("\/gmail\/sent-emails"/.test(inspectorRouteSrc));
  pass(`/api/gmail/thread/:threadId still in email-inspector.ts`, /router\.get\("\/gmail\/thread\/:threadId"/.test(inspectorRouteSrc));
  pass(`Doctrine still uses DOCTRINE_LABELS env var`, /const doctrineLabels = \(process\.env\.DOCTRINE_LABELS \|\| "doctrine"\)\.split\(","\)/.test(inspectorRouteSrc));
  pass(`Doctrine still uses hasDoctrineLabel`, /const hasDoctrineLabel = labelIds\.some\(/.test(inspectorRouteSrc));
  pass(`Doctrine still calls inferVertical`, /inferVertical\(/.test(inspectorRouteSrc));
  pass(`No hasDoctrineLabel field in context.ts`, !/hasDoctrineLabel/.test(ctxRouteSrc));
  pass(`No DOCTRINE_LABELS env var in context.ts`, !/process\.env\.DOCTRINE_LABELS/.test(ctxRouteSrc));

  // PASS 9: B7c/B7e/B7f regression
  log(`-- PASS 9: B7c/B7e/B7f regression --`);
  pass(`SCOPE_DOCTRINE in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`SCOPE in context.ts`, /const SCOPE = eq\(prospectsTable\.app, "context"\);/.test(ctxRouteSrc));
  pass(`/context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7e: /context/cancel-followup present`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7e: asc imported`, /import \{ and, asc, desc, eq, inArray, sql \} from "drizzle-orm"/.test(ctxRouteSrc));
  pass(`B7e: /context/followups returns snake_case`, /original_subject: r\.originalSubject,/.test(ctxRouteSrc));
  pass(`B7f: getFollowupCap helper`, /function getFollowupCap\(maxFollowups\?: number \| null\): number \| null \{/.test(ctxRouteSrc));
  pass(`B7f: /campaign/status returns context_label`, /context_label: u\.contextLabel,/.test(ctxRouteSrc));
  pass(`users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
