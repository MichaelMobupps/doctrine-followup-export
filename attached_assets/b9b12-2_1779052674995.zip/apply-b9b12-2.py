#!/usr/bin/env python3
"""
B9b.12.2 - Switch AG Email Inspector's label detection from
per-message to thread-level.

Bug: Gmail labels applied via the UI attach to specific messages
within a thread (typically the original or inbound), not every
outbound. The inspector's per-message check
`labelIds.some(id => antiGhostingLabelIds.includes(id))` misses
threads where the rendered message (often the latest outbound)
doesn't directly carry the label, even though the thread does.

Ingest pipeline uses threads.list({labelIds}) which matches threads
where AT LEAST ONE message has the label. Mirror that here.

One file edit (anti-ghosting.ts), two anchors:
  1. After existing handler-scope antiGhostingLabelIds declaration,
     add threads.list call + agLabeledThreadIds Set.
  2. Replace per-message hasAntiGhostingLabel computation with
     thread-level lookup.

matchedAntiGhostingLabels stays per-message (it shows which labels
are physically on this message, used for LABELS panel highlighting).

Idempotent. Anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ROUTE = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"

# Anchor 1: insert thread-list fetch after handler-scope label-IDs decl.
ANCHOR1_OLD = '''    const antiGhostingLabelIds = antiGhostingLabelStr
      ? await resolveAntiGhostingLabelIds(gmail, antiGhostingLabelStr)
      : [];
    const antiGhostingLabels = antiGhostingLabelStr.split(",").map((l) => l.trim()).filter(Boolean);'''

ANCHOR1_NEW = '''    const antiGhostingLabelIds = antiGhostingLabelStr
      ? await resolveAntiGhostingLabelIds(gmail, antiGhostingLabelStr)
      : [];
    const antiGhostingLabels = antiGhostingLabelStr.split(",").map((l) => l.trim()).filter(Boolean);

    // B9b.12.2: Gmail labels attach to specific messages within a thread
    // (typically the original or inbound), not every outbound. Per-message
    // checks miss threads where the rendered outbound message doesn't
    // directly carry the label. Mirror the ingest pipeline's
    // threads.list approach for inspector accuracy.
    const agLabeledThreadIds = new Set<string>();
    if (antiGhostingLabelIds.length > 0) {
      try {
        const threadsRes = await gmail.users.threads.list({
          userId: "me",
          labelIds: antiGhostingLabelIds,
          maxResults: 50,
        });
        for (const t of threadsRes.data.threads || []) {
          if (t.id) agLabeledThreadIds.add(t.id);
        }
      } catch (err) {
        logger.warn({ err }, "failed to fetch AG-labeled threads for inspector");
      }
    }'''

# Anchor 2: replace per-message hasAntiGhostingLabel with thread-level.
ANCHOR2_OLD = '''        const hasAntiGhostingLabel = labelIds.some((id) => antiGhostingLabelIds.includes(id));'''

ANCHOR2_NEW = '''        // B9b.12.2: thread-level check (see comment above the threads.list call).
        const hasAntiGhostingLabel = msg.threadId ? agLabeledThreadIds.has(msg.threadId) : false;'''


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def info(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label} already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    info(f"{label}: updated")
    return text.replace(old, new, 1), True


def main():
    if not ROUTE.exists():
        fail(f"route not found: {ROUTE}")
    text = ROUTE.read_text(encoding="utf-8")
    original = text

    if "B9b.12.1: also capture user email" not in text:
        fail("B9b.12.1 must be applied before B9b.12.2")

    text, _ = replace_unique(
        text, ANCHOR1_OLD, ANCHOR1_NEW,
        "thread-level fetch (after label-IDs decl)",
        marker="B9b.12.2: Gmail labels attach to specific messages",
    )

    text, _ = replace_unique(
        text, ANCHOR2_OLD, ANCHOR2_NEW,
        "per-message -> thread-level hasAntiGhostingLabel",
        marker="B9b.12.2: thread-level check",
    )

    if text != original:
        ROUTE.write_text(text, encoding="utf-8")
        info(f"wrote {ROUTE.relative_to(WORKSPACE)}")
    else:
        skip("route already patched")

    print()
    print("B9b.12.2 thread-level label detection applied.")


if __name__ == "__main__":
    main()
