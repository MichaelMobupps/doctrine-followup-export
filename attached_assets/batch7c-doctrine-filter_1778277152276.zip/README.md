# Batch 7c — Doctrine Route Filter

Phase 7c. Closes the dormant gap from 7b: every prospect query in
`routes/doctrine.ts` now gates on `app='doctrine'`. The Doctrine UI is
fully isolated from any context prospect that exists in the database.

## What's in this batch

**Files touched: 1.**

- `artifacts/api-server/src/routes/doctrine.ts`

**Edits: 24 surgical str_replace operations.**

1. Define `SCOPE_DOCTRINE = eq(prospectsTable.app, "doctrine")` constant
   near the top of the file.
2. Inject `SCOPE_DOCTRINE` into every where-clause that touches
   `prospectsTable`. Coverage:
   - `getUserTimingSettingsForProspect` helper (L35)
   - `partitionAndSchedule` inArray (L58)
   - `/stats` prospect + followup join, both ternary branches (L115, L115b)
   - `/prospects` list — conditions[] seed (L186)
   - `/prospect/by-thread/:threadId` (L299)
   - `/my/activity` last-prospect, queuedCount, nextDue (L363/L384/L393)
   - `/queue-batch` (L460)
   - `/followup-now/:prospectId` (L557)
   - `/followups` list — conditions[] seed (L683)
   - `/followups/:id/approve` SELECT (L782)
   - `/followups/:id/reject` UPDATE — sub-select gate via `inArray` (L851)
   - `/followup/send-bulk` inner-loop (L872)
   - `/prospect/pause-bulk` UPDATE (L957)
   - `/prospect/:id/pause` UPDATE (L1015)
   - `/prospect/:id/resume` SELECT + UPDATE (L1045+L1050)
   - `/prospect/:id/campaign-type` SELECT + UPDATE (L1129+L1149)
   - `/campaign/status` user-batch group, actionable, followup-status (L1192/L1204/L1255)
   - `/campaign/queue` and `/campaign/launch` unrepliedProspects (L1369/L1472)
   - `/campaign/stop` per-user + global (L1578/L1592)

## What changes for the user

- The Doctrine UI behaves exactly as before for users who already use it.
- A context prospect's ID can no longer affect doctrine endpoints. If a
  context prospect ID is sent to any `/api/<doctrine-route>/<id>` endpoint,
  the route returns 404.
- Per-user stats, queue counts, and campaign metrics are now correctly
  partitioned: a user with both doctrine and context prospects sees only
  their doctrine numbers in the doctrine UI.
- Defense-in-depth gate on `/followups/:id/reject` via inArray sub-select
  — even though the UI never exposes context follow-up IDs to the doctrine
  side, a direct API call cannot cross the boundary.

## Files

```
batch7c/
├── apply-batch7c.mjs       # Idempotent patch script (24 edits)
├── audit-batch7c.mjs       # Beautiful-Squidward 3 rounds × 9 passes
└── README.md
```

## Apply

Standard pattern — single bash block in the ship instruction.

## Verify

After applying, the apply script self-verifies:
- `SCOPE_DOCTRINE` appears 31× (1 const + 30 references)
- No remaining `.where(...)` clauses on prospects without scope (50-line
  lookbehind window covers conditions[]→whereClause distance in list
  endpoints)

The audit script runs 81 checks total (27 per round × 3 rounds):
- Round 1–3: 9 passes each round
- Each pass hard-asserts; any failure exits non-zero

## Known residual

None. After 7c the doctrine routes are fully scoped. The Context UI
clones (Pipeline, Email Inspector, Activity Log) ship in 7d.
