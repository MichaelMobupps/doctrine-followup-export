import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import doctrineRouter from "./doctrine";
import gmailAuthRouter from "./gmail-auth";
import emailInspectorRouter from "./email-inspector";
import contextRouter from "./context";
// B7o: admin salvage endpoint for stuck prospects.
import adminSalvageRouter from "./admin-salvage";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(gmailAuthRouter);
router.use(doctrineRouter);
router.use(emailInspectorRouter);
// Phase 7b: Context Based Followuper. Mounted under /context so URLs are
// /api/context/stats, /api/context/followups, etc. The doctrine router
// stays at the root (existing UI routes) until 7c adds parallel scoping.
router.use("/context", contextRouter);
// B7o: admin endpoints (X-API-Key gated).
router.use(adminSalvageRouter);

export default router;
