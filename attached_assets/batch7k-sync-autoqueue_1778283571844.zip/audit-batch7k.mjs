#!/usr/bin/env node
/**
 * audit-batch7k.mjs — Beautiful-Squidward audit for Phase 7k.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7k] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7k] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const schedulerSrc      = read(join(API_BASE, "services", "scheduler.ts"));
const gmailSyncSrc      = read(join(API_BASE, "services", "gmailSync.ts"));
const cronSrc           = read(join(API_BASE, "cron.ts"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

// Extract a /sync handler block from a route src, by matching the first
// router.post("/sync", ...) and reading until the matching ;}); line.
function extractSyncHandler(src) {
  const m = src.match(/router\.post\("\/sync"[\s\S]*?^\}\);$/m);
  return m ? m[0] : "";
}

const doctrineSyncBlock = extractSyncHandler(doctrineRouteSrc);
const contextSyncBlock  = extractSyncHandler(ctxRouteSrc);

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: doctrine /sync calls autoQueueAllCampaigns
  log(`-- PASS 1: doctrine /sync auto-queue --`);
  pass(`Phase 7k comment present in doctrine /sync block`,
       /Phase 7k: trigger autoQueueAllCampaigns so newly-synced prospects/.test(doctrineSyncBlock));
  pass(`Doctrine /sync dynamic-imports autoQueueAllCampaigns`,
       /const \{ autoQueueAllCampaigns \} = await import\("\.\.\/services\/scheduler"\);/.test(doctrineSyncBlock));
  pass(`Doctrine /sync awaits autoQueueAllCampaigns()`,
       /autoQueued = await autoQueueAllCampaigns\(\);/.test(doctrineSyncBlock));

  // PASS 2: doctrine /sync response shape extension
  log(`-- PASS 2: doctrine /sync response shape --`);
  pass(`Doctrine /sync returns spread + auto_queued`,
       /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(doctrineSyncBlock));
  pass(`Doctrine /sync defaults autoQueued to 0`,
       /let autoQueued = 0;/.test(doctrineSyncBlock));
  pass(`Doctrine /sync wraps autoQueue in try/catch`,
       /try \{\s*\n\s*autoQueued = await autoQueueAllCampaigns\(\);[\s\S]*?\} catch \(err\) \{[\s\S]*?logger\.warn/.test(doctrineSyncBlock));

  // PASS 3: context /sync calls autoQueueAllCampaigns
  log(`-- PASS 3: context /sync auto-queue --`);
  pass(`Phase 7k comment present in context /sync block`,
       /Phase 7k: same fix as doctrine \/sync — auto-queue F1 follow-ups/.test(contextSyncBlock));
  pass(`Context /sync dynamic-imports autoQueueAllCampaigns`,
       /const \{ autoQueueAllCampaigns \} = await import\("\.\.\/services\/scheduler"\);/.test(contextSyncBlock));
  pass(`Context /sync awaits autoQueueAllCampaigns()`,
       /autoQueued = await autoQueueAllCampaigns\(\);/.test(contextSyncBlock));

  // PASS 4: context /sync response shape extension
  log(`-- PASS 4: context /sync response shape --`);
  pass(`Context /sync returns spread + auto_queued`,
       /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(contextSyncBlock));
  pass(`Context /sync defaults autoQueued to 0`,
       /let autoQueued = 0;/.test(contextSyncBlock));
  pass(`Context /sync wraps autoQueue in try/catch`,
       /try \{\s*\n\s*autoQueued = await autoQueueAllCampaigns\(\);[\s\S]*?\} catch \(err\) \{[\s\S]*?logger\.warn/.test(contextSyncBlock));

  // PASS 5: doctrine /sync existing logic preserved
  log(`-- PASS 5: doctrine /sync regression --`);
  pass(`Doctrine input validation for non-string email preserved`,
       /if \(rawEmail !== undefined && rawEmail !== null && typeof rawEmail !== "string"\) \{[\s\S]*?res\.status\(400\)\.json\(\{ error: "Invalid 'email' value: must be a string" \}\);/.test(doctrineSyncBlock));
  pass(`Doctrine per_user log preserved`,
       /logger\.info\(\{ email, mode: "per_user" \}, "Manual sync requested"\);/.test(doctrineSyncBlock));
  pass(`Doctrine all_users log preserved`,
       /logger\.info\(\{ mode: "all_users" \}, "Manual sync requested"\);/.test(doctrineSyncBlock));
  pass(`Doctrine /sync still calls syncEmailsForUser`,
       /result = await syncEmailsForUser\(email\);/.test(doctrineSyncBlock));
  pass(`Doctrine /sync still calls syncEmails`,
       /result = await syncEmails\(\);/.test(doctrineSyncBlock));

  // PASS 6: structural — handlers have no orphan `const result =` followed by `res.json(result)`
  log(`-- PASS 6: structural cleanliness --`);
  pass(`Doctrine: no orphan const result = syncEmailsForUser(...)+res.json pattern`,
       !/const result = await syncEmailsForUser\(email\);\s*\n\s*res\.json\(result\);/.test(doctrineRouteSrc));
  pass(`Context: no orphan const result = syncEmailsForUser(...)+res.json pattern`,
       !/const result = await syncEmailsForUser\(email\);\s*\n\s*res\.json\(result\);/.test(ctxRouteSrc));

  // PASS 7: shared helper exists + no double-wiring
  log(`-- PASS 7: helper + cron unchanged --`);
  pass(`autoQueueAllCampaigns exported in scheduler.ts`,
       /export async function autoQueueAllCampaigns\(\)/.test(schedulerSrc));
  pass(`autoQueueAllCampaigns still wired in cron.ts (15-min tick)`,
       /const autoQueued = await autoQueueAllCampaigns\(\);/.test(cronSrc));
  pass(`autoQueueAllCampaigns reachable from both routes`,
       (doctrineRouteSrc.match(/autoQueueAllCampaigns/g) || []).length >= 2 &&
       (ctxRouteSrc.match(/autoQueueAllCampaigns/g) || []).length >= 2);
  pass(`gmailSync.ts STILL does not insert into followupsTable directly`,
       !/insert\(followupsTable\)/.test(gmailSyncSrc));

  // PASS 8: B7g/B7e/B7f/B7h/B7i/B7j regression
  log(`-- PASS 8: B7e-B7j regression --`);
  pass(`B7e: /context/cancel-followup endpoint`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7g: /context/gmail/sent-emails endpoint`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`B7i: /context/my/activity endpoint`, /router\.get\("\/my\/activity"/.test(ctxRouteSrc));
  pass(`B7i: layout.tsx product-aware activity URL`, /const activityPath = onContext \? "api\/context\/my\/activity" : "api\/my\/activity";/.test(layoutSrc));
  pass(`B7j: doctrine /api/stats includes drafted_followups`, /drafted_followups: Number\(fs\?\.draftedFollowups\) \|\| 0,/.test(doctrineRouteSrc));
  pass(`B7j: ctx-inspector vertical badge gated`,
       /\{vertLabel && <Badge variant="outline">\{vertLabel\}<\/Badge>\}/.test(read(join(DASH_BASE, "pages", "context-inspector.tsx"))));

  // PASS 9: B7a-B7c regression
  log(`-- PASS 9: B7a-B7c regression --`);
  pass(`B7c: SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`B7c: SCOPE_DOCTRINE referenced ≥30 times`, (doctrineRouteSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`B7b: /context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7a: users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
