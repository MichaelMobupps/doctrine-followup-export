#!/usr/bin/env python3
"""
apply_patches.py

Idempotent patcher for the Followuper api-server. Applies the doctrine-hardening
+ language-nativeness deterministic lint patches without overwriting unrelated
edits. Each patch op:
  * verifies an `anchor` string is present (so the file looks as expected)
  * checks for a unique `marker` to detect prior application (idempotent)
  * if not yet patched, replaces `old` -> `new` (single occurrence)

If anchor is missing the script aborts with a diagnostic. If marker is found
the op is skipped. Backups go to <BASE>/.backups/followuper-doctrine-v1/.

Usage:
    python3 apply_patches.py [BASE_DIR]

BASE_DIR defaults to current directory. Expected layout under BASE_DIR:
    services/followupPrompts.ts
    services/followupGenerator.ts
    services/contextFollowupGenerator.ts
"""

import sys
import os
import shutil
from pathlib import Path
from datetime import datetime
from typing import NamedTuple, List


class PatchOp(NamedTuple):
    name: str
    file: str
    marker: str
    old: str
    new: str


# ============================================================================
# Patch definitions
# ============================================================================

OPS: List[PatchOp] = [

    # ------------------------------------------------------------------------
    # OP 1: followupPrompts.ts — insert DOCTRINE ENFORCEMENT block in writer
    # ------------------------------------------------------------------------
    PatchOp(
        name="writer-prompt-doctrine-block",
        file="services/followupPrompts.ts",
        marker="DOCTRINE ENFORCEMENT — applies to every follow-up email",
        old=(
            "EVERY claim must be a CONCRETE STATEMENT a human reader can understand on its own, not a description of what the email is doing.\n"
            "\n"
            "OUTPUT FORMAT:"
        ),
        new=(
            "EVERY claim must be a CONCRETE STATEMENT a human reader can understand on its own, not a description of what the email is doing.\n"
            "\n"
            "DOCTRINE ENFORCEMENT — applies to every follow-up email:\n"
            "\n"
            "1. DECISIVE NUMBERS — never hedge before a number. Write \"250\" or \"250+\", not \"around 250\", \"approximately 250\", \"roughly 250\", or the target-language equivalent (\"alrededor de 250\", \"около 250\", \"ungefähr 250\", \"ประมาณ 250\", and so on). Numbers carry credibility; hedges undercut them. This applies whether the number is performance, volume, time, or money.\n"
            "\n"
            "2. NO HYPE ADJECTIVES — cut every marketing-deck adjective from the body. Banned in English: \"strong\", \"powerful\", \"robust\", \"significant\", \"exceptional\", \"outstanding\", \"innovative\", \"cutting-edge\", \"best-in-class\", \"world-class\", \"industry-leading\", \"game-changing\", \"groundbreaking\", \"revolutionary\", \"unparalleled\", \"next-generation\", \"transformative\", \"pioneering\". The target-language equivalents are also banned. Numbers, mechanisms, and named entities carry the claim — not adjectives.\n"
            "\n"
            "3. SINGLE-EVENT ANCHOR — if you make an optimization or volume claim, anchor it on EXACTLY ONE event type. Never \"we optimize toward installs or signups or sessions\". Pick the single dominant revenue event by volume for the prospect's business. Adjacent events may appear as context, but only one is the anchor.\n"
            "\n"
            "4. NO CPA-AS-DIFFERENTIATOR — never frame \"we pay only for X, not Y\" as a differentiator. Every ad network can offer that, so it does not differentiate. If a follow-up needs a differentiating claim at all, anchor it on one of: renewals/persistence (durable revenue past the first cycle), incrementality (incremental users vs cannibalized), or semi-exclusive supply (publishers not shared with named competitors).\n"
            "\n"
            "LANGUAGE NATIVENESS — additional rule for non-Latin-script target languages (Thai, Chinese, Japanese, Korean, Arabic, Hebrew, Persian, Hindi, Bengali, Urdu, Russian, Ukrainian, Greek, and others): never inject a multi-word English phrase into the prose. Single industry-standard adtech tokens that the language guide explicitly permits (cohort, event, retention) MAY stay in English as isolated single words. But two or more consecutive lowercase English content words (like \"quality user acquisition\" or \"approved revenue events\") inside non-Latin prose is ALWAYS a violation. Proper nouns (\"Brand Day\", \"King Power Online\") and acronyms (UA, LTV, ROAS, CPI, CPA, MMP, DSP, SDK, IAP, KPI) are exempt. When in doubt, write the phrase in the target language.\n"
            "\n"
            "OUTPUT FORMAT:"
        ),
    ),

    # ------------------------------------------------------------------------
    # OP 2: followupPrompts.ts — add criterion 9 to critic prompt
    # ------------------------------------------------------------------------
    PatchOp(
        name="critic-doctrine-criterion",
        file="services/followupPrompts.ts",
        marker="9. DOCTRINE COMPLIANCE",
        old=(
            "8. TONE: Professional but human? No corporate jargon, no spam signals? No AI-sounding words like \"delve\", \"leverage\", \"seamless\"?\n"
            "\n"
            "OUTPUT FORMAT:"
        ),
        new=(
            "8. TONE: Professional but human? No corporate jargon, no spam signals? No AI-sounding words like \"delve\", \"leverage\", \"seamless\"?\n"
            "\n"
            "9. DOCTRINE COMPLIANCE: The email must obey four doctrine rules. (a) DECISIVE NUMBERS — no hedge words before any number, including target-language equivalents like \"around\", \"approximately\", \"roughly\", \"alrededor de\", \"около\", \"ungefähr\", \"ประมาณ\". (b) NO HYPE ADJECTIVES — none of \"strong\", \"powerful\", \"significant\", \"exceptional\", \"innovative\", \"best-in-class\", \"industry-leading\", \"game-changing\", \"groundbreaking\", or target-language equivalents in body prose. (c) SINGLE-EVENT ANCHOR — if an optimization or volume claim is made, exactly one event type is named, not two or three combined. (d) NO CPA-AS-DIFFERENTIATOR — no \"we pay only for X, not Y\" framing as a differentiator. If the draft violates any of these four, score 1-2 and set needs_rewrite = true. Quote the specific offending phrase in \"issues\".\n"
            "\n"
            "OUTPUT FORMAT:"
        ),
    ),

    # ------------------------------------------------------------------------
    # OP 3: followupPrompts.ts — extend critic JSON schema with new score field
    # ------------------------------------------------------------------------
    PatchOp(
        name="critic-json-schema",
        file="services/followupPrompts.ts",
        marker="\"doctrine_compliance\": 1-5",
        old='"scores": { "no_meta_language": 1-5, "followup_ack": 1-5, "language_match": 1-5, "language_naturalness": 1-5, "conciseness": 1-5, "relevance": 1-5, "differentiation": 1-5, "tone": 1-5 }',
        new='"scores": { "no_meta_language": 1-5, "followup_ack": 1-5, "language_match": 1-5, "language_naturalness": 1-5, "conciseness": 1-5, "relevance": 1-5, "differentiation": 1-5, "tone": 1-5, "doctrine_compliance": 1-5 }',
    ),

    # ------------------------------------------------------------------------
    # OP 4: followupPrompts.ts — extend needs_rewrite trigger conditions
    # ------------------------------------------------------------------------
    PatchOp(
        name="critic-needs-rewrite-trigger",
        file="services/followupPrompts.ts",
        marker="OR doctrine_compliance < 4",
        old="Set needs_rewrite to true if overall < 4 OR no_meta_language < 4 OR followup_ack < 4 OR language_match < 4 OR language_naturalness < 4.",
        new="Set needs_rewrite to true if overall < 4 OR no_meta_language < 4 OR followup_ack < 4 OR language_match < 4 OR language_naturalness < 4 OR doctrine_compliance < 4. If doctrine_compliance is 1 or 2, needs_rewrite MUST be true.",
    ),

    # ------------------------------------------------------------------------
    # OP 5: followupPrompts.ts — rewriter prompt doctrine line
    # ------------------------------------------------------------------------
    PatchOp(
        name="rewriter-doctrine-line",
        file="services/followupPrompts.ts",
        marker="- DOCTRINE: cut hedge-on-number",
        old=(
            "- No spam signals, no exclamation marks, max one question mark.\n"
            "- Sign off with just the sender's first name."
        ),
        new=(
            "- No spam signals, no exclamation marks, max one question mark.\n"
            "- DOCTRINE: cut hedge-on-number (\"around 250\" → \"250\"), hype adjectives (\"strong\", \"powerful\", \"significant\", \"innovative\", \"best-in-class\", \"industry-leading\", and target-language equivalents), multi-event optimization claims (anchor on EXACTLY ONE event), and CPA-as-differentiator framing (\"we pay only for X, not Y\"). For non-Latin-script target languages, no multi-word English phrases inside the prose — single permitted-acronym tokens and proper nouns are fine, but two or more consecutive lowercase English content words is a violation.\n"
            "- Sign off with just the sender's first name."
        ),
    ),

    # ------------------------------------------------------------------------
    # OP 6: followupGenerator.ts — import the new detector
    # ------------------------------------------------------------------------
    PatchOp(
        name="generator-import",
        file="services/followupGenerator.ts",
        marker='import { detectAllDeterministicViolations }',
        old='import { logger } from "../lib/logger";',
        new=(
            'import { logger } from "../lib/logger";\n'
            'import { detectAllDeterministicViolations } from "../lib/doctrineLint";'
        ),
    ),

    # ------------------------------------------------------------------------
    # OP 7: followupGenerator.ts — call the detector in each iteration and
    # merge the report into the critique.
    # ------------------------------------------------------------------------
    PatchOp(
        name="generator-detector-call",
        file="services/followupGenerator.ts",
        marker="const deterministicCheck = detectAllDeterministicViolations(",
        old="    const metaCheck = detectMetaLanguage(current.body);\n",
        new=(
            "    const metaCheck = detectMetaLanguage(current.body);\n"
            "    const deterministicCheck = detectAllDeterministicViolations(current.body, ctx.original_language);\n"
        ),
    ),

    PatchOp(
        name="generator-detector-merge",
        file="services/followupGenerator.ts",
        marker="if (deterministicCheck.found) {",
        old=(
            '      critique.needs_rewrite = true;\n'
            '      critique.overall = Math.min(critique.overall, 2);\n'
            '    }\n'
            '\n'
            '    // Track the best draft we\'ve seen so we always have something to return\n'
        ),
        new=(
            '      critique.needs_rewrite = true;\n'
            '      critique.overall = Math.min(critique.overall, 2);\n'
            '    }\n'
            '\n'
            '    if (deterministicCheck.found) {\n'
            '      // Prepend deterministic doctrine + nativeness issues into the LLM\n'
            '      // critique so the rewriter receives them in the same channel as\n'
            '      // every other issue. Same pattern as the meta-language merge above.\n'
            '      critique.issues = [...deterministicCheck.issues, ...critique.issues];\n'
            '      critique.suggestions = [...deterministicCheck.suggestions, ...critique.suggestions];\n'
            '      critique.needs_rewrite = true;\n'
            '      critique.overall = Math.min(critique.overall, 2);\n'
            '      logger.info(\n'
            '        { prospect: ctx.prospect_name, iteration, matches: deterministicCheck.matches.slice(0, 5) },\n'
            '        "Deterministic doctrine/nativeness violations detected — merging into critique",\n'
            '      );\n'
            '    }\n'
            '\n'
            '    // Track the best draft we\'ve seen so we always have something to return\n'
        ),
    ),

    # ------------------------------------------------------------------------
    # OP 8: contextFollowupGenerator.ts — import + detector wiring
    # ------------------------------------------------------------------------
    PatchOp(
        name="context-generator-import",
        file="services/contextFollowupGenerator.ts",
        marker='import { detectAllDeterministicViolations }',
        # The context generator imports differ in shape; anchor on the logger
        # import which is unique and ordered.
        old='import { logger } from "../lib/logger";',
        new=(
            'import { logger } from "../lib/logger";\n'
            'import { detectAllDeterministicViolations } from "../lib/doctrineLint";'
        ),
    ),

    PatchOp(
        name="context-generator-merge",
        file="services/contextFollowupGenerator.ts",
        marker="// Deterministic doctrine + nativeness pre-flight",
        old=(
            "  let critique: ContextCriticResult;\n"
            "  try {\n"
            "    critique = await critiqueContextDraft(ctx, draft);\n"
            "  } catch (err) {\n"
            "    // Critic failure is non-fatal: ship the original draft. We log but\n"
            "    // don't block delivery on a transient critic problem.\n"
            "    logger.warn({ err }, \"Context-critic call failed — shipping original draft\");\n"
            "    return draft;\n"
            "  }\n"
        ),
        new=(
            "  let critique: ContextCriticResult;\n"
            "  try {\n"
            "    critique = await critiqueContextDraft(ctx, draft);\n"
            "  } catch (err) {\n"
            "    // Critic failure is non-fatal: ship the original draft. We log but\n"
            "    // don't block delivery on a transient critic problem.\n"
            "    logger.warn({ err }, \"Context-critic call failed — shipping original draft\");\n"
            "    return draft;\n"
            "  }\n"
            "\n"
            "  // Deterministic doctrine + nativeness pre-flight. Doctrine rules are\n"
            "  // mostly inert here (context flow is non-sales, no value claims), but\n"
            "  // the language-nativeness latin-token-leak detector applies universally\n"
            "  // and catches the Zekri-pattern multi-word English phrases inside\n"
            "  // non-Latin-script prose.\n"
            "  const deterministicCheck = detectAllDeterministicViolations(draft.body, ctx.original_language);\n"
            "  if (deterministicCheck.found) {\n"
            "    critique.issues = [...deterministicCheck.issues, ...critique.issues];\n"
            "    critique.suggestions = [...deterministicCheck.suggestions, ...critique.suggestions];\n"
            "    critique.needs_rewrite = true;\n"
            "    critique.overall = Math.min(critique.overall, 2);\n"
            "    logger.info(\n"
            "      { stage: ctx.stage, matches: deterministicCheck.matches.slice(0, 5) },\n"
            "      \"Context-flow deterministic violations detected — merging into critique\",\n"
            "    );\n"
            "  }\n"
        ),
    ),
]


# ============================================================================
# Engine
# ============================================================================

def apply_op(base: Path, op: PatchOp, backup_dir: Path) -> str:
    """Apply a single patch op. Returns a status string."""
    target = base / op.file
    if not target.exists():
        return f"SKIP  {op.name}: target not found at {target}"

    content = target.read_text(encoding="utf-8")

    # Idempotency check: if marker already present, skip.
    if op.marker in content:
        return f"SKIP  {op.name}: already applied (marker present)"

    # Anchor check: if old text isn't present, abort.
    if op.old not in content:
        return f"FAIL  {op.name}: anchor not found in {target} — likely already modified differently"

    # Single-occurrence check: don't double-replace if the anchor appears more
    # than once. The patch authors should pick uniquely-occurring anchors.
    occurrences = content.count(op.old)
    if occurrences > 1:
        return f"FAIL  {op.name}: anchor occurs {occurrences} times in {target} — anchor not unique"

    # Backup
    relpath = target.relative_to(base)
    bk = backup_dir / relpath
    bk.parent.mkdir(parents=True, exist_ok=True)
    if not bk.exists():
        bk.write_text(content, encoding="utf-8")

    # Apply
    new_content = content.replace(op.old, op.new, 1)
    target.write_text(new_content, encoding="utf-8")
    return f"OK    {op.name}: patched {target}"


def main():
    base = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    if not base.exists() or not base.is_dir():
        print(f"ERROR: base directory does not exist: {base}", file=sys.stderr)
        sys.exit(1)

    print(f"Base: {base}")
    backup_dir = base / ".backups" / "followuper-doctrine-v1"
    print(f"Backups: {backup_dir}")
    print()

    results = []
    failed = False
    for op in OPS:
        status = apply_op(base, op, backup_dir)
        results.append(status)
        print(status)
        if status.startswith("FAIL"):
            failed = True

    print()
    print(f"Total: {len(OPS)} ops, "
          f"OK={sum(1 for r in results if r.startswith('OK'))}, "
          f"SKIP={sum(1 for r in results if r.startswith('SKIP'))}, "
          f"FAIL={sum(1 for r in results if r.startswith('FAIL'))}")

    if failed:
        print()
        print("Some ops failed. Inspect the FAIL lines above. If a file looks already")
        print("modified, you may need to manually rebase the patches on top of your")
        print("local changes.")
        sys.exit(2)


if __name__ == "__main__":
    main()
