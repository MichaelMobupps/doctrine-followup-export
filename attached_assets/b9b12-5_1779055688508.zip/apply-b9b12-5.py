#!/usr/bin/env python3
"""
B9b.12.5 - Relax scheduler's replied=0 gates so AG prospects can be
processed by the cron after manual resume.

B9b.12.4 unlocked the UI and the API endpoints for resume-on-replied,
but the scheduler still gates on `replied=0` in three places, so a
followup scheduled by resuming a replied AG prospect never fires.

This batch scopes the relaxation to AG only \u2014 Doctrine and Context
keep their replied=0 filter (no SDR should auto-followup someone who
replied). The followupPaused=false filter stays in place across all
three apps (paused = user explicitly stopped; respect that).

Four edits in scheduler.ts:
  G0: Add `or` to drizzle-orm imports.
  G1: Top-level processDueFollowups query \u2014 replace replied=0
      filter with OR(replied=0, app=anti_ghosting).
  G2: queueNextFollowup early return \u2014 add `prospect.app !==
      "anti_ghosting"` to the replied check.
  G3: autoQueueAllCampaigns unrepliedProspects query \u2014 same OR
      pattern as G1.

Idempotent. All anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
SCHEDULER = WORKSPACE / "artifacts/api-server/src/services/scheduler.ts"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# --------------------------------------------------------------------
# G0: Add `or` to drizzle-orm imports.
# --------------------------------------------------------------------
G0_OLD = '''import { eq, ne, and, lte, lt, inArray } from "drizzle-orm";'''
G0_NEW = '''import { eq, ne, and, lte, lt, inArray, or } from "drizzle-orm";'''


# --------------------------------------------------------------------
# G1: processDueFollowups query \u2014 top-level cron filter.
# --------------------------------------------------------------------
G1_OLD = '''  if (!options?.forceSend) {
    conditions.push(eq(prospectsTable.replied, 0));
    conditions.push(eq(prospectsTable.followupPaused, false));
  }'''

G1_NEW = '''  if (!options?.forceSend) {
    // B9b.12.5: AG prospects bypass the replied gate so manually-resumed
    // replied threads can be processed by the cron. Doctrine/Context keep
    // strict replied=0 filtering. Pause stays universal.
    conditions.push(or(eq(prospectsTable.replied, 0), eq(prospectsTable.app, "anti_ghosting"))!);
    conditions.push(eq(prospectsTable.followupPaused, false));
  }'''


# --------------------------------------------------------------------
# G2: queueNextFollowup \u2014 per-prospect early return.
# --------------------------------------------------------------------
G2_OLD = '''  if (prospect.replied) return { queued: false, stage: null, scheduledAt: null, reason: "prospect_replied" };'''

G2_NEW = '''  // B9b.12.5: AG prospects bypass the replied gate (manual re-engagement).
  if (prospect.replied && prospect.app !== "anti_ghosting") return { queued: false, stage: null, scheduledAt: null, reason: "prospect_replied" };'''


# --------------------------------------------------------------------
# G3: autoQueueAllCampaigns \u2014 unrepliedProspects query.
# --------------------------------------------------------------------
G3_OLD = '''        eq(prospectsTable.replied, 0),
        eq(prospectsTable.followupPaused, false),
        inArray(prospectsTable.userId, userIds),'''

G3_NEW = '''        // B9b.12.5: AG prospects can be auto-queued past replied (manual re-engagement).
        or(eq(prospectsTable.replied, 0), eq(prospectsTable.app, "anti_ghosting"))!,
        eq(prospectsTable.followupPaused, false),
        inArray(prospectsTable.userId, userIds),'''


def patch_scheduler():
    if not SCHEDULER.exists():
        fail(f"scheduler not found: {SCHEDULER}")
    text = SCHEDULER.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, G0_OLD, G0_NEW,
        "G0: add 'or' to drizzle-orm imports",
        marker=', or }',
    )

    text, _ = replace_unique(
        text, G1_OLD, G1_NEW,
        "G1: processDueFollowups top-level filter",
        marker="B9b.12.5: AG prospects bypass the replied gate so manually-resumed",
    )

    text, _ = replace_unique(
        text, G2_OLD, G2_NEW,
        "G2: queueNextFollowup early return",
        marker="B9b.12.5: AG prospects bypass the replied gate (manual re-engagement)",
    )

    text, _ = replace_unique(
        text, G3_OLD, G3_NEW,
        "G3: autoQueueAllCampaigns query",
        marker="B9b.12.5: AG prospects can be auto-queued past replied",
    )

    if text != original:
        SCHEDULER.write_text(text, encoding="utf-8")
        ok(f"wrote {SCHEDULER.relative_to(WORKSPACE)}")
    else:
        skip("scheduler already patched")


def main():
    patch_scheduler()
    print()
    print("B9b.12.5 scheduler AG-replied-resume applied.")


if __name__ == "__main__":
    main()
