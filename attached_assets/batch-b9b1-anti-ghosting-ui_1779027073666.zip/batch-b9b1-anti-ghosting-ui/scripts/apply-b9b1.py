#!/usr/bin/env python3
r"""
B9b.1 — register the AntiGhosting page in the dashboard router.

Two edits to artifacts/dashboard/src/App.tsx:
  1. Import the new page module.
  2. Add a <Route path="/anti-ghosting" /> entry inside the Switch.

The page file itself (pages/anti-ghosting.tsx) and the picker.tsx
replacement are dropped into place separately by the deploy bash
block; this script only handles the App.tsx wiring.

Adopts the generalised NEW-is-substring-of-OLD check committed to
the patch_file helper in B9c.2.1's hotfix — eliminates the trap
that bit B9c.1 (exclusion-filter deletion) and B9c.2 (subset NEW)
without relying on author-side discipline.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        # Generalised idempotency: if NEW is empty (deletion) OR NEW is
        # a substring of OLD (we're appending/inserting next to OLD,
        # not replacing it), use OLD-presence to decide instead of
        # NEW-presence — NEW would trivially match because it's part
        # of OLD or part of every string.
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    totals = [0, 0, 0]

    print("\n--- artifacts/dashboard/src/App.tsx ---")
    a, b, w = patch_file(
        "artifacts/dashboard/src/App.tsx",
        [
            (
                'import ContextActivityLog from "@/pages/context-activity";\n',
                'import ContextActivityLog from "@/pages/context-activity";\n'
                '// B9b.1: AntiGhosting Followuper page (third product alongside\n'
                '// Doctrine and Context). Mark Gmail threads tagged with the\n'
                '// AntiGhosting label for re-engagement.\n'
                'import AntiGhosting from "@/pages/anti-ghosting";\n',
                "import the AntiGhosting page module",
            ),
            (
                '      <Route path="/context/activity" component={ContextActivityLog} />\n',
                '      <Route path="/context/activity" component={ContextActivityLog} />\n'
                '      {/* B9b.1: AntiGhosting Followuper route. */}\n'
                '      <Route path="/anti-ghosting" component={AntiGhosting} />\n',
                "add /anti-ghosting route",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    expected = 2
    seen = totals[0] + totals[1]
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {totals[0]}")
    print(f"  Already-applied:   {totals[1]}")
    print(f"  Warnings:          {totals[2]}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if totals[2] > 0:
        print("  At least one edit could not be applied. Inspect WARN lines.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
