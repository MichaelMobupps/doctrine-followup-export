# Batch 7h — Context Email Inspector frontend

Phase 7h. Replaces the placeholder at `/context/inspector` with a real
ContextEmailInspector page derived from the Doctrine Email Inspector.
Consumes the `/api/context/gmail/sent-emails` endpoint shipped in 7g.

## What's in this batch

**Frontend changes (`dashboard/pages/context-inspector.tsx`):**

The B7d placeholder is replaced with a transformed clone of
`email-inspector.tsx`. The apply script copies email-inspector.tsx in
place and runs 12 idempotent transformations — 9 single-anchor
str_replaces and 3 sentinel-gated globalStrReplaces for multi-occurrence
field renames. The new `globalStrReplace` helper is the only new piece
of machinery in this batch — it replaces ALL occurrences of `oldStr`
with `newStr`, idempotency-gated via a sentinel that must be in `newStr`
but not in `oldStr`.

Single-anchor transformations:

1. **Header comment** — Phase 7h marker explaining the clone.
2. **Trim imports** — drop `useGetSentEmails`, `useGetThread`,
   `useGetGmailAccounts` from the typed-hook import line. Add
   `useCallback` to the React import (needed for `refetch`).
3. **Rename component** `EmailInspector` → `ContextEmailInspector`.
4. **`ThreadView` raw fetch** — `useGetThread(threadId, ...)` replaced
   with `useState` + `useEffect` hitting `/api/gmail/thread/:threadId`
   (shared endpoint, no rename).
5. **Accounts raw fetch** — `useGetGmailAccounts(...)` replaced with
   `useState` + `useEffect` hitting `/api/gmail/accounts` (shared,
   no rename).
6. **Sent-emails raw fetch** — `useGetSentEmails(params, ...)` replaced
   with `useState` + `useEffect` hitting
   `/api/context/gmail/sent-emails` with `URLSearchParams`. Includes
   `refetchTrigger` state, `refetch` via `useCallback`, and `isFetching`
   spinner state.
7. **Sync URL retarget** `/api/sync` → `/api/context/sync`.
8. **Detection-panel string** `"Doctrine label"` → `"Context label"`.
9. **Stat-pill string** `"DOCTRINE LABELED"` → `"CONTEXT LABELED"`.
10. **Title text** "Email Inspector" → "Context Email Inspector".

Multi-occurrence transformations (via `globalStrReplace`):

11. **`hasDoctrineLabel` → `hasContextLabel`** (5 occurrences across
    type field, render, filter logic).
12. **`matchedDoctrineLabels` → `matchedContextLabels`** (2 occurrences).
13. **`withDoctrineLabel` → `withContextLabel`** (2 occurrences across
    type field + meta access).

**No backend changes in this batch** — 7g shipped the endpoint.

## What changes for the user

- **`/context/inspector`** is now a working Email Inspector page. Same
  layout as the doctrine version: account selector, search field,
  filter chips (all/detected/labeled/unlabeled), stat pills (TOTAL,
  CONTEXT LABELED, IN DATABASE, WOULD BE PICKED UP), email list with
  detection panel, expandable thread view, "Sync now" button. Amber
  theme.
- **What's the same vs doctrine**: account selector behavior, search
  flow, filter chips, animations, thread modal with reply detection.
- **What's renamed**: stat pill reads "CONTEXT LABELED" instead of
  "DOCTRINE LABELED". Detection panel says "Context label" instead of
  "Doctrine label". Internal field names (hasContextLabel etc.) match
  the 7g backend response shape.
- **What's hidden**: the vertical badge in the email row will likely
  not render (or render empty) because the 7g backend returns empty
  `vertical: ""`. The doctrine Inspector renders the badge with values
  like "Gaming UA" — the context Inspector won't.

## Files

```
batch7h/
├── apply-batch7h.mjs       # Idempotent patch + clone-from-email-inspector
├── audit-batch7h.mjs       # 9 passes × 3 rounds = 156 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build dashboard only (no
api-server changes). Mirror sync. Republish dashboard.

## Verify

After applying:

- The apply script self-verifies 28 anchors (3 identity + 4 + 3 + 5
  raw-fetch checks + 2 URL retargets + 5 field renames + 6 doctrine-leak
  absence checks).
- The audit script runs 156 checks (52 per round × 3 rounds): component
  identity, ThreadView/Accounts/Sent-emails raw fetch implementations,
  sync URL retargeted, all field renames present, all doctrine-flavored
  fields absent, typed hooks fully removed, doctrine email-inspector.tsx
  not regressed (still imports typed hooks, still uses hasDoctrineLabel,
  still hits /api/sync), B7c-B7g regression.

Browser smoke after dashboard republish + hard-reload:

1. Visit `/context/inspector`. Should render the new Inspector layout
   with amber theme, title "Context Email Inspector". Account selector
   shows the connected account. Stat pills include "CONTEXT LABELED".
2. With the expired-token state from current Gmail OAuth: the page
   will likely render an error card ("Failed to load sent emails")
   because the 7g backend returns `invalid_grant`. This is the same
   behavior as the doctrine `/inspector` page in the current state and
   confirms the new fetch path is reaching Gmail. Once Michael
   reconnects the account, both Inspectors light up with real data.
3. Visit `/inspector` (doctrine) — should render exactly as before
   with "DOCTRINE LABELED" stat pill, "Doctrine label" detection panel
   row, vertical badge populated, blue theme.
4. With a fresh Gmail OAuth, visit `/context/inspector` again. Stat
   pills should populate. Email rows should show `hasContextLabel: true`
   for any sent email with the user's `Context Followuper` label
   applied.

## Known residual

- The `vertical` badge will render empty on the context surface (7g
  intentionally skipped vertical inference). If the doctrine Inspector
  shows a "Gaming UA" or "CPS" badge per email, the context Inspector
  shows nothing for that. UI tweak to hide the badge entirely on the
  context surface is open — not a blocker.
- Polling: `useGetSentEmails` in the doctrine surface uses React Query
  defaults (refetchOnWindowFocus, etc.). The 7h raw-fetch replacement
  refetches only on (apiKey, selectedUserId, limit, search,
  refetchTrigger) changes. Stale data persists between manual refreshes
  on the context surface — same behavior as the 7e ContextPipeline.
- The 7d sidebar still lists the context inspector, pipeline, activity
  log nav items. All three are now real pages (no more placeholders).
- B7g endpoint still surfaces `invalid_grant` until Michael reconnects
  the Gmail account. Both Inspectors share that fate equally.
