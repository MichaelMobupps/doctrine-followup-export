#!/usr/bin/env bash
#
# Installs the deterministic structural linter into the Doctrine monorepo.
#
#   New files (additive):
#     src/lib/structuralLint.ts
#     src/tests/test-structural-lint.ts
#   Patched (idempotent, two surgical edits, anchored on untouched lines):
#     src/services/followupGenerator.ts
#
# Gates: typecheck -> tests -> build -> mirror. Backup + restore.sh provided.

set -uo pipefail

WORKSPACE="/home/runner/workspace"
API_PKG="$WORKSPACE/artifacts/api-server"
API_SRC="$API_PKG/src"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
BACKUP="$SCRIPT_DIR/backup"

say() { echo "[structural-lint] $*"; }
die() { echo ""; echo "[structural-lint] HALT: $*"; exit 1; }

[ -d "$API_SRC" ] || die "api-server src not found at $API_SRC"
[ -f "$PAYLOAD/lib/structuralLint.ts" ] || die "missing payload/lib/structuralLint.ts"
[ -f "$PAYLOAD/tests/test-structural-lint.ts" ] || die "missing payload/tests/test-structural-lint.ts"
[ -f "$API_SRC/services/followupGenerator.ts" ] || die "followupGenerator.ts not found"
[ -f "$API_SRC/lib/doctrineLint.ts" ] || die "doctrineLint.ts not found (type dependency)"

# ---- backup + restore script ----
mkdir -p "$BACKUP"
cp "$API_SRC/services/followupGenerator.ts" "$BACKUP/followupGenerator.ts.bak"
cat > "$SCRIPT_DIR/restore.sh" <<RESTORE
#!/usr/bin/env bash
set -e
cp "$BACKUP/followupGenerator.ts.bak" "$API_SRC/services/followupGenerator.ts"
rm -f "$API_SRC/lib/structuralLint.ts" "$API_SRC/tests/test-structural-lint.ts"
echo "[structural-lint] reverted followupGenerator.ts and removed new files."
echo "[structural-lint] re-run typecheck/build and re-mirror to finish the revert."
RESTORE
chmod +x "$SCRIPT_DIR/restore.sh"
say "backup written; restore.sh ready"

# ---- copy additive files ----
say "copying structuralLint.ts -> src/lib"
cp "$PAYLOAD/lib/structuralLint.ts" "$API_SRC/lib/structuralLint.ts"
say "copying test-structural-lint.ts -> src/tests"
cp "$PAYLOAD/tests/test-structural-lint.ts" "$API_SRC/tests/test-structural-lint.ts"

# ---- idempotent wiring patch ----
say "patching followupGenerator.ts (idempotent)"
python3 "$SCRIPT_DIR/apply.py" "$API_SRC/services/followupGenerator.ts" || die "patch failed (see message above). Nothing else changed; run restore.sh."

# ---- GATE 1: typecheck ----
say "GATE typecheck (tsc -b)"
( cd "$API_PKG" && pnpm run typecheck ) || die "typecheck failed. Run restore.sh to revert."
say "typecheck passed"

# ---- GATE 2: tests (new file first, then full suite) ----
say "GATE tests: new structural-lint suite"
( cd "$API_PKG" && node --import tsx --test src/tests/test-structural-lint.ts ) || die "structural-lint tests failed. Run restore.sh."
say "GATE tests: full suite"
( cd "$API_PKG" && node --import tsx --test src/tests/*.ts ) || die "full test suite failed. Run restore.sh."
say "tests passed"

# ---- GATE 3: build ----
say "GATE build"
( cd "$API_PKG" && pnpm run build ) || die "build failed. Run restore.sh."
say "build passed"

# ---- mirror ----
if [ -f "$WORKSPACE/source-code/sync.sh" ]; then
  say "mirroring artifacts -> source-code"
  bash "$WORKSPACE/source-code/sync.sh" || say "WARN: mirror failed (non-fatal)"
fi

echo ""
say "SUCCESS. Structural linter installed and wired."
echo ""
echo "  New deterministic rules now run in the follow-up loop, merged into the"
echo "  existing deterministic gate (rewrite-without-LLM when any rule fires):"
echo "    A. SENTENCE-COUNT   cap, default 7 (doctrine 6 + 1 tolerance)"
echo "    B. FORBIDDEN-DASH   em dash + en dash"
echo "    C. VERBATIM-OVERLAP long span copied from the original outreach"
echo "    D. FOLLOWUP-ACK     opening must reference prior outreach (tabled langs)"
echo ""
echo "  Tunable env (all optional, safe defaults):"
echo "    STRUCTURAL_LINT_ENABLED=0       kill switch for the whole layer"
echo "    STRUCTURAL_MAX_SENTENCES=7      sentence cap"
echo "    STRUCTURAL_OVERLAP_CHARS=45     overlap window (spaced scripts)"
echo "    STRUCTURAL_OVERLAP_CHARS_CJK=16 overlap window (dense scripts)"
echo "    STRUCTURAL_BAN_DASHES=0         disable rule B"
echo "    STRUCTURAL_CHECK_SENTENCES=0    disable rule A"
echo "    STRUCTURAL_CHECK_OVERLAP=0      disable rule C"
echo "    STRUCTURAL_REQUIRE_ACK=0        disable rule D"
echo ""
echo "  Revert anytime: bash $SCRIPT_DIR/restore.sh"
