#!/usr/bin/env node
/**
 * audit-batch7j.mjs — Beautiful-Squidward audit for Phase 7j.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7j] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7j] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxInspectorSrc   = read(join(DASH_BASE, "pages", "context-inspector.tsx"));
const inspectorSrc      = read(join(DASH_BASE, "pages", "email-inspector.tsx"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: vertical badge gated on vertLabel
  log(`-- PASS 1: vertical badge gated --`);
  pass(`Phase 7j comment for badge`, /Phase 7j: hide empty vertical badge — context emails carry no vertical\./.test(ctxInspectorSrc));
  pass(`Badge wrapped in vertLabel guard`, /\{vertLabel && <Badge variant="outline">\{vertLabel\}<\/Badge>\}/.test(ctxInspectorSrc));
  pass(`No bare unconditional badge render`, !/\n\s*<Badge variant="outline">\{vertLabel\}<\/Badge>\n/.test(ctxInspectorSrc));

  // PASS 2: detection panel gated on vertLabel
  log(`-- PASS 2: detection panel gated --`);
  pass(`Phase 7j comment for detection panel`, /Phase 7j: detection panel hides Vertical\/Reason rows when vertical inference is empty\./.test(ctxInspectorSrc));
  pass(`Detection panel wrapped in vertLabel guard`, /\{vertLabel && \(\s*\n\s*<>/.test(ctxInspectorSrc));
  pass(`Vertical row inside guard`, /<>[\s\S]*?<span style=\{\{ color: "var\(--text-secondary\)" \}\}>Vertical<\/span>[\s\S]*?<\/>/.test(ctxInspectorSrc));
  pass(`Reason row inside guard`, /<>[\s\S]*?<span style=\{\{ color: "var\(--text-secondary\)" \}\}>Reason<\/span>[\s\S]*?<\/>/.test(ctxInspectorSrc));

  // PASS 3: doctrine /api/stats — drafted_followups added (filtered branch)
  log(`-- PASS 3: doctrine /api/stats SELECT (filtered) --`);
  pass(`Phase 7j comment in filtered SELECT`, /Phase 7j: drafted_followups added so doctrine \/api\/stats matches the context shape\./.test(doctrineRouteSrc));
  pass(`Filtered SELECT projects draftedFollowups`, /draftedFollowups: sql<number>`sum\(case when \$\{followupsTable\.status\} = 'drafted' then 1 else 0 end\)`/.test(doctrineRouteSrc));

  // PASS 4: doctrine /api/stats — drafted_followups added (unfiltered branch)
  log(`-- PASS 4: doctrine /api/stats SELECT (unfiltered) --`);
  pass(`Phase 7j comment in unfiltered SELECT`, /Phase 7j \(unfiltered branch\): drafted_followups parity with context\./.test(doctrineRouteSrc));
  pass(`Both SELECT branches present (≥2 occurrences)`, (doctrineRouteSrc.match(/draftedFollowups: sql<number>/g) || []).length >= 2);

  // PASS 5: doctrine /api/stats — response includes drafted_followups
  log(`-- PASS 5: doctrine /api/stats response --`);
  pass(`Phase 7j comment for response`, /Phase 7j: drafted_followups added for shape parity with \/api\/context\/stats\./.test(doctrineRouteSrc));
  pass(`drafted_followups in res.json`, /drafted_followups: Number\(fs\?\.draftedFollowups\) \|\| 0,/.test(doctrineRouteSrc));

  // PASS 6: shape parity — doctrine and context return identical /stats keys
  log(`-- PASS 6: shape parity --`);
  pass(`Doctrine /stats response has total_sent`, /total_sent: Number\(ps\?\.totalSent\) \|\| 0,[\s\S]{0,300}drafted_followups: Number\(fs\?\.draftedFollowups\)/.test(doctrineRouteSrc));
  pass(`Context /stats response has drafted_followups`, /drafted_followups: Number\(fs\?\.draftedFollowups\) \|\| 0,/.test(ctxRouteSrc));
  pass(`Doctrine /stats response has all 6 fields`, (() => {
    const block = doctrineRouteSrc.match(/res\.json\(\{[\s\S]{0,400}?drafted_followups: Number\(fs\?\.draftedFollowups\) \|\| 0,\s*\}\);/);
    if (!block) return false;
    return /total_sent/.test(block[0]) && /unreplied/.test(block[0]) && /replied/.test(block[0]) && /queued_followups/.test(block[0]) && /sent_followups/.test(block[0]) && /drafted_followups/.test(block[0]);
  })());

  // PASS 7: doctrine email-inspector NOT regressed
  log(`-- PASS 7: doctrine inspector unchanged --`);
  pass(`Doctrine email-inspector still has unconditional vertical badge`, /<Badge variant="outline">\{vertLabel\}<\/Badge>/.test(inspectorSrc));
  pass(`Doctrine email-inspector still has Vertical row`, />Vertical<\/span>/.test(inspectorSrc));
  pass(`Doctrine email-inspector still has Reason row`, />Reason<\/span>/.test(inspectorSrc));

  // PASS 8: B7e-B7i regression
  log(`-- PASS 8: B7e-B7i regression --`);
  pass(`B7e: ContextPipeline default export`, /export default function ContextPipeline\(\)/.test(read(join(DASH_BASE, "pages", "context-pipeline.tsx"))));
  pass(`B7e: /context/cancel-followup endpoint`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7f: ContextActivityLog default export`, /export default function ContextActivityLog\(\)/.test(read(join(DASH_BASE, "pages", "context-activity.tsx"))));
  pass(`B7g: /context/gmail/sent-emails endpoint`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`B7h: ContextEmailInspector default export`, /export default function ContextEmailInspector\(\)/.test(ctxInspectorSrc));
  pass(`B7i: /context/my/activity endpoint`, /router\.get\("\/my\/activity"/.test(ctxRouteSrc));
  pass(`B7i: layout.tsx product-aware activity URL`, /const activityPath = onContext \? "api\/context\/my\/activity" : "api\/my\/activity";/.test(layoutSrc));

  // PASS 9: B7a-B7c regression
  log(`-- PASS 9: B7a-B7c regression --`);
  pass(`B7c: SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`B7c: SCOPE_DOCTRINE referenced ≥30 times`, (doctrineRouteSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`B7b: /context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7a: users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
  pass(`Layout still product-aware (data-product)`, /data-product=\{dataProduct\}/.test(layoutSrc));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
