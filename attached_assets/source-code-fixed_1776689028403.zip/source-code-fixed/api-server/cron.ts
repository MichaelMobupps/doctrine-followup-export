import cron from "node-cron";
import { syncEmails } from "./services/gmailSync";
import { processDueFollowups, autoQueueAllCampaigns } from "./services/scheduler";
import { logger } from "./lib/logger";

export function startCronJobs(): void {
  // Gmail sync + auto-queue every 15 minutes.
  cron.schedule("*/15 * * * *", async () => {
    logger.info("Running Gmail sync...");
    try {
      const result = await syncEmails();
      logger.info(
        { synced: result.synced, repliesDetected: result.repliesDetected },
        "Sync done",
      );
    } catch (err) {
      logger.error({ err }, "Sync error");
    }

    try {
      const autoQueued = await autoQueueAllCampaigns();
      if (autoQueued > 0) {
        logger.info({ autoQueued }, "Auto-queued follow-up stages");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue error");
    }
  });

  // Process due follow-ups four times per hour on the main tick.
  cron.schedule("5,20,35,50 * * * *", async () => {
    logger.info("Processing due follow-ups...");
    try {
      const result = await processDueFollowups();
      logger.info(
        { sent: result.sent, failed: result.failed },
        "Follow-up processing done",
      );
    } catch (err) {
      logger.error({ err }, "Scheduler error");
    }
  });

  // Fast tick every 3 minutes to pick up "Send now" items that were just
  // queued with scheduledAt=now and shouldn't wait 15 min for the main tick.
  // No longer tied to test mode — this runs for all users and is scoped to
  // picking up already-due rows only.
  cron.schedule("*/3 * * * *", async () => {
    try {
      const result = await processDueFollowups();
      if (result.sent > 0 || result.processed > 0) {
        logger.info(
          { sent: result.sent, failed: result.failed },
          "Fast-tick processed follow-ups",
        );
      }
    } catch (err) {
      logger.error({ err }, "Fast-tick error");
    }
  });

  logger.info("Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50, fast-tick @*/3");
}
