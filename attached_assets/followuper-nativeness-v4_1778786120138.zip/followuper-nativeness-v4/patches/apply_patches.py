#!/usr/bin/env python3
"""
apply_patches.py — Followuper v4 native-style + translationese patch script.

TypeScript port of the Prospector v4 patch surface. Idempotent. Anchor-based.
Each operation:
  - Reads the target file
  - Checks for the v3-baseline anchor
  - If FRESH → applies the edit
  - If ALREADY APPLIED → SKIPs cleanly
  - If anchor missing AND v4 marker missing → FAILs loudly
  - Writes a byte-identical .v3_backup beside each touched file

Run from the api-server source root:
    python3 patches/apply_patches.py [api-server-dir]

Rollback:
    for f in $(find api-server -name '*.v3_backup'); do cp "$f" "${f%.v3_backup}"; done
"""

import os
import shutil
import sys
from pathlib import Path
from typing import Tuple


# ============================================================================
# Operation primitives
# ============================================================================

class Op:
    def __init__(self, name: str, path: str):
        self.name = name
        self.path = path
        self.status = ""

    def apply(self, root: Path) -> Tuple[str, str]:
        raise NotImplementedError


class NewFile(Op):
    def __init__(self, name: str, path: str, content: str):
        super().__init__(name, path)
        self.content = content

    def apply(self, root: Path) -> Tuple[str, str]:
        target = root / self.path
        if target.exists():
            existing = target.read_text(encoding="utf-8")
            if existing == self.content:
                return ("SKIP", f"{self.path} already installed (byte-identical)")
            return ("FAIL", f"{self.path} exists but differs from payload")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(self.content, encoding="utf-8")
        return ("OK", f"{self.path} installed ({len(self.content)} bytes)")


class Patch(Op):
    def __init__(self, name: str, path: str, anchor: str, v4_marker: str,
                 new_text: str, expected_marker_count: int = 1):
        super().__init__(name, path)
        self.anchor = anchor
        self.v4_marker = v4_marker
        self.new_text = new_text
        # Number of marker occurrences expected in the file after this op
        # (and any earlier ops with the same marker) have been applied.
        # Default 1; for shared-marker ops (e.g. writer + rewriter both
        # patching the same v4.3 GREETING rule), the second op declares 2.
        self.expected_marker_count = expected_marker_count

    def apply(self, root: Path) -> Tuple[str, str]:
        target = root / self.path
        if not target.exists():
            return ("FAIL", f"{self.path} not found")
        text = target.read_text(encoding="utf-8")

        # Count-based idempotency: SKIP only when the marker has appeared
        # at least expected_marker_count times. This correctly handles
        # both standalone ops (count=1) and shared-marker ops where the
        # writer adds occurrence 1 and the rewriter adds occurrence 2.
        actual_count = text.count(self.v4_marker)
        if actual_count >= self.expected_marker_count:
            return ("SKIP", f"{self.path}: v4 marker present {actual_count}x (>= {self.expected_marker_count})")

        if self.anchor not in text:
            return ("FAIL", f"{self.path}: v3 anchor not found AND v4 marker count {actual_count} < {self.expected_marker_count}")

        backup = target.with_suffix(target.suffix + ".v3_backup")
        if not backup.exists():
            shutil.copy2(target, backup)

        new_text = text.replace(self.anchor, self.new_text, 1)
        if new_text == text:
            return ("FAIL", f"{self.path}: anchor replacement was a no-op")

        target.write_text(new_text, encoding="utf-8")
        return ("OK", f"{self.path}: anchor patched (marker now {new_text.count(self.v4_marker)}x)")


# ============================================================================
# Payload — v4 module source loaded from disk
# ============================================================================

SCRIPT_DIR = Path(__file__).resolve().parent
PAYLOAD_DIR = SCRIPT_DIR.parent / "api-server" / "lib"
NATIVENESS_V4_SRC = (PAYLOAD_DIR / "nativenessV4.ts").read_text(encoding="utf-8")
V4_TEST_SRC = (SCRIPT_DIR.parent / "api-server" / "tests" / "test-nativeness-v4.ts").read_text(encoding="utf-8")


# ============================================================================
# Anchors
# ============================================================================

# -- languageNativeness.ts: switch buildNativenessBlock forwarder to v4 --
LN_WRITER_ANCHOR = (
    'export function buildNativenessBlock(languageTag: string | null | undefined): string {\n'
    '  return buildNativenessBlockV3(languageTag);\n'
    '}'
)
LN_WRITER_NEW = (
    '// v4: forward to nativenessV4.buildNativenessBlockV4 which calls\n'
    '// buildNativenessBlockV3 internally and appends three additional\n'
    '// sections (NATIVE STYLE GUIDE, TRANSLATIONESE BAN, UNIVERSAL NAME\n'
    '// ADAPTATION). v3 behaviour is preserved exactly.\n'
    'export function buildNativenessBlock(languageTag: string | null | undefined): string {\n'
    '  return buildNativenessBlockV4(languageTag);\n'
    '}'
)
LN_WRITER_V4_MARKER = "return buildNativenessBlockV4(languageTag);"

# -- languageNativeness.ts: switch buildCriticNativenessBlock to wrap v3 + v4 critic block --
LN_CRITIC_ANCHOR = (
    '// v3 forwarder for buildCriticNativenessBlock — delegates to the\n'
    '// Reading-A++ critic block. Same policy as buildNativenessBlock.\n'
    'export function buildCriticNativenessBlock(languageTag: string | null | undefined): string {\n'
    '  return buildCriticNativenessBlockV3(languageTag);\n'
    '}'
)
LN_CRITIC_NEW = (
    '// v4 forwarder for buildCriticNativenessBlock — concatenates v3 critic\n'
    '// block (Reading-A++) with v4 critic block (native style guide +\n'
    '// translationese patterns + name adaptation for all 35 languages).\n'
    'export function buildCriticNativenessBlock(languageTag: string | null | undefined): string {\n'
    '  const v3 = buildCriticNativenessBlockV3(languageTag);\n'
    '  const v4 = buildCriticNativeStyleBlockV4(languageTag);\n'
    '  if (!v3 && !v4) return "";\n'
    '  if (!v4) return v3;\n'
    '  if (!v3) return v4;\n'
    '  return v3 + "\\n\\n" + v4;\n'
    '}'
)
LN_CRITIC_V4_MARKER = "buildCriticNativeStyleBlockV4(languageTag)"

# -- languageNativeness.ts: add v4 imports --
LN_IMPORT_ANCHOR = (
    'import { buildNativenessBlockV3, buildCriticNativenessBlockV3 } from "./nativenessV3";'
)
LN_IMPORT_NEW = (
    'import { buildNativenessBlockV3, buildCriticNativenessBlockV3 } from "./nativenessV3";\n'
    'import { buildNativenessBlockV4, buildCriticNativeStyleBlockV4 } from "./nativenessV4";'
)
LN_IMPORT_V4_MARKER = 'import { buildNativenessBlockV4, buildCriticNativeStyleBlockV4 } from "./nativenessV4";'

# -- doctrineLint.ts: switch aggregator import to v4 --
DL_IMPORT_ANCHOR = (
    'import { findAllNativenessViolations } from "./nativenessV3";'
)
DL_IMPORT_NEW = (
    '// v4: aggregator extended to include translationese patterns (literal\n'
    '// English-idiom translations) and universal greeting-name adaptation.\n'
    '// v3 keys are preserved exactly; v4 adds translationese and\n'
    '// greeting_name_adaptation, plus filters forbidden_singletons by the\n'
    '// per-language NATIVE_ENGLISH_LOANWORDS exemption set.\n'
    'import { findAllNativenessViolationsV4 } from "./nativenessV4";\n'
    'import { findAllNativenessViolations } from "./nativenessV3";'
)
DL_IMPORT_V4_MARKER = 'import { findAllNativenessViolationsV4 } from "./nativenessV4";'

# -- doctrineLint.ts: switch the detectNativenessViolations to use v4 + emit translationese --
DL_CALL_ANCHOR = (
    'export function detectNativenessViolations(body: string, languageTag: string): ViolationReport {\n'
    '  const report = findAllNativenessViolations(body, languageTag);'
)
DL_CALL_NEW = (
    'export function detectNativenessViolations(body: string, languageTag: string): ViolationReport {\n'
    '  // v4: use the v4 aggregator which extends v3 with translationese\n'
    '  // patterns + greeting-name-adaptation, and filters v3\'s singleton\n'
    '  // flag by the NATIVE_ENGLISH_LOANWORDS exemption set per language.\n'
    '  const report = findAllNativenessViolationsV4(body, languageTag);'
)
DL_CALL_V4_MARKER = "findAllNativenessViolationsV4(body, languageTag)"

# -- doctrineLint.ts: add translationese emission after the existing untransliterated-name block --
DL_EMIT_ANCHOR = (
    '    matches.push(...report.untransliterated_greeting_name);\n'
    '  }\n'
    '\n'
    '  if (issues.length === 0) return EMPTY_REPORT;'
)
DL_EMIT_NEW = (
    '    matches.push(...report.untransliterated_greeting_name);\n'
    '  }\n'
    '\n'
    '  // v4: translationese lint emission. Flags literal-translated English\n'
    '  // idioms (evento norte, gancho de, mistura de editores, contra o\n'
    '  // CPA, etc.) — patterns whose individual words are correct local-\n'
    '  // language tokens but whose combination reads as translated-from-\n'
    '  // English. Full per-language reference in nativenessV4.ts.\n'
    '  if (report.translationese.length > 0) {\n'
    '    const sample = report.translationese.slice(0, 5).map(t => `"${t}"`).join(", ");\n'
    '    issues.push(\n'
    '      `TRANSLATIONESE-PATTERN \\u2014 literal-translated English idiom(s) ` +\n'
    '      `inside ${languageTag} prose (${sample}). v4 native-style rule: ` +\n'
    '      `native speakers do not use these constructions even though the ` +\n'
    '      `individual words are correct local-language tokens.`\n'
    '    );\n'
    '    suggestions.push(\n'
    '      "Rewrite each flagged phrase using native alternatives from the " +\n'
    '      "v4 NATIVE STYLE GUIDE for this language."\n'
    '    );\n'
    '    matches.push(...report.translationese);\n'
    '  }\n'
    '\n'
    '  if (issues.length === 0) return EMPTY_REPORT;'
)
DL_EMIT_V4_MARKER = "TRANSLATIONESE-PATTERN"

# -- followupPrompts.ts: add criteria 11, 12, 13 to the critic system prompt --
# Anchor on the end of criterion 10 (which ends with a specific sentence
# about scoring language_naturalness).
FP_CAT10_ANCHOR = (
    "If the greeting name is in Latin and the target uses a non-Latin script, "
    "score language_naturalness 1-2 and set needs_rewrite = true; this is a "
    "high-visibility nativeness failure since it is the first thing the recipient sees."
)
FP_CAT10_NEW = (
    "If the greeting name is in Latin and the target uses a non-Latin script, "
    "score language_naturalness 1-2 and set needs_rewrite = true; this is a "
    "high-visibility nativeness failure since it is the first thing the recipient sees.\n\n"
    "11. TRANSLATIONESE PATTERNS (v4 native-style layer, severity: block, applies to "
    "EVERY non-English email): The email contains a literal English-idiom translation "
    "whose individual words are correct local-language tokens but whose combination "
    "reads as translated-from-English. Native speakers in the target language do NOT "
    "use these constructions. Flag every match. Portuguese examples to flag: "
    "\"evento norte\" (literal \"north star event\" — rephrase as \"métrica principal\" "
    "or omit), \"gancho de\" (literal \"hook\" — \"gancho\" means physical hanger in "
    "PT, use \"atrativo\" or \"promessa\"), \"mistura de editores\" (literal \"publisher "
    "mix\" — use \"mix de editores\" with English loanword \"mix\"), \"posicionamentos "
    "editoriais\" (literal \"editorial placements\"), \"em sobreposição direta\" (literal "
    "\"in direct overlap\"), \"contra o CPA\" (literal \"vs the CPA\" — use \"versus\" "
    "or \"comparado a\"), \"O ponto específico aqui é que\" (literal narrative tic), "
    "\"A forma como trabalhamos é rodar\" (hyper-colloquial spoken register in formal "
    "B2B), \"Ponderamos editores\" (literal \"we weight publishers\"), \"safra de "
    "usuários\" mixed with \"coorte\" (inconsistent — pick \"coorte\"). Spanish examples: "
    "\"evento norte\", \"gancho de\", \"mezcla de editores\", \"posicionamientos "
    "editoriales\", \"en superposición directa\", \"contra el CPA\", \"el punto "
    "específico aquí es que\", \"ponderamos publishers\". Other languages have parallel "
    "literal translations of \"north star\", \"hook\", \"publisher mix\", \"in direct "
    "overlap\", \"vs\", \"the specific point here is that\", \"the way we work is to "
    "run\" — all forbidden. See nativenessV4.TRANSLATIONESE_PATTERNS for the full "
    "~170-pattern list per language. Regional variant leakage: Spain-Spanish vocabulary "
    "in a LatAm-Spanish email (\"ordenador\", \"vosotros\", \"os escribo\"), European "
    "Portuguese in a Brazilian Portuguese email (\"estamos a fazer\" progressive form), "
    "Traditional Chinese tokens in a Simplified Chinese email (伺服器, 網路, 資料, 軟體, "
    "硬體), Egyptian colloquialisms in MSA Arabic (\"عايز\", \"مش كده\") all count as "
    "translationese. Score language_naturalness 1-2 and set needs_rewrite = true.\n\n"
    "12. NATIVE-STRUCTURE SCAFFOLD (v4 native-style layer, severity: block, applies to "
    "EVERY non-English email): The non-English email lacks the structural elements that "
    "distinguish a native B2B sales email from an English-translated one. Flag every "
    "missing element. Required structural elements: (a) Social opener after the "
    "greeting line. Examples: Brazilian Portuguese \"Olá, NAME. Como vai?\"; LatAm "
    "Spanish \"Hola, NAME. ¿Cómo estás?\"; Japanese \"突然のご連絡失礼いたします。\"; "
    "Korean \"갑작스러운 연락 드려 죄송합니다.\"; Chinese \"冒昧打扰\". A greeting line "
    "\"Olá NAME,\" with no social opener and immediate business content is a violation. "
    "(b) At least one connector phrase from the language's native cohesion repertoire "
    "weaving claims together. Portuguese: \"Sabemos que\", \"Considerando que\", \"Vale "
    "mencionar que\", \"Com isso\", \"Além disso\". Spanish: \"Sabemos que\", "
    "\"Considerando que\", \"Vale la pena mencionar que\", \"Además\". Stacking 4-fact "
    "declarative sentences without connectors is a violation. (c) At least one softener "
    "phrase for the differentiator claim or the CTA. Portuguese: \"acredito que\", "
    "\"pode fazer sentido\". Spanish: \"creo que\", \"puede tener sentido\". Raw "
    "declarative CTAs like \"Faz sentido X?\" / \"¿Tiene sentido X?\" without softener "
    "are violations. (d) Collaborative two-sentence close with a permission ask and "
    "explicit time-frame. Portuguese: \"Acredito que pode fazer sentido avaliarmos um "
    "piloto comparativo... Você está disponível para falarmos na próxima semana?\" "
    "Spanish: \"Creo que puede tener sentido evaluar... ¿Tendrías disponibilidad para "
    "conversar la próxima semana?\" A single-sentence declarative-question close is a "
    "violation. See nativenessV4.NATIVE_STYLE_GUIDES for the full per-language "
    "structural scaffold across all 35 languages. Score language_naturalness 1-2 and "
    "set needs_rewrite = true.\n\n"
    "13. PRODUCTION-FAILURE PATTERN CHECKLIST (v4.2 universal native-quality layer, "
    "severity: block, applies to EVERY non-English email): These eight checks (13a-13h) "
    "are calibrated against gold-reference native salesperson emails and against "
    "specific failure modes observed in pre-v4 production emails. Each check is a "
    "language-AGNOSTIC failure PRINCIPLE — the SPECIFIC phrases vary by target language "
    "but the failure pattern applies universally. Flag every violation individually. "
    "13a. GREETING WITHOUT SOCIAL OPENER (all languages). Native B2B emails open with "
    "greeting + social-pleasantry line BEFORE going into business. Native patterns: "
    "pt-BR \"Olá, NAME. Como vai?\"; es-LA \"Hola, NAME. ¿Cómo estás?\"; ja \"NAME様  "
    "突然のご連絡失礼いたします。\" (Japanese REQUIRES apologetic opener); zh \"NAME "
    "您好，冒昧打扰，\"; ko \"NAME 님, 갑작스러운 연락 드려 죄송합니다.\"; ar \"السلام "
    "عليكم NAME، أتمنى أن تكون بخير.\"; ru \"Здравствуйте, NAME. Надеюсь, что у Вас "
    "всё хорошо.\"; he \"שלום NAME, מקווה שאתה במצב טוב.\"; hi \"नमस्ते NAME, आशा है "
    "आप कुशल हैं।\"; th \"เรียน NAME, หวังว่าคุณสบายดี.\"; vi \"Kính gửi anh/chị NAME, "
    "Hy vọng anh/chị nhận được email này khi đang khỏe.\" "
    "13b. STACKED FACTS WITHOUT COHESION MARKERS (all languages). Any paragraph with 3+ "
    "factual claims and zero cohesion markers from the language's repertoire is a "
    "violation. Per-language markers: pt \"Sabemos que / Considerando que / Vale "
    "mencionar que / Acredito que / Com isso / Além disso\"; es \"Sabemos que / "
    "Considerando que / Vale la pena mencionar que / Creo que / Con esto / Además\"; "
    "it \"Sappiamo che / Considerando che / Inoltre\"; fr \"Nous savons que / "
    "Considérant que / Par ailleurs\"; de \"Wir wissen, dass / Angesichts der Tatsache, "
    "dass / Darüber hinaus\"; ru \"Мы знаем, что / Учитывая, что / Кроме того\"; ja "
    "\"〜と存じます / また、 / さらに、\"; zh \"我们了解到 / 考虑到 / 此外\"; ko \"〜을 "
    "알고 있습니다 / 또한\"; ar \"نعلم أن / علاوة على ذلك\"; he \"אנו יודעים ש / בנוסף\"; "
    "hi \"हम जानते हैं कि / इसके अलावा\"; th \"เราทราบว่า / นอกจากนี้\"; vi \"Chúng "
    "tôi biết rằng / Ngoài ra\". "
    "13c. DIFFERENTIATOR CLAIM WITHOUT SOFTENER (all languages). Main value claims must "
    "be hedged. Per-language softeners: pt \"acredito que / pode fazer sentido\"; es "
    "\"creo que / puede tener sentido\"; it \"ritengo che / potrebbe avere senso\"; fr "
    "\"je pense que / il pourrait avoir du sens\"; de \"ich glaube, dass / es könnte "
    "Sinn machen\"; ru \"полагаю, что / может иметь смысл\"; ja \"〜と存じます / もし"
    "よろしければ\"; zh \"我们认为 / 或许可以\"; ko \"〜라고 생각합니다 / 혹시 괜찮으시"
    "다면\"; ar \"أعتقد أن / قد يكون من المفيد\"; he \"אני מאמין ש / ייתכן שיהיה "
    "הגיוני\"; hi \"मेरा मानना है कि\"; th \"คิดว่า\"; vi \"chúng tôi tin rằng\". "
    "13d. CTA VERB-FORM CHECK (all languages). The CTA must use the target language's "
    "native collaborative grammar — NOT a declarative-infinitive form translated from "
    "English. Universal failure: CTA verb in dictionary form when the target language "
    "uses inflected/subjunctive/permission-asking grammar. pt: subjunctive plural "
    "\"falarmos / avaliarmos / conversarmos\" or two-sentence \"Você está disponível?\". "
    "es: \"conversemos / evaluemos\" or \"¿Tendrías disponibilidad?\". it: \"possiamo "
    "valutare / parlarne\". fr: conditional \"pourrions-nous évaluer / seriez-vous "
    "disponible\". de: Konjunktiv II \"könnten wir prüfen / hätten Sie Zeit\". ru: "
    "subjunctive plural \"могли бы мы обсудить\". ja: keigo permission \"ご相談させて"
    "いただけますでしょうか\". zh: 您 + 是否方便. ko: 존댓말 permission \"가능하실까요\". "
    "ar: \"هل ستكون متاحًا للتحدث\". he: \"האם תהיה זמין לשיחה\". hi: \"क्या आप बात "
    "करने के लिए उपलब्ध होंगे\". th: \"คุณสะดวกที่จะคุยในสัปดาห์หน้าหรือไม่\". vi: "
    "\"Anh/chị có thể sắp xếp thời gian trao đổi không\". "
    "13e. TECHNICAL TERMINOLOGY INCONSISTENCY (all languages). Same technical concept "
    "rendered with two LOCAL-language terms in the same email. pt \"coorte\" vs "
    "\"safra\" — pick \"coorte\". es \"cohorte\" vs \"grupo\" — pick \"cohorte\". ru "
    "\"когорта\" vs \"группа\" vs \"аудитория\" — pick \"когорта\". ja \"コホート\" vs "
    "\"グループ\" — pick \"コホート\". zh \"群组\" vs \"队列\" vs \"分群\" — pick one. "
    "Apply same principle to any other concept and language. "
    "13f. SPECIFIC BANNED PHRASES per target language (full ~170-pattern list in "
    "nativenessV4.TRANSLATIONESE_PATTERNS). Flag every match. pt-BR: \"evento norte\", "
    "\"gancho de/do/com\", \"mistura de editores\", \"Ponderamos editores\", \"O ponto "
    "específico aqui é que\", \"A forma como X é Y\", \"posicionamentos editoriais\", "
    "\"em sobreposição direta\", \"competição por lance no leilão\", \"safra de "
    "usuários\", \"controlamos qualidade em várias camadas\", \"redirecionamento via "
    "DSP sobre usuários\", \"no sinal de conversão\", \"contra o CPA\", \"contra a "
    "(persistência|retenção|conversão)\". es-LA: \"evento norte\", \"gancho de\", "
    "\"mezcla de editores\", \"posicionamientos editoriales\", \"en superposición "
    "directa\", \"contra el CPA\", \"el punto específico aquí es que\", \"ponderamos "
    "publishers\". it: \"evento stella polare\", \"gancio di/del\", \"miscela di "
    "editori\", \"in sovrapposizione diretta\", \"contro il CPA\". fr: \"événement "
    "étoile du nord\", \"l'hameçon\", \"mélange d'éditeurs\", \"en superposition "
    "directe\", \"contre le CPA\". de: \"Nordstern-Event/Metrik\", \"der Köder\", "
    "\"Publisher-Mischung\", \"in direkter Überlappung\", \"gegen den CPA\". ru: "
    "\"событие полярная звезда\", \"крючок для\", \"смесь издателей\", \"против CPA\", "
    "\"взвешиваем издателей\". ja: \"北極星イベント\", \"パブリッシャーミックス\", "
    "\"CPAに対して\". zh: \"北极星事件\", \"发布商混合\", \"对抗CPA\". ko: \"북극성 "
    "이벤트\", \"퍼블리셔 믹스\", \"CPA에 반대\". ar: \"حدث النجم الشمالي\", \"خطاف من/في\". "
    "he: \"אירוע כוכב הצפון\", \"וו של/עבור\". hi: \"उत्तरी तारा घटना\", \"CPA के "
    "खिलाफ\". th: \"เหตุการณ์ดาวเหนือ\", \"เทียบกับ CPA\". vi: \"sự kiện sao bắc "
    "đẩu\", \"chống lại CPA\". "
    "13g. REGIONAL VARIANT LEAKAGE. pt → pt-BR default (reject EU PT \"estamos a "
    "fazer\", \"ordenador\"). es → es-LatAm default (reject Spain \"ordenador\", "
    "\"vosotros\", \"os escribo\", \"móvil\" in adtech). zh → zh-CN (Simplified "
    "Mainland) default (reject Traditional \"伺服器\", \"網路\", \"資料\", \"軟體\", "
    "\"硬體\", \"視頻\"). ar → MSA default (reject Egyptian \"عايز\", \"مش كده\"). fr "
    "→ fr-FR default unless fr-CA configured. en → market-appropriate variant (us, uk, "
    "in, au). "
    "13h. LOANWORD INCONSISTENCY (adtech-heavy languages). Some target languages have "
    "NATIVE English loanwords that MUST stay in English; others require translation. "
    "pt-BR, es-LatAm, it, nl, id, ms, fil/tl: KEEP \"performance\", \"fee\", "
    "\"players\", \"mix\", \"mobile\", \"app/apps\", \"blog/blogs\", \"ROAS\", \"LTV\", "
    "\"KPI/KPIs\", \"CTV\", \"RTG\", \"AB\" (testes AB / tests AB) in English. "
    "Translating these is a violation. \"mix de editores\" ACCEPTABLE; \"mistura de "
    "editores\" / \"mezcla de editores\" VIOLATION. de, fr, ru, ja, zh, ko, ar, he, "
    "hi, th, vi: NO loanword exemption — translate the same concepts (\"performance\" "
    "in German is \"Leistung\"). See nativenessV4.NATIVE_ENGLISH_LOANWORDS for the "
    "per-language set. Score language_naturalness 1-2 and set needs_rewrite = true for "
    "any 13a-13h violation."
)
FP_CAT10_V4_MARKER = "13. PRODUCTION-FAILURE PATTERN CHECKLIST"

# -- test-nativeness-v3.ts: update the 2 strict-equality forwarder tests --
# Under v4 the wrapper functions return v3 content + v4 sections appended.
# The strict-equality assertions in the v3 test file need to be relaxed to
# "wrapper starts with v3 content AND includes v4 sections". This keeps the
# v3 test count stable (67/67) and documents the v4 contract change.
TEST_WRITER_ANCHOR = (
    'test.test("buildNativenessBlock forwards to v3 for non-English", () => {\n'
    '  const directV3 = buildNativenessBlockV3("ru");\n'
    '  const viaWrapper = buildNativenessBlock("ru");\n'
    '  assert.equal(viaWrapper, directV3);\n'
    '  assert.ok(viaWrapper.includes("Reading A++"));\n'
    '});'
)
TEST_WRITER_NEW = (
    'test.test("buildNativenessBlock forwards to v3 for non-English", () => {\n'
    '  // v4: wrapper now returns v3 content + v4 sections (NATIVE STYLE\n'
    '  // GUIDE, TRANSLATIONESE BAN, UNIVERSAL NAME ADAPTATION) appended.\n'
    '  // The v3 content must remain the prefix; the v4 sections are added\n'
    '  // after.\n'
    '  const directV3 = buildNativenessBlockV3("ru");\n'
    '  const viaWrapper = buildNativenessBlock("ru");\n'
    '  assert.ok(viaWrapper.startsWith(directV3),\n'
    '    "v4 wrapper must begin with full v3 block verbatim");\n'
    '  assert.ok(viaWrapper.includes("Reading A++"));\n'
    '  assert.ok(viaWrapper.includes("NATIVE STYLE GUIDE"),\n'
    '    "v4 wrapper must include NATIVE STYLE GUIDE section");\n'
    '});'
)
TEST_WRITER_V4_MARKER = "v4 wrapper must begin with full v3 block verbatim"

TEST_CRITIC_ANCHOR = (
    'test.test("buildCriticNativenessBlock forwards to v3 for non-English", () => {\n'
    '  const directV3 = buildCriticNativenessBlockV3("th");\n'
    '  const viaWrapper = buildCriticNativenessBlock("th");\n'
    '  assert.equal(viaWrapper, directV3);\n'
    '  assert.ok(viaWrapper.includes("Reading A++") || viaWrapper.includes("v3 Reading"));\n'
    '});'
)
TEST_CRITIC_NEW = (
    'test.test("buildCriticNativenessBlock forwards to v3 for non-English", () => {\n'
    '  // v4: wrapper now concatenates v3 critic block (Reading-A++) with v4\n'
    '  // critic block (native style + translationese + name adaptation).\n'
    '  const directV3 = buildCriticNativenessBlockV3("th");\n'
    '  const viaWrapper = buildCriticNativenessBlock("th");\n'
    '  assert.ok(viaWrapper.startsWith(directV3),\n'
    '    "v4 critic wrapper must begin with full v3 critic block verbatim");\n'
    '  assert.ok(viaWrapper.includes("Reading A++") || viaWrapper.includes("v3 Reading"));\n'
    '  assert.ok(viaWrapper.includes("v4 NATIVE STYLE") ||\n'
    '            viaWrapper.includes("TRANSLATIONESE PATTERNS"),\n'
    '    "v4 critic wrapper must include v4 sections");\n'
    '});'
)
TEST_CRITIC_V4_MARKER = "v4 critic wrapper must begin with full v3 critic block verbatim"

# ============================================================================
# v4.3 HOTFIX — writer/rewriter GREETING instruction must explicitly handle
# non-Latin-script targets. The original GREETING instruction had "use it
# (e.g., 'Hi Sarah,')" as the only example, which gave the LLM permission to
# write Latin-script names inside non-Latin-script emails. This is the
# root cause of failures like "เรียน Thasawan," in Thai outreach. The v4
# UNIVERSAL NAME ADAPTATION block lives later in the prompt and competes
# with — and loses to — the explicit Latin example here.
#
# The hotfix replaces the weak instruction with a script-aware, non-
# bypassable rule that lists the 14+ non-Latin-script languages explicitly
# and shows BAD→GOOD examples in 8 scripts.
# ============================================================================

GREETING_WRITER_ANCHOR = (
    '- GREETING: ALWAYS start the email with a greeting. If a first name is provided, '
    'use it (e.g., "Hi Sarah,"). If the context says no name is on file, use a NEUTRAL '
    'language-appropriate greeting ("Hi there," / "Shalom," / "Bonjour," / "Hola," / '
    'etc.). NEVER use an email address, email local-part, or username as a greeting name. '
    'If what you were given looks like an email (contains @) or looks like a website '
    'handle (lowercase jammed letters), treat it as "no name" and use the neutral greeting.'
)
GREETING_NEW_TEXT_WRITER = (
    '- GREETING NAME SCRIPT (CRITICAL — non-bypassable rule that overrides any default to "use the name as provided"): '
    'The script of the prospect\'s first name in the greeting line MUST match the script of the target language. '
    'There are three cases. '
    'CASE 1 — Non-Latin-script target language (Thai th, Chinese zh, Japanese ja, Korean ko, Arabic ar, Hebrew he, '
    'Persian fa, Urdu ur, Hindi hi, Bengali bn, Tamil ta, Telugu te, Marathi mr, Russian ru, Ukrainian uk, Greek el, '
    'Amharic am, Georgian ka, Armenian hy): you MUST transliterate the Latin-script first name into the target script. '
    'NEVER write the prospect\'s name in Latin/English letters inside a non-Latin-script email — this is a hard '
    'failure that the email cannot ship with. FORBIDDEN → REQUIRED examples: '
    'Thai "เรียน Thasawan," → "เรียน ทศวรรณ,"; '
    'Thai "เรียน Songsitt," → "เรียน ทรงสิทธิ์,"; '
    'Hindi "नमस्ते Manish," → "नमस्ते मनीश,"; '
    'Japanese "Yuki様," → "ゆき様," or "ユキ様,"; '
    'Korean "Manish 님," → "마니쉬 님,"; '
    'Chinese "您好 Vinicius," → "您好 维尼修斯,"; '
    'Russian "Здравствуйте, John," → "Здравствуйте, Джон,"; '
    'Arabic "مرحبًا John," → "مرحبًا جون,"; '
    'Hebrew "שלום John," → "שלום ג\'ון,"; '
    'Greek "Γεια σας John," → "Γεια σας Τζον,". '
    'Pick a reasonable phonetic transliteration if no canonical form is known and use it consistently. '
    'The sender\'s signature at the bottom of the email stays in Latin; ONLY the recipient\'s greeting name is transliterated. '
    'CASE 2 — Latin-script-with-diacritic target language (Portuguese pt, Spanish es, French fr, Italian it, Vietnamese vi, '
    'Czech cs, Polish pl, Hungarian hu, German de, Romanian ro, Turkish tr, Swedish sv, Norwegian no/nb, Danish da, Finnish fi): '
    'apply the language\'s native orthography to the name if a canonical form exists. Examples: '
    'Vinicius → Vinícius (pt); Jose → José, Maria → María (es); Tuan → Tuấn, Huong → Hương (vi); '
    'Tomas → Tomáš (cs); Lukasz → Łukasz (pl); Andras → András (hu); Helene → Hélène, Francois → François (fr); '
    'Jurgen → Jürgen, Andre → André (de). If unsure about the diacritic form, KEEP the ASCII spelling rather than guess incorrectly. '
    'CASE 3 — ASCII-Latin-script target language (English en, Dutch nl, Indonesian id, Malay ms, Swahili sw, Filipino/Tagalog fil/tl): '
    'use the prospect\'s first name as provided (e.g., "Hi Sarah,"). '
    '- GREETING (general format rules): ALWAYS start the email with a greeting in the target language\'s standard format. '
    'If no name is on file, use a NEUTRAL language-appropriate greeting in the TARGET SCRIPT '
    '("Hi there," / "שלום," / "Bonjour," / "Hola," / "您好，" / "สวัสดี," / "नमस्ते," etc.). '
    'NEVER use an email address, email local-part, or username as a greeting name. If what you were given looks like an email '
    '(contains @) or looks like a website handle (lowercase jammed letters), treat it as "no name" and use the neutral greeting.'
)
GREETING_WRITER_V4_MARKER = "GREETING NAME SCRIPT (CRITICAL — non-bypassable rule"

# The rewriter system prompt has a near-identical GREETING line but with the
# extra "in the context" phrasing.
GREETING_REWRITER_ANCHOR = (
    '- GREETING: ALWAYS start the email with a greeting. If a first name is provided in the context, '
    'use it (e.g., "Hi Sarah,"). If the context says no name is on file, use a NEUTRAL '
    'language-appropriate greeting ("Hi there," / "Shalom," / "Bonjour," / "Hola," / '
    'etc.). NEVER use an email address, email local-part, or username as a greeting name. '
    'If what you were given looks like an email (contains @) or looks like a website '
    'handle (lowercase jammed letters), treat it as "no name" and use the neutral greeting.'
)
# Same target text for the rewriter
GREETING_REWRITER_V4_MARKER = "GREETING NAME SCRIPT (CRITICAL — non-bypassable rule"


# ============================================================================
# Operation list
# ============================================================================

OPS = [
    NewFile(
        name="install nativenessV4 module",
        path="api-server/lib/nativenessV4.ts",
        content=NATIVENESS_V4_SRC,
    ),
    NewFile(
        name="install v4 test suite",
        path="api-server/tests/test-nativeness-v4.ts",
        content=V4_TEST_SRC,
    ),
    Patch(
        name="languageNativeness: add v4 imports",
        path="api-server/lib/languageNativeness.ts",
        anchor=LN_IMPORT_ANCHOR,
        v4_marker=LN_IMPORT_V4_MARKER,
        new_text=LN_IMPORT_NEW,
    ),
    Patch(
        name="languageNativeness: switch buildNativenessBlock forwarder to v4",
        path="api-server/lib/languageNativeness.ts",
        anchor=LN_WRITER_ANCHOR,
        v4_marker=LN_WRITER_V4_MARKER,
        new_text=LN_WRITER_NEW,
    ),
    Patch(
        name="languageNativeness: extend buildCriticNativenessBlock with v4 critic block",
        path="api-server/lib/languageNativeness.ts",
        anchor=LN_CRITIC_ANCHOR,
        v4_marker=LN_CRITIC_V4_MARKER,
        new_text=LN_CRITIC_NEW,
    ),
    Patch(
        name="doctrineLint: add v4 aggregator import",
        path="api-server/lib/doctrineLint.ts",
        anchor=DL_IMPORT_ANCHOR,
        v4_marker=DL_IMPORT_V4_MARKER,
        new_text=DL_IMPORT_NEW,
    ),
    Patch(
        name="doctrineLint: switch detectNativenessViolations to v4 aggregator",
        path="api-server/lib/doctrineLint.ts",
        anchor=DL_CALL_ANCHOR,
        v4_marker=DL_CALL_V4_MARKER,
        new_text=DL_CALL_NEW,
    ),
    Patch(
        name="doctrineLint: emit translationese lint violations",
        path="api-server/lib/doctrineLint.ts",
        anchor=DL_EMIT_ANCHOR,
        v4_marker=DL_EMIT_V4_MARKER,
        new_text=DL_EMIT_NEW,
    ),
    Patch(
        name="followupPrompts: add critic criteria 11, 12, 13 after criterion 10",
        path="api-server/services/followupPrompts.ts",
        anchor=FP_CAT10_ANCHOR,
        v4_marker=FP_CAT10_V4_MARKER,
        new_text=FP_CAT10_NEW,
    ),
    Patch(
        name="test-nativeness-v3: relax writer-wrapper strict equality for v4",
        path="api-server/tests/test-nativeness-v3.ts",
        anchor=TEST_WRITER_ANCHOR,
        v4_marker=TEST_WRITER_V4_MARKER,
        new_text=TEST_WRITER_NEW,
    ),
    Patch(
        name="test-nativeness-v3: relax critic-wrapper strict equality for v4",
        path="api-server/tests/test-nativeness-v3.ts",
        anchor=TEST_CRITIC_ANCHOR,
        v4_marker=TEST_CRITIC_V4_MARKER,
        new_text=TEST_CRITIC_NEW,
    ),
    # v4.3 HOTFIX — writer/rewriter GREETING instruction must transliterate
    # names in non-Latin-script target languages (Thai/Chinese/Japanese/
    # Korean/Arabic/Hebrew/Hindi/Russian/etc). Root cause of the
    # "เรียน Thasawan," production failure.
    Patch(
        name="followupPrompts: v4.3 hotfix writer GREETING script-aware",
        path="api-server/services/followupPrompts.ts",
        anchor=GREETING_WRITER_ANCHOR,
        v4_marker=GREETING_WRITER_V4_MARKER,
        new_text=GREETING_NEW_TEXT_WRITER,
    ),
    Patch(
        name="followupPrompts: v4.3 hotfix rewriter GREETING script-aware",
        path="api-server/services/followupPrompts.ts",
        anchor=GREETING_REWRITER_ANCHOR,
        v4_marker=GREETING_REWRITER_V4_MARKER,
        new_text=GREETING_NEW_TEXT_WRITER,
        expected_marker_count=2,  # writer set count=1 first; this op brings it to 2
    ),
]


def main():
    if len(sys.argv) > 1:
        root = Path(sys.argv[1]).resolve()
    else:
        root = Path.cwd()

    print(f"Followuper v4 patch script — applying {len(OPS)} operations")
    print(f"Target root: {root}")
    print()

    counts = {"OK": 0, "SKIP": 0, "FAIL": 0}
    for op in OPS:
        try:
            status, msg = op.apply(root)
        except Exception as exc:
            status, msg = ("FAIL", f"{type(exc).__name__}: {exc}")
        op.status = status
        counts[status] = counts.get(status, 0) + 1
        sigil = {"OK": "  OK  ", "SKIP": " SKIP ", "FAIL": " FAIL "}[status]
        print(f"[{sigil}] {op.name}")
        print(f"         {msg}")

    print()
    print(f"Summary: {counts['OK']} OK, {counts['SKIP']} SKIP, {counts['FAIL']} FAIL")
    if counts["FAIL"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
