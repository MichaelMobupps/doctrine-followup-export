#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = process.cwd();

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DB_BASE = process.env.DB_BASE || "lib/db/src";
const MIRROR_BASE = process.env.MIRROR_BASE || "source-code";

const payloadRoot = path.join(__dirname, "payload", "api-server");

const files = [
  "services/gmailClient.ts",
  "services/timingEngine.ts",
  "services/scheduler.ts",
  "services/gmailSync.ts",
  "cron.ts",
  "routes/doctrine.ts",
];

function abs(...parts) {
  return path.join(repoRoot, ...parts);
}

function read(file) {
  return fs.readFileSync(file, "utf8");
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

function ensureFile(file, label) {
  assert(fs.existsSync(file), `${label} missing: ${file}`);
}

function copyIfChanged(source, target) {
  ensureFile(source, "Payload file");
  ensureFile(target, "Target file");
  const next = read(source);
  const current = read(target);
  if (current === next) {
    console.log(`UNCHANGED ${path.relative(repoRoot, target)}`);
    return false;
  }
  fs.copyFileSync(target, `${target}.batch3b.bak`);
  fs.writeFileSync(target, next);
  console.log(`UPDATED   ${path.relative(repoRoot, target)}`);
  return true;
}

function copyMirrorIfPresent(source, mirrorTarget) {
  if (!fs.existsSync(mirrorTarget)) return false;
  const next = read(source);
  const current = read(mirrorTarget);
  if (current === next) {
    console.log(`MIRROR OK ${path.relative(repoRoot, mirrorTarget)}`);
    return false;
  }
  fs.writeFileSync(mirrorTarget, next);
  console.log(`MIRROR   ${path.relative(repoRoot, mirrorTarget)}`);
  return true;
}

function includes(file, text, label) {
  assert(read(file).includes(text), `${label} missing in ${file}: ${text}`);
}

function regex(file, pattern, label) {
  assert(pattern.test(read(file)), `${label} missing in ${file}: ${pattern}`);
}

function main() {
  const apiBase = abs(API_BASE);
  ensureFile(apiBase, "API_BASE directory");

  const usersSchema = abs(DB_BASE, "schema", "users.ts");
  const followupsSchema = abs(DB_BASE, "schema", "followups.ts");
  ensureFile(usersSchema, "Batch 3a users schema");
  ensureFile(followupsSchema, "Batch 3a followups schema");
  includes(usersSchema, "followupMode", "Batch 3a followupMode field");
  includes(usersSchema, "draftStageTiming", "Batch 3a draftStageTiming field");
  includes(followupsSchema, "draftMessageId", "Batch 3a draftMessageId field");

  let changed = 0;
  for (const rel of files) {
    const source = path.join(payloadRoot, rel);
    const target = path.join(apiBase, rel);
    if (copyIfChanged(source, target)) changed++;

    const mirrorRel = rel === "cron.ts" ? path.join(MIRROR_BASE, "api-server", "cron.ts") : path.join(MIRROR_BASE, "api-server", rel);
    copyMirrorIfPresent(source, abs(mirrorRel));
  }

  const gmailClient = path.join(apiBase, "services", "gmailClient.ts");
  const timingEngine = path.join(apiBase, "services", "timingEngine.ts");
  const scheduler = path.join(apiBase, "services", "scheduler.ts");
  const gmailSync = path.join(apiBase, "services", "gmailSync.ts");
  const cronFile = path.join(apiBase, "cron.ts");
  const doctrine = path.join(apiBase, "routes", "doctrine.ts");

  includes(gmailClient, "export async function createFollowupDraft", "Gmail draft creation helper");
  includes(gmailClient, "export async function deleteDraft", "Gmail draft delete helper");
  includes(gmailClient, "export async function detectManualFollowupSend", "manual-send detection helper");
  includes(gmailClient, "X-Doctrine-Followup-Id", "draft identity header");

  includes(timingEngine, "draft_in_gmail", "draft scheduling mode");
  includes(timingEngine, "computeDraftStageScheduledAt", "draft timing helper");
  includes(timingEngine, "lastFollowupSentAt", "manual-send anchor support");

  includes(scheduler, "createFollowupDraft", "scheduler draft branch import/use");
  includes(scheduler, "status: \"drafted\"", "scheduler drafted status write");
  includes(scheduler, "draftMessageId: draft.draftId", "scheduler stores Gmail draft id");
  includes(scheduler, "queueNextFollowupStageForProspect", "next-stage queue helper");
  includes(scheduler, "stallDraftedFollowups", "30-day stall helper");
  includes(scheduler, "stalled_awaiting_manual_send", "stall status");
  regex(scheduler, /ACTIVE_FOLLOWUP_STATUSES = \["queued", "generating", "pending_approval", "drafted"\]/, "drafted active status guard");

  includes(gmailSync, "detectManualFollowupSend", "gmailSync manual-send detector");
  includes(gmailSync, "queueNextFollowupStageForProspect", "gmailSync next queue trigger");
  includes(gmailSync, "Paused because the user sent a custom outbound message", "pause-on-user-reply behavior");
  includes(gmailSync, "Prospect replied; active follow-up cancelled.", "reply cleanup path");

  includes(cronFile, "stallDraftedFollowups", "cron imports stall watcher");
  includes(cronFile, "30 0 * * *", "daily stall watcher schedule");

  includes(doctrine, "requeueStalledDraftForProspect", "resume requeues stalled drafts");
  includes(doctrine, "cancelActiveFollowupsForProspects", "pause cancels active drafts");
  includes(doctrine, "draft_in_gmail", "manual queue/launch draft mode scheduling");

  console.log(`Batch 3b applied. Changed files: ${changed}/${files.length}`);
  console.log("Verification: PASS");
}

try {
  main();
} catch (err) {
  console.error("Batch 3b apply failed:", err instanceof Error ? err.message : err);
  process.exit(1);
}
