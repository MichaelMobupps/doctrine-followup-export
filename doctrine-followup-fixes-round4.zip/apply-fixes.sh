#!/usr/bin/env bash
# Doctrine Follow-up — round 4: shift-click range select on the pipeline.
# Dashboard-only, one file. Idempotent, all-or-nothing, applies from workspace
# root (repo-safe). Usage: bash apply-fixes.sh [WORKSPACE] [--dry-run] [--no-gates]
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_DIR="$SCRIPT_DIR/patches"
WORKSPACE="/home/runner/workspace"; DRY_RUN=0; NO_GATES=0
for arg in "$@"; do case "$arg" in
  --dry-run) DRY_RUN=1 ;; --no-gates) NO_GATES=1 ;;
  -*) echo "unknown flag: $arg" >&2; exit 2 ;; *) WORKSPACE="$arg" ;;
esac; done
echo "Workspace: $WORKSPACE"
[ -d "$WORKSPACE/artifacts/dashboard/src" ] || { echo "ERROR: not found: $WORKSPACE/artifacts/dashboard/src" >&2; exit 1; }
[ -f "$PATCH_DIR/dashboard.patch" ] || { echo "ERROR: missing dashboard.patch" >&2; exit 1; }
cd "$WORKSPACE"; STRIP=2
classify() { local p="$1"
  if git apply -p$STRIP --reverse --check "$p" 2>/dev/null; then echo APPLIED; return; fi
  if git apply -p$STRIP --check "$p" 2>/dev/null; then echo APPLICABLE; return; fi
  echo DRIFT; }
echo "Preflight…"; S="$(classify "$PATCH_DIR/dashboard.patch")"; echo "  [dashboard] $S"
[ "$S" = DRIFT ] && { echo "ERROR: dashboard.patch DRIFT — pipeline.tsx differs from the expected baseline. Stop and inspect." >&2; exit 1; }
[ "$DRY_RUN" = 1 ] && { echo "Dry-run: $S. No files changed."; exit 0; }
if [ "$S" = APPLICABLE ]; then git apply -p$STRIP "$PATCH_DIR/dashboard.patch"; echo "  [dashboard] applied ✓"; else echo "  [dashboard] already applied — skipping"; fi
echo "Post-checks…"
grep -q "handleRowSelect" "$WORKSPACE/artifacts/dashboard/src/pages/pipeline.tsx" && echo "  ✓ shift-click range handler present" || { echo "  ✗ handler missing" >&2; exit 1; }
[ "$NO_GATES" = 1 ] && { echo "Skipping gates (--no-gates)."; exit 0; }
echo "Running gates…"; set -x
pnpm --filter @workspace/dashboard typecheck
pnpm --filter @workspace/dashboard build
set +x; echo "All gates passed ✓ — safe to restart + sync.sh"
