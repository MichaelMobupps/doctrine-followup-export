#!/usr/bin/env python3
r"""
B9b.3 — auto-create the AntiGhosting Gmail label.

Bug: the dashboard Settings page (B9b.2) lets the operator set
`users.antiGhostingLabel`, and the marking endpoint reads it, but
nothing creates the label in the operator's Gmail mailbox. Doctrine
and Context labels are created automatically by `syncForUser` via
`ensureLabelsExist`; AntiGhosting was never plumbed into that path.

This batch closes that gap. Five surgical edits in
artifacts/api-server/src/services/gmailSync.ts:

  1. Widen syncForUser input type to include antiGhostingLabel.
  2. Parse antiGhostingLabel into antiGhostingLabels array.
  3. Include antiGhostingLabels in the allLabels array passed to
     ensureLabelsExist.
  4. Forward antiGhostingLabel at the first call site (syncEmailsForUser).
  5. Forward antiGhostingLabel at the second call site (syncEmails loop).

Both call sites use `db.select().from(usersTable)` with no projection,
so `user.antiGhostingLabel` is already available in their scope — no
SELECT widening required.

Scope is intentionally limited to label CREATION. AntiGhosting is
operator-driven (Mark button in the dashboard), not ingest-driven,
so we do NOT add an antiGhostingLabels fetch to syncForUser's email
processing — that would conflict with the explicit-marking model.

Idempotency: generalized NEW-substring-of-OLD check.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    totals = [0, 0, 0]

    print("\n--- artifacts/api-server/src/services/gmailSync.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/services/gmailSync.ts",
        [
            # ─────────────────────────────────────────────────────
            # 1. Widen syncForUser input type
            # ─────────────────────────────────────────────────────
            (
                '  doctrineLabel: string;\n'
                '  // Phase 7b: Gmail label that scopes ingest into the Context Based flow.\n'
                '  contextLabel: string;\n'
                '}): Promise<{ synced: number; repliesDetected: number }> {\n',
                '  doctrineLabel: string;\n'
                '  // Phase 7b: Gmail label that scopes ingest into the Context Based flow.\n'
                '  contextLabel: string;\n'
                '  // B9b.3: AntiGhosting label, plumbed in for auto-creation.\n'
                '  // Not used for ingest — AntiGhosting is operator-driven via\n'
                '  // the dashboard Mark flow, not label-scan-driven.\n'
                '  antiGhostingLabel: string;\n'
                '}): Promise<{ synced: number; repliesDetected: number }> {\n',
                "widen syncForUser input type with antiGhostingLabel",
            ),
            # ─────────────────────────────────────────────────────
            # 2 + 3. Parse antiGhostingLabel and add to allLabels
            # ─────────────────────────────────────────────────────
            (
                '  const contextLabels = (user.contextLabel || "").split(",").map((l) => l.trim()).filter(Boolean);\n'
                '  const allLabels = [...doctrineLabels, ...contextLabels];\n',
                '  const contextLabels = (user.contextLabel || "").split(",").map((l) => l.trim()).filter(Boolean);\n'
                '  // B9b.3: include AntiGhosting label(s) so ensureLabelsExist creates\n'
                '  // them in the operator\'s mailbox if missing. The label is used by\n'
                '  // the Mark flow (operator tags a thread in Gmail, then clicks Mark\n'
                '  // in the dashboard); auto-creation removes the manual setup step.\n'
                '  const antiGhostingLabels = (user.antiGhostingLabel || "").split(",").map((l) => l.trim()).filter(Boolean);\n'
                '  const allLabels = [...doctrineLabels, ...contextLabels, ...antiGhostingLabels];\n',
                "parse antiGhostingLabels and include in allLabels",
            ),
            # ─────────────────────────────────────────────────────
            # 4. First call site (syncEmailsForUser)
            # ─────────────────────────────────────────────────────
            (
                '  return syncForUser({\n'
                '    id: user.id,\n'
                '    email: user.email,\n'
                '    name: user.name,\n'
                '    googleRefreshToken: user.googleRefreshToken,\n'
                '    doctrineLabel: user.doctrineLabel,\n'
                '    // Phase 7b: forward the user\'s context label into syncForUser.\n'
                '    contextLabel: user.contextLabel,\n'
                '  });\n'
                '}\n',
                '  return syncForUser({\n'
                '    id: user.id,\n'
                '    email: user.email,\n'
                '    name: user.name,\n'
                '    googleRefreshToken: user.googleRefreshToken,\n'
                '    doctrineLabel: user.doctrineLabel,\n'
                '    // Phase 7b: forward the user\'s context label into syncForUser.\n'
                '    contextLabel: user.contextLabel,\n'
                '    // B9b.3: forward antiGhostingLabel so the label gets auto-created.\n'
                '    antiGhostingLabel: user.antiGhostingLabel,\n'
                '  });\n'
                '}\n',
                "forward antiGhostingLabel at first call site (syncEmailsForUser)",
            ),
            # ─────────────────────────────────────────────────────
            # 5. Second call site (syncEmails loop)
            # ─────────────────────────────────────────────────────
            (
                '      const result = await syncForUser({\n'
                '        id: user.id,\n'
                '        email: user.email,\n'
                '        name: user.name,\n'
                '        googleRefreshToken: user.googleRefreshToken,\n'
                '        doctrineLabel: user.doctrineLabel,\n'
                '        // Phase 7b: forward the user\'s context label into syncForUser (loop).\n'
                '        contextLabel: user.contextLabel,\n'
                '      });\n',
                '      const result = await syncForUser({\n'
                '        id: user.id,\n'
                '        email: user.email,\n'
                '        name: user.name,\n'
                '        googleRefreshToken: user.googleRefreshToken,\n'
                '        doctrineLabel: user.doctrineLabel,\n'
                '        // Phase 7b: forward the user\'s context label into syncForUser (loop).\n'
                '        contextLabel: user.contextLabel,\n'
                '        // B9b.3: forward antiGhostingLabel so the label gets auto-created.\n'
                '        antiGhostingLabel: user.antiGhostingLabel,\n'
                '      });\n',
                "forward antiGhostingLabel at second call site (syncEmails loop)",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # syncForLegacyUser (env-var fallback path) deliberately not modified.
    # The legacy path uses GOOGLE_REFRESH_TOKEN / SENDER_EMAIL env vars
    # and has no DB user row to pull antiGhostingLabel from. AntiGhosting
    # is a per-user product that requires a connected account; the legacy
    # single-tenant fallback is out of scope.

    expected = 4
    seen = totals[0] + totals[1]
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {totals[0]}")
    print(f"  Already-applied:   {totals[1]}")
    print(f"  Warnings:          {totals[2]}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if totals[2] > 0:
        print("  At least one edit could not be applied. Inspect WARN lines.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
