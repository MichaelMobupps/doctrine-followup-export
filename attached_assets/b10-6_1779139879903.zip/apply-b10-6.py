#!/usr/bin/env python3
"""
B10.6 - Email Inspector: suppress "missing label" line for outbound
messages. When a sent-by-me message is a sibling in a tracked thread,
showing "not syncing (missing label)" is misleading - outbound replies
are intentionally not new prospects.

New branch inserted before the existing kind === "thread" branches:
  email.isSentByMe && kind === "thread"  ->
    grey "Outbound (thread ID: N)"

The other branches still handle inbound siblings (yellow pending or
grey missing-label). Only this top branch suppresses the verbose
text for sent-by-me cases.

Single anchor. Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INSP = WORKSPACE / "artifacts/dashboard/src/pages/email-inspector.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


OLD = '''                            ) : kind === "thread" && email.detection.wouldBePickedUp ? ('''

NEW = '''                            ) : email.isSentByMe && kind === "thread" ? (
                              // B10.6: outbound message in a tracked thread. Showing
                              // "not syncing (missing label)" was misleading - outbound
                              // replies are intentionally not new prospects. Simplify
                              // the display to just acknowledge the thread is tracked.
                              <span className="font-mono font-medium" style={{ color: "var(--text-tertiary)" }}>
                                Outbound (thread ID: {email.dbRecord?.id})
                              </span>
                            ) : kind === "thread" && email.detection.wouldBePickedUp ? ('''

MARKER = "B10.6: outbound message in a tracked thread"


def main():
    if not INSP.exists():
        fail(f"email-inspector.tsx not found: {INSP}")
    text = INSP.read_text(encoding="utf-8")

    if MARKER in text:
        print("[skip] B10.6 already applied")
        return

    count = text.count(OLD)
    if count == 0:
        fail("anchor not found")
    if count != 1:
        fail(f"anchor matched {count} times; expected 1")

    text = text.replace(OLD, NEW)
    INSP.write_text(text, encoding="utf-8")
    ok("outbound branch inserted")
    ok(f"wrote {INSP.relative_to(WORKSPACE)}")
    print()
    print("B10.6 outbound sibling suppress applied.")


if __name__ == "__main__":
    main()
