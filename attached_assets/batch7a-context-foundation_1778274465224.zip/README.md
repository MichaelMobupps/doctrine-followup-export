# Batch 7a — Context Based Followuper foundation

## What this batch does

Lays the database and schema foundation for the new "Context Based"
Followuper, the parallel sub-product running alongside the Sales Doctrine
Followuper inside this same app.

**Zero behavior drift on the existing Doctrine flow.** No service, scheduler,
sync, or UI file is touched. Existing rows continue exactly as today. The
new column sits ready for Batch 7b to read and route on.

## What's in 7a vs what's in 7b/7c

| Concern | 7a (this batch) | 7b | 7c |
|---|---|---|---|
| DB columns + index | ✓ | | |
| Schema TS types | ✓ | | |
| `gmail-auth` accepts `contextLabel` | ✓ | | |
| Context generator (Sonnet → Opus critic → Sonnet rewriter, no doctrine) | | ✓ | |
| `gmailSync` scans both labels and tags `app` per row | | ✓ | |
| Dispatcher (`processDueFollowups`) branches on `app` | | ✓ | |
| New `/api/context/*` routes (clone of doctrine routes) | | ✓ | |
| Product picker landing page (`/`) | | | ✓ |
| Sidebar product switcher | | | ✓ |
| Themed UI clone (amber theme, "Context Based" branding) | | | ✓ |

## Files in this bundle

| File | Purpose |
|---|---|
| `migrate-batch7a.mjs` | DB migration: 2 columns + 1 CHECK constraint. Idempotent, transactional. |
| `apply-batch7a.mjs`   | Code patch: 7 idempotent str_replace operations + 7 self-verifies. |
| `audit-batch7a.mjs`   | Beautiful-Squidward harness: 3 rounds × 9 passes = 93 assertions. |

No payload directory. No new packages.

## Schema changes

### `prospects.app text NOT NULL DEFAULT 'doctrine'`

Discriminator column. Values constrained at the DB level by the
`prospects_app_check` CHECK constraint to `('doctrine', 'context')`.
TypeScript mirrors via `ProspectApp` type and `PROSPECT_APPS` const.

Existing prospects auto-backfill to `'doctrine'` via the column default —
PostgreSQL on modern versions performs this as a metadata-only operation,
no row rewrites.

Also adds `idx_prospects_app` index for efficient per-product filtering.

### `users.context_label text NOT NULL DEFAULT 'Context Followuper'`

The Gmail label that scopes ingest into the Context Based Followuper. User
must add this label to threads they want followed up on a context-only
basis. Default name chosen to be self-explanatory for non-technical team
members. Per-user override available via the existing PUT settings
endpoint.

## Operating defaults baked in

- `DB_BASE = lib/db/src`
- `API_BASE = artifacts/api-server/src`
- Migration script runs from `lib/db/` (so `pg` resolves)
- No db build step
- No dashboard build needed (this batch doesn't touch UI)

## Manual verification after deploy

```bash
# 1. Confirm columns landed with correct types and defaults
psql "$DATABASE_URL" -c "
  SELECT table_name, column_name, data_type, is_nullable, column_default
  FROM information_schema.columns
  WHERE (table_name='prospects' AND column_name='app')
     OR (table_name='users'     AND column_name='context_label')
  ORDER BY table_name, column_name;"
# expect 2 rows

# 2. Confirm CHECK constraint is enforcing the enum
psql "$DATABASE_URL" -c "
  SELECT constraint_name, check_clause
  FROM information_schema.check_constraints
  WHERE constraint_name = 'prospects_app_check';"
# expect: app IN ('doctrine', 'context')

# 3. Confirm all existing prospects are tagged 'doctrine'
psql "$DATABASE_URL" -c "
  SELECT app, COUNT(*) FROM prospects GROUP BY app ORDER BY app;"
# expect single row: app=doctrine, count=<your prospect count>

# 4. Confirm CHECK constraint blocks invalid values (this should ERROR)
psql "$DATABASE_URL" -c "
  INSERT INTO prospects (gmail_message_id, gmail_thread_id, email, sent_at, app)
  VALUES ('test_check_constraint', 'test', 'test@test.com', NOW(), 'invalid');"
# expect: ERROR — violates check constraint "prospects_app_check"
```

## What 7b will need from this

Batch 7b will:
- Read `prospects.app` in the dispatcher to route generation
- Read `users.contextLabel` in `gmailSync` to scope context-label syncs
- Set `app: 'context'` on inserts of context-labeled threads
- Create `services/contextFollowupGenerator.ts` (3-call Sonnet/Opus pipeline)
- Add `routes/context.ts` for context-specific endpoints

Nothing in 7a blocks 7b. After 7a deploys, the prod system continues to
behave identically to today. Context functionality only activates after 7b.

## Roll-forward note

Forward-only. To revert (only if you need to):

```sql
-- Optional: only if rolling back. Drop in this order:
ALTER TABLE prospects DROP CONSTRAINT IF EXISTS prospects_app_check;
ALTER TABLE prospects DROP COLUMN IF EXISTS app;
DROP INDEX IF EXISTS idx_prospects_app;
ALTER TABLE users DROP COLUMN IF EXISTS context_label;
```

Then revert the code changes via git or by reversing the apply script
edits. The schema-side reversal can run independently of the code-side
reversal because nothing in 7a actively reads the new columns.
