#!/usr/bin/env node
/**
 * audit-batch7d.mjs — Beautiful-Squidward audit for Phase 7d.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7d] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7d] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const pickerSrc           = read(join(DASH_BASE, "pages", "picker.tsx"));
const ctxPipelineSrc      = read(join(DASH_BASE, "pages", "context-pipeline.tsx"));
const ctxInspectorSrc     = read(join(DASH_BASE, "pages", "context-inspector.tsx"));
const ctxActivitySrc      = read(join(DASH_BASE, "pages", "context-activity.tsx"));
const appSrc              = read(join(DASH_BASE, "App.tsx"));
const cssSrc              = read(join(DASH_BASE, "index.css"));
const layoutSrc           = read(join(DASH_BASE, "components", "layout.tsx"));
const accountsSrc         = read(join(DASH_BASE, "pages", "accounts.tsx"));
const pipelineSrc         = read(join(DASH_BASE, "pages", "pipeline.tsx"));

// Regression checks against earlier batches:
const doctrineSrc         = read(join(API_BASE, "routes", "doctrine.ts"));
const contextRouteSrc     = read(join(API_BASE, "routes", "context.ts"));
const indexRouteSrc       = read(join(API_BASE, "routes", "index.ts"));
const prospectsSchemaSrc  = read(join(DB_BASE, "schema", "prospects.ts"));
const usersSchemaSrc      = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: New page files exist with expected exports
  log(`-- PASS 1: New page files exist --`);
  pass(`picker.tsx default export`, /export default function Picker\(\)/.test(pickerSrc));
  pass(`context-pipeline.tsx default export`, /export default function ContextPipeline\(\)/.test(ctxPipelineSrc));
  pass(`context-inspector.tsx default export`, /export default function ContextEmailInspector\(\)/.test(ctxInspectorSrc));
  pass(`context-activity.tsx default export`, /export default function ContextActivityLog\(\)/.test(ctxActivitySrc));

  // PASS 2: Picker UX — two cards, localStorage, navigation
  log(`-- PASS 2: Picker UX --`);
  pass(`Picker imports useLocation`, /import \{ useLocation \} from "wouter"/.test(pickerSrc));
  pass(`Picker uses localStorage`, /localStorage\.setItem\(STORAGE_KEY,/.test(pickerSrc));
  pass(`Picker navigates to / for doctrine`, /navigate\("\/"\)/.test(pickerSrc));
  pass(`Picker navigates to /context/pipeline for context`, /navigate\("\/context\/pipeline"\)/.test(pickerSrc));
  pass(`Picker has both card titles`, /Sales Doctrine Followuper/.test(pickerSrc) && /Context Based Followuper/.test(pickerSrc));

  // PASS 3: App.tsx routes registered
  log(`-- PASS 3: App.tsx routes --`);
  pass(`Picker imported`, /import Picker from "@\/pages\/picker"/.test(appSrc));
  pass(`ContextPipeline imported`, /import ContextPipeline from "@\/pages\/context-pipeline"/.test(appSrc));
  pass(`ContextEmailInspector imported`, /import ContextEmailInspector from "@\/pages\/context-inspector"/.test(appSrc));
  pass(`ContextActivityLog imported`, /import ContextActivityLog from "@\/pages\/context-activity"/.test(appSrc));
  pass(`/picker route mounted`, /<Route path="\/picker" component=\{Picker\} \/>/.test(appSrc));
  pass(`/context/pipeline route mounted`, /<Route path="\/context\/pipeline" component=\{ContextPipeline\} \/>/.test(appSrc));
  pass(`/context/inspector route mounted`, /<Route path="\/context\/inspector" component=\{ContextEmailInspector\} \/>/.test(appSrc));
  pass(`/context/activity route mounted`, /<Route path="\/context\/activity" component=\{ContextActivityLog\} \/>/.test(appSrc));
  pass(`Doctrine routes preserved (root, pipeline, inspector, accounts, activity)`,
    /<Route path="\/" component=\{Pipeline\}/.test(appSrc) &&
    /<Route path="\/pipeline" component=\{Pipeline\}/.test(appSrc) &&
    /<Route path="\/inspector" component=\{EmailInspector\}/.test(appSrc) &&
    /<Route path="\/accounts" component=\{Accounts\}/.test(appSrc) &&
    /<Route path="\/activity" component=\{ActivityLog\}/.test(appSrc)
  );

  // PASS 4: Amber theme override in CSS
  log(`-- PASS 4: Amber theme CSS --`);
  pass(`[data-product="context"] selector exists`, /\[data-product="context"\]/.test(cssSrc));
  pass(`amber accent override`, /--accent: #f59e0b/.test(cssSrc));
  pass(`amber accent-hover`, /--accent-hover: #d97706/.test(cssSrc));
  pass(`amber accent-muted`, /--accent-muted: rgba\(245,158,11,0\.10\)/.test(cssSrc));
  pass(`default :root --accent unchanged`, /:root \{[^}]*--accent: #3b82f6/s.test(cssSrc));

  // PASS 5: Layout product awareness
  log(`-- PASS 5: Layout product awareness --`);
  pass(`Layout imports ArrowLeftRight`, /ArrowLeftRight/.test(layoutSrc));
  pass(`Layout derives onContext from URL`, /const onContext = location\.startsWith\("\/context"\)/.test(layoutSrc));
  pass(`Layout sets dataProduct based on onContext`, /const dataProduct = onContext \? "context" : "doctrine"/.test(layoutSrc));
  pass(`Layout sets brandLabel`, /const brandLabel = onContext \? "Context Based" : "Doctrine AI"/.test(layoutSrc));
  pass(`data-product attr on root div`, /data-product=\{dataProduct\}/.test(layoutSrc));
  pass(`{brandLabel} rendered`, /\{brandLabel\}/.test(layoutSrc));
  pass(`navItems product-aware (ternary)`, /const navItems = onContext\s*\n\s*\?/.test(layoutSrc));
  pass(`Switch product link goes to /picker`, /<Link href="\/picker" className="block">/.test(layoutSrc));

  // PASS 6: Accounts contextLabel field
  log(`-- PASS 6: Accounts contextLabel field --`);
  pass(`contextLabel state declared`, /const \[contextLabel, setContextLabel\] = useState<string>\(account\.contextLabel \|\| "Context Followuper"\)/.test(accountsSrc));
  pass(`contextLabel in save body`, /        contextLabel,\n        weeklyDigestEnabled,/.test(accountsSrc));
  pass(`Context Gmail label section rendered`, /Context Gmail label/.test(accountsSrc));
  pass(`Context label input wires setContextLabel`, /onChange=\{\(e\) => setContextLabel\(e\.target\.value\)\}/.test(accountsSrc));
  pass(`Context label placeholder is "Context Followuper"`, /placeholder="Context Followuper"/.test(accountsSrc));

  // PASS 7: Doctrine UI semantically unchanged
  log(`-- PASS 7: Doctrine UI not regressed --`);
  pass(`pipeline.tsx unchanged (still imports same hooks)`, /import \{ useGetFollowups, useCancelFollowups, useQueueBatch \} from "@workspace\/api-client-react"/.test(pipelineSrc));
  pass(`accounts.tsx still has Doctrine Gmail label`, /Doctrine Gmail label/.test(accountsSrc));
  pass(`accounts.tsx still has doctrineLabel state`, /const \[doctrineLabel, setDoctrineLabel\] = useState<string>/.test(accountsSrc));
  pass(`Layout still has Settings link`, /<Link href="\/accounts" className="block">/.test(layoutSrc));
  pass(`Layout still has Sign out button`, /Sign out/.test(layoutSrc));

  // PASS 8: B7c regression — doctrine route filter intact
  log(`-- PASS 8: B7c regression --`);
  pass(`SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineSrc));
  pass(`SCOPE_DOCTRINE referenced ≥30 times`, (doctrineSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`/reject sub-select gate still present`, /Phase 7c: gate by prospect\.app via sub-select/.test(doctrineSrc));

  // PASS 9: B7a/B7b regression
  log(`-- PASS 9: B7a/B7b regression --`);
  pass(`prospects.app schema column`, /app:\s*text\("app"\)\.\$type<ProspectApp>\(\)\.notNull\(\)\.default\("doctrine"\)/.test(prospectsSchemaSrc));
  pass(`users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)\.notNull\(\)\.default\("Context Followuper"\)/.test(usersSchemaSrc));
  pass(`/context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`context.ts uses SCOPE constant`, /const SCOPE = eq\(prospectsTable\.app, "context"\)/.test(contextRouteSrc));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
