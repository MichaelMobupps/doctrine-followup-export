#!/usr/bin/env python3
"""
B9b.12.1 - Surface validator rejection reasons in the AG Email Inspector.

Two file edits:

  1. artifacts/api-server/src/services/antiGhostingIngest.ts
     - Revert the B9b.12-diag log bump (logger.info -> logger.debug).
       We have our answer; verbose logging is no longer needed in prod.

  2. artifacts/api-server/src/routes/anti-ghosting.ts
     - Extend the user query to also select `email` (needed for the
       validator call which requires userEmail).
     - Change `const wouldBePickedUp` to `let wouldBePickedUp` so the
       validator can flip it to false on rejection.
     - After the basic detection logic, call validateThreadForMarking
       for AG-labeled threads. On rejection, set wouldBePickedUp=false
       and append the reason to whyNot.

validateThreadForMarking is already imported in anti-ghosting.ts
(from B9b.6); no import changes needed.

Idempotent. Anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INGEST = WORKSPACE / "artifacts/api-server/src/services/antiGhostingIngest.ts"
ROUTE = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"

# --------------------------------------------------------------------
# Edit 1: revert the B9b.12-diag bump
# --------------------------------------------------------------------
DIAG_OLD = '''// B9b.12-diag: temporarily bumped to info for prod log surfacing.
        logger.info(
          { threadId: t.id, reason: result.reason, userId: args.userId },
          "AntiGhosting auto-ingest skipped \u2014 validator rejected thread",
        );'''

DIAG_NEW = '''logger.debug(
          { threadId: t.id, reason: result.reason, userId: args.userId },
          "AntiGhosting auto-ingest skipped \u2014 validator rejected thread",
        );'''

# --------------------------------------------------------------------
# Edit 2: extend user query to grab email
# --------------------------------------------------------------------
USER_QUERY_OLD = '''let antiGhostingLabelStr = "";
    if (userIdForLabels) {
      const u = await db
        .select({ antiGhostingLabel: usersTable.antiGhostingLabel })
        .from(usersTable)
        .where(eq(usersTable.id, userIdForLabels))
        .limit(1);
      if (u.length > 0 && u[0].antiGhostingLabel) antiGhostingLabelStr = u[0].antiGhostingLabel;
    }'''

USER_QUERY_NEW = '''let antiGhostingLabelStr = "";
    // B9b.12.1: also capture user email for the validator call below.
    let userEmailFromDb = "";
    if (userIdForLabels) {
      const u = await db
        .select({
          antiGhostingLabel: usersTable.antiGhostingLabel,
          email: usersTable.email,
        })
        .from(usersTable)
        .where(eq(usersTable.id, userIdForLabels))
        .limit(1);
      if (u.length > 0) {
        if (u[0].antiGhostingLabel) antiGhostingLabelStr = u[0].antiGhostingLabel;
        if (u[0].email) userEmailFromDb = u[0].email;
      }
    }'''

# --------------------------------------------------------------------
# Edit 3: switch const -> let on wouldBePickedUp + insert validator call
# --------------------------------------------------------------------
DETECTION_OLD = '''        // AG-specific: no 60-day-window gate because the ingest
        // helper picks up labeled threads regardless of age.
        const wouldBePickedUp = hasAntiGhostingLabel && isSentByMe;

        const reasons: string[] = [];
        if (!isSentByMe) reasons.push("Not sent by configured sender email");
        if (!hasAntiGhostingLabel) reasons.push("Missing AntiGhosting label");

        emails.push({'''

DETECTION_NEW = '''        // AG-specific: no 60-day-window gate because the ingest
        // helper picks up labeled threads regardless of age.
        let wouldBePickedUp = hasAntiGhostingLabel && isSentByMe;

        const reasons: string[] = [];
        if (!isSentByMe) reasons.push("Not sent by configured sender email");
        if (!hasAntiGhostingLabel) reasons.push("Missing AntiGhosting label");

        // B9b.12.1: validator gate for AG-labeled threads. The ingest
        // pipeline runs validateThreadForMarking before creating a
        // prospect; surface its rejection reason in the inspector so
        // the user sees WHY a labeled thread isn't getting picked up.
        if (wouldBePickedUp && userIdForLabels && userEmailFromDb) {
          try {
            const outcome = await validateThreadForMarking(msg.threadId, gmail, userEmailFromDb, userIdForLabels);
            if (!outcome.ok) {
              wouldBePickedUp = false;
              reasons.push(outcome.failureReason || "Validator rejected thread");
            }
          } catch (err) {
            logger.warn({ err, threadId: msg.threadId }, "validator threw during inspector — leaving detection unchanged");
          }
        }

        emails.push({'''


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def info(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker=None):
    check = marker if marker is not None else new
    if check in text:
        skip(f"{label} already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found: {old[:80]!r}")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    info(f"{label}: updated")
    return text.replace(old, new, 1), True


def patch_ingest():
    if not INGEST.exists():
        fail(f"ingest not found: {INGEST}")
    text = INGEST.read_text(encoding="utf-8")
    original = text

    # If diag bump isn't present, nothing to revert. That's a soft success.
    if "B9b.12-diag" not in text:
        skip("B9b.12-diag bump not present; nothing to revert")
        return

    text, _ = replace_unique(text, DIAG_OLD, DIAG_NEW, "revert B9b.12-diag bump",
                              marker="REVERT_PLACEHOLDER_NEVER_PRESENT")

    if text != original:
        INGEST.write_text(text, encoding="utf-8")
        info(f"wrote {INGEST.relative_to(WORKSPACE)}")


def patch_route():
    if not ROUTE.exists():
        fail(f"route not found: {ROUTE}")
    text = ROUTE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(text, USER_QUERY_OLD, USER_QUERY_NEW,
                              "user query extension (email)",
                              marker="B9b.12.1: also capture user email")

    text, _ = replace_unique(text, DETECTION_OLD, DETECTION_NEW,
                              "validator call in detection",
                              marker="B9b.12.1: validator gate for AG-labeled threads")

    if text != original:
        ROUTE.write_text(text, encoding="utf-8")
        info(f"wrote {ROUTE.relative_to(WORKSPACE)}")
    else:
        skip("route already patched")


def main():
    patch_ingest()
    patch_route()
    print()
    print("B9b.12.1 validator-reason surfacing applied.")


if __name__ == "__main__":
    main()
