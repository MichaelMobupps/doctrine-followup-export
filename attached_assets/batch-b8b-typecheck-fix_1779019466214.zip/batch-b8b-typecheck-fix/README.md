# Batch B8b — Typecheck Resolution Fix

**Scope.** Surgical fix for the `@workspace/db` typecheck drift documented in B8a and widened in B9a. Restores green typecheck across the workspace without changing any runtime behaviour. After this ship, future batches that touch `lib/db/src/schema/` will typecheck cleanly without manual `.d.ts` rebuilds.

## Root cause

The api-server uses TypeScript Project References:

```jsonc
// artifacts/api-server/tsconfig.json
"references": [
  { "path": "../../lib/db" },
  { "path": "../../lib/api-zod" }
]
```

With project references, tsc does NOT read `lib/db/src/*.ts` directly. It reads `.d.ts` files emitted to `lib/db/dist/` by `lib/db`'s own composite build. The lib/db tsconfig is configured to do this (`composite: true`, `emitDeclarationOnly: true`, `outDir: "dist"`), but no script in the deploy pipeline ever runs it:

- `lib/db/package.json` defines no `build` script.
- `api-server/package.json`'s typecheck script is `tsc -p tsconfig.json --noEmit`. The `-p` (project) mode does NOT trigger rebuild of referenced projects — it trusts whatever `.d.ts` already exists in their `outDir`.

Result: `lib/db/dist/` was last generated April 20 and has been stale ever since. Every column added since (contextLabel, weeklyDigestEnabled, lastWeeklyDigestAt, pausedByAdmin, plus all of B9a) is invisible to tsc. The api-server has been typechecking against a schema that's 4+ weeks behind reality.

esbuild (used for runtime builds via `node ./build.mjs`) bundles `lib/db/src/` directly and was never affected, which is why production has been fine throughout.

## Fix

Two edits to the api-server's project configuration plus a one-time cleanup of stale build state.

### `artifacts/api-server/tsconfig.json`

- Add `"noEmit": true` to `compilerOptions`. The api-server uses esbuild for its runtime build (`build.mjs`); tsc's role is typecheck-only. With the typecheck script switching to `tsc -b` (below), without `noEmit` tsc would emit api-server's compiled JS to `outDir: "dist"` as a side effect, which we don't want. The `noEmit` only applies to the api-server project itself; referenced projects (lib/db, lib/api-zod) honour their own `emitDeclarationOnly: true` setting and emit their `.d.ts` as needed.

### `artifacts/api-server/package.json`

- Change `scripts.typecheck` from `"tsc -p tsconfig.json --noEmit"` to `"tsc -b"`. Build mode walks the references graph, rebuilds any referenced project whose `tsbuildinfo` shows it is out of date, then proceeds to typecheck the current project. The `tsbuildinfo` files in `lib/db` and `lib/api-zod` keep this incremental on subsequent runs.

### One-time cleanup

- Delete `lib/db/dist/` and `lib/db/tsconfig.tsbuildinfo` before the first `tsc -b`. The stale tsbuildinfo would otherwise trick incremental build into thinking the existing dist is fine for some files. A clean slate forces full regeneration. Subsequent `tsc -b` runs are incremental as designed.

## Risk surface

1. **Runtime is untouched.** No source file in `artifacts/api-server/src/` or `lib/db/src/` is modified. esbuild's build path is unchanged. The runtime migrations and server boot behaviour are unaffected.
2. **First `tsc -b` may surface real type errors** that have been hidden behind the stale `.d.ts`. This is a feature: any genuine type drift in the live source is now visible. If errors appear that are NOT a result of B8b's changes (i.e., they would have been there regardless once the .d.ts caught up), they are real bugs and should be fixed in a follow-up batch. The bash block reports verbatim.
3. **The `dist/` deletion is local to `lib/db`.** Other workspace packages (api-zod, dashboard, integrations-anthropic-ai) keep their own dist artifacts.
4. **No bundling change.** The `customConditions: ["workspace"]` and `resolvePackageJsonExports: true` settings in the resolved tsconfig (from `tsconfig.base.json`) continue to do their job for runtime path resolution. Project references operate independently of those.

## Layout

```
batch-b8b-typecheck-fix/
|-- README.md
`-- api-server/
    `-- tsconfig.json   (replace)
```

The `package.json` script update is applied via a Python one-liner inside the bash block (preserves every other field). The cleanup of `lib/db/dist/` is also a bash step. There is no source code in this batch, so `source-code/sync.sh` does not need to run (tsconfig and package.json are not in the mirror).

No workflow restart is needed — runtime is unaffected.
