# Batch B9b.5 — Validator 3 Refinement (Active Followups Check)

**Scope.** Fix the over-strict third AntiGhosting validator so completed Doctrine campaigns don't permanently block AntiGhosting on the same thread.

## The bug

B9b's `mostRecentOutboundNotInFollowups` validator asked: "is the seed message's ID present as a followups row for this user?" The intent was "don't AntiGhosting threads that already have a follow-up campaign running." But the check missed a key state: when a Doctrine campaign completes (all F1/F2/F3 status='sent'), the message IDs ARE still in the followups table. So AntiGhosting refused to ingest — exactly the case AntiGhosting was designed for (re-engage after Doctrine exhausts).

You hit this on the Konami thread: Doctrine prospect ID 97476, status UNREPLIED, F1+ already in followups. Auto-ingest rejected.

## The fix

Refine the check: "does any prospect for this thread have a follow-up in a non-terminal status?"

- **Terminal statuses** (campaign done, AntiGhosting can proceed): `sent`, `cancelled`, `failed`.
- **Non-terminal statuses** (campaign still in flight, AntiGhosting must wait): `queued`, `generating`, `drafted`, `pending_approval`, `stalled_awaiting_manual_send`, and any unknown future status.

Implementation uses `not(inArray(...terminal))` rather than `inArray(...active)` so new statuses default to BLOCKING. Failing safe is the right default — incorrectly blocking is recoverable (operator manually cancels), incorrectly allowing risks a double-send.

## What this allows / blocks now

| Scenario | Old behavior | New behavior |
|---|---|---|
| Doctrine fully sent (F1+F2+F3 all `sent`), prospect went silent | ❌ blocked | ✅ allowed |
| Doctrine F1 sent, F2 queued | ❌ blocked | ❌ blocked (correct: still active) |
| Doctrine cancelled by operator | ❌ blocked | ✅ allowed |
| Doctrine F1 errored, no retry | ❌ blocked | ✅ allowed (errored is terminal) |
| No prior prospect on this thread | ✅ allowed | ✅ allowed |
| Existing anti_ghosting prospect | Caught upstream by idempotency check | Caught upstream by idempotency check |

## Three surgical edits in `services/antiGhostingValidators.ts`

1. **Widen drizzle-orm import** to include `inArray, not`.
2. **Replace Validator 3 query** with the active-followups check, scoped by `gmailThreadId` instead of `gmailMessageId`. Variable renamed `inFollowups` → `activeFollowups`.
3. **Update failureReason** to describe the new check accurately.

ValidatorResults field name `mostRecentOutboundNotInFollowups` is preserved — the dashboard chip already reads "Not already in active follow-up", which describes the new semantics correctly. No frontend churn.

## Risk surface

- **Backward compat at the API level**: ValidatorResults shape unchanged. Dashboard reads `results.mostRecentOutboundNotInFollowups` and renders the same chip. No frontend changes needed.
- **Semantics change**: more threads will now pass this validator. Some threads that the candidates endpoint USED TO show as "validator failure" will now pass and (via the B9b.4 auto-ingest pass on the next sync cycle) become real anti_ghosting prospects. Expected and intended.
- **Idempotency check upstream**: B9b.4's `getAlreadyMarkedThreadIds` still filters out threads that already have an anti_ghosting prospect. So even if Validator 3 passes, a re-labeled thread won't create a duplicate. Layered protection.
- **No schema change.**

## Validation

```bash
python3 scripts/apply-b9b5.py
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server run build
```

Expect: 3 edits applied, 0 typecheck errors, build succeeds.

After deploy + next sync cycle: the Konami thread (and any other completed-Doctrine threads you've labeled) should auto-ingest as anti_ghosting prospects with cycle=1 + F1 scheduled. Check api-server logs for `AntiGhosting auto-ingest pass complete` with `ingested > 0`.

## Layout

```
batch-b9b5-validator-refinement/
|-- README.md
`-- scripts/
    `-- apply-b9b5.py
```

Sandbox-tested: 3 FIX on first run, 3 SKIP on second run. Final shape confirmed: drizzle imports widened, activeFollowups query in place with gmailThreadId scoping + terminal-status check, old inFollowups query and failureReason both removed, new failureReason present.

## On Issue 2 ("Failed to load thread")

Still outstanding. That's a separate problem in the Email Inspector's thread-view fetch — not blocked by this batch and not fixed by it. Need api-server log output when expanding a thread to triage. Will pick up after this ships.
