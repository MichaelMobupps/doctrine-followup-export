#!/usr/bin/env node
// apply-hotfix-1.mjs
//
// Hotfix for unique-constraint blind-insert bug. The followups table has
// uq_followups_prospect_stage on (prospect_id, stage). When a pause cancels
// queued follow-ups, the rows remain with status='cancelled'. Subsequent
// INSERTs at the same (prospect, stage) silently fail under .onConflictDoNothing()
// or try/catch, leaving prospects stuck with no queued stages after a resume.
//
// Adds queueStageForProspect() helper in scheduler.ts that revives non-active,
// non-sent rows in place, and wires 6 call sites through it:
//   scheduler.ts:  autoQueueAllCampaigns, queueNextFollowupStageForProspect
//   doctrine.ts:   /queue, /queue-batch, /prospect/resume-bulk, /prospect/:id/resume
//
// Idempotent: every operation is anchor-gated. Safe to re-run.

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const SCHEDULER_TS = join(API_BASE, "services/scheduler.ts");
const DOCTRINE_TS = join(API_BASE, "routes/doctrine.ts");

let opsApplied = 0;
let opsSkipped = 0;

function read(path) {
  if (!existsSync(path)) {
    console.error(`FATAL: file not found: ${path}`);
    process.exit(1);
  }
  return readFileSync(path, "utf8");
}

function write(path, content) {
  writeFileSync(path, content, "utf8");
}

function countOccurrences(haystack, needle) {
  let count = 0;
  let from = 0;
  while (true) {
    const i = haystack.indexOf(needle, from);
    if (i === -1) break;
    count++;
    from = i + needle.length;
  }
  return count;
}

function applyReplacement(path, label, oldStr, newStr) {
  let s = read(path);
  if (!s.includes(oldStr)) {
    console.log(`  SKIP  ${label} (old pattern absent — already patched or N/A)`);
    opsSkipped++;
    return;
  }
  // Replace every occurrence in one shot. Routes with identical bodies
  // (e.g., /queue and /queue-batch) both get patched on the first matching op.
  const count = countOccurrences(s, oldStr);
  s = s.split(oldStr).join(newStr);
  write(path, s);
  console.log(`  APPLY ${label} (${count}× replacement${count !== 1 ? "s" : ""})`);
  opsApplied++;
}

function applyInsertion(path, label, sentinel, anchor, insertion, position = "before") {
  let s = read(path);
  if (s.includes(sentinel)) {
    console.log(`  SKIP  ${label} (sentinel present)`);
    opsSkipped++;
    return;
  }
  if (!s.includes(anchor)) {
    console.error(`  FAIL  ${label} :: anchor not found in ${path}`);
    process.exit(2);
  }
  if (s.indexOf(anchor) !== s.lastIndexOf(anchor)) {
    console.error(`  FAIL  ${label} :: anchor not unique in ${path}`);
    process.exit(2);
  }
  s = position === "before"
    ? s.replace(anchor, insertion + anchor)
    : s.replace(anchor, anchor + insertion);
  write(path, s);
  console.log(`  APPLY ${label}`);
  opsApplied++;
}

/* ===================================================================== */
/*  scheduler.ts                                                          */
/* ===================================================================== */

console.log("\n[scheduler.ts] adding queueStageForProspect helper + rewiring callers");

/* ---- Op 1 — Add queueStageForProspect helper ---- */

const HELPER_FN = `export async function queueStageForProspect(
  prospectId: number,
  stage: number,
  scheduledAt: Date,
): Promise<{ queued: boolean; revived: boolean }> {
  // The uq_followups_prospect_stage unique index on (prospect_id, stage)
  // means a blind INSERT blocks if any prior row exists at this stage —
  // including 'cancelled' rows left behind by a previous pause/cancel.
  // Detect such rows and revive them in place; otherwise insert fresh.
  // Never touches rows that are already 'sent' or currently active.
  const existing = await db
    .select({ id: followupsTable.id, status: followupsTable.status })
    .from(followupsTable)
    .where(and(
      eq(followupsTable.prospectId, prospectId),
      eq(followupsTable.stage, stage),
    ))
    .limit(1);

  if (existing[0]) {
    const status = existing[0].status;
    if (status === "sent") return { queued: false, revived: false };
    if (isActiveFollowupStatus(status)) return { queued: false, revived: false };
    const updateResult = await db
      .update(followupsTable)
      .set({
        status: "queued",
        scheduledAt,
        draftMessageId: null,
        errorMessage: null,
        gmailMessageId: null,
        generatedBody: null,
        generatedSubject: null,
        sentAt: null,
      })
      .where(eq(followupsTable.id, existing[0].id));
    const did = Boolean(updateResult.rowCount);
    return { queued: did, revived: did };
  }

  // No prior row. Insert. onConflictDoNothing guards a concurrent-insert
  // race (e.g., autoQueue running in parallel inserting first).
  const insertResult = await db
    .insert(followupsTable)
    .values({ prospectId, stage, scheduledAt, status: "queued" })
    .onConflictDoNothing();
  return { queued: Boolean(insertResult.rowCount), revived: false };
}

`;

applyInsertion(
  SCHEDULER_TS,
  "add queueStageForProspect helper",
  "export async function queueStageForProspect",
  `export async function cancelActiveFollowupsForProspects(`,
  HELPER_FN,
  "before",
);

/* ---- Op 2 — Rewire autoQueueAllCampaigns ---- */

applyReplacement(
  SCHEDULER_TS,
  "rewire autoQueueAllCampaigns to use helper",
  `    try {
      const result = await db.insert(followupsTable).values({
        prospectId: prospect.id,
        stage: nextStage,
        scheduledAt,
        status: "queued",
      }).onConflictDoNothing();
      if (result.rowCount && result.rowCount > 0) {
        queued++;
        logger.info(
          {
            prospectId: prospect.id,
            stage: nextStage,
            scheduledAt: scheduledAt.toISOString(),
            followupMode: userFull?.followupMode || "auto_send",
          },
          "Auto-queued next follow-up stage",
        );
      }
    } catch (err) {
      logger.error({ err, prospectId: prospect.id, stage: nextStage }, "Failed to auto-queue follow-up stage");
    }`,
  `    try {
      const { queued: didQueue, revived } = await queueStageForProspect(prospect.id, nextStage, scheduledAt);
      if (didQueue) {
        queued++;
        logger.info(
          {
            prospectId: prospect.id,
            stage: nextStage,
            scheduledAt: scheduledAt.toISOString(),
            followupMode: userFull?.followupMode || "auto_send",
            revived,
          },
          revived ? "Auto-queued next follow-up stage (revived cancelled row)" : "Auto-queued next follow-up stage",
        );
      }
    } catch (err) {
      logger.error({ err, prospectId: prospect.id, stage: nextStage }, "Failed to auto-queue follow-up stage");
    }`,
);

/* ---- Op 3 — Rewire queueNextFollowupStageForProspect ---- */

applyReplacement(
  SCHEDULER_TS,
  "rewire queueNextFollowupStageForProspect to use helper",
  `  const inserted = await db
    .insert(followupsTable)
    .values({
      prospectId,
      stage: nextStage,
      scheduledAt,
      status: "queued",
    })
    .onConflictDoNothing()
    .returning({ id: followupsTable.id });

  return {
    queued: Boolean(inserted[0]?.id),
    stage: nextStage,
    scheduledAt,
    reason: inserted[0]?.id ? undefined : "insert_conflict",
  };
}`,
  `  const { queued: didQueue } = await queueStageForProspect(prospectId, nextStage, scheduledAt);

  return {
    queued: didQueue,
    stage: nextStage,
    scheduledAt,
    reason: didQueue ? undefined : "insert_conflict",
  };
}`,
);

/* ===================================================================== */
/*  doctrine.ts                                                           */
/* ===================================================================== */

console.log("\n[doctrine.ts] importing helper + rewiring 4 call sites in 3 ops");

/* ---- Op 4 — Add queueStageForProspect to the scheduler import ---- */

applyReplacement(
  DOCTRINE_TS,
  "import queueStageForProspect from scheduler",
  `import { cancelActiveFollowupsForProspects, processDueFollowups, requeueStalledDraftForProspect } from "../services/scheduler";`,
  `import { cancelActiveFollowupsForProspects, processDueFollowups, queueStageForProspect, requeueStalledDraftForProspect } from "../services/scheduler";`,
);

/* ---- Op 5 — Rewire /queue AND /queue-batch (identical loop bodies) ---- */

applyReplacement(
  DOCTRINE_TS,
  "rewire /queue and /queue-batch to use helper",
  `    for (const [pid, scheduledAt] of schedule) {
      try {
        const result = await db
          .insert(followupsTable)
          .values({
            prospectId: pid,
            stage,
            scheduledAt: new Date(scheduledAt),
          })
          .onConflictDoNothing();

        if (result.rowCount && result.rowCount > 0) {
          queued++;
          if (!earliest || scheduledAt < earliest) earliest = scheduledAt;
          if (!latest || scheduledAt > latest) latest = scheduledAt;
        }
      } catch {
      }
    }`,
  `    for (const [pid, scheduledAt] of schedule) {
      try {
        const { queued: didQueue } = await queueStageForProspect(pid, stage, new Date(scheduledAt));
        if (didQueue) {
          queued++;
          if (!earliest || scheduledAt < earliest) earliest = scheduledAt;
          if (!latest || scheduledAt > latest) latest = scheduledAt;
        }
      } catch {
      }
    }`,
);

/* ---- Op 6 — Rewire /prospect/resume-bulk ---- */

applyReplacement(
  DOCTRINE_TS,
  "rewire /prospect/resume-bulk to use helper",
  `          try {
            await db.insert(followupsTable).values({
              prospectId: p.id,
              stage: nextStage,
              scheduledAt,
              status: "queued",
            });
            queued_new++;
          } catch {
            // Concurrent insert race (autoQueue cron tick + this resume).
            // Matches single-prospect /resume tolerance — silently swallow.
          }`,
  `          const { queued: didQueue } = await queueStageForProspect(p.id, nextStage, scheduledAt);
          if (didQueue) queued_new++;`,
);

/* ---- Op 7 — Rewire /prospect/:id/resume ---- */

applyReplacement(
  DOCTRINE_TS,
  "rewire /prospect/:id/resume to use helper",
  `        try {
          await db.insert(followupsTable).values({
            prospectId,
            stage: nextStage,
            scheduledAt,
            status: "queued",
          });
          queued_stage = nextStage;
        } catch {
        }`,
  `        const { queued: didQueue } = await queueStageForProspect(prospectId, nextStage, scheduledAt);
        if (didQueue) queued_stage = nextStage;`,
);

/* ===================================================================== */

console.log(`\nDone. Applied ${opsApplied}, skipped ${opsSkipped}.`);
