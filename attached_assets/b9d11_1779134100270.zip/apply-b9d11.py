#!/usr/bin/env python3
"""
B9d.11 - 3D cursor-tracked tilt on Card hover.

Replaces B9d.8's simple whileHover y-lift with a cursor-position-aware
3D tilt effect. As the mouse moves over a Card, the card rotates
subtly on X and Y axes following the cursor. Spring physics give a
natural, weighted feel.

Mechanism:
  - useMotionValue(0) tracks normalized x, y mouse position (-0.5 to 0.5)
  - useSpring smooths the motion values (stiffness 300, damping 25)
  - useTransform maps the springs to rotation degrees (max 5deg per axis)
  - transformPerspective: 1000 puts perspective into the transform stack
    (motion's prop for "perspective(1000px)" inside transform)
  - onMouseMove updates motion values, onMouseLeave resets to 0

Reduced-motion respect:
  - useReducedMotion gate forces rotation to 0 for users with the OS
    preference set, regardless of cursor position
  - Mouse handlers still fire but skip the set() calls

Performance:
  - Motion values update via framer-motion's RAF loop, not React state
  - Only hovered cards actively process mouse moves
  - Each Card adds 4 hooks (useMotionValue x2, useSpring x2 sets,
    useTransform x2) - cheap, negligible at typical list sizes
  - Wraps user-provided onMouseMove/onMouseLeave (called via prop
    destructuring) so consumers' handlers still fire

Variants from B9d.8 (hidden/visible for stagger entrance) preserved.

Two anchors in ui.tsx:
  A1: framer-motion import - add useMotionValue, useSpring,
      useTransform, useReducedMotion to existing import line.
  A2: Card component definition - swap simple whileHover for the
      tilt mechanism, add mouse handlers + cardVariants stays.

Idempotent. Unique markers per anchor.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: framer-motion import expansion
# Anchor on the existing import line from B9d.6 (motion + AnimatePresence).
# ====================================================================
A1_OLD = '''import { AnimatePresence, motion } from "framer-motion";'''

A1_NEW = '''// B9d.11: 3D tilt requires useMotionValue, useSpring, useTransform; reduced-motion via useReducedMotion.
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
} from "framer-motion";'''


# ====================================================================
# A2: Card component - replace B9d.8 simple whileHover with 3D tilt
# Anchor on the post-B9d.8 Card definition.
# ====================================================================
A2_OLD = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + always-on subtle hover lift.
// B9d.8: motion-converted with variants - inherits hidden/visible state from
// the App.tsx page motion.div, cascading in via staggerChildren. Hover-lift
// moved from CSS to whileHover to avoid clash with variant-driven transform.
const cardVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2, ease: "easeOut" as const } },
};

export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <motion.div
    variants={cardVariants}
    whileHover={{ y: -1 }}
    transition={{ type: "spring", stiffness: 400, damping: 30 }}
    className={cn(
      "rounded-xl shadow-sm",
      "transition-shadow duration-300 ease-out",
      "hover:shadow-md",
      className
    )}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...(props as any)}
  />
);'''

A2_NEW = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + hover lift for modern fintech feel.
// B9d.8: motion-converted with variants - inherits hidden/visible state
// from the page motion.div for staggered entrance.
// B9d.11: cursor-tracked 3D tilt replaces flat whileHover. As the mouse
// moves over the card, springs drive rotateX/rotateY toward the cursor
// (max 5deg per axis). Reduced-motion users skip the tilt entirely.
const cardVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2, ease: "easeOut" as const } },
};

const TILT_MAX_DEG = 5;

export const Card = ({
  className,
  onMouseMove,
  onMouseLeave,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => {
  const reduceMotion = useReducedMotion();
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springConfig = { stiffness: 300, damping: 25 } as const;
  const springX = useSpring(x, springConfig);
  const springY = useSpring(y, springConfig);
  // Y-axis mouse movement rotates around X-axis (top tips back), and vice versa.
  const rotateY = useTransform(springX, [-0.5, 0.5], [-TILT_MAX_DEG, TILT_MAX_DEG]);
  const rotateX = useTransform(springY, [-0.5, 0.5], [TILT_MAX_DEG, -TILT_MAX_DEG]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!reduceMotion) {
      const rect = e.currentTarget.getBoundingClientRect();
      x.set((e.clientX - rect.left) / rect.width - 0.5);
      y.set((e.clientY - rect.top) / rect.height - 0.5);
    }
    onMouseMove?.(e);
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    x.set(0);
    y.set(0);
    onMouseLeave?.(e);
  };

  return (
    <motion.div
      variants={cardVariants}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={cn(
        "rounded-xl shadow-sm",
        "transition-shadow duration-300 ease-out",
        "hover:shadow-md",
        className
      )}
      style={{
        background: "var(--bg-secondary)",
        border: "1px solid var(--border-default)",
        rotateX: reduceMotion ? 0 : rotateX,
        rotateY: reduceMotion ? 0 : rotateY,
        transformPerspective: 1000,
      }}
      {...(props as any)}
    />
  );
};'''


def main():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: expand framer-motion import",
        marker="B9d.11: 3D tilt requires useMotionValue",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: Card 3D tilt mechanism",
        marker="B9d.11: cursor-tracked 3D tilt",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")

    print()
    print("B9d.11 3D cursor-tracked tilt on Cards applied.")


if __name__ == "__main__":
    main()
