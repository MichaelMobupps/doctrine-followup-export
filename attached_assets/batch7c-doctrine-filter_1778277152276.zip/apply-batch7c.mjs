#!/usr/bin/env node
/**
 * apply-batch7c.mjs — Phase 7c (Doctrine route filter).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Closes the dormant gap from Batch 7b: every prospect query in
 * routes/doctrine.ts now includes `app='doctrine'` as a where clause.
 * The Doctrine UI is now fully isolated from any context prospect.
 *
 * Strategy: define a single SCOPE_DOCTRINE constant near the top of
 * doctrine.ts, then add it to every where() that touches prospectsTable.
 * Each edit's oldStr and newStr include enough surrounding context for
 * the sentinel (the new code being injected) to be unique file-wide.
 *
 * Usage:
 *   node apply-batch7c.mjs
 *   API_BASE=artifacts/api-server/src node apply-batch7c.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[apply-batch7c] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7c] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const doctrinePath = join(API_BASE, "routes", "doctrine.ts");

// ============================================================
// Step 1: Define SCOPE_DOCTRINE constant
// ============================================================
log("Step 1: Define SCOPE_DOCTRINE constant...");

strReplace(
  doctrinePath,
  `// Test mode fully removed — TEST_MODE_LABEL constant is no longer referenced.

const router = Router();`,
  `// Test mode fully removed — TEST_MODE_LABEL constant is no longer referenced.

// Phase 7c: app-scoping. Every prospect query in this file gates on
// app='doctrine' so the Doctrine UI is isolated from any context
// prospect that exists in the same prospects table.
const SCOPE_DOCTRINE = eq(prospectsTable.app, "doctrine");

const router = Router();`,
  "doctrine.ts: define SCOPE_DOCTRINE",
  `const SCOPE_DOCTRINE = eq(prospectsTable.app, "doctrine");`
);

// ============================================================
// Step 2: 22 surgical edits with full surrounding context
// ============================================================
log("Step 2: Apply SCOPE_DOCTRINE to every prospect query...");

// L35
strReplace(
  doctrinePath,
  `  const prospect = await db.select({ userId: prospectsTable.userId }).from(prospectsTable).where(eq(prospectsTable.id, prospectId)).limit(1);
  if (!prospect[0]?.userId) return undefined;`,
  `  const prospect = await db.select({ userId: prospectsTable.userId }).from(prospectsTable).where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
  if (!prospect[0]?.userId) return undefined;`,
  "L35: getUserTimingSettingsForProspect",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
  if (!prospect[0]?.userId) return undefined;`
);

// L58
strReplace(
  doctrinePath,
  `    .select({ id: prospectsTable.id, userId: prospectsTable.userId })
    .from(prospectsTable)
    .where(inArray(prospectsTable.id, prospectIds));

  const prospectUserMap = new Map<number, number | null>();`,
  `    .select({ id: prospectsTable.id, userId: prospectsTable.userId })
    .from(prospectsTable)
    .where(and(SCOPE_DOCTRINE, inArray(prospectsTable.id, prospectIds)));

  const prospectUserMap = new Map<number, number | null>();`,
  "L58: partitionAndSchedule inArray",
  `.where(and(SCOPE_DOCTRINE, inArray(prospectsTable.id, prospectIds)));

  const prospectUserMap = new Map<number, number | null>();`
);

// L115
strReplace(
  doctrinePath,
  `    const userIdFilter = req.query.userId ? parseInt(req.query.userId as string) : null;

    const prospectConditions = userIdFilter ? eq(prospectsTable.userId, userIdFilter) : undefined;`,
  `    const userIdFilter = req.query.userId ? parseInt(req.query.userId as string) : null;

    // Phase 7c: always scope to doctrine, optionally narrow by user.
    const prospectConditions = userIdFilter
      ? and(SCOPE_DOCTRINE, eq(prospectsTable.userId, userIdFilter))
      : SCOPE_DOCTRINE;`,
  "L115: /stats prospectConditions",
  `// Phase 7c: always scope to doctrine, optionally narrow by user.`
);

// L115b
strReplace(
  doctrinePath,
  `    const followupQuery = userIdFilter
      ? db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(eq(prospectsTable.userId, userIdFilter))
      : db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
        })
        .from(followupsTable);`,
  `    // Phase 7c: followup stats must also scope to doctrine via the prospects join.
    const followupQuery = userIdFilter
      ? db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId, userIdFilter)))
      : db.select({
          queuedFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'queued' then 1 else 0 end)\`,
          sentFollowups: sql<number>\`sum(case when \${followupsTable.status} = 'sent' then 1 else 0 end)\`,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(SCOPE_DOCTRINE);`,
  "L115b: /stats followup join",
  `// Phase 7c: followup stats must also scope to doctrine via the prospects join.`
);

// L186
strReplace(
  doctrinePath,
  `router.get("/prospects", async (req: Request, res: Response) => {
  try {
  const conditions: any[] = [];`,
  `router.get("/prospects", async (req: Request, res: Response) => {
  try {
  // Phase 7c: scope all returned prospects to the doctrine app.
  const conditions: any[] = [SCOPE_DOCTRINE];`,
  "L186: /prospects list",
  `// Phase 7c: scope all returned prospects to the doctrine app.
  const conditions: any[] = [SCOPE_DOCTRINE];`
);

// L683: /followups list — same conditions[] pattern as /prospects.
strReplace(
  doctrinePath,
  `router.get("/followups", async (req: Request, res: Response) => {
  try {
    const conditions: any[] = [];`,
  `router.get("/followups", async (req: Request, res: Response) => {
  try {
    // Phase 7c: scope to doctrine via the prospects inner-join.
    const conditions: any[] = [SCOPE_DOCTRINE];`,
  "L683: /followups list",
  `// Phase 7c: scope to doctrine via the prospects inner-join.
    const conditions: any[] = [SCOPE_DOCTRINE];`
);

// L782: /followups/:id/approve SELECT — joined to prospects, add SCOPE_DOCTRINE.
strReplace(
  doctrinePath,
  `      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(eq(followupsTable.id, followupId), eq(followupsTable.status, "pending_approval")))
      .limit(1);

    if (rows.length === 0) {
      res.status(404).json({ error: "Follow-up not found or not pending approval" });
      return;
    }

    const item = rows[0];`,
  `      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(SCOPE_DOCTRINE, eq(followupsTable.id, followupId), eq(followupsTable.status, "pending_approval")))
      .limit(1);

    if (rows.length === 0) {
      res.status(404).json({ error: "Follow-up not found or not pending approval" });
      return;
    }

    const item = rows[0];`,
  "L782: /followups/:id/approve SELECT",
  `.where(and(SCOPE_DOCTRINE, eq(followupsTable.id, followupId), eq(followupsTable.status, "pending_approval")))
      .limit(1);

    if (rows.length === 0) {
      res.status(404).json({ error: "Follow-up not found or not pending approval" });
      return;
    }

    const item = rows[0];`
);

// L851: /followups/:id/reject UPDATE — has no SELECT guard before, add an inArray sub-select on prospects.
strReplace(
  doctrinePath,
  `    const result = await db
      .update(followupsTable)
      .set({ status: "cancelled" })
      .where(and(eq(followupsTable.id, followupId), eq(followupsTable.status, "pending_approval")));

    if (!result.rowCount) {
      res.status(404).json({ error: "Follow-up not found or not pending approval" });
      return;
    }
    res.json({ success: true });`,
  `    // Phase 7c: gate by prospect.app via sub-select so a context follow-up
    // cannot be cancelled through the doctrine route.
    const result = await db
      .update(followupsTable)
      .set({ status: "cancelled" })
      .where(and(
        eq(followupsTable.id, followupId),
        eq(followupsTable.status, "pending_approval"),
        inArray(
          followupsTable.prospectId,
          db.select({ id: prospectsTable.id }).from(prospectsTable).where(SCOPE_DOCTRINE),
        ),
      ));

    if (!result.rowCount) {
      res.status(404).json({ error: "Follow-up not found or not pending approval" });
      return;
    }
    res.json({ success: true });`,
  "L851: /followups/:id/reject UPDATE",
  `// Phase 7c: gate by prospect.app via sub-select so a context follow-up
    // cannot be cancelled through the doctrine route.`
);

// L299
strReplace(
  doctrinePath,
  `      .select()
      .from(prospectsTable)
      .where(eq(prospectsTable.gmailThreadId, threadId))
      .limit(5);

    if (rows.length === 0) {
      res.status(404).json({ error: "Prospect not found for this thread" });`,
  `      .select()
      .from(prospectsTable)
      .where(and(SCOPE_DOCTRINE, eq(prospectsTable.gmailThreadId, threadId)))
      .limit(5);

    if (rows.length === 0) {
      res.status(404).json({ error: "Prospect not found for this thread" });`,
  "L299: /prospect/by-thread/:threadId",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.gmailThreadId, threadId)))
      .limit(5);

    if (rows.length === 0) {
      res.status(404).json({ error: "Prospect not found for this thread" });`
);

// L363
strReplace(
  doctrinePath,
  `      .select({ createdAt: prospectsTable.createdAt })
      .from(prospectsTable)
      .where(eq(prospectsTable.userId, userId))
      .orderBy(desc(prospectsTable.createdAt))
      .limit(1);`,
  `      .select({ createdAt: prospectsTable.createdAt })
      .from(prospectsTable)
      .where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId, userId)))
      .orderBy(desc(prospectsTable.createdAt))
      .limit(1);`,
  "L363: /my/activity",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId, userId)))
      .orderBy(desc(prospectsTable.createdAt))
      .limit(1);`
);

// L384: /my/activity queuedCount — followups inner-joined to prospects
strReplace(
  doctrinePath,
  `    const queuedCount = await db
      .select({ count: sql<number>\`count(*)\` })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ));`,
  `    const queuedCount = await db
      .select({ count: sql<number>\`count(*)\` })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        SCOPE_DOCTRINE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ));`,
  "L384: /my/activity queuedCount",
  `.where(and(
        SCOPE_DOCTRINE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ));`
);

// L393: /my/activity nextDue — same pattern
strReplace(
  doctrinePath,
  `    const nextDue = await db
      .select({ scheduledAt: followupsTable.scheduledAt })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ))
      .orderBy(asc(followupsTable.scheduledAt))
      .limit(1);`,
  `    const nextDue = await db
      .select({ scheduledAt: followupsTable.scheduledAt })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        SCOPE_DOCTRINE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ))
      .orderBy(asc(followupsTable.scheduledAt))
      .limit(1);`,
  "L393: /my/activity nextDue",
  `.where(and(
        SCOPE_DOCTRINE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ))
      .orderBy(asc(followupsTable.scheduledAt))`
);

// L460
strReplace(
  doctrinePath,
  `      .select({ id: prospectsTable.id })
      .from(prospectsTable)
      .where(and(...conditions));

    let ids = rows.map((r) => r.id);`,
  `      .select({ id: prospectsTable.id })
      .from(prospectsTable)
      .where(and(SCOPE_DOCTRINE, ...conditions));

    let ids = rows.map((r) => r.id);`,
  "L460: /queue-batch",
  `.where(and(SCOPE_DOCTRINE, ...conditions));

    let ids = rows.map((r) => r.id);`
);

// L557
strReplace(
  doctrinePath,
  `  try {
    const prospect = await db.select().from(prospectsTable).where(eq(prospectsTable.id, prospectId)).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }

    const p = prospect[0];
    if (!p.userId) { res.status(400).json({ error: "Prospect has no associated user" }); return; }`,
  `  try {
    const prospect = await db.select().from(prospectsTable).where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }

    const p = prospect[0];
    if (!p.userId) { res.status(400).json({ error: "Prospect has no associated user" }); return; }`,
  "L557: /followup-now/:prospectId",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }

    const p = prospect[0];
    if (!p.userId) { res.status(400).json({ error: "Prospect has no associated user" }); return; }`
);

// L872
strReplace(
  doctrinePath,
  `    try {
      const prospect = await db.select().from(prospectsTable).where(eq(prospectsTable.id, prospectId)).limit(1);
      if (!prospect[0]) { failed.push({ prospectId, error: "prospect not found" }); continue; }
      const p = prospect[0];
      if (!p.userId) { failed.push({ prospectId, error: "prospect has no associated user" }); continue; }`,
  `    try {
      const prospect = await db.select().from(prospectsTable).where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
      if (!prospect[0]) { failed.push({ prospectId, error: "prospect not found" }); continue; }
      const p = prospect[0];
      if (!p.userId) { failed.push({ prospectId, error: "prospect has no associated user" }); continue; }`,
  "L872: /followup/send-bulk inner",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
      if (!prospect[0]) { failed.push({ prospectId, error: "prospect not found" }); continue; }`
);

// L957
strReplace(
  doctrinePath,
  `    const pausedResult = await db
      .update(prospectsTable)
      .set({ followupPaused: true })
      .where(inArray(prospectsTable.id, ids));

    const cancelledCount = await cancelActiveFollowupsForProspects(`,
  `    const pausedResult = await db
      .update(prospectsTable)
      .set({ followupPaused: true })
      .where(and(SCOPE_DOCTRINE, inArray(prospectsTable.id, ids)));

    const cancelledCount = await cancelActiveFollowupsForProspects(`,
  "L957: /prospect/pause-bulk UPDATE",
  `.where(and(SCOPE_DOCTRINE, inArray(prospectsTable.id, ids)));

    const cancelledCount = await cancelActiveFollowupsForProspects(`
);

// L1015
strReplace(
  doctrinePath,
  `    const result = await db
      .update(prospectsTable)
      .set({ followupPaused: true })
      .where(eq(prospectsTable.id, prospectId));

    if (!result.rowCount) {
      res.status(404).json({ error: "Prospect not found" });`,
  `    const result = await db
      .update(prospectsTable)
      .set({ followupPaused: true })
      .where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId)));

    if (!result.rowCount) {
      res.status(404).json({ error: "Prospect not found" });`,
  "L1015: /prospect/:id/pause UPDATE",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId)));

    if (!result.rowCount) {
      res.status(404).json({ error: "Prospect not found" });`
);

// L1045+L1050
strReplace(
  doctrinePath,
  `  try {
    const prospect = await db.select().from(prospectsTable).where(eq(prospectsTable.id, prospectId)).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }
    if (prospect[0].replied) { res.status(400).json({ error: "Prospect already replied" }); return; }

    await db
      .update(prospectsTable)
      .set({ followupPaused: false })
      .where(eq(prospectsTable.id, prospectId));`,
  `  try {
    const prospect = await db.select().from(prospectsTable).where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }
    if (prospect[0].replied) { res.status(400).json({ error: "Prospect already replied" }); return; }

    await db
      .update(prospectsTable)
      .set({ followupPaused: false })
      .where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId)));`,
  "L1045+L1050: /prospect/:id/resume SELECT+UPDATE",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }
    if (prospect[0].replied) { res.status(400).json({ error: "Prospect already replied" }); return; }`
);

// L1129
strReplace(
  doctrinePath,
  `      batchLabel: prospectsTable.batchLabel,
    }).from(prospectsTable).where(eq(prospectsTable.id, prospectId)).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }`,
  `      batchLabel: prospectsTable.batchLabel,
    }).from(prospectsTable).where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);
    if (!prospect[0]) { res.status(404).json({ error: "Prospect not found" }); return; }`,
  "L1129: /prospect/:id/campaign-type SELECT",
  `      batchLabel: prospectsTable.batchLabel,
    }).from(prospectsTable).where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId))).limit(1);`
);

// L1149
strReplace(
  doctrinePath,
  `    await db
      .update(prospectsTable)
      .set({ batchLabel: newLabel })
      .where(eq(prospectsTable.id, prospectId));

    res.json({
      success: true,`,
  `    await db
      .update(prospectsTable)
      .set({ batchLabel: newLabel })
      .where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId)));

    res.json({
      success: true,`,
  "L1149: /prospect/:id/campaign-type UPDATE",
  `.set({ batchLabel: newLabel })
      .where(and(SCOPE_DOCTRINE, eq(prospectsTable.id, prospectId)));`
);

// L1192
strReplace(
  doctrinePath,
  `          .from(prospectsTable)
          .where(inArray(prospectsTable.userId!, userIds))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel)`,
  `          .from(prospectsTable)
          .where(and(SCOPE_DOCTRINE, inArray(prospectsTable.userId!, userIds)))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel)`,
  "L1192: /campaign/status group",
  `.where(and(SCOPE_DOCTRINE, inArray(prospectsTable.userId!, userIds)))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel)`
);

// L1204
strReplace(
  doctrinePath,
  `          .from(prospectsTable)
          .where(
            and(
              eq(prospectsTable.replied, 0),
              eq(prospectsTable.followupPaused, false),
              inArray(prospectsTable.userId!, userIds),`,
  `          .from(prospectsTable)
          .where(
            and(
              SCOPE_DOCTRINE,
              eq(prospectsTable.replied, 0),
              eq(prospectsTable.followupPaused, false),
              inArray(prospectsTable.userId!, userIds),`,
  "L1204: /campaign/status actionable",
  `              SCOPE_DOCTRINE,
              eq(prospectsTable.replied, 0),
              eq(prospectsTable.followupPaused, false),
              inArray(prospectsTable.userId!, userIds),`
);

// L1255
strReplace(
  doctrinePath,
  `          .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
          .where(inArray(prospectsTable.userId!, userIds))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel, followupsTable.status)`,
  `          .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
          .where(and(SCOPE_DOCTRINE, inArray(prospectsTable.userId!, userIds)))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel, followupsTable.status)`,
  "L1255: /campaign/status followup-status",
  `.where(and(SCOPE_DOCTRINE, inArray(prospectsTable.userId!, userIds)))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel, followupsTable.status)`
);

// L1369 (was L1355 before earlier scope edits): /campaign/queue.
//   Variable unrepliedProspects, 3-item and(),
//   disambiguated by the trailing res.json with the /queue-specific message.
strReplace(
  doctrinePath,
  `    const unrepliedProspects = await db
      .select({ id: prospectsTable.id, userId: prospectsTable.userId, sentAt: prospectsTable.sentAt })
      .from(prospectsTable)
      .where(
        and(
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
          or(...labelConditions),
        ),
      );

    if (unrepliedProspects.length === 0) {
      res.json({ queued: 0, message: "No unreplied prospects found." });`,
  `    const unrepliedProspects = await db
      .select({ id: prospectsTable.id, userId: prospectsTable.userId, sentAt: prospectsTable.sentAt })
      .from(prospectsTable)
      .where(
        and(
          SCOPE_DOCTRINE,
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
          or(...labelConditions),
        ),
      );

    if (unrepliedProspects.length === 0) {
      res.json({ queued: 0, message: "No unreplied prospects found." });`,
  "L1369: /campaign/queue unrepliedProspects",
  `      .where(
        and(
          SCOPE_DOCTRINE,
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
          or(...labelConditions),
        ),
      );

    if (unrepliedProspects.length === 0) {
      res.json({ queued: 0, message: "No unreplied prospects found." });`
);

// L1472: /campaign/launch — variable unrepliedProspects, 3-item and(),
//   disambiguated by the trailing res.json with `launched: true`.
strReplace(
  doctrinePath,
  `    const unrepliedProspects = await db
      .select({ id: prospectsTable.id, userId: prospectsTable.userId, sentAt: prospectsTable.sentAt })
      .from(prospectsTable)
      .where(
        and(
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
          or(...labelConditions),
        ),
      );

    if (unrepliedProspects.length === 0) {
      res.json({ launched: true, queued: 0, message: "No unreplied/unpaused prospects found." });`,
  `    const unrepliedProspects = await db
      .select({ id: prospectsTable.id, userId: prospectsTable.userId, sentAt: prospectsTable.sentAt })
      .from(prospectsTable)
      .where(
        and(
          SCOPE_DOCTRINE,
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
          or(...labelConditions),
        ),
      );

    if (unrepliedProspects.length === 0) {
      res.json({ launched: true, queued: 0, message: "No unreplied/unpaused prospects found." });`,
  "L1472: /campaign/launch unrepliedProspects",
  `      .where(
        and(
          SCOPE_DOCTRINE,
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
          or(...labelConditions),
        ),
      );

    if (unrepliedProspects.length === 0) {
      res.json({ launched: true, queued: 0, message: "No unreplied/unpaused prospects found." });`
);

// L1578
strReplace(
  doctrinePath,
  `        .select({ id: prospectsTable.id })
        .from(prospectsTable)
        .where(eq(prospectsTable.userId!, targetUserId));

      const prospectIds = userProspects.map((p) => p.id);`,
  `        .select({ id: prospectsTable.id })
        .from(prospectsTable)
        .where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId!, targetUserId)));

      const prospectIds = userProspects.map((p) => p.id);`,
  "L1578: /campaign/stop per-user",
  `.where(and(SCOPE_DOCTRINE, eq(prospectsTable.userId!, targetUserId)));

      const prospectIds = userProspects.map((p) => p.id);`
);

// L1592
strReplace(
  doctrinePath,
  `        .select({ id: prospectsTable.id })
        .from(prospectsTable);
      cancelledCount = await cancelActiveFollowupsForProspects(
        allProspects.map((p) => p.id),
        "Campaign stop requested; active follow-up cancelled.",
      );`,
  `        .select({ id: prospectsTable.id })
        .from(prospectsTable)
        .where(SCOPE_DOCTRINE);
      cancelledCount = await cancelActiveFollowupsForProspects(
        allProspects.map((p) => p.id),
        "Campaign stop requested; active follow-up cancelled.",
      );`,
  "L1592: /campaign/stop global",
  `.from(prospectsTable)
        .where(SCOPE_DOCTRINE);
      cancelledCount = await cancelActiveFollowupsForProspects(`
);

// ============================================================
// Step 3: Self-verify — count + naked-where scan
// ============================================================
log("Step 3: Self-verify...");

const final = readFileOrFail(doctrinePath);
const scopeCount = final.split("SCOPE_DOCTRINE").length - 1;
// Expected: 1 const declaration + 30 in-query references.
//   L115 has 2 (and-branch + ternary-else SCOPE_DOCTRINE)
//   L115b has 2 (with-userId branch + without-userId branch)
//   L1045+L1050 has 2 (SELECT + UPDATE)
//   Other 24 edits = 1 each.
//   Total: 1 + 2 + 2 + 2 + 24 = 31.
const expected = 31;
if (scopeCount !== expected) {
  fail(`Expected ${expected} SCOPE_DOCTRINE occurrences, found ${scopeCount}`);
}
log(`  [OK] SCOPE_DOCTRINE appears ${scopeCount}× (expected ${expected}).`);

// Final guard: scan every `.where(...)` whose clause body actually
// references prospectsTable columns, and verify SCOPE_DOCTRINE is
// reachable within a generous window.
//
// The "clause body" is heuristically the .where line + 6 following lines
// (covers multi-line where(and(...)) blocks). If those lines don't
// reference prospectsTable columns directly, the where filters another
// table only — chain-of-trust may apply (e.g. inArray on prospectIds
// derived from an already-scoped parent query).
//
// Lookbehind is 50 lines (covers conditions[] seed → whereClause distance
// in /prospects and /followups list endpoints).
const lines = final.split("\n");
const naked = [];
for (let i = 0; i < lines.length; i++) {
  if (!/\.where\(/.test(lines[i])) continue;
  const clauseBody = lines.slice(i, Math.min(lines.length, i + 7)).join("\n");
  if (!/prospectsTable\.(id|userId|gmailThreadId|replied|followupPaused|app|sentAt|batchLabel|createdAt)/.test(clauseBody)) continue;
  const lookahead = lines.slice(i, Math.min(lines.length, i + 8)).join("\n");
  const lookbehind = lines.slice(Math.max(0, i - 50), i).join("\n");
  const window = lookahead + "\n" + lookbehind;
  if (window.includes("SCOPE_DOCTRINE")) continue;
  naked.push(`L${i + 1}: ${lines[i].trim()}`);
}
if (naked.length > 0) {
  log("WARNING: candidate naked .where()s touching prospectsTable without SCOPE_DOCTRINE:");
  for (const n of naked) log(`    ${n}`);
  fail(`Found ${naked.length} unscoped where-clauses on prospectsTable.`);
}
log(`  [OK] No naked prospects where-clauses found.`);

log("");
log("================================================================");
log("Batch 7c patch applied. Doctrine routes are fully scoped to");
log("app='doctrine'. The dormant gap from 7b is closed.");
log("================================================================");
