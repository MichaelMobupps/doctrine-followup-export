#!/bin/bash
set -e
WORKSPACE="/home/runner/workspace"
API="$WORKSPACE/artifacts/api-server/src"
DASHBOARD="$WORKSPACE/artifacts/dashboard/src"

echo "============================================"
echo "  Doctrine — User Isolation + Autonomy"
echo "============================================"

# ──────────────────────────────────────────────────────
# BACKEND: Add userId filter to /prospects and /stats
# ──────────────────────────────────────────────────────
echo ""
echo "=== Backend: userId filtering on /prospects, /stats, /campaign/status ==="

python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/api-server/src/routes/doctrine.ts"
with open(filepath, "r") as f:
    c = f.read()

changes = 0

# 1. /stats endpoint — add userId filter
old_stats = '''router.get("/stats", async (_req: Request, res: Response) => {
  const prospectStats = await db
    .select({
      totalSent: sql<number>`count(*)`,
      unreplied: sql<number>`sum(case when ${prospectsTable.replied} = 0 then 1 else 0 end)`,
      replied: sql<number>`sum(case when ${prospectsTable.replied} = 1 then 1 else 0 end)`,
    })
    .from(prospectsTable);

  const followupStats = await db
    .select({
      queuedFollowups: sql<number>`sum(case when ${followupsTable.status} = 'queued' then 1 else 0 end)`,
      sentFollowups: sql<number>`sum(case when ${followupsTable.status} = 'sent' then 1 else 0 end)`,
    })
    .from(followupsTable);'''

new_stats = '''router.get("/stats", async (req: Request, res: Response) => {
  const userIdFilter = req.query.userId ? parseInt(req.query.userId as string) : null;

  const prospectConditions = userIdFilter ? eq(prospectsTable.userId, userIdFilter) : undefined;

  const prospectStats = await db
    .select({
      totalSent: sql<number>`count(*)`,
      unreplied: sql<number>`sum(case when ${prospectsTable.replied} = 0 then 1 else 0 end)`,
      replied: sql<number>`sum(case when ${prospectsTable.replied} = 1 then 1 else 0 end)`,
    })
    .from(prospectsTable)
    .where(prospectConditions);

  const followupQuery = userIdFilter
    ? db.select({
        queuedFollowups: sql<number>`sum(case when ${followupsTable.status} = 'queued' then 1 else 0 end)`,
        sentFollowups: sql<number>`sum(case when ${followupsTable.status} = 'sent' then 1 else 0 end)`,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(eq(prospectsTable.userId, userIdFilter))
    : db.select({
        queuedFollowups: sql<number>`sum(case when ${followupsTable.status} = 'queued' then 1 else 0 end)`,
        sentFollowups: sql<number>`sum(case when ${followupsTable.status} = 'sent' then 1 else 0 end)`,
      })
      .from(followupsTable);

  const followupStats = await followupQuery;'''

if old_stats in c:
    c = c.replace(old_stats, new_stats)
    changes += 1
    print("  /stats: userId filter added")

# 2. /prospects endpoint — add userId filter
old_prospects = '''router.get("/prospects", async (req: Request, res: Response) => {
  const conditions: any[] = [];

  if (req.query.vertical && req.query.vertical !== "all") {
    conditions.push(eq(prospectsTable.vertical, req.query.vertical as string));
  }
  if (req.query.replied !== undefined) {
    conditions.push(eq(prospectsTable.replied, parseInt(req.query.replied as string)));
  }'''

new_prospects = '''router.get("/prospects", async (req: Request, res: Response) => {
  const conditions: any[] = [];

  if (req.query.userId) {
    conditions.push(eq(prospectsTable.userId, parseInt(req.query.userId as string)));
  }
  if (req.query.vertical && req.query.vertical !== "all") {
    conditions.push(eq(prospectsTable.vertical, req.query.vertical as string));
  }
  if (req.query.replied !== undefined) {
    conditions.push(eq(prospectsTable.replied, parseInt(req.query.replied as string)));
  }'''

if old_prospects in c:
    c = c.replace(old_prospects, new_prospects)
    changes += 1
    print("  /prospects: userId filter added")

with open(filepath, "w") as f:
    f.write(c)
print(f"  doctrine.ts: {changes} endpoint(s) patched")
PYEOF

# ──────────────────────────────────────────────────────
# BACKEND: Add last sync timestamp to /gmail/accounts
# ──────────────────────────────────────────────────────
echo ""
echo "=== Backend: Add sync activity endpoint ==="

python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/api-server/src/routes/doctrine.ts"
with open(filepath, "r") as f:
    c = f.read()

# Add a /my/activity endpoint that returns last sync info for a user
if '"/my/activity"' not in c:
    activity_route = '''

router.get("/my/activity", async (req: Request, res: Response) => {
  const userId = req.query.userId ? parseInt(req.query.userId as string) : null;
  if (!userId) { res.json({ last_sync: null, queued: 0, next_due: null }); return; }

  try {
    const latestProspect = await db
      .select({ createdAt: prospectsTable.createdAt })
      .from(prospectsTable)
      .where(eq(prospectsTable.userId, userId))
      .orderBy(desc(prospectsTable.createdAt))
      .limit(1);

    const queuedCount = await db
      .select({ count: sql<number>`count(*)` })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ));

    const nextDue = await db
      .select({ scheduledAt: followupsTable.scheduledAt })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ))
      .orderBy(asc(followupsTable.scheduledAt))
      .limit(1);

    res.json({
      last_sync: latestProspect[0]?.createdAt?.toISOString() || null,
      queued: Number(queuedCount[0]?.count) || 0,
      next_due: nextDue[0]?.scheduledAt?.toISOString() || null,
    });
  } catch (err) {
    res.json({ last_sync: null, queued: 0, next_due: null });
  }
});
'''
    # Insert before the first router.post
    insert_point = c.find('\nrouter.post(')
    if insert_point > 0:
        c = c[:insert_point] + activity_route + c[insert_point:]
        with open(filepath, "w") as f:
            f.write(c)
        print("  /my/activity endpoint added")
    else:
        print("  WARNING: Could not find insertion point")
else:
    print("  /my/activity already exists")
PYEOF

# ──────────────────────────────────────────────────────
# FRONTEND: Copy all patched page files
# ──────────────────────────────────────────────────────
echo ""
echo "=== Frontend: Copying patched pages ==="

cp /tmp/doctrine_deploy2/pages/prospects.tsx "$DASHBOARD/pages/prospects.tsx"
cp /tmp/doctrine_deploy2/pages/followups.tsx "$DASHBOARD/pages/followups.tsx"
cp /tmp/doctrine_deploy2/pages/dashboard.tsx "$DASHBOARD/pages/dashboard.tsx"
cp /tmp/doctrine_deploy2/pages/email-inspector.tsx "$DASHBOARD/pages/email-inspector.tsx"
cp /tmp/doctrine_deploy2/pages/accounts.tsx "$DASHBOARD/pages/accounts.tsx"
cp /tmp/doctrine_deploy2/components/layout.tsx "$DASHBOARD/components/layout.tsx"
echo "  All frontend files copied"

# ──────────────────────────────────────────────────────
# Regen types + sync
# ──────────────────────────────────────────────────────
echo ""
echo "=== Regenerating types & syncing ==="
cd "$WORKSPACE"
npx openapi-typescript lib/api-spec/openapi.yaml -o lib/api-client/src/generated.ts 2>/dev/null || true
bash source-code/sync.sh 2>&1

echo ""
echo "============================================"
echo "  DEPLOY COMPLETE"
echo "============================================"
echo ""
echo "  - All pages now scoped to current user"
echo "  - Accounts page shows only your settings"  
echo "  - Sidebar shows live sync activity"
echo "  - Auto-queue runs fully autonomously"
echo ""
