# Batch B9b.3 — Auto-Create AntiGhosting Gmail Label

**Scope.** Plumb `users.antiGhostingLabel` into `syncForUser` so the label gets auto-created in the operator's Gmail mailbox, matching how Doctrine and Context labels are handled. Closes the bug where freshly-onboarded operators (or anyone who renames their AntiGhosting label in Settings) saw `note: "No Gmail labels matching ... found"` and had to create the label manually in Gmail.

## The bug

`syncForUser` in `services/gmailSync.ts` collects `doctrineLabels` and `contextLabels` from the user record, concatenates them, and calls `ensureLabelsExist(allLabels, gmail)` — which creates any missing labels in the operator's mailbox. `antiGhostingLabel` was never added to this path, so the label only existed in Gmail if the operator created it manually.

The dashboard previously surfaced a setup-help card walking the operator through manual label creation. That card is now mostly redundant — after this batch ships, the next sync run creates the label automatically.

## Four surgical edits, all in `services/gmailSync.ts`

1. **Widen `syncForUser` input type.** Add `antiGhostingLabel: string;` after the existing `contextLabel: string;`.
2. **Parse + include in allLabels.** Add `antiGhostingLabels` parsing line mirroring the existing `contextLabels` line, and update `allLabels` to spread `...antiGhostingLabels` after `...contextLabels`.
3. **Forward at first call site (`syncEmailsForUser`).** The per-user "Sync Gmail now" path from the add-on button. Add `antiGhostingLabel: user.antiGhostingLabel,` to the object passed to `syncForUser`.
4. **Forward at second call site (`syncEmails` loop).** The cron-driven all-users sync path. Same one-line addition.

Both call sites use `db.select().from(usersTable)` with no projection, so `user.antiGhostingLabel` is already in scope — no SELECT widening needed.

## What this batch does NOT do

- **No ingest from the AntiGhosting label.** Doctrine and Context use the label to scope email ingest — labeled threads get auto-converted into prospects. AntiGhosting is operator-driven: the operator clicks Mark in the dashboard. Adding `fetchLabeledSentEmails(antiGhostingLabels, ...)` would conflict with that model and create duplicate prospect rows.
- **No legacy-path support.** `syncForLegacyUser` is the env-var fallback for single-tenant deployments without DB user rows. It reads labels from `process.env.DOCTRINE_LABELS`. AntiGhosting requires a per-user account, so the legacy path is intentionally out of scope.

## Risk surface

1. **No schema change.** Column exists from B9a.
2. **No marking-flow change.** The `/api/anti-ghosting/candidates` and `/api/anti-ghosting/mark` endpoints already read the label correctly; this batch just ensures the label exists to be matched against.
3. **No new dependencies.**
4. **Existing users with the default `"AntiGhosting Followuper"` value get the label created on their next sync cycle.** No manual action required.
5. **Operators who already created the label manually:** `ensureLabelsExist` is idempotent — if the label exists (case-insensitive name match), it's skipped. No duplication.
6. **Operators who renamed their label in Settings (B9b.2):** the new name gets auto-created on the next sync cycle. The old default label is NOT cleaned up (intentional — could still contain operator-tagged threads from earlier).

## Timing

Label creation happens on the next sync cycle, not instantly. Cron probably runs every few minutes; new users see the label appear in Gmail within that window. If immediate creation matters, the operator can hit the "Sync Gmail now" button in the add-on, which triggers `syncEmailsForUser` synchronously.

## Validation

```bash
python3 scripts/apply-b9b3.py
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server run build
```

Expect: 4 edits applied, 0 typecheck errors, build succeeds.

After deploy and the next sync run:
- A fresh operator with default `antiGhostingLabel="AntiGhosting Followuper"` opens Gmail → sees the new label in the sidebar.
- An operator who set `antiGhostingLabel="My Custom Re-Engage Tag"` in Settings → sees that exact label appear after sync runs.
- The `/anti-ghosting` page's setup-help card stops appearing (the API endpoint finds matching labels).

## Layout

```
batch-b9b3-anti-ghosting-label-auto-create/
|-- README.md
`-- scripts/
    `-- apply-b9b3.py
```

Sandbox-tested: 4 FIX on first run, 4 SKIP on second run, anchors all hit exactly once, post-patch source contains the expected 7 line references to `antiGhostingLabel`.
