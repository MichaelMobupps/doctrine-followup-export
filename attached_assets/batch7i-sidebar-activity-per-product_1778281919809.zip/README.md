# Batch 7i — Sidebar activity per-product

Phase 7i. Fixes the sidebar's "AUTO-DETECTING / All caught up" indicator
to poll the right product's activity endpoint based on the current
route.

## The problem

Before this batch, `layout.tsx` polls `/api/my/activity` (the doctrine
endpoint) every 30 seconds regardless of which product page the user is
viewing. On `/context/*` pages, the sidebar indicator shows doctrine
queue numbers (or "All caught up" reflecting doctrine state) even
though the user is looking at the context surface. Misleading
information, no functional break.

## What's in this batch

**Backend changes (`routes/context.ts`):**

- **New endpoint `GET /api/context/my/activity`**. Mirrors
  `/api/my/activity` (in `routes/doctrine.ts`) line-for-line with one
  difference: every `SCOPE_DOCTRINE` becomes `SCOPE`. Same response
  shape: `{ last_sync, queued, next_due }`. Same userId-required guard
  (returns null/zero defaults when userId missing). Same try/catch
  fallback to defaults on error.

**Frontend changes (`dashboard/components/layout.tsx`):**

- The polling effect now derives `activityPath` from `onContext`:
  - On `/context/*` routes: `api/context/my/activity`
  - Anywhere else: `api/my/activity`
- `onContext` is added to the effect's dependency array so the poll
  re-fires immediately when the user navigates between products
  (instead of waiting up to 30 seconds for the next interval tick).
- Bonus correctness: the previous deps array `[apiKey, currentUser?.userId]`
  was missing `onContext`, which meant a stale-closure bug — when the
  user switched products, the effect kept using the old `onContext`
  value until something else triggered a re-render with new deps. Now
  fixed.

## What changes for the user

- **Sidebar indicator on `/context/*` pages** now shows context queue
  numbers (or "All caught up" reflecting context state).
- **Sidebar indicator on doctrine pages** continues to show doctrine
  numbers — unchanged.
- **Switching products** triggers an immediate refetch (visible as the
  indicator briefly flickering) rather than waiting up to 30s.

## Files

```
batch7i/
├── apply-batch7i.mjs       # Idempotent patch (one backend + one frontend edit)
├── audit-batch7i.mjs       # 9 passes × 3 rounds = 102 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build api-server + dashboard.
Mirror sync. Restart api-server + republish dashboard.

## Verify

After applying:

- The apply script self-verifies 8 anchors (4 backend + 3 frontend +
  1 absence check).
- The audit script runs 102 checks (34 per round × 3 rounds): backend
  endpoint declared, response shape mirrors doctrine, all three queries
  in the handler use `SCOPE` (not `SCOPE_DOCTRINE`), layout.tsx URL
  ternary lands, `onContext` in deps, doctrine `/my/activity` not
  regressed (still `SCOPE_DOCTRINE`-gated 3 times), B7a-B7h regression.

Backend smoke after restart:

```bash
# 1. New endpoint responds with the standard shape (no userId → defaults)
curl -s "http://localhost:8080/api/context/my/activity" \
  -H "x-api-key: $ADDON_API_KEY"

# 2. With userId, returns context queue state
curl -s "http://localhost:8080/api/context/my/activity?userId=1" \
  -H "x-api-key: $ADDON_API_KEY"

# 3. Doctrine endpoint unchanged (regression check)
curl -s "http://localhost:8080/api/my/activity?userId=1" \
  -H "x-api-key: $ADDON_API_KEY"
```

Expected:
1. `{"last_sync":null,"queued":0,"next_due":null}`
2. `{"last_sync":null,"queued":0,"next_due":null}` (since no context
   prospects exist for userId=1 yet)
3. `{"last_sync":"2026-...Z","queued":0,"next_due":null}` or similar
   (the doctrine state — should match what was there before this
   batch)

Browser smoke after dashboard republish + hard-reload:

1. On `/` (doctrine pipeline): sidebar shows the doctrine-flavored
   activity indicator. Open DevTools Network tab — see polls to
   `/api/my/activity?userId=...` every 30s.
2. Navigate to `/context/pipeline`: indicator updates within seconds.
   Network tab now shows polls to `/api/context/my/activity?userId=...`
   instead.
3. Navigate back to `/`: indicator re-targets `/api/my/activity` again.

## Known residual

- The indicator's visual state ("AUTO-DETECTING" vs "All caught up")
  is unchanged — same logic, same thresholds. Only the data source is
  product-aware now. If the user wants different copy per product
  (e.g., "Doctrine: All caught up" vs "Context: All caught up"), that's
  a separate cosmetic batch.
- Network polling cadence is still 30s on both products.
