#!/usr/bin/env python3
"""
B9b.12.4 - Allow resume on replied AG prospects.

Use case: prospect replied once, user wants to re-engage in case they
ghost the next exchange. Currently the Resume button is hidden on
replied prospects (UI), and the backend blocks resume calls on
replied (single + bulk). Both layers need relaxation.

Frontend (anti-ghosting-pipeline.tsx):
  E1: Inline row pause/resume toggle wrapper \u2014 drop !replied gate
      so the Resume icon shows on replied+paused prospects.
  E2: Detail panel Resume button condition \u2014 drop !replied gate.

Backend (anti-ghosting.ts):
  E3: /prospect/:id/resume \u2014 remove the early-return `if
      (prospect.replied)` block.
  E4: /prospect/resume-bulk \u2014 remove the `.filter(p => !p.replied)`
      so replied prospects pass through to the per-prospect insert loop.

Status logic in the UI is unchanged (replied still wins for display),
but a newly-scheduled stage will appear underneath the status, and the
operator can click `+` to force-send if they prefer immediate dispatch.

Idempotent. All anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ROUTE = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"
PIPELINE = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-pipeline.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# --------------------------------------------------------------------
# E1: Inline row pause/resume wrapper. Anchor on the unique surrounding
# context so we don't accidentally match in other files / locations.
# --------------------------------------------------------------------
E1_OLD = '''                    {!thread.replied && !thread.all_done && (
                      <Button
                        variant="ghost" size="sm"
                        onClick={() => handleTogglePause(thread.prospect_id, thread.followup_paused)}'''

E1_NEW = '''                    {/* B9b.12.4: show pause/resume toggle on replied prospects too \u2014 manual re-engagement. */}
                    {!thread.all_done && (
                      <Button
                        variant="ghost" size="sm"
                        onClick={() => handleTogglePause(thread.prospect_id, thread.followup_paused)}'''


# --------------------------------------------------------------------
# E2: Detail panel Resume button condition. Drop !replied gate.
# --------------------------------------------------------------------
E2_OLD = '''                      {thread.followup_paused && !thread.replied && (
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => handleTogglePause(thread.prospect_id, true)}'''

E2_NEW = '''                      {/* B9b.12.4: show Resume on any paused (including replied). */}
                      {thread.followup_paused && (
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => handleTogglePause(thread.prospect_id, true)}'''


# --------------------------------------------------------------------
# E3: Single resume \u2014 remove the early-return replied defense.
# --------------------------------------------------------------------
E3_OLD = '''    if (!prospect) {
      res.status(404).json({ error: "anti_ghosting prospect not found" });
      return;
    }
    if (prospect.replied) {
      res.status(400).json({ error: "Prospect already replied" });
      return;
    }
    await db.update(prospectsTable)
      .set({ followupPaused: false })'''

E3_NEW = '''    if (!prospect) {
      res.status(404).json({ error: "anti_ghosting prospect not found" });
      return;
    }
    // B9b.12.4: replied prospects can be resumed for manual re-engagement.
    // The status display still shows "Replied", but a newly-scheduled
    // followup will appear and operator can force-send via the + button.
    await db.update(prospectsTable)
      .set({ followupPaused: false })'''


# --------------------------------------------------------------------
# E4: Bulk resume \u2014 remove the !p.replied filter on candidates.
# --------------------------------------------------------------------
E4_OLD = '''    const eligible = candidates.filter((p) => !p.replied);'''

E4_NEW = '''    // B9b.12.4: replied prospects can be resumed too (manual re-engagement).
    const eligible = candidates;'''


def patch_route():
    if not ROUTE.exists():
        fail(f"route not found: {ROUTE}")
    text = ROUTE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, E3_OLD, E3_NEW,
        "single resume: drop replied defense",
        marker="B9b.12.4: replied prospects can be resumed for manual",
    )

    text, _ = replace_unique(
        text, E4_OLD, E4_NEW,
        "bulk resume: drop replied filter",
        marker="B9b.12.4: replied prospects can be resumed too",
    )

    if text != original:
        ROUTE.write_text(text, encoding="utf-8")
        ok(f"wrote {ROUTE.relative_to(WORKSPACE)}")
    else:
        skip("route already patched")


def patch_pipeline():
    if not PIPELINE.exists():
        fail(f"pipeline not found: {PIPELINE}")
    text = PIPELINE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, E1_OLD, E1_NEW,
        "inline row pause/resume wrapper",
        marker="B9b.12.4: show pause/resume toggle on replied",
    )

    text, _ = replace_unique(
        text, E2_OLD, E2_NEW,
        "detail panel Resume condition",
        marker="B9b.12.4: show Resume on any paused",
    )

    if text != original:
        PIPELINE.write_text(text, encoding="utf-8")
        ok(f"wrote {PIPELINE.relative_to(WORKSPACE)}")
    else:
        skip("pipeline already patched")


def main():
    patch_route()
    patch_pipeline()
    print()
    print("B9b.12.4 resume-on-replied applied.")


if __name__ == "__main__":
    main()
