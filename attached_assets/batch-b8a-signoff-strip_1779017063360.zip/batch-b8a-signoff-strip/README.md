# Batch B8a — Sign-Off and Signature-Line Removal

**Scope.** Stop the Doctrine and Context follow-up writers from emitting a closing line or signature-name line at the bottom of the body. Production observation (2026-05-17): the model produced "Best regards,\nMichael Goder" at the bottom of the body, and the Gmail signature was then appended below that, producing a duplicated sign-off.

## What changed

### Prompts
- `services/followupPrompts.ts`
  - Writer system prompt: replaced the ambiguous "Sign off with just the sender's first name." rule with an explicit no-closing rule listing banned phrases in 15+ languages.
  - Writer user prompt: removed SENDER NAME field (the model no longer receives the name).
  - Critic system prompt: added criterion **15. NO CLOSING / SIGN-OFF**; added `closing_strip` to scores JSON; added `closing_strip < 4` to the `needs_rewrite` trigger.
  - Rewriter system prompt: replaced the same ambiguous sign-off rule with an explicit strip-the-closing rule.
  - Rewriter user prompt: removed SENDER NAME field.
  - Four references to "the sender's signature at the bottom" rephrased to "any signature appended automatically by the email client" so the prompt no longer implicitly instructs the model to produce one.

- `services/contextFollowupPrompts.ts`
  - Generator system prompt: added hard constraint **#9 NO CLOSING / SIGN-OFF**.
  - Critic system prompt: added `closing_strip` dimension (1-10), added `closing_present` flag category, updated scores JSON, recomputed overall as the average of **6** scores.
  - Rewriter system prompt: added hard constraint **#9** mirroring the generator.
  - User prompt: removed the `From: ` sender_name line.

### Deterministic safety net (new file)
- `services/signatureStripper.ts` exports `stripClosingFromBody(body)`. Three-phase algorithm:
  1. Pop trailing whitespace.
  2. Pop trailing closing lines (curated phrase list across 18 languages, normalised for punctuation and case).
  3. If a closing was popped, conservatively pop the immediately-preceding name line (short, no sentence-terminator, max 4 whitespace tokens, max 40 chars).
- Multi-pass (handles stacked closings), idempotent, CRLF-preserving.
- Hooked into `humanizeFollowup` (doctrine) and wrapped around all 4 return paths of `generateContextFollowup` (context).

### Tests
- `tests/test-signoff-strip-b8a.ts` — 42 tests across positive cases (en/es/pt/fr/de/it/ru/he/ar/ja/zh/ko/th/vi/hi), negative cases (inline mentions, real CTAs, bare orphan names), edge cases (empty, idempotency, CRLF, stacked closings, name-line punctuation guard), and phrase-table sanity checks.
- Locally verified before bundling: **42 / 42 pass.**

## Layout

```
batch-b8a-signoff-strip/
|-- README.md
|-- services/
|   |-- followupPrompts.ts          (replace)
|   |-- contextFollowupPrompts.ts   (replace)
|   |-- followupGenerator.ts        (replace)
|   |-- contextFollowupGenerator.ts (replace)
|   `-- signatureStripper.ts        (new)
`-- tests/
    `-- test-signoff-strip-b8a.ts   (new)
```

Apply to `artifacts/api-server/src/services/` and `artifacts/api-server/src/tests/` respectively. The `source-code/` tree is read-only review material and is refreshed via `source-code/sync.sh` after the batch lands.

## Risk surface

- Critic scores schema is `Record<string, number>` — adding `closing_strip` is non-breaking.
- `sender_name` stays on the `FollowupContext` interface so the scheduler upstream call site is unaffected. We only stopped surfacing it in prompt text.
- Stripper only acts on truly trailing closings. Mid-body occurrences (rare but possible) are left for the critic to flag, since stripping mid-body risks false positives on real content.
