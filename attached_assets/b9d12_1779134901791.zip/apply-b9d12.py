#!/usr/bin/env python3
"""
B9d.12 - Sidebar right-edge depth shadow.

Pure CSS. Adds a box-shadow on the sidebar aside so it visibly
floats above the page content. Per-theme tuning:
  Doctrine/Context (dark themes): shadow alpha 0.25 (visible
    against near-black bg).
  AG (light theme): shadow alpha 0.08 (subtle on white sidebar
    against slate-200 page bg).

Single anchor: end of the Context override block from B9d.4.
Inserts new selectors before @layer base.

No JSX changes. Sidebar's existing inline border-right is
unaffected (different property, composes naturally with shadow).

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INDEX_CSS = WORKSPACE / "artifacts/dashboard/src/index.css"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


# Anchor on the unique closing of the Context block.
# (--color-info-foreground: #1a1208; only appears in Context block.)
OLD = '''  --color-info: #f59e0b;
  --color-info-foreground: #1a1208;
}'''

NEW = '''  --color-info: #f59e0b;
  --color-info-foreground: #1a1208;
}

/* ============================================================== */
/* B9d.12: Sidebar depth shadow                                    */
/* ============================================================== */
/* The sidebar (`<aside>`) is fixed-positioned left. A right-edge  */
/* box-shadow gives the page visual hierarchy: sidebar floats      */
/* above content. Per-theme alpha tuning - high on dark, subtle    */
/* on light. The aside's inline border-right stays unaffected.     */
[data-product="doctrine"] aside,
[data-product="context"] aside {
  box-shadow: 4px 0 24px rgba(0, 0, 0, 0.25);
}

[data-product="anti_ghosting"] aside {
  box-shadow: 4px 0 16px rgba(15, 23, 42, 0.08);
}'''

MARKER = "B9d.12: Sidebar depth shadow"


def main():
    if not INDEX_CSS.exists():
        fail(f"index.css not found: {INDEX_CSS}")
    text = INDEX_CSS.read_text(encoding="utf-8")

    if MARKER in text:
        print("[skip] sidebar depth shadow already applied")
        return

    count = text.count(OLD)
    if count == 0:
        fail("anchor not found - expected Context block closing")
    if count != 1:
        fail(f"anchor matched {count} times; expected exactly 1")

    text = text.replace(OLD, NEW)
    INDEX_CSS.write_text(text, encoding="utf-8")
    print("[ok]   sidebar depth shadow inserted")
    print(f"[ok]   wrote {INDEX_CSS.relative_to(WORKSPACE)}")
    print()
    print("B9d.12 sidebar depth shadow applied.")


if __name__ == "__main__":
    main()
