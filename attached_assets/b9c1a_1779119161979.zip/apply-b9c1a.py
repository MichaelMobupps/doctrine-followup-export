#!/usr/bin/env python3
"""
B9c.1a - Backend endpoint for fetching parsed thread messages with seed
annotation. Foundational for the seed-viewer + seed-selector UX.

GET /api/anti-ghosting/thread/:gmailThreadId/messages?userId=N

Returns:
  {
    threadId: string,
    prospect: { id: number, currentSeedMessageId: string | null } | null,
    messages: [
      {
        id: string,                    // Gmail message ID
        sentAt: string,                // ISO timestamp
        fromHeader: string,            // raw "Name <email>" header
        fromEmail: string,             // parsed
        fromName: string,              // parsed
        direction: "inbound"|"outbound",
        isSeed: boolean,               // matches prospect.gmailMessageId
        ...other fields from ThreadMessageBrief
      }
    ]
  }

Reuses existing helpers:
  - parseGmailThread (antiGhostingValidators.ts)
  - classifyDirection (threadReader.ts)
  - getGmailForUser (gmailClient.ts \u2014 already imported in anti-ghosting.ts)

One file edit (anti-ghosting.ts):
  P1: Add parseGmailThread + classifyDirection to the existing imports.
  P2: Insert the new route handler after /sync (or at end of routes).

Idempotent. Both anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ROUTE = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# --------------------------------------------------------------------
# P1: Extend the existing validators import with parseGmailThread, and
# add a new classifyDirection import from threadReader.
# --------------------------------------------------------------------
P1_OLD = '''import { validateThreadForMarking } from "../services/antiGhostingValidators";'''

P1_NEW = '''// B9c.1a: parseGmailThread for surfacing thread structure to the inspector.
import { validateThreadForMarking, parseGmailThread } from "../services/antiGhostingValidators";
import { classifyDirection } from "../services/threadReader";'''


# --------------------------------------------------------------------
# P2: Append the new route at the end of the file. Anchor on the
# `export default router;` line (or whatever closes the module).
# Fallback: anchor on a unique stable line near the end.
# --------------------------------------------------------------------
# Anchor: the /sync route is at line 1339 per the earlier route grep.
# Use the `})` close of /sync as the anchor and inject the new route
# immediately after it.
P2_OLD = '''router.post("/sync", async (req: Request, res: Response) => {'''

P2_NEW = '''// B9c.1a: GET /api/anti-ghosting/thread/:gmailThreadId/messages
// Lists every message in a Gmail thread with direction (inbound/outbound)
// and a `isSeed` flag for the message currently driving F1/F2/F3
// generation. Used by the inspector's expanded view (B9c.1b) to show
// the operator what the AI is reading; B9c.2 will add a write
// endpoint so the operator can change the seed.
router.get("/thread/:gmailThreadId/messages", async (req: Request, res: Response) => {
  const gmailThreadId = String(req.params.gmailThreadId);
  const userId = req.query.userId ? parseInt(String(req.query.userId), 10) : null;
  if (!gmailThreadId) {
    res.status(400).json({ error: "missing gmailThreadId" });
    return;
  }
  if (!userId || !Number.isFinite(userId)) {
    res.status(400).json({ error: "missing or invalid userId" });
    return;
  }

  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, userId))
      .limit(1);
    if (!user) {
      res.status(404).json({ error: "user not found" });
      return;
    }
    if (!user.googleRefreshToken || !user.isConnected) {
      res.status(400).json({ error: "user Gmail not connected" });
      return;
    }

    const gmail = getGmailForUser({
      refreshToken: user.googleRefreshToken,
      email: user.email,
    });

    // Cross-reference an AG prospect for this thread so we know which
    // message is the active seed. Scoped per-user + per-app.
    const [prospect] = await db
      .select({
        id: prospectsTable.id,
        gmailMessageId: prospectsTable.gmailMessageId,
      })
      .from(prospectsTable)
      .where(and(
        eq(prospectsTable.app, "anti_ghosting"),
        eq(prospectsTable.gmailThreadId, gmailThreadId),
        eq(prospectsTable.userId, userId),
      ))
      .limit(1);

    const briefs = await parseGmailThread(gmail, gmailThreadId, user.email);

    const messages = briefs.map((b) => ({
      ...b,
      sentAt: b.sentAt.toISOString(),
      direction: classifyDirection(b.fromHeader, user.email),
      isSeed: prospect ? b.id === prospect.gmailMessageId : false,
    }));

    res.json({
      threadId: gmailThreadId,
      prospect: prospect
        ? { id: prospect.id, currentSeedMessageId: prospect.gmailMessageId }
        : null,
      messages,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err, gmailThreadId, userId }, "GET /thread/:gmailThreadId/messages failed");
    res.status(500).json({ error: msg });
  }
});

router.post("/sync", async (req: Request, res: Response) => {'''


def main():
    if not ROUTE.exists():
        fail(f"route not found: {ROUTE}")
    text = ROUTE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, P1_OLD, P1_NEW,
        "P1: extend imports (parseGmailThread + classifyDirection)",
        marker="B9c.1a: parseGmailThread for surfacing thread structure",
    )

    text, _ = replace_unique(
        text, P2_OLD, P2_NEW,
        "P2: insert /thread/:gmailThreadId/messages route",
        marker="B9c.1a: GET /api/anti-ghosting/thread/:gmailThreadId/messages",
    )

    if text != original:
        ROUTE.write_text(text, encoding="utf-8")
        ok(f"wrote {ROUTE.relative_to(WORKSPACE)}")
    else:
        skip("route already patched")

    print()
    print("B9c.1a thread messages endpoint applied.")


if __name__ == "__main__":
    main()
