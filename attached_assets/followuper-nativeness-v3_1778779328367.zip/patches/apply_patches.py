#!/usr/bin/env python3
"""
apply_patches.py — Followuper v3 nativeness hardening (Reading A++)

Static-import variant (compatible with the Followuper's ESM module type).
Adds the top-of-file import of nativenessV3 separately from the function
body replacement, so each touched file gets two ops.

Op layout (13 ops total):
  1. install lib/nativenessV3.ts (new file)
  2. languageNativeness.ts  — add import { buildNativenessBlockV3, buildCriticNativenessBlockV3 } from "./nativenessV3"
  3. languageNativeness.ts  — buildNativenessBlock body → forwarder
  4. languageNativeness.ts  — buildCriticNativenessBlock body → forwarder
  5. doctrineLint.ts        — add import { findAllNativenessViolations } from "./nativenessV3"
  6. doctrineLint.ts        — detectNativenessViolations body → v3 aggregator
  7. followupPrompts.ts     — criterion 4 (LANGUAGE NATURALNESS) → Reading-A++
  8. followupPrompts.ts     — criterion 9 sub-rule (d) → universal X-not-Y
  9. followupPrompts.ts     — criterion 10 → UNTRANSLITERATED GREETING NAME

Usage:
    python3 apply_patches.py [BASE_DIR]

BASE_DIR defaults to current directory. For the live Followuper tree, this
is typically artifacts/api-server/src/  (the directory that contains lib/
and services/). For the source-code mirror, this is source-code/api-server/.
"""

import sys
from pathlib import Path
from typing import NamedTuple, List


class PatchOp(NamedTuple):
    name: str
    file: str
    marker: str
    old: str
    new: str


class NewFile(NamedTuple):
    name: str
    src: str
    dst: str


NEW_FILES: List[NewFile] = [
    NewFile(
        name="install-nativenessV3-module",
        src="followuper/lib/nativenessV3.ts",
        dst="lib/nativenessV3.ts",
    ),
    NewFile(
        name="install-test-nativeness-v3",
        src="followuper/tests/test-nativeness-v3.ts",
        dst="tests/test-nativeness-v3.ts",
    ),
    NewFile(
        name="update-test-doctrine-hardening-to-v3",
        src="followuper/tests/test-doctrine-hardening.ts",
        dst="tests/test-doctrine-hardening.ts",
    ),
]


OPS: List[PatchOp] = [

    # ------------------------------------------------------------------------
    # OP A: languageNativeness.ts — add static ESM import at top
    # ------------------------------------------------------------------------
    PatchOp(
        name="languageNativeness-add-import",
        file="lib/languageNativeness.ts",
        marker='from "./nativenessV3"',
        old=' *   const block = buildNativenessBlock("sw-TZ");  // normalizes to "sw"\n */\n\n/**\n * Extract the primary language subtag from a BCP 47 language tag.',
        new=' *   const block = buildNativenessBlock("sw-TZ");  // normalizes to "sw"\n */\n\nimport { buildNativenessBlockV3, buildCriticNativenessBlockV3 } from "./nativenessV3";\n\n/**\n * Extract the primary language subtag from a BCP 47 language tag.',
    ),

    # ------------------------------------------------------------------------
    # OP B: languageNativeness.ts — buildNativenessBlock body → forwarder
    # ------------------------------------------------------------------------
    PatchOp(
        name="languageNativeness-buildNativenessBlock-forwarder",
        file="lib/languageNativeness.ts",
        marker="v3 forwarder for buildNativenessBlock",
        old='/**\n * Build the nativeness rule block that gets injected into LLM prompts\n * for non-English emails. Returns empty string for English/unknown/empty.\n */\nexport function buildNativenessBlock(languageTag: string | null | undefined): string {\n  const lang = normalizeLanguageCode(languageTag);\n  if (!lang || lang === "en") return "";',
        new='/**\n * Build the nativeness rule block that gets injected into LLM prompts.\n * v3 forwarder for buildNativenessBlock — delegates to the Reading-A++\n * policy in lib/nativenessV3.ts.\n *\n * Reading-A++: every non-acronym, non-proper-noun English token in a\n * non-English email is a violation. The historical ENGLISH-TOLERANT and\n * ENGLISH-HEAVY carve-outs for German, Dutch, Nordics, Vietnamese, Thai,\n * Indonesian, Malay, Filipino, Tagalog, and Swahili are removed. All 35\n * supported languages are held to the same strict translation standard.\n *\n * Two universal style rules apply to every language including English:\n *   - X-not-Y comma-negation pattern is banned.\n *   - Non-Latin-script targets must transliterate the prospect\'s first\n *     name in the greeting into the local script.\n */\nexport function buildNativenessBlock(languageTag: string | null | undefined): string {\n  return buildNativenessBlockV3(languageTag);\n}\n\n/**\n * Legacy v2 buildNativenessBlock body. Retained for the audit trail only —\n * not called from anywhere.\n */\nfunction _buildNativenessBlock_v2_LEGACY_REMOVED(languageTag: string | null | undefined): string {\n  const lang = normalizeLanguageCode(languageTag);\n  if (!lang || lang === "en") return "";',
    ),

    # ------------------------------------------------------------------------
    # OP C: languageNativeness.ts — buildCriticNativenessBlock → forwarder
    # ------------------------------------------------------------------------
    PatchOp(
        name="languageNativeness-buildCriticNativenessBlock-forwarder",
        file="lib/languageNativeness.ts",
        marker="v3 forwarder for buildCriticNativenessBlock",
        old='export function buildCriticNativenessBlock(languageTag: string | null | undefined): string {\n  const lang = normalizeLanguageCode(languageTag);\n  if (!lang || lang === "en") return "";',
        new='// v3 forwarder for buildCriticNativenessBlock — delegates to the\n// Reading-A++ critic block. Same policy as buildNativenessBlock.\nexport function buildCriticNativenessBlock(languageTag: string | null | undefined): string {\n  return buildCriticNativenessBlockV3(languageTag);\n}\n\n/** Legacy v2 buildCriticNativenessBlock body, retained for audit only. */\nfunction _buildCriticNativenessBlock_v2_LEGACY_REMOVED(languageTag: string | null | undefined): string {\n  const lang = normalizeLanguageCode(languageTag);\n  if (!lang || lang === "en") return "";',
    ),

    # ------------------------------------------------------------------------
    # OP D: doctrineLint.ts — add static ESM import at top
    # ------------------------------------------------------------------------
    PatchOp(
        name="doctrineLint-add-import",
        file="lib/doctrineLint.ts",
        marker='from "./nativenessV3"',
        old='import { normalizeLanguageCode } from "./languageNativeness";',
        new='import { normalizeLanguageCode } from "./languageNativeness";\nimport { findAllNativenessViolations } from "./nativenessV3";',
    ),

    # ------------------------------------------------------------------------
    # OP E: doctrineLint.ts — detectNativenessViolations → v3 aggregator
    # ------------------------------------------------------------------------
    PatchOp(
        name="doctrineLint-detectNativeness-v3-body",
        file="lib/doctrineLint.ts",
        marker="detectNativenessViolations: v3 aggregator",
        old='/**\n * Run deterministic language-nativeness checks. For non-Latin-script\n * languages, detect multi-word English phrases (the Zekri pattern) leaking\n * into the prose. For Latin-script languages, this is a no-op.\n */\nexport function detectNativenessViolations(body: string, languageTag: string): ViolationReport {\n  const lang = normalizeLanguageCode(languageTag);\n  if (!lang || !NON_LATIN_LANGUAGES.has(lang)) {\n    return EMPTY_REPORT;\n  }',
        new='/**\n * detectNativenessViolations: v3 aggregator.\n *\n * Reading-A++ policy enforcement at the deterministic-lint layer. Runs\n * every v3 detector (multi-word forbidden phrases, Latin-token runs in\n * non-Latin prose, English content singletons, X-not-Y comma-negation,\n * untransliterated greeting names) and folds all hits into the existing\n * ViolationReport shape so callers in followupGenerator / contextFollowup\n * keep working with no changes.\n */\nexport function detectNativenessViolations(body: string, languageTag: string): ViolationReport {\n  const report = findAllNativenessViolations(body, languageTag);\n  const issues: string[] = [];\n  const suggestions: string[] = [];\n  const matches: string[] = [];\n\n  if (report.forbidden_phrases.length > 0) {\n    const sample = report.forbidden_phrases.slice(0, 4).map(p => `"${p}"`).join(", ");\n    issues.push(\n      `FORBIDDEN-ENGLISH-PHRASE \\u2014 multi-word English adtech phrase(s) ` +\n      `inside ${languageTag} prose (${sample}). v3 Reading-A++ requires ` +\n      `every multi-word English phrase to be translated entirely; splitting ` +\n      `the phrase (translating one word and leaving another in English) is ` +\n      `also a violation.`\n    );\n    suggestions.push(\n      "Rewrite every flagged multi-word phrase into the target language. " +\n      "Use the per-language TRANSLATION REFERENCE in the nativeness block " +\n      "if one is provided for this language."\n    );\n    matches.push(...report.forbidden_phrases);\n  }\n\n  if (report.latin_token_runs.length > 0) {\n    const sample = report.latin_token_runs.slice(0, 4).map(r => `"${r}"`).join(", ");\n    issues.push(\n      `LATIN-TOKEN-RUN \\u2014 2+ consecutive non-allowlist Latin words ` +\n      `inside non-Latin-script ${languageTag} prose (${sample}). Every ` +\n      `multi-word Latin run inside non-Latin prose must be translated or ` +\n      `transliterated. Only curated acronyms (CPI, ROAS, LTV, etc.) and ` +\n      `proper nouns may remain in Latin script.`\n    );\n    suggestions.push(\n      "Translate or transliterate every flagged Latin run. If the run is " +\n      "genuinely a proper noun (brand name, product name, person name), " +\n      "it stays as is; otherwise it is rewritten in the target language."\n    );\n    matches.push(...report.latin_token_runs);\n  }\n\n  if (report.forbidden_singletons.length > 0) {\n    const sample = report.forbidden_singletons.slice(0, 6).map(s => `"${s}"`).join(", ");\n    issues.push(\n      `FORBIDDEN-ENGLISH-SINGLETON \\u2014 English content word(s) inside ` +\n      `${languageTag} prose (${sample}). v3 Reading-A++ permits ONLY ` +\n      `curated acronyms and proper nouns in Latin script. Every other ` +\n      `English content word \\u2014 including capitalized loan-nouns like ` +\n      `German "Conversion" or "Performance" \\u2014 must be translated.`\n    );\n    suggestions.push(\n      "Translate every flagged English content word into the target " +\n      "language. The historical ENGLISH-TOLERANT / ENGLISH-HEAVY carve-outs " +\n      "for German, Dutch, Nordics, Vietnamese, Thai, Indonesian, etc. are " +\n      "removed in v3."\n    );\n    matches.push(...report.forbidden_singletons);\n  }\n\n  if (report.x_not_y.length > 0) {\n    const sample = report.x_not_y.slice(0, 3).map(x => `"${x}"`).join(", ");\n    issues.push(\n      `X-NOT-Y \\u2014 comma-plus-negation contrast pattern (${sample}). ` +\n      `This cadence reads as classic LLM output and humans detect it ` +\n      `instantly as AI writing. Applies in every language including English.`\n    );\n    suggestions.push(\n      "Rewrite each flagged X-not-Y phrase using \\"rather than\\" or " +\n      "\\"instead of\\" (or the target-language equivalent), or rephrase " +\n      "to drop the contrast entirely."\n    );\n    matches.push(...report.x_not_y);\n  }\n\n  if (report.untransliterated_greeting_name.length > 0) {\n    const sample = report.untransliterated_greeting_name.map(n => `"${n}"`).join(", ");\n    issues.push(\n      `UNTRANSLITERATED-GREETING-NAME \\u2014 Latin-script name in greeting ` +\n      `line of non-Latin ${languageTag} email (${sample}). Native speakers ` +\n      `write names in the local script; "เรียน Songsitt" should be ` +\n      `"เรียน ทรงสิทธิ์".`\n    );\n    suggestions.push(\n      "Transliterate the prospect\'s first name into the target script " +\n      "in the greeting line. The sender\'s signature at the bottom stays " +\n      "in Latin."\n    );\n    matches.push(...report.untransliterated_greeting_name);\n  }\n\n  if (issues.length === 0) return EMPTY_REPORT;\n  return { found: true, issues, suggestions, matches };\n}\n\n/** Legacy v1 body, retained for audit only. Not called. */\nfunction _detectNativenessViolations_v1_LEGACY_REMOVED(body: string, languageTag: string): ViolationReport {\n  const lang = normalizeLanguageCode(languageTag);\n  if (!lang || !NON_LATIN_LANGUAGES.has(lang)) {\n    return EMPTY_REPORT;\n  }',
    ),

    # ------------------------------------------------------------------------
    # OP F: followupPrompts.ts — criterion 4 → Reading-A++
    # ------------------------------------------------------------------------
    PatchOp(
        name="critic-criterion4-readingApp",
        file="services/followupPrompts.ts",
        marker="v3 Reading-A++ critic criterion 4",
        old='4. LANGUAGE NATURALNESS (applies only when target language is NOT English): Does the email read like a native-speaking salesperson wrote it, or like an English draft with key terms left untranslated? When the target language is not English, you will receive a LANGUAGE-SPECIFIC CHECKS block below that encodes how ad-tech professionals in that specific language\'s market actually write. Evaluate the draft against THAT block. Critically: the rule is NOT a universal "translate all jargon" rule — different languages have different norms. Russian/Chinese/Spanish translate nearly everything; Vietnamese/Thai/Indonesian/Filipino keep nearly everything in English; German/Dutch/Nordic are mixed. Score against the language\'s actual norm. Flag: (a) terms the guide says to translate but appear in English, (b) terms the guide says to keep in English but appear over-translated, (c) inconsistent code-switching where the same concept appears in both forms, (d) SCRIPT-MIXING — any Latin/English word directly adjacent to non-Latin characters in a non-Latin-script language (e.g. "pre-bid скрининг", "fraud対策", "lookalike定向", "pre-bid筛选" are all wrong — they must be transliterated). Acronyms (CPI, ROAS, DSP, LTV, D7, MMP) hyphenated to non-Latin words ARE acceptable. If the draft has 3+ such violations, score MUST be 1 and needs_rewrite MUST be true. If 1-2 violations, score 2-3 and set needs_rewrite = true. Quote the specific offending terms in "issues".',
        new='4. LANGUAGE NATURALNESS (v3 Reading-A++ critic criterion 4, applies when target language is NOT English): The ONLY Latin tokens permitted inside a non-English email are (a) pure acronyms from the curated allowlist (CPI, CPA, CPM, CPC, CTR, CVR, ROAS, AOV, ARPU, ARPDAU, LTV, MAU, DAU, D7, D30, MMP, SDK, IAP, OEM, KPI, KYC, AI, ML, DSP, SSP, RTB, B2B, etc.) and (b) proper nouns (Meta, Google, Apple, TikTok, Xiaomi, OPPO, Vivo, AppsFlyer, Adjust, the prospect\'s own brand and product names). EVERY OTHER English word — single tokens AND multi-word phrases — is a violation. This includes capitalized loan-nouns like German "Conversion" (must be "Umwandlung"), "Performance" (must be "Leistung"), "Retention" (must be "Kundenbindung"). The historical ENGLISH-TOLERANT carve-out for German/Dutch/Nordics and the ENGLISH-HEAVY carve-out for Vietnamese/Thai/Indonesian/Malay/Filipino/Swahili are REMOVED in v3 — all 35 supported languages are held to the same strict translation standard. The LANGUAGE-SPECIFIC CHECKS block below encodes the per-language translation table; use it as the reference for canonical localized forms. Flag every offending token: (a) any single English content word (cohort, install, conversion, retention, lookalike, audience, publisher, creative, screening, validation, attribution, optimization, anomaly, detection, filtering, modeling, inventory, supply, placement, postback, segment, payer, signup, subscriber, campaign, performance, channel, source, partner, platform, network, system, data, analytics, pipeline, feature, launch, experiment, test, tier, trial, subscription, event, click, impression, view, deposit, purchase, registration, bid, budget, deliver, optimize, convert, acquire, scale, premium, exclusive, durable), (b) any multi-word English phrase (semi-exclusive inventory, pre-bid screening, post-attribution verification, cohort-level anomaly detection, multi-layer fraud filtering, payer-lookalike modeling, first-party IAP postbacks, Android-heavy audience, publisher mix, one-time spenders, rewarded video, playable ads, genre signal, open-world hook, GTA-style gameplay loop, F2P-only users, fraud filtering, anomaly detection), (c) SCRIPT-MIXING — any Latin word directly adjacent to non-Latin characters (acronyms hyphenated with a space or hyphen ARE acceptable: "D7-удержание"). If the draft has 3+ such violations, score MUST be 1 and needs_rewrite MUST be true. If 1-2 violations, score 2-3 and set needs_rewrite = true. Quote the specific offending tokens / phrases in "issues".',
    ),

    # ------------------------------------------------------------------------
    # OP G: followupPrompts.ts — criterion 9 sub-rule (d) → universal X-not-Y
    # ------------------------------------------------------------------------
    PatchOp(
        name="critic-criterion9d-universal-x-not-y",
        file="services/followupPrompts.ts",
        marker="v3 universal X-NOT-Y ban",
        old='(d) NO CPA-AS-DIFFERENTIATOR — no "we pay only for X, not Y" framing as a differentiator.',
        new='(d) NO X-NOT-Y COMMA-NEGATION — v3 universal X-NOT-Y ban: in EVERY language including English, the comma-plus-negation contrast pattern is forbidden. Examples to flag in English: "performance partners, not raw installs", "approved events, not signups", "real users, not bots". Target-language equivalents to flag: ", no" (es/pt), ", non" (it/fr), ", nicht" (de), ", не" / ", а не" (ru/uk), ", nie" (pl), ", ไม่ใช่" (th), ", không phải" (vi), ", 不是" (zh), ", ではなく" (ja), ", 아니라" (ko). This cadence reads as classic LLM output and humans detect it instantly. Acceptable alternative: "rather than" / "instead of" / or rephrase to drop the contrast entirely. Flag every occurrence. The narrower v2 rule that only banned X-not-Y when used as a CPA-as-differentiator framing is replaced by this universal ban.',
    ),

    # ------------------------------------------------------------------------
    # OP H: followupPrompts.ts — criterion 10 (untransliterated name)
    # ------------------------------------------------------------------------
    PatchOp(
        name="critic-criterion10-untransliterated-name",
        file="services/followupPrompts.ts",
        marker="v3 criterion 10 untransliterated greeting name",
        old='OUTPUT FORMAT:\nReturn ONLY a JSON object:\n{\n  "scores": { "no_meta_language": 1-5, "followup_ack": 1-5, "language_match": 1-5, "language_naturalness": 1-5, "conciseness": 1-5, "relevance": 1-5, "differentiation": 1-5, "tone": 1-5, "doctrine_compliance": 1-5 },',
        new='10. UNTRANSLITERATED GREETING NAME (v3 criterion 10 untransliterated greeting name, applies ONLY when target language uses a non-Latin script: th, zh, ja, ko, ar, he, fa, ur, hi, bn, ta, te, mr, gu, kn, ml, pa, ru, uk, el, am, ka, hy, etc.): the greeting line of the email contains the prospect\'s first name written in Latin/English script while the rest of the greeting is in the target script. Examples to flag: "เรียน Songsitt" (Thai greeting + Latin name — must become "เรียน ทรงสิทธิ์" or similar Thai-script transliteration), "Hi Manish" inside a Hindi email body (must become "नमस्ते मनीश"), "Dear Yuki" inside a Japanese email body (must become "ゆきさん、" or similar). Native speakers always write names in the local script. The sender\'s signature at the bottom of the email is exempt — only the GREETING name is checked. Acronyms in the greeting (rare) are exempt. If the greeting name is in Latin and the target uses a non-Latin script, score language_naturalness 1-2 and set needs_rewrite = true; this is a high-visibility nativeness failure since it is the first thing the recipient sees.\n\nOUTPUT FORMAT:\nReturn ONLY a JSON object:\n{\n  "scores": { "no_meta_language": 1-5, "followup_ack": 1-5, "language_match": 1-5, "language_naturalness": 1-5, "conciseness": 1-5, "relevance": 1-5, "differentiation": 1-5, "tone": 1-5, "doctrine_compliance": 1-5 },',
    ),

    # ------------------------------------------------------------------------
    # OP I: followupPrompts.ts — rewriter LANGUAGE NATURALNESS → Reading-A++
    # ------------------------------------------------------------------------
    # The rewriter prompt also carried v2 carve-out language. The critic flags
    # issues against v3 norms; the rewriter must fix them against v3 norms or
    # the rewrite cycle ping-pongs between the two specs.
    PatchOp(
        name="rewriter-language-naturalness-v3",
        file="services/followupPrompts.ts",
        marker="v3 rewriter LANGUAGE NATURALNESS",
        old='- LANGUAGE NATURALNESS: When the target language is not English, you will receive a LANGUAGE NATIVENESS RULES block below that specifies EXACTLY which industry terms to translate and which to keep in English for that language. Follow that block exactly. The rule is NOT universal — different languages have different norms (Russian/Chinese/Spanish translate nearly everything; Vietnamese/Thai/Indonesian/Filipino keep nearly everything in English; German/Dutch/Nordic are mixed). Replace every term the critic flagged with the form specified by the language\'s guide. Also eliminate any SCRIPT-MIXING: in non-Latin-script languages, no Latin/English word may sit directly adjacent to non-Latin characters — transliterate or restructure. Acronyms (CPI, ROAS, DSP, LTV, D7, MMP) hyphenated to non-Latin words are acceptable.',
        new='- LANGUAGE NATURALNESS (v3 rewriter LANGUAGE NATURALNESS, Reading-A++): When the target language is not English, the rule is universal across all 35 supported languages. The ONLY Latin tokens allowed inside the email body are (a) pure acronyms (CPI, CPA, ROAS, LTV, MMP, SDK, IAP, KPI, KYC, AI, ML, D7, D30, DSP, SSP, RTB, B2B, iOS, USD, EUR, etc.) and (b) proper nouns (Meta, Google, Apple, TikTok, Xiaomi, OPPO, AppsFlyer, Adjust, the prospect\'s own brand and product names). EVERY OTHER English word — single tokens and multi-word phrases — must be translated. This includes capitalized loan-nouns like German "Conversion" → "Umwandlung", "Performance" → "Leistung", "Retention" → "Kundenbindung". The v2 ENGLISH-TOLERANT / ENGLISH-HEAVY carve-outs for German/Dutch/Nordics/Vietnamese/Thai/Indonesian/Filipino/Swahili are removed. Use the LANGUAGE NATIVENESS RULES block below as the canonical translation reference. Eliminate any SCRIPT-MIXING in non-Latin-script languages: no Latin word may sit directly adjacent to non-Latin characters. Acronyms (CPI, ROAS, LTV, D7, MMP) hyphenated to non-Latin words ARE acceptable. For non-Latin-script targets, also TRANSLITERATE the prospect\'s first name in the greeting into the target script ("เรียน Songsitt" → "เรียน ทรงสิทธิ์"). The sender\'s signature at the bottom stays in Latin.',
    ),

    # ------------------------------------------------------------------------
    # OP J: followupPrompts.ts — rewriter DOCTRINE → universal X-not-Y ban
    # ------------------------------------------------------------------------
    PatchOp(
        name="rewriter-doctrine-universal-x-not-y",
        file="services/followupPrompts.ts",
        marker="v3 rewriter universal X-NOT-Y",
        old='- DOCTRINE: cut hedge-on-number ("around 250" → "250"), hype adjectives ("strong", "powerful", "significant", "innovative", "best-in-class", "industry-leading", and target-language equivalents), multi-event optimization claims (anchor on EXACTLY ONE event), and CPA-as-differentiator framing ("we pay only for X, not Y"). For non-Latin-script target languages, no multi-word English phrases inside the prose — single permitted-acronym tokens and proper nouns are fine, but two or more consecutive lowercase English content words is a violation.',
        new='- DOCTRINE (v3 rewriter universal X-NOT-Y): cut hedge-on-number ("around 250" → "250"), hype adjectives ("strong", "powerful", "significant", "innovative", "best-in-class", "industry-leading", and target-language equivalents), and multi-event optimization claims (anchor on EXACTLY ONE event). Eliminate the X-NOT-Y comma-negation pattern in EVERY language including English — "performance partners, not raw installs" is forbidden; rewrite as "performance partners rather than raw installs" or rephrase to drop the contrast. Target-language equivalents to remove: ", no" (es/pt), ", nicht" (de), ", не" (ru), ", ไม่ใช่" (th), ", không phải" (vi), ", 不是" (zh), ", ではなく" (ja), etc. For non-English target languages (Reading-A++), no multi-word English phrases and no single non-acronym English content words inside the prose — only curated acronyms and proper nouns may remain in Latin script.',
    ),

    # ------------------------------------------------------------------------
    # OP K: followupPrompts.ts — writer doctrine bullet 4 → universal X-not-Y
    # ------------------------------------------------------------------------
    # The writer also had a narrow "NO CPA-AS-DIFFERENTIATOR" rule. Universalize.
    PatchOp(
        name="writer-doctrine-universal-x-not-y",
        file="services/followupPrompts.ts",
        marker="v3 writer universal X-NOT-Y",
        old='4. NO CPA-AS-DIFFERENTIATOR — never frame "we pay only for X, not Y" as a differentiator. Every ad network can offer that, so it does not differentiate. If a follow-up needs a differentiating claim at all, anchor it on one of: renewals/persistence (durable revenue past the first cycle), incrementality (incremental users vs cannibalized), or semi-exclusive supply (publishers not shared with named competitors).',
        new='4. NO X-NOT-Y COMMA-NEGATION (v3 writer universal X-NOT-Y) — in every language including English, the comma-plus-negation contrast pattern is banned. "performance partners, not raw installs" / "approved events, not signups" / "real users, not bots" all read as classic LLM cadence and humans detect it instantly as AI writing. Acceptable alternatives: "rather than" / "instead of" / or rephrase to drop the contrast. Target-language equivalents are also banned: ", no" (es/pt), ", nicht" (de), ", не" / ", а не" (ru/uk), ", ไม่ใช่" (th), ", không phải" (vi), ", 不是" (zh), ", ではなく" (ja). Differentiating claims should anchor on one of: renewals/persistence (durable revenue past the first cycle), incrementality (incremental users vs cannibalized), or semi-exclusive supply (publishers not shared with named competitors).',
    ),

    # ------------------------------------------------------------------------
    # OP L: followupPrompts.ts — writer LANGUAGE NATIVENESS → Reading-A++
    # ------------------------------------------------------------------------
    # The writer system prompt also had a v2-style nativeness bullet with the
    # "single tokens MAY stay" carve-out. v3 removes that carve-out entirely.
    PatchOp(
        name="writer-language-nativeness-readingApp",
        file="services/followupPrompts.ts",
        marker="v3 writer Reading-A++ LANGUAGE NATIVENESS",
        old='LANGUAGE NATIVENESS — additional rule for non-Latin-script target languages (Thai, Chinese, Japanese, Korean, Arabic, Hebrew, Persian, Hindi, Bengali, Urdu, Russian, Ukrainian, Greek, and others): never inject a multi-word English phrase into the prose. Single industry-standard adtech tokens that the language guide explicitly permits (cohort, event, retention) MAY stay in English as isolated single words. But two or more consecutive lowercase English content words (like "quality user acquisition" or "approved revenue events") inside non-Latin prose is ALWAYS a violation. Proper nouns ("Brand Day", "King Power Online") and acronyms (UA, LTV, ROAS, CPI, CPA, MMP, DSP, SDK, IAP, KPI) are exempt. When in doubt, write the phrase in the target language.',
        new='LANGUAGE NATIVENESS (v3 writer Reading-A++ LANGUAGE NATIVENESS) — for every non-English target language: the ONLY Latin tokens permitted in the email body are (a) curated acronyms (CPI, CPA, ROAS, LTV, MMP, SDK, IAP, KPI, KYC, AI, ML, D7, D30, DSP, SSP, RTB, B2B, iOS, USD, EUR, etc.) and (b) proper nouns (Meta, Google, Apple, TikTok, Xiaomi, OPPO, AppsFlyer, Adjust, brand and product names). Every other English word, single or multi-word, must be translated. This includes capitalized loan-nouns like German "Conversion" (must be "Umwandlung"), "Performance" (must be "Leistung"). The historical "single tokens like cohort/event/retention may stay" carve-out and the per-language ENGLISH-TOLERANT / ENGLISH-HEAVY exceptions are REMOVED in v3 — all 35 supported languages follow the same strict rule. For non-Latin-script targets (Thai, Chinese, Japanese, Korean, Arabic, Hebrew, Persian, Hindi, Bengali, Urdu, Russian, Ukrainian, Greek, and others), also TRANSLITERATE the prospect\'s first name in the greeting into the target script ("เรียน Songsitt" should be "เรียน ทรงสิทธิ์"). The sender\'s Latin-script signature at the bottom is exempt.',
    ),
]


# ============================================================================
# Engine
# ============================================================================

def apply_new_file(base: Path, payload: Path, nf: NewFile, backup_dir: Path) -> str:
    src = payload / nf.src
    dst = base / nf.dst
    if not src.exists():
        return f"FAIL  {nf.name}: source not found at {src}"
    if dst.exists():
        if dst.read_bytes() == src.read_bytes():
            return f"SKIP  {nf.name}: already installed (byte-identical)"
        relpath = dst.relative_to(base)
        bk = backup_dir / relpath
        bk.parent.mkdir(parents=True, exist_ok=True)
        if not bk.exists():
            bk.write_bytes(dst.read_bytes())
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(src.read_bytes())
    return f"OK    {nf.name}: installed {dst}"


def apply_op(base: Path, op: PatchOp, backup_dir: Path) -> str:
    target = base / op.file
    if not target.exists():
        return f"SKIP  {op.name}: target not found at {target}"

    content = target.read_text(encoding="utf-8")
    if op.marker in content:
        return f"SKIP  {op.name}: already applied (marker present)"
    if op.old not in content:
        return f"FAIL  {op.name}: anchor not found in {target}"

    occurrences = content.count(op.old)
    if occurrences > 1:
        return f"FAIL  {op.name}: anchor occurs {occurrences} times — not unique"

    relpath = target.relative_to(base)
    bk = backup_dir / relpath
    bk.parent.mkdir(parents=True, exist_ok=True)
    if not bk.exists():
        bk.write_text(content, encoding="utf-8")

    new_content = content.replace(op.old, op.new, 1)
    target.write_text(new_content, encoding="utf-8")
    return f"OK    {op.name}: patched {target}"


def main():
    base = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    payload = Path(__file__).parent.parent.resolve()

    if not base.exists() or not base.is_dir():
        print(f"ERROR: base directory does not exist: {base}", file=sys.stderr)
        sys.exit(1)

    print(f"Base: {base}")
    print(f"Payload: {payload}")
    backup_dir = base / ".backups" / "followuper-nativeness-v3"
    print(f"Backups: {backup_dir}")
    print()

    results = []
    failed = False

    for nf in NEW_FILES:
        status = apply_new_file(base, payload, nf, backup_dir)
        results.append(status)
        print(status)
        if status.startswith("FAIL"):
            failed = True

    for op in OPS:
        status = apply_op(base, op, backup_dir)
        results.append(status)
        print(status)
        if status.startswith("FAIL"):
            failed = True

    total_ops = len(NEW_FILES) + len(OPS)
    print()
    print(f"Total: {total_ops} ops, "
          f"OK={sum(1 for r in results if r.startswith('OK'))}, "
          f"SKIP={sum(1 for r in results if r.startswith('SKIP'))}, "
          f"FAIL={sum(1 for r in results if r.startswith('FAIL'))}")

    if failed:
        print()
        print("Some ops failed. Inspect FAIL lines above.")
        sys.exit(2)


if __name__ == "__main__":
    main()
