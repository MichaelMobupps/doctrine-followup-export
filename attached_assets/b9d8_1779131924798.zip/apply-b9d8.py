#!/usr/bin/env python3
"""
B9d.8 - Stagger animations on lists via variant propagation.

Cards now cascade in after each page transition. The mechanism:

  App.tsx motion.div uses variants pattern (initial="hidden",
  animate="visible") with staggerChildren in the transition.
  Card converts from <div> to <motion.div> with matching
  variants (hidden / visible). Framer-motion propagates the
  parent state through React context to all motion descendants,
  so any Card on any page picks up the cascade automatically -
  no per-page wiring needed.

Sequence on every route change:
  1. New page fade-in (200ms, when: "beforeChildren")
  2. Cards inside cascade in (30ms stagger between each)

The previous B9d.6 hover-lift (CSS `hover:-translate-y-px`) is
moved to motion's `whileHover={{ y: -1 }}` to avoid colliding with
the variant-driven transform. Shadow hover stays in CSS (no
transform overlap).

Reduced-motion respect from B9d.7.1 is preserved - when
prefers-reduced-motion is set, motionProps is {} and no
animation runs. Cards render statically in that case.

Two anchors:
  A1 (App.tsx): motion props upgraded to variants pattern with
      staggerChildren orchestration.
  A2 (ui.tsx): Card converts to motion.div with hidden/visible
      variants + whileHover lift.

Idempotent. Markers are uniquely worded to avoid the B9d.7 vs
B9d.7.1 collision lesson.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
APP = WORKSPACE / "artifacts/dashboard/src/App.tsx"
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: App.tsx - upgrade motion to variants pattern with staggerChildren
# Anchor on B9d.7.1's reduceMotion + motionProps block (which uses
# direct prop objects, not variants).
# ====================================================================
A1_OLD = '''  const [location] = useLocation();
  const reduceMotion = useReducedMotion();
  const motionProps = reduceMotion ? {} : {
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -8 },
    transition: { duration: 0.2, ease: "easeOut" as const },
  };'''

A1_NEW = '''  const [location] = useLocation();
  const reduceMotion = useReducedMotion();
  // B9d.8: variants pattern with staggerChildren orchestrates cascade.
  // when: "beforeChildren" runs page fade-in first, then cascades cards
  // via the same hidden/visible state names (Card uses matching variants).
  const pageVariants = {
    hidden: { opacity: 0, y: 8 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.2,
        ease: "easeOut" as const,
        when: "beforeChildren" as const,
        staggerChildren: 0.03,
      },
    },
    exit: { opacity: 0, y: -8, transition: { duration: 0.2 } },
  };
  const motionProps = reduceMotion ? {} : {
    initial: "hidden" as const,
    animate: "visible" as const,
    exit: "exit" as const,
    variants: pageVariants,
  };'''


# ====================================================================
# A2: ui.tsx - Card converts to motion.div with variants
# Anchor on B9d.6 Card definition (post B9d.3 shadow + B9d.6 rounded-xl hover).
# ====================================================================
A2_OLD = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + always-on subtle hover lift for modern fintech feel.
export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn(
      "rounded-xl shadow-sm",
      "transition-[transform,box-shadow] duration-300 ease-out",
      "hover:shadow-md hover:-translate-y-px",
      className
    )}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...props}
  />
);'''

A2_NEW = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + always-on subtle hover lift.
// B9d.8: motion-converted with variants - inherits hidden/visible state from
// the App.tsx page motion.div, cascading in via staggerChildren. Hover-lift
// moved from CSS to whileHover to avoid clash with variant-driven transform.
const cardVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2, ease: "easeOut" as const } },
};

export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <motion.div
    variants={cardVariants}
    whileHover={{ y: -1 }}
    transition={{ type: "spring", stiffness: 400, damping: 30 }}
    className={cn(
      "rounded-xl shadow-sm",
      "transition-shadow duration-300 ease-out",
      "hover:shadow-md",
      className
    )}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...(props as any)}
  />
);'''


def main():
    if not APP.exists():
        fail(f"App.tsx not found: {APP}")
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")

    # App.tsx
    text = APP.read_text(encoding="utf-8")
    original = text
    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: variants pattern with staggerChildren",
        marker="B9d.8: variants pattern with staggerChildren orchestrates cascade",
    )
    if text != original:
        APP.write_text(text, encoding="utf-8")
        ok(f"wrote {APP.relative_to(WORKSPACE)}")

    # ui.tsx
    text = UI.read_text(encoding="utf-8")
    original = text
    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: Card motion.div with variants + whileHover",
        marker="B9d.8: motion-converted with variants",
    )
    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")

    print()
    print("B9d.8 stagger animations applied.")


if __name__ == "__main__":
    main()
