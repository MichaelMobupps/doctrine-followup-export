#!/usr/bin/env python3
"""
B9d.7.1 - Respect prefers-reduced-motion for page transitions.

Hotfix on top of the already-shipped B9d.7. Adds:
  - useReducedMotion to the framer-motion import
  - reduceMotion hook + ternary motionProps in Router
  - motion.div now spreads {...motionProps} instead of hardcoded props

Users with OS-level prefers-reduced-motion: reduce now get a static
wrapper (no entrance/exit animation, no slide). Everyone else keeps
the 200ms fade + slide from B9d.7.

Two anchors in App.tsx, both surgical. Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
APP = WORKSPACE / "artifacts/dashboard/src/App.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: Import - add useReducedMotion
# Anchor on the v1 framer-motion import line.
# ====================================================================
A1_OLD = '''import { motion, AnimatePresence } from "framer-motion";'''

A1_NEW = '''// B9d.7.1: useReducedMotion gates animations on OS prefers-reduced-motion.
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";'''


# ====================================================================
# A2: Replace v1 Router opening with reduceMotion-gated version
# Anchor on the v1 motion.div props block.
# ====================================================================
A2_OLD = '''  // B9d.7: AnimatePresence wraps Switch so route changes animate as a fade+slide.
  // mode="wait" ensures the old page exits before the new one mounts.
  const [location] = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
      >
        <Switch>'''

A2_NEW = '''  // B9d.7: AnimatePresence wraps Switch so route changes animate as a fade+slide.
  // mode="wait" ensures the old page exits before the new one mounts.
  // B9d.7.1: motion props gated on prefers-reduced-motion. Users with that OS
  // preference get a static wrapper (no entrance/exit animation, no slide).
  const [location] = useLocation();
  const reduceMotion = useReducedMotion();
  const motionProps = reduceMotion ? {} : {
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -8 },
    transition: { duration: 0.2, ease: "easeOut" as const },
  };
  return (
    <AnimatePresence mode="wait">
      <motion.div key={location} {...motionProps}>
        <Switch>'''


def main():
    if not APP.exists():
        fail(f"App.tsx not found: {APP}")
    text = APP.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: add useReducedMotion import",
        marker="B9d.7.1: useReducedMotion gates animations",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: gate motion.div props on prefers-reduced-motion",
        marker="B9d.7.1: motion props gated on prefers-reduced-motion",
    )

    if text != original:
        APP.write_text(text, encoding="utf-8")
        ok(f"wrote {APP.relative_to(WORKSPACE)}")
    else:
        skip("App.tsx already patched")

    print()
    print("B9d.7.1 reduced-motion hotfix applied.")


if __name__ == "__main__":
    main()
