#!/usr/bin/env node
/**
 * audit-batch7m.mjs — Beautiful-Squidward audit for Phase 7m.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7m] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7m] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const pipelineSrc       = read(join(DASH_BASE, "pages", "pipeline.tsx"));
const ctxPipelineSrc    = read(join(DASH_BASE, "pages", "context-pipeline.tsx"));
const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const ctxInspectorSrc   = read(join(DASH_BASE, "pages", "context-inspector.tsx"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

// Extract the StageProgress function block from each pipeline file.
function extractStageProgress(src) {
  const m = src.match(/function StageProgress\([\s\S]*?\n\}/);
  return m ? m[0] : "";
}

const docStageBlock = extractStageProgress(pipelineSrc);
const ctxStageBlock = extractStageProgress(ctxPipelineSrc);

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: doctrine StageProgress block extracted
  log(`-- PASS 1: doctrine StageProgress block --`);
  pass(`Block extracted`, docStageBlock.length > 0);
  pass(`Phase 7m comment present`, /Phase 7m: capped branch must also fit highestStage so stages added/.test(docStageBlock));
  pass(`Block contains highestStage compute`, /const highestStage = thread\.stages\.length > 0 \? Math\.max\(\.\.\.thread\.stages\.map\(\(s\) => s\.stage\)\) : 0;/.test(docStageBlock));

  // PASS 2: doctrine capped branch is the new shape
  log(`-- PASS 2: doctrine capped branch fixed --`);
  pass(`Capped branch uses Math.max(thread.max_followups, highestStage)`,
       /: Math\.max\(thread\.max_followups, highestStage\);/.test(docStageBlock));
  pass(`Old capped branch (just thread.max_followups) absent in StageProgress`,
       !/\? Math\.max\(3, highestStage\)\s*\n\s*: thread\.max_followups;/.test(docStageBlock));
  pass(`Unlimited branch unchanged`,
       /\? Math\.max\(3, highestStage\)/.test(docStageBlock));

  // PASS 3: context StageProgress block extracted + fixed
  log(`-- PASS 3: context StageProgress block --`);
  pass(`Context block extracted`, ctxStageBlock.length > 0);
  pass(`Context Phase 7m comment present`, /Phase 7m: same fix as doctrine pipeline\.tsx — capped branch must/.test(ctxStageBlock));
  pass(`Context highestStage compute present`, /const highestStage = thread\.stages\.length > 0 \? Math\.max\(\.\.\.thread\.stages\.map\(\(s\) => s\.stage\)\) : 0;/.test(ctxStageBlock));

  // PASS 4: context capped branch is the new shape
  log(`-- PASS 4: context capped branch fixed --`);
  pass(`Context capped branch uses Math.max`,
       /: Math\.max\(thread\.max_followups, highestStage\);/.test(ctxStageBlock));
  pass(`Context old capped branch absent`,
       !/\? Math\.max\(3, highestStage\)\s*\n\s*: thread\.max_followups;/.test(ctxStageBlock));
  pass(`Context unlimited branch unchanged`,
       /\? Math\.max\(3, highestStage\)/.test(ctxStageBlock));

  // PASS 5: rendering loop unchanged
  log(`-- PASS 5: render loop unchanged --`);
  pass(`Doctrine for loop iterates 1..maxStages`,
       /for \(let i = 1; i <= maxStages; i\+\+\) \{/.test(docStageBlock));
  pass(`Context for loop iterates 1..maxStages`,
       /for \(let i = 1; i <= maxStages; i\+\+\) \{/.test(ctxStageBlock));
  pass(`Doctrine still has stage status switch (sent, queued, etc)`,
       /case "sent":[\s\S]*?case "queued"[\s\S]*?case "pending_approval"[\s\S]*?case "cancelled"[\s\S]*?case "failed"/.test(docStageBlock));
  pass(`Context still has stage status switch`,
       /case "sent":[\s\S]*?case "queued"[\s\S]*?case "pending_approval"[\s\S]*?case "cancelled"[\s\S]*?case "failed"/.test(ctxStageBlock));

  // PASS 6: behavioral correctness — both branches now respect highestStage
  log(`-- PASS 6: branches respect highestStage uniformly --`);
  pass(`Doctrine: both branches reference highestStage`,
       (docStageBlock.match(/highestStage/g) || []).length >= 3);
  pass(`Context: both branches reference highestStage`,
       (ctxStageBlock.match(/highestStage/g) || []).length >= 3);

  // PASS 7: B7e/B7h regression — context-pipeline + context-inspector exist intact
  log(`-- PASS 7: B7e/B7h regression --`);
  pass(`B7e: ContextPipeline default export`, /export default function ContextPipeline\(\)/.test(ctxPipelineSrc));
  pass(`B7e: context-pipeline polls /api/context/followups`, /api\/context\/followups/.test(ctxPipelineSrc));
  pass(`B7h: ContextEmailInspector default export`, /export default function ContextEmailInspector\(\)/.test(ctxInspectorSrc));
  pass(`B7j: ctx-inspector vertical badge gated`, /\{vertLabel && <Badge variant="outline">\{vertLabel\}<\/Badge>\}/.test(ctxInspectorSrc));

  // PASS 8: B7k/B7l regression
  log(`-- PASS 8: B7k/B7l regression --`);
  pass(`B7k: doctrine /sync auto_queued field`, /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(doctrineRouteSrc));
  pass(`B7k: context /sync auto_queued field`, /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(ctxRouteSrc));
  pass(`B7l: context resume Gap A SCOPE-gated UPDATE`,
       /set\(\{ followupPaused: false \}\)\.where\(and\(SCOPE, eq\(prospectsTable\.id, prospectId\)\)\)/.test(ctxRouteSrc));
  pass(`B7l: context resume Gap B queued_stage in response`,
       /queued_stage,[\s\S]*?max_followups: maxFollowups \?\? 0,/.test(ctxRouteSrc));
  pass(`B7l: timingEngine import in context.ts`,
       /import \{ computeNextStageScheduledAt \} from "\.\.\/services\/timingEngine";/.test(ctxRouteSrc));

  // PASS 9: B7a-B7c regression + sidebar
  log(`-- PASS 9: foundational regression --`);
  pass(`B7a: users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
  pass(`B7b: /context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7c: SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`B7c: SCOPE_DOCTRINE referenced ≥30 times`, (doctrineRouteSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`B7i: layout.tsx product-aware activity URL`, /const activityPath = onContext \? "api\/context\/my\/activity" : "api\/my\/activity";/.test(layoutSrc));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
