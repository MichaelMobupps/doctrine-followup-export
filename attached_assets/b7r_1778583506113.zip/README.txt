B7r — per-LLM-call usage tracking for Email Followuper
========================================================

Foundation batch for the activity-log upgrade. After this ships,
every Anthropic API call made on behalf of a follow-up (draft/critic/
rewriter for doctrine or context flows) writes one row to a new
`followup_usage` table with: who, which followup, which app, which
stage, which model, token counts, web searches, and computed USD cost.

No UI in this batch. Pure capture. Later batches (B7s/B7t) read from
this table to build the per-user activity-log dashboard and Excel
export, mirroring what the Email Prospector already has.

Files written (5 new):
  - lib/db/src/schema/followup-usage.ts
  - artifacts/api-server/src/lib/pricing.ts
  - artifacts/api-server/src/lib/usageContext.ts
  - artifacts/api-server/src/lib/usageTracker.ts
  - artifacts/api-server/src/lib/startupMigrations.ts

Files patched (5 surgical edits):
  - lib/db/src/schema/index.ts                     (export new table)
  - artifacts/api-server/src/index.ts              (run migration on boot)
  - artifacts/api-server/src/services/scheduler.ts (wrap generator dispatch)
  - artifacts/api-server/src/services/followupGenerator.ts        (3 call sites)
  - artifacts/api-server/src/services/contextFollowupGenerator.ts (3 call sites)

Safety:
  - All usage capture is best-effort (try/catch). A tracker bug or DB
    hiccup CANNOT break follow-up sends.
  - Table creation uses CREATE TABLE IF NOT EXISTS so re-applying is
    a clean no-op.
  - Migration fires in the background at server boot — does not block
    listen() so Replit healthchecks don't time out.
  - Apply script is fully idempotent. Tested by running twice against
    the source mirror.

---

PROMPT FOR THE REPLIT AGENT
---------------------------

Paste this exact text to the Replit Agent (the AI assistant inside
Replit). It will run the bash block, restart the workflow, and report
back the first 20 lines of the api-server log so you can confirm the
"B7r: followup_usage table ready" line appeared.

> Apply the b7r patch from ~/b7r.zip.
>
> Step 1: run this single bash block in the shell, exactly as-is:
>
> ```
> set -e
> cd ~/workspace
> rm -rf /tmp/b7r && mkdir -p /tmp/b7r
> unzip -o ~/b7r.zip -d /tmp/b7r
> node /tmp/b7r/apply-b7r.mjs
> ./source-code/sync.sh
> pnpm --filter @workspace/api-server run build
> echo "B7r applied. Ready to restart the workflow."
> ```
>
> Step 2: restart the api-server workflow.
>
> Step 3: wait until the server logs "Server listening port: 8080".
>
> Step 4: show me the last 30 lines of the api-server log. I want to
> see the line "B7r: followup_usage table ready" appear once.
>
> Do not do anything else. Do not edit any files. Do not modify the
> bash block. Do not retry on partial failure — paste the exact output
> back to me.

---

POST-DEPLOY VERIFICATION
------------------------

After the agent reports success, deploy to production as you did for
B7p and B7q. Once production is live, run this curl to see if any
rows are landing in the new table:

```
curl -s -X POST "https://doctrine-followupv-2.replit.app/api/admin/digest/preview" \
  -H "X-API-Key: $ADDON_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"michael@mobupps.com"}' > /dev/null
```

(That curl just exercises the API. It doesn't directly query
followup_usage, but on the next cron tick that generates a follow-up
the new table will start receiving rows.)

To actually see rows, ask the agent: "Show me the last 10 rows of the
followup_usage table in production, ordered by generated_at desc."

When you confirm rows are landing with sensible token/cost values,
we move to B7s (the admin /activity endpoint that rolls up this data
per user/per app).
