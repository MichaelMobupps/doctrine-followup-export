import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import React from "react";

interface CurrentUser {
  email: string;
  userId: number | null;
  name: string;
}

interface CurrentUserContextValue {
  user: CurrentUser | null;
  setUser: (user: CurrentUser) => void;
  clearUser: () => void;
  isLoaded: boolean;
}

const CurrentUserContext = createContext<CurrentUserContextValue | null>(null);

export function CurrentUserProvider({ children }: { children: ReactNode }) {
  const [user, setUserValue] = useState<CurrentUser | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem("doctrine_current_user");
    if (stored) {
      try {
        setUserValue(JSON.parse(stored));
      } catch {}
    }
    setIsLoaded(true);
  }, []);

  const setUser = (u: CurrentUser) => {
    localStorage.setItem("doctrine_current_user", JSON.stringify(u));
    setUserValue(u);
  };

  const clearUser = () => {
    localStorage.removeItem("doctrine_current_user");
    setUserValue(null);
  };

  return React.createElement(
    CurrentUserContext.Provider,
    { value: { user, setUser, clearUser, isLoaded } },
    children
  );
}

export function useCurrentUser(): CurrentUserContextValue {
  const ctx = useContext(CurrentUserContext);
  if (!ctx) {
    throw new Error("useCurrentUser must be used within a CurrentUserProvider");
  }
  return ctx;
}
