import { anthropic } from "@workspace/integrations-anthropic-ai";
import type { FollowupContext } from "./followupPrompts";
import {
  getFollowupSystemPrompt,
  getFollowupUserPrompt,
  getCriticSystemPrompt,
  getCriticUserPrompt,
  getRewriterSystemPrompt,
  getRewriterUserPrompt,
} from "./followupPrompts";
import { logger } from "../lib/logger";

export interface GeneratedFollowup {
  subject: string;
  body: string;
}

function humanizeText(text: string): string {
  let result = text;
  result = result.replace(/\s*—\s*/g, " - ");
  result = result.replace(/\s*–\s*/g, " - ");
  result = result.replace(/[""\u201C\u201D]/g, '"');
  result = result.replace(/[''‛\u2018\u2019]/g, "'");
  result = result.replace(/…/g, "...");
  result = result.replace(/\u00A0/g, " ");
  result = result.replace(/\u200B/g, "");
  const aiPhrases = [
    /\bI'd love to\b/gi,
    /\bI wanted to reach out\b/gi,
    /\bI hope this (?:email )?finds you well\b/gi,
    /\bI hope you're doing well\b/gi,
    /\bI trust this (?:email )?finds you well\b/gi,
    /\bdelve(?:s|d)?\b/gi,
    /\bleverage(?:s|d)?\b/gi,
    /\bin today's (?:rapidly )?(?:evolving|changing) (?:landscape|world)\b/gi,
    /\bIt's worth noting that\b/gi,
    /\bIt bears mentioning that\b/gi,
    /\bNavigate the (?:complexities|landscape)\b/gi,
    /\bseamless(?:ly)?\b/gi,
    /\bsynerg(?:y|ies|ize)\b/gi,
    /\bholistic(?:ally)?\b/gi,
    /\bgame[\s-]?changer\b/gi,
    /\bunlock(?:ing)? (?:the )?(?:full )?potential\b/gi,
  ];
  for (const pattern of aiPhrases) {
    result = result.replace(pattern, (match) => {
      const replacements: Record<string, string> = {
        "delve": "dig",
        "delves": "digs",
        "delved": "dug",
        "leverage": "use",
        "leverages": "uses",
        "leveraged": "used",
        "seamlessly": "smoothly",
        "seamless": "smooth",
        "holistically": "broadly",
        "holistic": "broad",
      };
      const lower = match.toLowerCase();
      if (replacements[lower]) return replacements[lower];
      return "";
    });
  }
  result = result.replace(/ {2,}/g, " ");
  result = result.replace(/^\s+/gm, (m) => m);
  result = result.trim();
  return result;
}

function humanizeFollowup(followup: GeneratedFollowup): GeneratedFollowup {
  return {
    subject: humanizeText(followup.subject),
    body: humanizeText(followup.body),
  };
}

function unescapeJsonString(s: string): string {
  return s
    .replace(/\\n/g, "\n")
    .replace(/\\r/g, "\r")
    .replace(/\\t/g, "\t")
    .replace(/\\"/g, '"')
    .replace(/\\\\/g, "\\");
}

function parseJsonResponse(text: string): any {
  let raw = text.replace(/```json\s*|```/g, "").trim();

  const firstBrace = raw.indexOf("{");
  const lastBrace = raw.lastIndexOf("}");
  if (firstBrace !== -1 && lastBrace > firstBrace) {
    raw = raw.slice(firstBrace, lastBrace + 1);
  }

  try {
    return JSON.parse(raw);
  } catch {
    const subjectMatch = raw.match(/"subject"\s*:\s*"((?:[^"\\]|\\.)*)"/);
    const bodyMatch = raw.match(/"body"\s*:\s*"((?:[^"\\]|\\[\s\S])*)"\s*\}$/s);
    if (subjectMatch && bodyMatch) {
      return {
        subject: unescapeJsonString(subjectMatch[1]),
        body: unescapeJsonString(bodyMatch[1]),
      };
    }
    throw new SyntaxError(`Failed to parse AI response as JSON: ${raw.slice(0, 200)}...`);
  }
}

async function generateDraft(ctx: FollowupContext, attempt = 1): Promise<GeneratedFollowup> {
  const maxAttempts = 2;
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 8192,
    system: getFollowupSystemPrompt(),
    messages: [{ role: "user", content: getFollowupUserPrompt(ctx) }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("No text in draft response");
  }

  try {
    const parsed = parseJsonResponse(textBlock.text);
    if (!parsed.subject || !parsed.body) {
      throw new Error("Draft missing subject or body");
    }
    return { subject: parsed.subject, body: parsed.body };
  } catch (err) {
    logger.warn({ attempt, rawPreview: textBlock.text.slice(0, 300) }, "Draft JSON parse failed");
    if (attempt < maxAttempts) {
      logger.info("Retrying draft generation...");
      return generateDraft(ctx, attempt + 1);
    }
    throw err;
  }
}

interface CriticResult {
  scores: Record<string, number>;
  overall: number;
  issues: string[];
  suggestions: string[];
  needs_rewrite: boolean;
}

async function critiqueDraft(
  ctx: FollowupContext,
  draft: GeneratedFollowup,
): Promise<CriticResult> {
  const response = await anthropic.messages.create({
    model: "claude-opus-4-6",
    max_tokens: 8192,
    system: getCriticSystemPrompt(),
    messages: [{ role: "user", content: getCriticUserPrompt(ctx, draft) }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("No text in critic response");
  }

  const parsed = parseJsonResponse(textBlock.text);
  return {
    scores: parsed.scores || {},
    overall: parsed.overall || 5,
    issues: parsed.issues || [],
    suggestions: parsed.suggestions || [],
    needs_rewrite: parsed.needs_rewrite ?? false,
  };
}

async function rewriteDraft(
  ctx: FollowupContext,
  draft: GeneratedFollowup,
  critique: CriticResult,
): Promise<GeneratedFollowup> {
  const response = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 8192,
    system: getRewriterSystemPrompt(),
    messages: [{
      role: "user",
      content: getRewriterUserPrompt(ctx, draft, {
        issues: critique.issues,
        suggestions: critique.suggestions,
      }),
    }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("No text in rewriter response");
  }

  const parsed = parseJsonResponse(textBlock.text);
  if (!parsed.subject || !parsed.body) {
    throw new Error("Rewrite missing subject or body");
  }

  return { subject: parsed.subject, body: parsed.body };
}

export async function generateFollowupEmail(
  ctx: FollowupContext,
): Promise<GeneratedFollowup> {
  logger.info(
    { prospect: ctx.prospect_name, stage: ctx.stage, previousFollowups: ctx.previous_followups?.length || 0 },
    "Step 1: Generating initial draft (Sonnet)",
  );
  const draft = await generateDraft(ctx);

  logger.info(
    { prospect: ctx.prospect_name, stage: ctx.stage },
    "Step 2: Critiquing draft (Opus)",
  );

  let critique: CriticResult;
  try {
    critique = await critiqueDraft(ctx, draft);
  } catch (err) {
    logger.warn({ err, prospect: ctx.prospect_name }, "Critic failed, using initial draft");
    return draft;
  }

  logger.info(
    { prospect: ctx.prospect_name, overall: critique.overall, needsRewrite: critique.needs_rewrite, issues: critique.issues },
    "Critic evaluation complete",
  );

  if (!critique.needs_rewrite) {
    logger.info({ prospect: ctx.prospect_name }, "Draft passed critic review, no rewrite needed");
    const humanized = humanizeFollowup(draft);
    logger.info({ prospect: ctx.prospect_name }, "Humanizer applied");
    return humanized;
  }

  logger.info(
    { prospect: ctx.prospect_name, stage: ctx.stage },
    "Step 3: Rewriting draft based on critique (Sonnet)",
  );

  try {
    const rewritten = await rewriteDraft(ctx, draft, critique);
    logger.info({ prospect: ctx.prospect_name }, "Rewrite complete");
    const humanized = humanizeFollowup(rewritten);
    logger.info({ prospect: ctx.prospect_name }, "Humanizer applied");
    return humanized;
  } catch (err) {
    logger.warn({ err, prospect: ctx.prospect_name }, "Rewriter failed, using initial draft");
    const humanized = humanizeFollowup(draft);
    return humanized;
  }
}
