# Batch 7j — Polish: hide empty vertical + stats shape parity

Phase 7j. Two small polish items bundled.

## What's in this batch

**Frontend (`dashboard/pages/context-inspector.tsx`):**

The B7g context backend deliberately returns `vertical: ""`,
`subVertical: ""`, `verticalReason: ""` because context prospects
don't carry verticals. The B7h frontend clone inherits the doctrine
Inspector's vertical-badge render unchanged, which means an empty
`<Badge>` shows up in every email row plus an empty Vertical/Reason
row pair in the detection panel. Two small wraps fix this:

1. **Email row badge** wrapped in `{vertLabel && <Badge ...>}` so the
   badge is omitted entirely when `vertLabel` is falsy.
2. **Detection panel Vertical/Reason rows** wrapped in
   `{vertLabel && (<>...</>)}` so the entire two-row block disappears
   when there's no vertical.

When `vertLabel` is non-empty (e.g., if 7g ever populates verticals
later), both render normally — same UX as the doctrine Inspector.

**Backend (`routes/doctrine.ts`):**

The doctrine `/api/stats` endpoint returns 5 fields: `total_sent,
unreplied, replied, queued_followups, sent_followups`. The context
`/api/stats` returns 6: same 5 plus `drafted_followups` (added in
B7b for visibility into the Phase 3c draft-in-Gmail mode). The
mismatch is harmless functionally but an inconsistency on the wire.

This batch adds `drafted_followups` to the doctrine endpoint:

3. **Filtered SELECT branch** (when userId query param is set) —
   adds `draftedFollowups` projection.
4. **Unfiltered SELECT branch** (no userId) — adds `draftedFollowups`
   projection.
5. **Response object** — adds `drafted_followups: Number(fs?.draftedFollowups) || 0`
   to the `res.json({...})`.

Both endpoints now return the same 6-field shape. Drafted follow-ups
exist in the doctrine flow (Phase 3c draft-in-Gmail mode); this just
surfaces them through `/api/stats` for any consumer that asks.

## What changes for the user

- **`/context/inspector` email rows** no longer show a thin empty
  outline pill where the vertical badge was.
- **`/context/inspector` detection panel** (expanded view) no longer
  shows blank "Vertical:" and "Reason:" rows. Cleaner panel for
  context emails.
- **`/api/stats` shape** is the same on both products. If anything new
  consumes `/api/stats` (typed hooks, dashboards, exports), it doesn't
  have to handle "field present sometimes, absent sometimes."
- **Existing dashboard consumers** (`dashboard.tsx`, `pipeline.tsx`)
  that use `/api/stats` get the new field for free; if they ignore it,
  no behavior change. If they want to surface drafted counts, they
  can read it now.

## Files

```
batch7j/
├── apply-batch7j.mjs       # Idempotent patch — 5 str_replaces
├── audit-batch7j.mjs       # 9 passes × 3 rounds = 93 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build api-server + dashboard.
Mirror sync. Restart api-server + republish dashboard.

## Verify

After applying:

- The apply script self-verifies 10 anchors (4 frontend gating + 5
  backend additions + 1 occurrence-count check on the SELECT branches).
- The audit runs 93 checks (31 per round × 3 rounds): vertical badge
  + detection panel both gated, doctrine `/api/stats` SELECT
  draftedFollowups present in both branches, response field present,
  shape parity (6 fields on both endpoints), doctrine `email-inspector.tsx`
  not regressed (still has unconditional vertical badge), B7a-B7i
  regression.

Backend smoke after restart:

```bash
# /api/stats now includes drafted_followups
curl -s "http://localhost:8080/api/stats?userId=1" -H "x-api-key: $ADDON_API_KEY"

# /api/context/stats unchanged
curl -s "http://localhost:8080/api/context/stats?userId=1" -H "x-api-key: $ADDON_API_KEY"
```

Both should return the same 6-key shape. Doctrine: real numbers (12+
total_sent based on prior smokes). Context: all zeros.

Browser smoke after dashboard republish + hard-reload:

1. `/context/inspector` — email rows have no empty pill where the
   vertical badge was. Once Gmail OAuth is reconnected and emails
   load, expand any email's detection panel — no Vertical/Reason
   rows appear (they only render when vertical inference produced a
   value, which it never does for context).
2. `/inspector` (doctrine) — vertical badge still renders (e.g.,
   "Gaming UA"), Vertical/Reason rows in detection panel still
   present. Unchanged.
3. `/context/pipeline`, `/context/activity` (regression) — render as
   before.

## Known residual

- Drafted follow-ups exist in the doctrine flow but `/api/stats` was
  never being asked for them before this batch. If any downstream
  consumer (e.g., a future dashboard widget) wants to display them,
  the field is now available.
- Context's `/api/context/stats` uses `::int` casts (PostgreSQL),
  doctrine doesn't. Both work — doctrine returns string counts that
  `Number()` coerces, context returns ints directly. Cosmetic
  inconsistency, not a follow-up.
