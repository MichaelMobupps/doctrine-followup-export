#!/usr/bin/env node
/**
 * audit-batch7a.mjs — Beautiful-Squidward audit for Phase 7a.
 * 3 rounds × 9 passes per round.
 *
 * Verifies the Context Based foundation:
 *   - ProspectApp enum + PROSPECT_APPS const exported from schema
 *   - prospects.app column with default 'doctrine' and index
 *   - users.context_label column with default 'Context Followuper'
 *   - gmail-auth route projects + accepts contextLabel
 *   - ZERO regression: scheduler, gmailSync, generators untouched
 *   - All five existing crons still present
 *
 * Run AFTER apply-batch7a.mjs.
 *
 * Env vars:
 *   DB_BASE  = path to schema dir       (default: lib/db/src)
 *   API_BASE = path to api-server src   (default: artifacts/api-server/src)
 */

import { existsSync, readFileSync, readdirSync, statSync } from "fs";
import { join } from "path";

const DB_BASE  = process.env.DB_BASE  || "lib/db/src";
const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const prospectsSchemaPath = join(DB_BASE, "schema", "prospects.ts");
const usersSchemaPath     = join(DB_BASE, "schema", "users.ts");
const gmailAuthPath       = join(API_BASE, "routes", "gmail-auth.ts");
const schedulerPath       = join(API_BASE, "services", "scheduler.ts");
const gmailSyncPath       = join(API_BASE, "services", "gmailSync.ts");
const cronPath            = join(API_BASE, "cron.ts");

let totalPasses = 0;
let totalFails = 0;
const failureMessages = [];

function read(path) {
  if (!existsSync(path)) throw new Error(`File missing: ${path}`);
  return readFileSync(path, "utf-8");
}

function check(label, condition, detail = "") {
  totalPasses++;
  if (condition) {
    console.log(`    [PASS] ${label}`);
  } else {
    totalFails++;
    failureMessages.push(`${label}${detail ? " — " + detail : ""}`);
    console.log(`    [FAIL] ${label}${detail ? " — " + detail : ""}`);
  }
}

function countIn(path, needle) {
  return read(path).split(needle).length - 1;
}

function walkAll(dir) {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const n of readdirSync(dir)) {
    const full = join(dir, n);
    const st = statSync(full);
    if (st.isDirectory()) out.push(...walkAll(full));
    else if (st.isFile()) out.push(full);
  }
  return out;
}

function runOneRound(roundNum) {
  console.log(`\n--- Round ${roundNum} ---`);

  // PASS 1: ProspectApp type + const exported from schema
  console.log(`  PASS 1: ProspectApp type + const`);
  const ps = read(prospectsSchemaPath);
  check("1a. ProspectApp type exported with both members",
    /export type ProspectApp =\s*"doctrine"\s*\|\s*"context";/.test(ps));
  check("1b. PROSPECT_APPS const exported with both members",
    /export const PROSPECT_APPS:\s*ProspectApp\[\]\s*=\s*\["doctrine",\s*"context"\];/.test(ps));

  // PASS 2: prospects.app column declared correctly
  console.log(`  PASS 2: prospects.app column`);
  check("2a. app column with text type and ProspectApp generic",
    ps.includes(`app: text("app").$type<ProspectApp>().notNull().default("doctrine")`));
  check("2b. app column declared exactly once",
    countIn(prospectsSchemaPath, `app: text("app")`) === 1);

  // PASS 3: index on prospects.app
  console.log(`  PASS 3: prospects.app index`);
  check("3a. index idx_prospects_app declared",
    ps.includes(`index("idx_prospects_app").on(table.app)`));

  // PASS 4: users.context_label column declared correctly
  console.log(`  PASS 4: users.context_label column`);
  const us = read(usersSchemaPath);
  check("4a. contextLabel column with default 'Context Followuper'",
    us.includes(`contextLabel: text("context_label").notNull().default("Context Followuper")`));
  check("4b. contextLabel column declared exactly once",
    countIn(usersSchemaPath, `contextLabel: text("context_label")`) === 1);
  check("4c. existing doctrineLabel column still present (no accidental removal)",
    us.includes(`doctrineLabel: text("doctrine_label").notNull().default("Doctrine SDR")`));

  // PASS 5: gmail-auth route projects + accepts contextLabel
  console.log(`  PASS 5: gmail-auth wiring`);
  const ga = read(gmailAuthPath);
  check("5a. ACCOUNT_SELECT projects contextLabel",
    ga.includes(`contextLabel: usersTable.contextLabel,`));
  check("5b. PUT body destructures contextLabel",
    /doctrineLabel,\s*\n\s*contextLabel,/.test(ga));
  check("5c. PUT writes contextLabel to updates",
    ga.includes(`if (contextLabel !== undefined) updates.contextLabel = String(contextLabel);`));
  check("5d. existing doctrineLabel projection still present",
    ga.includes(`doctrineLabel: usersTable.doctrineLabel,`));
  check("5e. existing doctrineLabel write still present",
    ga.includes(`if (doctrineLabel !== undefined) updates.doctrineLabel = String(doctrineLabel);`));

  // PASS 6: ZERO regression — scheduler.ts has not been modified by 7a
  console.log(`  PASS 6: Scheduler untouched`);
  const sched = read(schedulerPath);
  check("6a. scheduler still imports isInSendWindow (B6 still in place)",
    sched.includes(`import { isInSendWindow }`));
  check("6b. scheduler still imports checkSendBudget (B6 still in place)",
    sched.includes(`import { checkSendBudget }`));
  check("6c. scheduler still has Phase 6 gate A",
    sched.includes(`Phase 6 gate A: send-window enforcement`));
  check("6d. scheduler still has Phase 6 gate B",
    sched.includes(`Phase 6 gate B: per-user send rate limiter`));
  check("6e. scheduler does NOT yet branch on app discriminator (that lands in 7b)",
    !/(prospect|item)\.app\s*===\s*["']context["']/.test(sched));

  // PASS 7: ZERO regression — gmailSync untouched
  console.log(`  PASS 7: gmailSync untouched`);
  const gs = read(gmailSyncPath);
  check("7a. gmailSync still imports detectManualFollowupSend (B3b still in place)",
    gs.includes(`detectManualFollowupSend`));
  check("7b. gmailSync does NOT yet read contextLabel (that lands in 7b)",
    !gs.includes(`contextLabel`));
  check("7c. gmailSync does NOT yet set app on inserts (that lands in 7b)",
    !/app:\s*["'](doctrine|context)["']/.test(gs));

  // PASS 8: All five existing crons still present
  console.log(`  PASS 8: Cron stability`);
  const cron = read(cronPath);
  check("8a. sync+auto-queue cron */15", cron.includes(`cron.schedule("*/15 * * * *"`));
  check("8b. main process cron 5,20,35,50", cron.includes(`cron.schedule("5,20,35,50 * * * *"`));
  check("8c. draft-stall cron 30 0", cron.includes(`cron.schedule("30 0 * * *"`));
  check("8d. weekly-digest cron Tue 00:00", cron.includes(`cron.schedule("0 0 * * 2"`));
  check("8e. fast-tick cron */3", cron.includes(`cron.schedule("*/3 * * * *"`));

  // PASS 9: No stray .bak files, no new generator files yet
  console.log(`  PASS 9: Cleanliness`);
  const allFiles = walkAll(API_BASE);
  const bakFiles = allFiles.filter((f) => f.endsWith(".bak"));
  check("9a. zero .bak files in api-server tree", bakFiles.length === 0, bakFiles.join(", "));
  // The context generator + routes land in 7b, not now.
  check("9b. contextFollowupGenerator.ts NOT yet present (7b territory)",
    !existsSync(join(API_BASE, "services", "contextFollowupGenerator.ts")));
  check("9c. context routes NOT yet present (7b territory)",
    !existsSync(join(API_BASE, "routes", "context.ts")));
  // The prior B6 lib files should still be here (no accidental removal)
  check("9d. lib/sendBudget.ts still present (B6)",
    existsSync(join(API_BASE, "lib", "sendBudget.ts")));
  check("9e. lib/scheduleWindow.ts still present (B6)",
    existsSync(join(API_BASE, "lib", "scheduleWindow.ts")));
}

console.log("================================================================");
console.log("Batch 7a audit — 3 rounds × 9 passes (Beautiful-Squidward)");
console.log("================================================================");

for (let round = 1; round <= 3; round++) {
  runOneRound(round);
}

console.log("");
console.log("================================================================");
console.log(`Total: ${totalPasses - totalFails}/${totalPasses} passed across 3 rounds.`);
if (totalFails > 0) {
  console.log(`FAILURES (${totalFails}):`);
  for (const m of failureMessages) console.log(`  - ${m}`);
  console.log("================================================================");
  process.exit(1);
} else {
  console.log("All passes succeeded across all 3 rounds.");
  console.log("================================================================");
}
