#!/usr/bin/env node
/**
 * apply-batch7m.mjs — Phase 7m (Pipeline stage indicator visual fix).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * The bug: in StageProgress (both pipeline.tsx and context-pipeline.tsx),
 * the loop bound `maxStages` is set to `thread.max_followups` when the
 * user has a finite cap. That ignores `highestStage` — the actual
 * highest stage present in `thread.stages`. When a prospect has
 * stages beyond the cap (manual "Send now" forces past the cap, or
 * the user reduced max_followups after some stages were already sent),
 * those real stages exist in the data but never render — the squares
 * top out at the cap value (typically 3).
 *
 * The screenshot symptom: rows showing "5/3" or "4/3" in the stage
 * counter but only 3 squares lit. The data is right, the visualization
 * is short.
 *
 * The fix: in the capped branch, use Math.max(thread.max_followups,
 * highestStage). This mirrors what the unlimited branch already does
 * — it already extends past 3 to fit highestStage. Now the capped
 * branch does the same: it extends past the cap to fit reality.
 *
 * Capped branch — before:  thread.max_followups
 * Capped branch — after:   Math.max(thread.max_followups, highestStage)
 *
 * Both branches now follow the same rule: render exactly enough squares
 * to cover both the configured cap AND every real stage that exists.
 *
 * Usage:
 *   DASH_BASE=artifacts/dashboard/src node apply-batch7m.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const log  = (msg) => console.log(`[apply-batch7m] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7m] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const pipelinePath    = join(DASH_BASE, "pages", "pipeline.tsx");
const ctxPipelinePath = join(DASH_BASE, "pages", "context-pipeline.tsx");

// ============================================================
// Step 1: Doctrine pipeline.tsx — capped branch extends to highestStage
// ============================================================
log("Step 1: pipeline.tsx — extend capped branch to highestStage...");

strReplace(
  pipelinePath,
  `  const maxStages = isUnlimitedFollowups(thread.max_followups)
    ? Math.max(3, highestStage)
    : thread.max_followups;`,
  `  // Phase 7m: capped branch must also fit highestStage so stages added
  // beyond max_followups (manual "Send Now" force, or post-reduction
  // legacy stages) render visually instead of being silently capped.
  const maxStages = isUnlimitedFollowups(thread.max_followups)
    ? Math.max(3, highestStage)
    : Math.max(thread.max_followups, highestStage);`,
  "pipeline.tsx: capped branch fits highestStage",
  `// Phase 7m: capped branch must also fit highestStage so stages added`
);

// ============================================================
// Step 2: Context pipeline — same fix
// ============================================================
log("Step 2: context-pipeline.tsx — extend capped branch to highestStage...");

strReplace(
  ctxPipelinePath,
  `  const maxStages = isUnlimitedFollowups(thread.max_followups)
    ? Math.max(3, highestStage)
    : thread.max_followups;`,
  `  // Phase 7m: same fix as doctrine pipeline.tsx — capped branch must
  // fit highestStage so stages beyond the cap (Send Now force, or
  // post-reduction legacy stages) render visually.
  const maxStages = isUnlimitedFollowups(thread.max_followups)
    ? Math.max(3, highestStage)
    : Math.max(thread.max_followups, highestStage);`,
  "context-pipeline.tsx: capped branch fits highestStage",
  `// Phase 7m: same fix as doctrine pipeline.tsx — capped branch must`
);

// ============================================================
// Step 3: Self-verify
// ============================================================
log("Step 3: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Doctrine
expectInFile(pipelinePath, `// Phase 7m: capped branch must also fit highestStage so stages added`, "V1 doctrine Phase 7m comment");
expectInFile(pipelinePath, `: Math.max(thread.max_followups, highestStage);`, "V2 doctrine capped branch fixed");

// Context
expectInFile(ctxPipelinePath, `// Phase 7m: same fix as doctrine pipeline.tsx — capped branch must`, "V3 context Phase 7m comment");
expectInFile(ctxPipelinePath, `: Math.max(thread.max_followups, highestStage);`, "V4 context capped branch fixed");

// Old (broken) shape gone
expectNotInFile(pipelinePath,    `    : thread.max_followups;\n  const stages: React.ReactNode[] = [];`, "V5 doctrine old capped pattern gone");
expectNotInFile(ctxPipelinePath, `    : thread.max_followups;\n  const stages: React.ReactNode[] = [];`, "V6 context old capped pattern gone");

// Sanity: unlimited branch still extends to highestStage
expectInFile(pipelinePath,    `? Math.max(3, highestStage)`, "V7 doctrine unlimited branch unchanged");
expectInFile(ctxPipelinePath, `? Math.max(3, highestStage)`, "V8 context unlimited branch unchanged");

// Sanity: highestStage still computed the same way
expectInFile(pipelinePath,    `const highestStage = thread.stages.length > 0 ? Math.max(...thread.stages.map((s) => s.stage)) : 0;`, "V9 doctrine highestStage compute preserved");
expectInFile(ctxPipelinePath, `const highestStage = thread.stages.length > 0 ? Math.max(...thread.stages.map((s) => s.stage)) : 0;`, "V10 context highestStage compute preserved");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7m patch applied. Pipeline stage squares (both products)");
log("now extend past max_followups to fit the highest real stage in");
log("thread.stages. A prospect with cap=3 and 5 sent stages now");
log("renders 5 squares, all green.");
log("================================================================");
