#!/usr/bin/env node
/**
 * audit-batch7e.mjs — Beautiful-Squidward audit for Phase 7e.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7e] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7e] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const ctxPipelineSrc    = read(join(DASH_BASE, "pages", "context-pipeline.tsx"));
const pipelineSrc       = read(join(DASH_BASE, "pages", "pipeline.tsx"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const appSrc            = read(join(DASH_BASE, "App.tsx"));
const accountsSrc       = read(join(DASH_BASE, "pages", "accounts.tsx"));
const prospectsSchema   = read(join(DB_BASE, "schema", "prospects.ts"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: /api/context/followups response shape
  log(`-- PASS 1: /api/context/followups response shape --`);
  pass(`Reshape comment present`, /Phase 7e: reshape to match the doctrine \/api\/followups response shape/.test(ctxRouteSrc));
  pass(`Drizzle projects originalSubject`, /originalSubject: prospectsTable\.subject,/.test(ctxRouteSrc));
  pass(`Drizzle projects originalBody`,    /originalBody: prospectsTable\.originalBody,/.test(ctxRouteSrc));
  pass(`Drizzle projects originalLanguage`, /originalLanguage: prospectsTable\.originalLanguage,/.test(ctxRouteSrc));
  pass(`Drizzle projects userMaxFollowups`, /userMaxFollowups: usersTable\.maxFollowups,/.test(ctxRouteSrc));
  pass(`Result map: snake_case original_subject`, /original_subject: r\.originalSubject,/.test(ctxRouteSrc));
  pass(`Result map: snake_case max_followups with fallback`, /max_followups: r\.userMaxFollowups \?\? 3,/.test(ctxRouteSrc));
  pass(`Result map: snake_case followup_mode`, /followup_mode: r\.userFollowupMode \?\? "auto_send",/.test(ctxRouteSrc));
  pass(`Order by ascending scheduledAt`, /\.orderBy\(asc\(followupsTable\.scheduledAt\)\)/.test(ctxRouteSrc));

  // PASS 2: /api/context/cancel-followup endpoint
  log(`-- PASS 2: /api/context/cancel-followup --`);
  pass(`/cancel-followup endpoint declared`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`Accepts followup_ids`, /const \{ followup_ids \} = req\.body;/.test(ctxRouteSrc));
  pass(`Defense-in-depth comment`, /Defense-in-depth: only cancel follow-ups whose prospect is app='context'/.test(ctxRouteSrc));
  pass(`Sub-select on prospects with SCOPE`, /db\.select\(\{ id: prospectsTable\.id \}\)\.from\(prospectsTable\)\.where\(SCOPE\)/.test(ctxRouteSrc));
  pass(`Filters status='queued'`, /eq\(followupsTable\.status, "queued"\)/.test(ctxRouteSrc));
  pass(`Original /cancel still present`, /router\.post\("\/cancel"/.test(ctxRouteSrc));

  // PASS 3: ContextPipeline component identity
  log(`-- PASS 3: ContextPipeline component --`);
  pass(`Default export ContextPipeline`, /export default function ContextPipeline\(\)/.test(ctxPipelineSrc));
  pass(`Phase 7e header comment`, /Phase 7e: ContextPipeline — clone of pipeline\.tsx retargeted to/.test(ctxPipelineSrc));
  pass(`Title text "Context Pipeline"`, /Context Pipeline\n\s*<\/h1>/.test(ctxPipelineSrc));
  pass(`Empty-state copy mentions Context label`, /label a Gmail thread with the Context label/.test(ctxPipelineSrc));

  // PASS 4: All API URLs retargeted to /api/context/*
  log(`-- PASS 4: API URLs retargeted --`);
  pass(`followups URL`, /api\/context\/followups\?userId=/.test(ctxPipelineSrc) || /api\/context\/followups/.test(ctxPipelineSrc));
  pass(`send-bulk URL`, /api\/context\/followup\/send-bulk/.test(ctxPipelineSrc));
  pass(`pause-bulk URL`, /api\/context\/prospect\/pause-bulk/.test(ctxPipelineSrc));
  pass(`prospect/:id/{pause|resume} URL`, /api\/context\/prospect\/\$\{prospectId\}\/\$\{endpoint\}/.test(ctxPipelineSrc));
  pass(`followup-now URL`, /api\/context\/followup-now\/\$\{prospectId\}/.test(ctxPipelineSrc));
  pass(`stalled-resume URL`, /api\/context\/prospect\/\$\{prospectId\}\/resume/.test(ctxPipelineSrc));
  pass(`approve URL`, /api\/context\/followups\/\$\{id\}\/approve/.test(ctxPipelineSrc));
  pass(`reject URL`, /api\/context\/followups\/\$\{id\}\/reject/.test(ctxPipelineSrc));
  pass(`cancel-followup URL`, /api\/context\/cancel-followup/.test(ctxPipelineSrc));

  // PASS 5: Raw fetch + setInterval polling (no api-client-react hooks)
  log(`-- PASS 5: Raw fetch data layer --`);
  pass(`useState followups`, /const \[followups, setFollowups\] = useState<FollowupRow\[\] \| null>\(null\);/.test(ctxPipelineSrc));
  pass(`refetchTrigger state`, /const \[refetchTrigger, setRefetchTrigger\] = useState\(0\);/.test(ctxPipelineSrc));
  pass(`30-second setInterval polling`, /const interval = setInterval\(fetchFollowups, 30000\);/.test(ctxPipelineSrc));
  pass(`cancelStageById helper`, /async function cancelStageById\(stageId: number\)/.test(ctxPipelineSrc));
  pass(`invalidateAll bumps refetchTrigger`, /setRefetchTrigger\(\(t\) => t \+ 1\);/.test(ctxPipelineSrc));

  // PASS 6: api-client-react hooks fully removed from context-pipeline
  log(`-- PASS 6: Typed hooks removed --`);
  pass(`useGetFollowups absent`, !/useGetFollowups/.test(ctxPipelineSrc));
  pass(`useCancelFollowups absent`, !/useCancelFollowups/.test(ctxPipelineSrc));
  pass(`useQueueBatch absent`, !/useQueueBatch/.test(ctxPipelineSrc));
  pass(`useQueryClient absent`, !/useQueryClient/.test(ctxPipelineSrc));
  pass(`@workspace/api-client-react import statement removed`, !/from "@workspace\/api-client-react"/.test(ctxPipelineSrc));

  // PASS 7: Doctrine-specific UI surfaces dropped
  log(`-- PASS 7: Doctrine-specific UI removed --`);
  pass(`Queue follow-ups button onClick removed`, !/setIsQueueModalOpen\(true\)/.test(ctxPipelineSrc));
  pass(`queueBatchMutation removed`, !/queueBatchMutation/.test(ctxPipelineSrc));
  pass(`cancelMutation.mutate() call removed`, !/cancelMutation\.mutate\(/.test(ctxPipelineSrc));
  pass(`Modal usage removed`, !/<Modal/.test(ctxPipelineSrc));
  pass(`filterVertical setter removed`, !/setFilterVertical/.test(ctxPipelineSrc));
  pass(`VERTICAL filter Select label removed`, !/>VERTICAL<\/label>/.test(ctxPipelineSrc) && !/VERTICAL\s*<\/label>/.test(ctxPipelineSrc));
  pass(`Layers icon import removed`, !/Layers,/.test(ctxPipelineSrc));

  // PASS 8: Doctrine pipeline.tsx + UI not regressed
  log(`-- PASS 8: Doctrine UI not regressed --`);
  pass(`pipeline.tsx still imports typed hooks`, /import \{ useGetFollowups, useCancelFollowups, useQueueBatch \} from "@workspace\/api-client-react"/.test(pipelineSrc));
  pass(`pipeline.tsx still default-exports Pipeline`, /export default function Pipeline\(\)/.test(pipelineSrc));
  pass(`pipeline.tsx still has Queue follow-ups button onClick`, /setIsQueueModalOpen\(true\)/.test(pipelineSrc));
  pass(`Layout still product-aware (data-product attr)`, /data-product=\{dataProduct\}/.test(layoutSrc));
  pass(`App.tsx still mounts /context/pipeline`, /<Route path="\/context\/pipeline" component=\{ContextPipeline\} \/>/.test(appSrc));
  pass(`accounts.tsx still has Context Gmail label`, /Context Gmail label/.test(accountsSrc));

  // PASS 9: B7c regression — doctrine route filter still in place
  log(`-- PASS 9: B7c/B7a regression --`);
  pass(`SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`SCOPE_DOCTRINE referenced ≥30 times`, (doctrineRouteSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`/reject sub-select gate present`, /Phase 7c: gate by prospect\.app via sub-select/.test(doctrineRouteSrc));
  pass(`/context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`prospects.app schema column present`, /app:\s*text\("app"\)\.\$type<ProspectApp>\(\)/.test(prospectsSchema));
  pass(`users.contextLabel schema column present`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
