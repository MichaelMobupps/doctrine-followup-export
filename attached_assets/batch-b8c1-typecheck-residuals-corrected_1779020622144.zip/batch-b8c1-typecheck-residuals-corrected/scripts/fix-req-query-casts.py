#!/usr/bin/env python3
r"""
B8c.1 — surgical req.query.X cast injection.

Targets the exact 16 lines surfaced by the post-B8c typecheck. For each
target line, finds the `req.query.<identifier>` pattern (not already
cast, not already String-wrapped) and wraps it with the appropriate
type cast.

The 15 Category-1 sites need `as string`. The 1 Category-2 site
(email-inspector.ts:370) needs `as string | undefined` because the
target function accepts undefined.

Idempotent — negative lookahead `(?!\s+as\s+\w)` skips already-cast
sites, so re-runs produce no further changes.

Self-reporting — prints before/after for each line, plus NOOP warnings
if a target line does not match the expected shape (in which case a
manual follow-up is needed).
"""

import re
import sys
import os

# (file, line_number, target_cast)
TARGETS = [
    # Category 1 — `as string`
    ('artifacts/api-server/src/routes/admin-user-controls.ts',  50, 'string'),
    ('artifacts/api-server/src/routes/admin-user-controls.ts',  64, 'string'),
    ('artifacts/api-server/src/routes/context.ts',             336, 'string'),
    ('artifacts/api-server/src/routes/context.ts',             459, 'string'),
    ('artifacts/api-server/src/routes/context.ts',             500, 'string'),
    ('artifacts/api-server/src/routes/context.ts',             532, 'string'),
    ('artifacts/api-server/src/routes/context.ts',             561, 'string'),
    ('artifacts/api-server/src/routes/doctrine.ts',            572, 'string'),
    ('artifacts/api-server/src/routes/doctrine.ts',            775, 'string'),
    ('artifacts/api-server/src/routes/doctrine.ts',            855, 'string'),
    ('artifacts/api-server/src/routes/doctrine.ts',           1046, 'string'),
    ('artifacts/api-server/src/routes/doctrine.ts',           1210, 'string'),
    ('artifacts/api-server/src/routes/doctrine.ts',           1282, 'string'),
    ('artifacts/api-server/src/routes/gmail-auth.ts',          204, 'string'),
    ('artifacts/api-server/src/routes/gmail-auth.ts',          228, 'string'),
    # Category 2 — `as string | undefined` (googleapis overload accepts undefined)
    ('artifacts/api-server/src/routes/email-inspector.ts',     370, 'string | undefined'),
]

PATTERN = re.compile(
    r'(?<!String\()\b(req\.query\.[a-zA-Z_][a-zA-Z0-9_]*)\b(?!\s+as\s+\w)'
)
# Simpler pattern that catches req.query.X regardless of surrounding cast/wrap.
# Used to distinguish "line has req.query but already cast" (OK re-run) from
# "line has no req.query at all" (wrong line number; needs manual triage).
SIMPLE_PATTERN = re.compile(
    r'\b(req\.query\.[a-zA-Z_][a-zA-Z0-9_]*)\b'
)

def cast_suffix(target_type: str) -> str:
    return ' as string' if target_type == 'string' else ' as string | undefined'

def main() -> int:
    # Group by file so each file is read+written once
    by_file: dict[str, list[tuple[int, str]]] = {}
    for fp, ln, tt in TARGETS:
        by_file.setdefault(fp, []).append((ln, tt))

    total_changes = 0
    already_cast = 0
    bad_noops = []

    for fp, line_specs in by_file.items():
        print(f"\n--- {fp} ---")
        if not os.path.isfile(fp):
            print(f"  ERROR: file not found")
            bad_noops.extend([(fp, ln) for ln, _ in line_specs])
            continue

        with open(fp) as f:
            lines = f.readlines()

        changed = False
        for ln, target_type in line_specs:
            idx = ln - 1
            if idx >= len(lines):
                print(f"  WARN  line {ln} beyond file end ({len(lines)} lines)")
                bad_noops.append((fp, ln))
                continue

            original = lines[idx]
            cast = cast_suffix(target_type)
            new = PATTERN.sub(lambda m: f"({m.group(1)}{cast})", original)

            if new != original:
                print(f"  FIX   line {ln}")
                print(f"    OLD: {original.rstrip()}")
                print(f"    NEW: {new.rstrip()}")
                lines[idx] = new
                changed = True
                total_changes += 1
            elif SIMPLE_PATTERN.search(original):
                # Line has req.query.X but the strict pattern didn't match —
                # almost certainly already cast (idempotent re-run).
                print(f"  SKIP  line {ln} — req.query.X present and already cast (idempotent)")
                already_cast += 1
            else:
                # Line has NO req.query at all — wrong line number, manual triage.
                print(f"  NOOP  line {ln} — no req.query.X pattern on this line (line number stale?)")
                print(f"    Content: {original.rstrip()}")
                bad_noops.append((fp, ln))

        if changed:
            with open(fp, 'w') as f:
                f.writelines(lines)

    print(f"\n=== Summary ===")
    print(f"  Lines fixed:        {total_changes} / {len(TARGETS)}")
    print(f"  Already cast (skip): {already_cast}")
    print(f"  Bad NOOPs:          {len(bad_noops)}")
    if bad_noops:
        print(f"  Sites needing manual triage:")
        for fp, ln in bad_noops:
            print(f"    - {fp}:{ln}")
        return 2  # non-zero exit so the bash block stops before typecheck
    return 0

if __name__ == '__main__':
    sys.exit(main())
