#!/usr/bin/env python3
r"""
B8c.2 — req.params.<ident> cast injection across the 5 error-affected routes.

In this codebase's Express 5 + @types/express resolution, `req.params.<key>`
resolves to `string | string[]` rather than the documented `string`. The
result is a typecheck error wherever a route handler passes a URL param
to a function expecting `string` (parseInt, eq(...), googleapis call
arguments, etc.). The 21 errors in the post-B8c typecheck output are all
this shape.

The codebase already uses the `as string` cast pattern for `req.query.X`
in many places (see doctrine.ts:110,173,179,692 etc.). This script
applies the same pattern to every `req.params.<ident>` in the 5 affected
files, except where it is already cast or already wrapped in `String(...)`.

File-scan rather than line-targeted (B8c.1 was bitten by stale line
numbers). The regex is narrow enough that the only sites it touches are
genuine `req.params.<ident>` member accesses.
"""

import re
import sys
import os

TARGET_FILES = [
    'artifacts/api-server/src/routes/admin-user-controls.ts',
    'artifacts/api-server/src/routes/context.ts',
    'artifacts/api-server/src/routes/doctrine.ts',
    'artifacts/api-server/src/routes/gmail-auth.ts',
    'artifacts/api-server/src/routes/email-inspector.ts',
]

# req.params.<ident> NOT preceded by 'String(' and NOT followed by ' as <word>'
PATTERN = re.compile(
    r'(?<!String\()\b(req\.params\.[a-zA-Z_][a-zA-Z0-9_]*)\b(?!\s+as\s+\w)'
)

def main() -> int:
    total_fixed = 0
    errors = []
    for fp in TARGET_FILES:
        print(f"\n--- {fp} ---")
        if not os.path.isfile(fp):
            print(f"  ERROR: file not found")
            errors.append(fp)
            continue

        with open(fp) as f:
            content = f.read()

        # Find every match with its line number for reporting
        match_lines = []
        for m in PATTERN.finditer(content):
            # Compute the line number of the match by counting newlines up to start
            line_no = content[:m.start()].count('\n') + 1
            match_lines.append((line_no, m.group(0)))

        if not match_lines:
            print(f"  0 sites needing cast (already wrapped, or no req.params.<X> usages)")
            continue

        new_content = PATTERN.sub(lambda m: f"({m.group(1)} as string)", content)
        with open(fp, 'w') as f:
            f.write(new_content)

        print(f"  {len(match_lines)} sites wrapped:")
        for ln, expr in match_lines:
            print(f"    line {ln}: {expr} -> ({expr} as string)")
        total_fixed += len(match_lines)

    print(f"\n=== Summary ===")
    print(f"  Files scanned:  {len(TARGET_FILES)}")
    print(f"  Sites wrapped:  {total_fixed}")
    print(f"  Errors:         {len(errors)}")
    return 0 if not errors else 2

if __name__ == '__main__':
    sys.exit(main())
