# B7w — Inspector "DB" badge truth + Korean greeting + pipeline label fallback

## What this fixes

The Email Inspector's `inDatabase` field conflated direct `gmailMessageId` matches with `gmailThreadId` thread-sibling matches. The consequences cascaded:

- DB pill green for messages that had not been ingested yet
- SYNCED badge green for the same false-positive set
- `pendingSyncCount` excluded these messages, **hiding the "Sync Now" CTA banner** exactly when the user needed it (new email in an existing test thread)
- `meta.inDatabase` stat card inflated by thread halos

Symptom: A Korean email sent to `hwholestorm@gmail.com` showed `SENT → LABEL → DB` all green + SYNCED in the inspector, while its own `gmailMessageId` was not yet a prospect row. User believed sync was broken; sync was fine, the inspector was lying.

Secondary fixes folded in:

- Inspector label source now uses `users.doctrineLabel` + `users.contextLabel` for the requesting `userId` (matches `gmailSync.ts` behaviour). Falls back to `process.env.DOCTRINE_LABELS` when no userId is supplied.
- Inspector now reports `hasContextLabel` so context-labeled emails light up LABEL too — sync ingests them as `app='context'`.
- `extractRecipientFirstNameFromBody` adds the formal Korean opener `안녕하십니까` and strips trailing CJK honorifics (Korean 님/씨, Japanese さん/さま/ちゃん/くん/様, Chinese 先生/女士/小姐) so "안녕하세요 김민준님" extracts `김민준` instead of `김민준님`.
- Pipeline `prospect_name` fallback chain: real name → email local-part → subject (truncated 48 chars) → "Unknown". No more 22 identical "Unknown hwholestorm@gmail.com" rows.

## Files touched

```
artifacts/api-server/src/routes/email-inspector.ts
artifacts/api-server/src/services/gmailClient.ts
artifacts/dashboard/src/pages/email-inspector.tsx
artifacts/dashboard/src/pages/pipeline.tsx
```

## Response shape changes (additive, back-compat)

`GET /api/gmail/sent-emails` per-email:
- NEW `inDatabaseByMessage: boolean`
- NEW `inDatabaseByThread: boolean` (true only when there is no direct match)
- NEW `hasContextLabel: boolean`
- NEW `matchedContextLabels: string[]`
- NEW `dbRecord.app: string` (when present)
- Existing `inDatabase` retained as `directMatch || threadMatch` for old clients

`GET /api/gmail/sent-emails` meta:
- NEW `inDatabaseByMessage`, `inDatabaseByThread`, `inDatabaseAny`, `pendingSync`, `withContextLabel`, `contextLabelIds`, `contextLabels`
- `inDatabase` now equals `inDatabaseByMessage` (direct-only). Migrated clients should read the explicit `inDatabaseByMessage` for clarity.

## Smoke test

After deploy, open Email Inspector as `michael@mobupps.com`. The Korean row should now show one of:
- DB pill green + SYNCED badge → message is actually ingested, no action needed (the May 13 0/3 entry in your pipeline IS this prospect)
- DB pill amber "DB?" + "via thread" sub-pill + PENDING SYNC badge → the "Sync Now" banner up top is now visible; click it and the prospect appears in the pipeline within seconds (manual `/api/sync` triggers `autoQueueAllCampaigns` inline)
