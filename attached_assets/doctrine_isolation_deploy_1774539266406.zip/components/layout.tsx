import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, Users, Send, Eye, UserPlus, LogOut, Workflow, Radio } from "lucide-react";
import { cn } from "@/lib/utils";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { apiKey, clearApiKey } = useApiKey();
  const { user: currentUser, clearUser } = useCurrentUser();
  const [activity, setActivity] = useState<{ queued: number; next_due: string | null } | null>(null);

  // Poll activity status every 30s
  useEffect(() => {
    if (!apiKey || !currentUser?.userId) return;
    const fetchActivity = async () => {
      try {
        const base = import.meta.env.BASE_URL || "/";
        const res = await fetch(`${base}api/my/activity?userId=${currentUser.userId}`, {
          headers: { "x-api-key": apiKey },
        });
        if (res.ok) setActivity(await res.json());
      } catch {}
    };
    fetchActivity();
    const interval = setInterval(fetchActivity, 30000);
    return () => clearInterval(interval);
  }, [apiKey, currentUser?.userId]);

  const handleLogout = () => {
    clearUser();
    clearApiKey();
  };

  const navItems = [
    { name: "Dashboard", href: "/", icon: LayoutDashboard },
    { name: "Prospects", href: "/prospects", icon: Users },
    { name: "Follow-ups", href: "/followups", icon: Send },
    { name: "Email Inspector", href: "/inspector", icon: Eye },
    { name: "Settings", href: "/accounts", icon: UserPlus },
  ];

  return (
    <div className="flex min-h-screen w-full">
      <aside
        className="w-[220px] flex-shrink-0 flex flex-col fixed top-0 left-0 h-screen z-20"
        style={{ background: "var(--bg-secondary)", borderRight: "1px solid var(--border-default)" }}
      >
        <div className="px-5 py-5 flex items-center gap-2.5">
          <span
            className="font-semibold tracking-tight"
            style={{ fontSize: "14px", letterSpacing: "-0.01em", color: "var(--text-primary)" }}
          >
            Doctrine AI
          </span>
        </div>

        <nav className="flex-1 px-3 py-1 space-y-0.5">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href} className="block">
                <div
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2.5 rounded-md text-[13px] font-medium transition-all duration-150",
                    isActive
                      ? "text-[var(--text-primary)] bg-[var(--bg-tertiary)]"
                      : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)]"
                  )}
                  style={isActive ? { borderRight: "2px solid var(--accent)" } : {}}
                >
                  <item.icon
                    className="h-4 w-4"
                    style={{ color: isActive ? "var(--text-primary)" : "var(--text-secondary)" }}
                    strokeWidth={1.5}
                  />
                  {item.name}
                </div>
              </Link>
            );
          })}
        </nav>

        <div className="p-3 mt-auto space-y-2">
          {/* Live activity indicator */}
          <div
            className="rounded-lg p-3"
            style={{ background: "var(--bg-tertiary)", border: "1px solid var(--border-default)" }}
          >
            <div className="flex items-center gap-2 mb-1.5">
              <div style={{ position: "relative" }}>
                <Radio className="h-3.5 w-3.5" style={{ color: "var(--success)" }} strokeWidth={1.5} />
                <div
                  style={{
                    position: "absolute", top: 0, left: 0, width: "14px", height: "14px",
                    borderRadius: "50%", background: "var(--success)", opacity: 0.3,
                    animation: "pulse 2s ease-in-out infinite",
                  }}
                />
              </div>
              <p className="text-[11px] font-medium uppercase tracking-[0.04em]" style={{ color: "var(--success)" }}>
                Auto-detecting
              </p>
            </div>
            {currentUser?.email && (
              <p className="text-[11px] truncate mb-1" style={{ color: "var(--text-secondary)" }}>
                {currentUser.email}
              </p>
            )}
            {activity && (
              <div className="text-[10px] space-y-0.5" style={{ color: "var(--text-tertiary)" }}>
                {activity.queued > 0 && (
                  <p>{activity.queued} followup{activity.queued !== 1 ? "s" : ""} queued</p>
                )}
                {activity.queued === 0 && (
                  <p>All caught up</p>
                )}
              </div>
            )}
          </div>

          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-2.5 px-3 py-2.5 rounded-md text-[13px] font-medium transition-all duration-150"
            style={{ color: "var(--text-tertiary)" }}
            onMouseEnter={(e) => {
              e.currentTarget.style.color = "var(--danger)";
              e.currentTarget.style.background = "var(--danger-muted)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.color = "var(--text-tertiary)";
              e.currentTarget.style.background = "transparent";
            }}
          >
            <LogOut className="h-4 w-4" strokeWidth={1.5} />
            Sign out
          </button>
        </div>
      </aside>

      <main className="flex-1 ml-[220px]" style={{ background: "var(--bg-primary)" }}>
        <div className="p-8 max-w-[1100px]">
          {children}
        </div>
      </main>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 0.3; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(1.4); }
        }
      `}</style>
    </div>
  );
}
