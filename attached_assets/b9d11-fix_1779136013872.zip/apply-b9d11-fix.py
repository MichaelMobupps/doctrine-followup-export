#!/usr/bin/env python3
"""
B9d.11-fix - Tune Card 3D tilt to be subtler.

After observing the tilt on wide content cards (e.g., Admin Activity's
Recent Events table at ~1500px wide), the original parameters caused
visible corner distortion: ~6.5% size delta between near and far corners
during hover. The grid of a wide table makes this distortion obvious.

Two single-value tweaks reduce that to ~3%, keeping the tilt felt on
compact cards (kanban, dashboards) while making it nearly invisible on
wide tables.

  TILT_MAX_DEG: 5 -> 3
    Reduces rotation magnitude. Corner depth delta scales linearly
    with sin(angle), so 3 degrees -> sin(3) = 0.052 vs 5 degrees ->
    sin(5) = 0.087. Roughly 40 percent less z-displacement.

  transformPerspective: 1000 -> 1500
    Increases viewer distance, which reduces the apparent
    foreshortening for any given rotation. Scale factor at the
    receding corner improves from ~0.935 (1000) to ~0.97 (1500) at
    3 degrees on a 1600px wide card.

No prop changes, no consumer impact - same API, less visually loud.

Idempotent: both new values are checked independently.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def main():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    # A1: TILT_MAX_DEG 5 -> 3
    old_a1 = "const TILT_MAX_DEG = 5;"
    new_a1 = "const TILT_MAX_DEG = 3; // B9d.11-fix: reduced from 5 to soften tilt on wide cards."
    if "const TILT_MAX_DEG = 3;" in text:
        skip("A1: TILT_MAX_DEG already at 3")
    elif text.count(old_a1) == 1:
        text = text.replace(old_a1, new_a1)
        ok("A1: TILT_MAX_DEG 5 -> 3")
    elif text.count(old_a1) == 0:
        fail("A1: anchor 'const TILT_MAX_DEG = 5;' not found")
    else:
        fail(f"A1: anchor matched {text.count(old_a1)} times")

    # A2: transformPerspective 1000 -> 1500
    old_a2 = "transformPerspective: 1000,"
    new_a2 = "transformPerspective: 1500, // B9d.11-fix: 1000 -> 1500 to reduce foreshortening."
    if "transformPerspective: 1500," in text:
        skip("A2: transformPerspective already at 1500")
    elif text.count(old_a2) == 1:
        text = text.replace(old_a2, new_a2)
        ok("A2: transformPerspective 1000 -> 1500")
    elif text.count(old_a2) == 0:
        fail("A2: anchor 'transformPerspective: 1000,' not found")
    else:
        fail(f"A2: anchor matched {text.count(old_a2)} times")

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already at tuned values")

    print()
    print("B9d.11-fix tilt tune applied.")


if __name__ == "__main__":
    main()
