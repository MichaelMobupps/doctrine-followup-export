B7v — auto-refresh + live indicator for Admin Activity
========================================================

Frontend-only batch. Adds:
  - Auto-refresh toggle (default ON, 30s interval)
  - Silent background polling — no spinner flicker
  - "Updated Ns ago" indicator next to Refresh button
  - Visibility-aware polling: pauses when tab is hidden, refetches
    immediately when tab regains focus
  - "In flight" stat card pulses subtly when active_generations > 0

No backend changes. No deps. No migration. Single file replacement
of artifacts/dashboard/src/pages/admin-activity.tsx.

Files written (1, replaces B7u version):
  - artifacts/dashboard/src/pages/admin-activity.tsx

Audit results:
  - TypeScript strict: 0 errors
  - Vite production build: 1512 modules, 166KB bundle, 0 errors
  - jsdom render: Auto:ON button, Updated indicator, "just now" all present
  - Toggle click flips ON → OFF correctly
  - Visibilitychange event triggers silent refetch (delta=1 verified)
  - Initial fetch count = 1 (no extra renders on mount)
  - Brace balance preserved (382/382)

---

PROMPT FOR THE REPLIT AGENT
---------------------------

> Apply the b7v patch from ~/b7v.zip.
>
> Step 1: run this single bash block in the shell, exactly as-is:
>
> ```
> set -e
> cd ~/workspace
> rm -rf /tmp/b7v && mkdir -p /tmp/b7v
> unzip -o ~/b7v.zip -d /tmp/b7v
> node /tmp/b7v/apply-b7v.mjs
> ./source-code/sync.sh
> pnpm --filter @workspace/dashboard run build
> echo "B7v applied. Ready to restart the workflow."
> ```
>
> Step 2: restart the api-server workflow.
>
> Step 3: wait until the server logs "Server listening port: 8080".
>
> Step 4: show me the last 10 lines of the api-server workflow log.
>
> Do not do anything else. Paste the exact output back to me.

---

POST-DEPLOY VERIFICATION (browser)
----------------------------------

After deploy, open https://doctrine-followupv-2.replit.app/admin-activity

You should see:
  - "Updated Ns ago" text next to the Refresh button (right side of toolbar)
  - "Auto: ON" button with a small pulsing green dot
  - The "In flight" stat card pulsing if active_generations > 0
  - Leave the page open for 30s — the "Updated" text should change to
    "just now" again automatically (silent refresh, no spinner)
  - Click "Auto: ON" → it becomes "Auto: OFF", the dot stops pulsing
  - Switch to another tab for ~10s, then come back — the page fetches
    immediately on focus

That completes the activity-log series (B7r through B7v). The Email
Followuper now has the same "Nazi-Accountant level" observability
the Email Prospector has — adapted to the followup's event-based
attribution model.
