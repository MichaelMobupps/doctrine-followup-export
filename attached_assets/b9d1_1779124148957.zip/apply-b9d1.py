#!/usr/bin/env python3
"""
B9d.1 - AntiGhosting whitish theme: per-product CSS token overrides.

Single CSS file change. Adds a [data-product="anti_ghosting"] block
that overrides both token namespaces:

  - Semantic tokens (--bg-*, --text-*, --border-*, --accent-*) used
    by direct style="" references across the dashboard.
  - Tailwind v4 @theme tokens (--color-*) used by utility classes.

The layout already sets data-product="anti_ghosting" when on /anti-
ghosting/* routes. No JS changes needed; the override cascades to all
descendants of the layout wrapper div.

Palette:
  bg-primary: #f8fafc (off-white page background)
  bg-secondary: #ffffff (pure white sidebar/cards)
  bg-tertiary: #f1f5f9 (light slate hover)
  bg-elevated: #ffffff (modals, popovers)
  border-default: #e2e8f0 (light slate)
  text-primary: #0f172a (slate-900, strong contrast)
  text-secondary: #475569 (slate-600)
  text-tertiary: #94a3b8 (slate-400)
  accent: #2563eb (slightly darker blue for white-bg contrast)
  status colors: tuned darker variants for legibility on white

Reversible: Doctrine and Context retain the existing dark theme
automatically (their data-product values don't match the new selector).

One anchor. Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INDEX_CSS = WORKSPACE / "artifacts/dashboard/src/index.css"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# Anchor on the unique closing of the :root block. `--info: #6366f1;`
# is only present in :root (the @theme block uses `--color-info`).
OLD = '''  --info: #6366f1;
}'''

NEW = '''  --info: #6366f1;
}

/* ============================================================== */
/* B9d.1: AntiGhosting whitish theme.                              */
/* ============================================================== */
/* Activated by the layout component setting data-product="anti_   */
/* ghosting" on its wrapper div. Doctrine and Context retain the   */
/* default dark theme (their data-product values don't match).     */
/* Cascades to all descendants \u2014 sidebar, cards, panels, badges,  */
/* form controls. Reversible: revert by deleting this block.       */
[data-product="anti_ghosting"] {
  color-scheme: light;

  /* Surfaces */
  --bg-primary: #f8fafc;
  --bg-secondary: #ffffff;
  --bg-tertiary: #f1f5f9;
  --bg-elevated: #ffffff;

  /* Borders */
  --border-default: #e2e8f0;
  --border-hover: #cbd5e1;
  --border-active: #94a3b8;

  /* Text */
  --text-primary: #0f172a;
  --text-secondary: #475569;
  --text-tertiary: #94a3b8;

  /* Accent */
  --accent: #2563eb;
  --accent-hover: #1d4ed8;
  --accent-muted: rgba(37,99,235,0.08);
  --accent-border: rgba(37,99,235,0.25);

  /* Status colors tuned for white background contrast */
  --success: #16a34a;
  --warning: #ca8a04;
  --danger: #dc2626;
  --info: #4f46e5;
  --success-muted: rgba(22,163,74,0.08);
  --success-border: rgba(22,163,74,0.25);
  --warning-muted: rgba(234,179,8,0.12);
  --warning-border: rgba(234,179,8,0.30);
  --danger-muted: rgba(220,38,38,0.08);
  --danger-border: rgba(220,38,38,0.25);
  --info-muted: rgba(79,70,229,0.08);
  --info-border: rgba(79,70,229,0.25);

  /* Tailwind v4 @theme token mirrors. Utility classes (bg-card,    */
  /* text-foreground, etc.) reference these. Keep aligned with the  */
  /* semantic tokens above so direct and utility styling agree.     */
  --color-background: #f8fafc;
  --color-foreground: #0f172a;
  --color-card: #ffffff;
  --color-card-foreground: #0f172a;
  --color-popover: #ffffff;
  --color-popover-foreground: #0f172a;
  --color-border: #e2e8f0;
  --color-input: #ffffff;
  --color-ring: #2563eb;
  --color-primary: #2563eb;
  --color-primary-foreground: #ffffff;
  --color-secondary: #f1f5f9;
  --color-secondary-foreground: #475569;
  --color-muted: #f1f5f9;
  --color-muted-foreground: #64748b;
  --color-accent: #eff6ff;
  --color-accent-foreground: #1e3a8a;
  --color-destructive: #dc2626;
  --color-destructive-foreground: #ffffff;
  --color-success: #16a34a;
  --color-success-foreground: #ffffff;
  --color-warning: #ca8a04;
  --color-warning-foreground: #ffffff;
  --color-info: #4f46e5;
  --color-info-foreground: #ffffff;
  --color-tertiary: #94a3b8;
}'''


def main():
    if not INDEX_CSS.exists():
        fail(f"index.css not found: {INDEX_CSS}")
    text = INDEX_CSS.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, OLD, NEW,
        "AG whitish theme block",
        marker='B9d.1: AntiGhosting whitish theme',
    )

    if text != original:
        INDEX_CSS.write_text(text, encoding="utf-8")
        ok(f"wrote {INDEX_CSS.relative_to(WORKSPACE)}")
    else:
        skip("index.css already patched")

    print()
    print("B9d.1 AG whitish theme applied.")


if __name__ == "__main__":
    main()
