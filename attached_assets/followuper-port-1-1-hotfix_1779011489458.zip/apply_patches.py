#!/usr/bin/env python3
"""
followuper-port-1.1 — Hotfix for followuper-port-1 ship defects.

Two defects fixed:

DEFECT 1 — test file fails at import in ESM scope:
  Original test file used CommonJS `__dirname` which is undefined in ESM
  module scope. The live api-server runs under ESM (Node 22 + tsx), so
  the test crashed at line 20 with ReferenceError.
  Fix: replace with the ESM idiom `fileURLToPath(import.meta.url)`.

DEFECT 2 — apply_patches.py auto-selected the wrong tree:
  The original script probed for `services/followupGenerator.ts` from each
  candidate root. The live api-server tree is `artifacts/api-server/src/
  services/...` (with a `src/` segment); the source-code/ mirror is flat
  (`source-code/api-server/services/...`). Without a `src/` probe variant,
  the script auto-selected the flat mirror layout — patches landed in the
  mirror, not the live tree.
  Fix: probe with-src first, then without. Also: TARGET_ROOTS now puts the
  live `artifacts/api-server/src` ahead of any mirror or sandbox path.

What this hotfix DOES:
  - Replaces the broken test file with the ESM-compatible version.
  - Patches followupGenerator.ts and followupPrompts.ts ONLY if they
    don't already have the v1 markers (idempotent — if a previous v1
    correctly applied to the live tree, those steps SKIP).

What this hotfix does NOT do:
  - Does not re-apply patches that are already in place (idempotent).
  - Does not touch the mirror. After this ship runs `sync.sh` from
    artifacts/ → source-code/, the mirror converges automatically.

Idempotent. Run from any directory; auto-detects the correct target.
"""
import os
import shutil
import sys
from pathlib import Path

BUNDLE_VERSION = "followuper-p1-1"
BACKUP_SUFFIX = f".{BUNDLE_VERSION}_backup"

SCRIPT_DIR = Path(__file__).resolve().parent
PAYLOAD_DIR = SCRIPT_DIR / "_payload" / "source-code"


def detect_target():
    """Find the live api-server tree, preferring the artifacts/.../src layout
    over the flat mirror.

    Order matters: probe live src first → live flat → mirror flat → sandbox.
    Without this ordering, an apply_patches run from the repo root will
    auto-select the mirror tree (which is the bug the original v1 ship had).
    """
    candidates = [
        # Live tree (Replit artifacts/) — src-based layout is the actual prod
        Path.cwd() / "artifacts" / "api-server" / "src",
        Path.cwd() / "artifacts" / "api-server",
        # Direct invocation inside artifacts/api-server
        Path.cwd() / "src",
        Path.cwd(),
        # Mirror tree (source-code/) — flat layout, read-only review material
        Path.cwd() / "source-code" / "api-server",
        # Local sandbox layouts
        Path("/home/claude/followuper_p1_1/test_apply_live/artifacts/api-server/src"),
        Path("/home/claude/followuper_p1_1/test_apply_mirror/source-code/api-server"),
        Path("/home/claude/followuper_p1/test_apply/api-server"),
    ]
    for c in candidates:
        if c.is_dir() and (c / "services" / "followupGenerator.ts").is_file():
            return c
    return None


TARGET_DIR = detect_target()
if TARGET_DIR is None:
    print("ERROR: cannot locate api-server tree.")
    print("       Probed under artifacts/api-server/src, artifacts/api-server,")
    print("       source-code/api-server, and current working directory.")
    sys.exit(1)


def banner(msg):
    print(f"\n=== {msg} ===")


def backup(path):
    bk = path.with_suffix(path.suffix + BACKUP_SUFFIX)
    if not bk.exists():
        shutil.copy2(path, bk)


def patch_text(path, old, new, label, predecessor_marker=None, idempotency_marker=None):
    text = path.read_text()
    if idempotency_marker and idempotency_marker in text:
        print(f"  SKIP {label} (already up-to-date)")
        return False
    if predecessor_marker and predecessor_marker not in text:
        print(f"  ERROR {label}: predecessor marker not found in {path}")
        print(f"         marker: {predecessor_marker[:80]}")
        sys.exit(1)
    if old not in text:
        print(f"  SKIP {label} (old string not found — likely already patched)")
        return False
    backup(path)
    path.write_text(text.replace(old, new, 1))
    print(f"  OK   {label}")
    return True


def write_file(path, content, label):
    if path.exists():
        backup(path)
    path.write_text(content)
    print(f"  OK   {label}")


# ────────────────────────────────────────────────────────────────────
# Patch 1 (re-applied if missing) — restoreUniversalTechBrands + humanizeText hook
# ────────────────────────────────────────────────────────────────────
def patch_humanize_text():
    p = TARGET_DIR / "services" / "followupGenerator.ts"
    OLD = (
        "function humanizeText(text: string): string {\n"
        "  let result = text;"
    )
    NEW = (
        "// followuper-p1: port of prospector v4r6x Patch B (core/brand_localization.py).\n"
        "// Reverts over-transliterations of universal Latin tech brands back to Latin in\n"
        "// non-Latin language emails. iOS, Android, etc. are always Latin in B2B media\n"
        "// across all languages — when the writer over-transliterates them (e.g. Russian\n"
        "// 'Андроид' / 'АйОС'), this restores them.\n"
        "//\n"
        "// Applied UNCONDITIONALLY (no language parameter needed): the source patterns\n"
        "// only appear in non-Latin scripts, so the map is a no-op on Latin-script bodies.\n"
        "// Map structure mirrors core/brand_localization._UNIVERSAL_TECH_RESTORE in the\n"
        "// prospector. Extensible per-language as production observations dictate.\n"
        "const UNIVERSAL_TECH_RESTORE: Record<string, string> = {\n"
        "  // Russian (observed in prospector production 2026-05-16 Magnit draft)\n"
        "  \"Андроид\": \"Android\",\n"
        "  \"АйОС\": \"iOS\",\n"
        "  \"АЙОС\": \"iOS\",\n"
        "  // Korean / Japanese / Chinese / Thai / Arabic: extend on observation.\n"
        "  // Empty for now — writer-prompt directive (BRAND ADAPTATION) keeps these\n"
        "  // Latin probabilistically across all languages.\n"
        "};\n"
        "\n"
        "function restoreUniversalTechBrands(text: string): string {\n"
        "  if (!text) return text;\n"
        "  let result = text;\n"
        "  for (const [nativeForm, latinForm] of Object.entries(UNIVERSAL_TECH_RESTORE)) {\n"
        "    if (result.includes(nativeForm)) {\n"
        "      result = result.split(nativeForm).join(latinForm);\n"
        "    }\n"
        "  }\n"
        "  return result;\n"
        "}\n"
        "\n"
        "function humanizeText(text: string): string {\n"
        "  let result = text;\n"
        "  // followuper-p1: revert universal Latin tech brand over-transliterations FIRST,\n"
        "  // before the existing humanize passes — the rest of humanizeText assumes Latin\n"
        "  // brand names won't be wrapped inside e.g. Cyrillic transliteration.\n"
        "  result = restoreUniversalTechBrands(result);"
    )
    patch_text(
        p,
        old=OLD,
        new=NEW,
        label="1  followupGenerator.ts += restoreUniversalTechBrands + humanizeText hook",
        predecessor_marker="function humanizeText(text: string): string {",
        idempotency_marker="followuper-p1: port of prospector v4r6x Patch B",
    )


# ────────────────────────────────────────────────────────────────────
# Patch 2 (re-applied if missing) — BRAND ADAPTATION directive
# ────────────────────────────────────────────────────────────────────

BRAND_ADAPTATION_BLOCK = (
    "- BRAND ADAPTATION (CRITICAL — applies to ALL non-Latin target languages, severity: block, "
    "ported from prospector v4r6x): when writing in a non-Latin target language (Russian, "
    "Ukrainian, Thai, Chinese, Japanese, Korean, Arabic, Hebrew, Greek, Hindi, Bengali, "
    "Urdu, Persian, Amharic, etc.), name local-market brands and competitors in their "
    "native-script form as they appear in local B2B media. For example in Russian: "
    "\"Кинопоиск\" (not \"Kinopoisk\"), \"Окко\" (not \"Okko\"), \"Озон\" (not \"Ozon\"), "
    "\"Тинькофф\" (not \"Tinkoff\"). For Chinese: \"微信\" (not \"WeChat\" in Chinese-language "
    "B2B copy). EXPLICIT LATIN-KEEP LIST: the following universal Latin tech brands MUST stay "
    "in Latin script in EVERY non-Latin target language. NEVER transliterate them — they "
    "appear in Latin in B2B media everywhere: iOS, Android, Google, Apple, Microsoft, Amazon, "
    "AWS, Facebook, Meta, Netflix, AppsFlyer, Adjust, Singular, Branch, Kochava, Firebase, "
    "Mixpanel, Amplitude, Tableau, Salesforce, HubSpot. Brand names of mobile measurement "
    "partners (MMPs), analytics SaaS, and cloud platforms always stay Latin. Apply the same "
    "principle to any globally-Latin SaaS / platform / OS brand. Brands whose canonical "
    "identity is Latin even in local-language media (Wildberries, AliExpress, Lamoda in "
    "Russia; Rakuten in Japan in some contexts) should also be kept in Latin script."
)


def patch_followup_prompts():
    p = TARGET_DIR / "services" / "followupPrompts.ts"
    GREETING_END = "treat it as \"no name\" and use the neutral greeting."

    # 2a — System prompt
    OLD_SYS = GREETING_END + "\n- COMPANY:"
    NEW_SYS = GREETING_END + "\n" + BRAND_ADAPTATION_BLOCK + "\n- COMPANY:"
    patch_text(
        p,
        old=OLD_SYS,
        new=NEW_SYS,
        label="2a followupPrompts.ts SYSTEM prompt += BRAND ADAPTATION directive",
        predecessor_marker=GREETING_END + "\n- COMPANY:",
        idempotency_marker="BRAND ADAPTATION (CRITICAL — applies to ALL non-Latin target languages, severity: block, ported from prospector v4r6x)",
    )

    # 2b — Rewriter prompt (guard against double-fire via marker-count check)
    OLD_RW = GREETING_END + "\n- Keep the email to 4-6 sentences maximum."
    NEW_RW = GREETING_END + "\n" + BRAND_ADAPTATION_BLOCK + "\n- Keep the email to 4-6 sentences maximum."
    text = p.read_text()
    marker_count = text.count(
        "BRAND ADAPTATION (CRITICAL — applies to ALL non-Latin target languages, severity: block, ported from prospector v4r6x)"
    )
    if marker_count >= 2:
        print("  SKIP 2b followupPrompts.ts REWRITER prompt += BRAND ADAPTATION (already up-to-date)")
    elif OLD_RW not in text:
        print("  SKIP 2b followupPrompts.ts REWRITER prompt (anchor not found — already patched or absent)")
    else:
        backup(p)
        new_text = text.replace(OLD_RW, NEW_RW, 1)
        p.write_text(new_text)
        print("  OK   2b followupPrompts.ts REWRITER prompt += BRAND ADAPTATION directive")


# ────────────────────────────────────────────────────────────────────
# Install fixed test file (force-rewrite; original v1 test was broken)
# ────────────────────────────────────────────────────────────────────
def install_test_file_v1_1():
    p = TARGET_DIR / "tests" / "test-followuper-port-1.ts"
    src = PAYLOAD_DIR / "api-server" / "tests" / "test-followuper-port-1.ts"
    if not src.is_file():
        print(f"  ERROR: payload missing: {src}")
        sys.exit(1)
    # Force-rewrite: if the v1 broken file exists, we want to overwrite it
    # with the ESM-compatible version. The .followuper-p1_backup from the
    # v1 install already preserves the pre-v1 state (which was "no file").
    # Our v1.1 backup is the v1 broken file, which we keep around as
    # reference for the hotfix.
    if p.exists():
        # Idempotency check: is the file ALREADY v1.1?
        existing = p.read_text()
        if "ESM-compatible __dirname (Node 16+)" in existing:
            print("  SKIP T  test-followuper-port-1.ts (already v1.1)")
            return
        # Otherwise back up the broken v1 file and replace it
        backup(p)
        p.write_text(src.read_text())
        print("  OK   T  test-followuper-port-1.ts (replaced broken v1 with v1.1 ESM-compatible)")
    else:
        p.write_text(src.read_text())
        print("  OK   T  test-followuper-port-1.ts (installed v1.1 ESM-compatible)")


def main():
    banner(f"followuper-p1-1 apply - target: {TARGET_DIR}")
    patch_humanize_text()
    patch_followup_prompts()
    install_test_file_v1_1()
    banner("followuper-p1-1 apply complete")


if __name__ == "__main__":
    main()
