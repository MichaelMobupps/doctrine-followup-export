#!/usr/bin/env python3
"""
B9b.11 patcher - bulk pause + bulk resume for AntiGhosting.

Backend (anti-ghosting.ts):
  1. Extend drizzle-orm import: add `inArray`.
  2. Insert POST /prospect/pause-bulk handler before `export default router;`.
     Mirrors context's pause-bulk exactly with SCOPE=anti_ghosting.
     Reuses cancelActiveFollowupsForProspects helper (app-agnostic).
  3. Insert POST /prospect/resume-bulk handler before `export default router;`.
     No direct context analog. Per-prospect logic loop:
       - Filter to AG + non-replied prospects.
       - UPDATE followupPaused=false for those.
       - Per prospect, compute nextStage from sent cycle stages.
       - INSERT next stage queued at scheduledAt = NOW + 7d.
       - try/catch around each INSERT to swallow UNIQUE collisions.

Frontend (anti-ghosting-pipeline.tsx): overwrite with B9b.11 additions
(state, handlers, row checkbox, select-all toggle, bulk-action bar).

Idempotent. Anchor uniqueness verified. Aborts loudly on drift.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
BACKEND = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"
FRONTEND = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-pipeline.tsx"

TSX_CONTENT = r'''// B9b.8/B9b.9: AntiGhostingPipeline — pipeline view for anti_ghosting prospects.
//
// B9b.8 (view-only listing) and B9b.9 (pause/resume actions) shipped here.
// Approve/reject + add-stage-now: B9b.10. Bulk actions: B9b.11.
//
// ModePill and StallPill (from context-pipeline) are dropped because
// AntiGhosting has no draft-in-gmail mode and no stall semantics.
//
// Data fetching uses raw fetch + 30s polling, mirroring context-pipeline.
import React, { useState, useMemo, useEffect } from "react";
import { format } from "date-fns";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";
import { Card, Button, Select } from "@/components/ui";
import {
  Send, AlertCircle, X, ChevronDown, ChevronUp,
  Pause, Play, Clock, Ban, Eye, EyeOff, MoreHorizontal, Mail, ExternalLink,
  RotateCcw, Loader2, Square, Plus, CheckSquare, MinusSquare,
} from "lucide-react";

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */

interface FollowupRow {
  id: number;
  prospect_id: number;
  stage: number;
  status: string;
  scheduled_at: string;
  generated_body: string | null;
  generated_subject: string | null;
  sent_at: string | null;
  gmail_message_id: string | null;
  error_message: string | null;
  created_at: string;
  cycle?: number;
  prospect_name: string;
  company: string;
  email: string;
  vertical: string;
  original_subject: string;
  original_body_summary?: string | null;
  original_body?: string | null;
  original_language?: string | null;
  original_sent_at?: string | null;
  gmail_thread_id?: string | null;
  followup_paused?: boolean;
  replied?: number;
  prospect_cycle?: number;
  max_followups?: number;
  followup_mode?: string;
}

interface EmailThread {
  prospect_id: number;
  prospect_name: string;
  company: string;
  email: string;
  vertical: string;
  original_subject: string;
  original_body_summary: string;
  original_body: string;
  original_language: string;
  original_sent_at: string | null;
  gmail_thread_id: string | null;
  followup_paused: boolean;
  replied: boolean;
  max_followups: number;
  followup_mode: string;
  stages: FollowupRow[];
  current_stage: number;
  next_followup: FollowupRow | null;
  has_more_scheduled: boolean;
  all_done: boolean;
  current_cycle: number;
  total_cycles: number;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                            */
/* ------------------------------------------------------------------ */

function groupByThread(followups: FollowupRow[]): EmailThread[] {
  const map = new Map<number, FollowupRow[]>();

  for (const f of followups) {
    const pid = f.prospect_id;
    if (!map.has(pid)) map.set(pid, []);
    map.get(pid)!.push(f);
  }

  const threads: EmailThread[] = [];

  for (const [pid, rows] of map) {
    const currentCycle = rows[0].prospect_cycle ?? 1;
    const totalCycles = Math.max(1, ...rows.map(r => r.cycle ?? 1));

    // Show followups belonging to the current cycle only. If none exist
    // yet (cycle was just bumped and F1 hasn't been generated), fall back
    // to all rows so the prospect stays visible in the list.
    const cycleRows = rows.filter(r => (r.cycle ?? 1) === currentCycle);
    const displayRows = cycleRows.length > 0 ? cycleRows : rows;
    const sorted = [...displayRows].sort((a, b) => a.stage - b.stage);
    const first = sorted[0];

    const sentStages = sorted.filter(r => r.status === "sent");
    const activeStages = sorted.filter(r =>
      ["queued", "generating", "pending_approval", "drafted"].includes(r.status)
    );
    const maxSentStage = sentStages.length > 0
      ? Math.max(...sentStages.map(s => s.stage))
      : 0;

    const currentStage = maxSentStage;
    const maxFollowups = first.max_followups ?? 3;

    const nextQueued = activeStages.length > 0
      ? activeStages.sort((a, b) =>
          new Date(a.scheduled_at).getTime() - new Date(b.scheduled_at).getTime()
        )[0]
      : null;

    const allDone = activeStages.length === 0 && currentStage >= maxFollowups;

    threads.push({
      prospect_id: pid,
      prospect_name: first.prospect_name || "Unknown",
      company: first.company || "",
      email: first.email,
      vertical: first.vertical,
      original_subject: first.original_subject,
      original_body_summary: first.original_body_summary || "",
      original_body: first.original_body || "",
      original_language: first.original_language || "en",
      original_sent_at: first.original_sent_at || null,
      gmail_thread_id: first.gmail_thread_id || null,
      followup_paused: !!first.followup_paused,
      replied: !!first.replied,
      max_followups: maxFollowups,
      followup_mode: first.followup_mode || "auto_send",
      stages: sorted,
      current_stage: currentStage,
      next_followup: nextQueued,
      has_more_scheduled: activeStages.length > 0,
      all_done: allDone,
      current_cycle: currentCycle,
      total_cycles: totalCycles,
    });
  }

  return threads.sort((a, b) => {
    if (a.has_more_scheduled && !b.has_more_scheduled) return -1;
    if (!a.has_more_scheduled && b.has_more_scheduled) return 1;
    if (a.next_followup && b.next_followup) {
      return new Date(a.next_followup.scheduled_at).getTime() -
             new Date(b.next_followup.scheduled_at).getTime();
    }
    return b.current_stage - a.current_stage;
  });
}

/* ------------------------------------------------------------------ */
/*  Sub-components                                                     */
/* ------------------------------------------------------------------ */

/**
 * CyclePill — AntiGhosting-specific. Shows the prospect's current cycle.
 * When there's cycle history (total > 1), shows it as "Cycle 2/3" so the
 * operator sees the thread has been re-engaged before.
 */
function CyclePill({ current, total }: { current: number; total: number }) {
  const hasHistory = total > 1;
  return (
    <span
      className="inline-flex items-center gap-1 text-[10px] font-mono font-medium px-1.5 py-0.5 rounded uppercase tracking-[0.04em]"
      style={{
        background: "var(--accent-muted)",
        color: "var(--accent)",
        border: "1px solid var(--accent-border)",
      }}
      title={hasHistory
        ? `Currently in cycle ${current}. This thread has been re-engaged ${total - 1} time${total - 1 !== 1 ? "s" : ""} before.`
        : `Currently in cycle ${current}.`
      }
    >
      <RotateCcw className="h-2.5 w-2.5" strokeWidth={2} />
      Cycle {current}
      {hasHistory && <span style={{ opacity: 0.7 }}>/{total}</span>}
    </span>
  );
}

function StageProgress({ thread }: { thread: EmailThread }) {
  const highestStage = thread.stages.length > 0 ? Math.max(...thread.stages.map((s) => s.stage)) : 0;
  const maxStages = Math.max(thread.max_followups, highestStage);
  const stages: React.ReactNode[] = [];

  for (let i = 1; i <= maxStages; i++) {
    const stage = thread.stages.find(s => s.stage === i);
    let bg = "var(--bg-tertiary)";
    let border = "var(--border-default)";
    let title = `Stage ${i}: not scheduled`;

    if (stage) {
      switch (stage.status) {
        case "sent":
          bg = "var(--success)"; border = "var(--success)";
          title = `Stage ${i}: sent`; break;
        case "queued": case "generating":
          bg = "var(--warning)"; border = "var(--warning)";
          title = `Stage ${i}: queued`; break;
        case "pending_approval":
          bg = "var(--accent)"; border = "var(--accent)";
          title = `Stage ${i}: pending approval`; break;
        case "cancelled":
          bg = "transparent"; border = "var(--border-hover)";
          title = `Stage ${i}: cancelled`; break;
        case "failed":
          bg = "var(--danger)"; border = "var(--danger)";
          title = `Stage ${i}: failed`; break;
        case "drafted":
          bg = "rgba(255,140,0,0.4)"; border = "rgb(255,140,0)";
          title = `Stage ${i}: drafted`; break;
      }
    }

    stages.push(
      <div
        key={i}
        title={title}
        style={{
          width: "10px", height: "10px", borderRadius: "2px",
          background: bg, border: `1.5px solid ${border}`,
          transition: "all 0.15s ease",
        }}
      />
    );
  }

  return <div className="flex items-center gap-1">{stages}</div>;
}

function StatusSummary({ thread }: { thread: EmailThread }) {
  if (thread.replied) {
    return (
      <span className="text-[12px] font-medium" style={{ color: "var(--success)" }}>
        Replied — thread closed
      </span>
    );
  }
  if (thread.followup_paused) {
    return (
      <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--warning)" }}>
        <Pause className="h-3 w-3" /> Paused
      </span>
    );
  }
  if (thread.all_done) {
    return (
      <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--text-tertiary)" }}>
        <Ban className="h-3 w-3" /> Cycle complete
      </span>
    );
  }
  if (thread.next_followup) {
    if (thread.next_followup.status === "pending_approval") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--accent)" }}>
          <Eye className="h-3 w-3" /> Awaiting approval
        </span>
      );
    }
    return null;
  }
  return (
    <span className="text-[12px]" style={{ color: "var(--text-tertiary)" }}>
      No stages queued
    </span>
  );
}

function CountdownTimer({ scheduledAt }: { scheduledAt: string }) {
  const [, setTick] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => setTick(t => t + 1), 30000);
    return () => clearInterval(interval);
  }, []);

  const target = new Date(scheduledAt);
  const diff = target.getTime() - Date.now();

  if (diff <= 0) {
    return (
      <span className="font-mono text-[12px] font-semibold" style={{ color: "var(--warning)" }}>
        Due now
      </span>
    );
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

  let display = "";
  if (days > 0) display = `${days}d ${hours}h`;
  else if (hours > 0) display = `${hours}h ${minutes}m`;
  else display = `${minutes}m`;

  return (
    <span className="font-mono text-[12px]" style={{ color: "var(--text-primary)" }}>
      {display}
    </span>
  );
}

/* ------------------------------------------------------------------ */
/*  Main component                                                     */
/* ------------------------------------------------------------------ */

export default function AntiGhostingPipeline() {
  const { apiKey } = useApiKey();
  const { user: currentUser } = useCurrentUser();

  const [filterState, setFilterState] = useState<string>("all");
  const [expandedThread, setExpandedThread] = useState<number | null>(null);
  const [expandedPreview, setExpandedPreview] = useState<number | null>(null);
  const [viewingOriginalFor, setViewingOriginalFor] = useState<EmailThread | null>(null);

  // B9b.9: pause/resume action state.
  const [togglingPauseId, setTogglingPauseId] = useState<number | null>(null);
  const [addingStageId, setAddingStageId] = useState<number | null>(null);

  // B9b.11: Multi-select state for bulk actions.
  const [selectedIds, setSelectedIds] = useState<Set<number>>(new Set());
  const [bulkPausing, setBulkPausing] = useState(false);
  const [bulkResuming, setBulkResuming] = useState(false);

  function toggleSelected(prospectId: number) {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(prospectId)) next.delete(prospectId);
      else next.add(prospectId);
      return next;
    });
  }

  function clearSelection() {
    setSelectedIds(new Set());
  }
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [feedbackError, setFeedbackError] = useState(false);

  // B9b.8: raw-fetch data layer. 30s poll mirrors context-pipeline.
  const [followups, setFollowups] = useState<FollowupRow[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [refetchTrigger, setRefetchTrigger] = useState(0);

  useEffect(() => {
    if (!apiKey) return;
    let cancelled = false;

    async function fetchFollowups() {
      try {
        const base = import.meta.env.BASE_URL || "/";
        const url = currentUser?.userId
          ? `${base}api/anti-ghosting/followups?userId=${currentUser.userId}`
          : `${base}api/anti-ghosting/followups`;
        const res = await fetch(url, { headers: { "x-api-key": apiKey || "" } });
        if (cancelled) return;
        if (!res.ok) { setIsError(true); setIsLoading(false); return; }
        const data = await res.json();
        if (cancelled) return;
        setFollowups(Array.isArray(data) ? data : []);
        setIsError(false);
        setIsLoading(false);
      } catch {
        if (!cancelled) { setIsError(true); setIsLoading(false); }
      }
    }

    fetchFollowups();
    const interval = setInterval(fetchFollowups, 30000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [apiKey, currentUser?.userId, refetchTrigger]);

  function invalidateAll() {
    setRefetchTrigger((t) => t + 1);
  }

  function showFeedback(msg: string, isError = false) {
    setFeedbackError(isError);
    setFeedbackMsg(msg);
    setTimeout(() => setFeedbackMsg(null), 5000);
  }

  /* ---- Actions ---- */

  const handleTogglePause = async (prospectId: number, currentlyPaused: boolean) => {
    setTogglingPauseId(prospectId);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const endpoint = currentlyPaused ? "resume" : "pause";
      const res = await fetch(`${base}api/anti-ghosting/prospect/${prospectId}/${endpoint}`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
      });
      const data = await res.json();
      if (!res.ok) {
        showFeedback(data.error || `Failed to ${endpoint}`, true);
        return;
      }
      const verb = currentlyPaused ? "Resumed" : "Stopped";
      const extra = data.queued_stage
        ? ` — queued F${data.queued_stage}`
        : data.cancelled_queued
        ? ` — cancelled ${data.cancelled_queued} queued`
        : "";
      showFeedback(`${verb} followups for this thread${extra}`);
      invalidateAll();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed";
      showFeedback(msg, true);
    } finally {
      setTogglingPauseId(null);
    }
  };

  const handleAddStage = async (prospectId: number) => {
    setAddingStageId(prospectId);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(`${base}api/anti-ghosting/followup-now/${prospectId}`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok) {
        showFeedback(data.error || "Failed to queue next stage", true);
        return;
      }
      showFeedback(data.message || `Stage F${data.queued_stage} queued`);
      invalidateAll();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed";
      showFeedback(msg, true);
    } finally {
      setAddingStageId(null);
    }
  };

  async function handleBulkPause() {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm(`Pause AntiGhosting campaigns for ${ids.length} prospect${ids.length !== 1 ? "s" : ""}? Queued follow-ups will be cancelled.`)) return;
    setBulkPausing(true);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(`${base}api/anti-ghosting/prospect/pause-bulk`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
        body: JSON.stringify({ prospectIds: ids }),
      });
      const data = await res.json();
      if (!res.ok) {
        showFeedback(data.error || "Bulk pause failed", true);
        return;
      }
      showFeedback(
        `Paused ${data.paused || 0} of ${data.total || ids.length}; cancelled ${data.cancelled_queued || 0} queued follow-up${(data.cancelled_queued || 0) !== 1 ? "s" : ""}`,
      );
      clearSelection();
      invalidateAll();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Bulk pause failed";
      showFeedback(msg, true);
    } finally {
      setBulkPausing(false);
    }
  }

  async function handleBulkResume() {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm(`Resume AntiGhosting campaigns for ${ids.length} prospect${ids.length !== 1 ? "s" : ""}? Next-stage follow-ups will be queued for eligible (non-replied) prospects.`)) return;
    setBulkResuming(true);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(`${base}api/anti-ghosting/prospect/resume-bulk`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
        body: JSON.stringify({ prospectIds: ids }),
      });
      const data = await res.json();
      if (!res.ok) {
        showFeedback(data.error || "Bulk resume failed", true);
        return;
      }
      showFeedback(
        `Resumed ${data.resumed || 0} of ${data.total || ids.length}; queued ${data.queued || 0} new stage${(data.queued || 0) !== 1 ? "s" : ""}`,
      );
      clearSelection();
      invalidateAll();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Bulk resume failed";
      showFeedback(msg, true);
    } finally {
      setBulkResuming(false);
    }
  }

  const threads = useMemo(() => {
    if (!followups || !Array.isArray(followups)) return [];
    return groupByThread(followups as FollowupRow[]);
  }, [followups]);

  const filteredThreads = useMemo(() => {
    return threads.filter(t => {
      if (filterState === "active" && (t.all_done || t.followup_paused || t.replied)) return false;
      if (filterState === "paused" && !t.followup_paused) return false;
      if (filterState === "completed" && !t.all_done) return false;
      if (filterState === "pending" && !t.stages.some(s => s.status === "pending_approval")) return false;
      return true;
    });
  }, [threads, filterState]);

  /* ---- Counters ---- */

  const activeCount = threads.filter(t => t.has_more_scheduled && !t.followup_paused && !t.replied).length;
  const pausedCount = threads.filter(t => t.followup_paused).length;
  const pendingCount = threads.filter(t => t.stages.some(s => s.status === "pending_approval")).length;
  const doneCount = threads.filter(t => t.all_done).length;

  /* ---- Render ---- */

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>
            AntiGhosting Pipeline
          </h1>
          <p className="text-[12px] mt-0.5" style={{ color: "var(--text-tertiary)" }}>
            Pause/resume and add-stage-now actions live.
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 text-[12px]" style={{ color: "var(--text-secondary)" }}>
            <span>
              <span className="font-mono font-semibold" style={{ color: "var(--success)" }}>{activeCount}</span> active
            </span>
            <span>
              <span className="font-mono font-semibold" style={{ color: "var(--warning)" }}>{pausedCount}</span> paused
            </span>
            {pendingCount > 0 && (
              <span>
                <span className="font-mono font-semibold" style={{ color: "var(--accent)" }}>{pendingCount}</span> pending
              </span>
            )}
            <span>
              <span className="font-mono font-semibold" style={{ color: "var(--text-tertiary)" }}>{doneCount}</span> done
            </span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="w-48">
          <label
            className="block mb-1.5 font-medium uppercase tracking-[0.04em]"
            style={{ fontSize: "11px", color: "var(--text-tertiary)" }}
          >
            STATE
          </label>
          <Select value={filterState} onChange={e => setFilterState(e.target.value)}>
            <option value="all">All states</option>
            <option value="active">Active (has queued)</option>
            <option value="paused">Paused</option>
            <option value="pending">Pending approval</option>
            <option value="completed">Completed (cycle done)</option>
          </Select>
        </div>
      </div>

      {/* Feedback banner */}
      {feedbackMsg && (
        <div
          className="rounded-lg p-3 text-[13px]"
          style={{
            background: feedbackError ? "var(--danger-muted)" : "var(--success-muted)",
            border: `1px solid ${feedbackError ? "var(--danger-border)" : "var(--success-border)"}`,
            color: feedbackError ? "var(--danger)" : "var(--success)",
          }}
        >
          {feedbackMsg}
        </div>
      )}

      {/* B9b.11: Select-all toggle (visible when threads are listed) */}
      {!isLoading && !isError && filteredThreads.length > 0 && (() => {
        const allVisibleIds = filteredThreads.map(t => t.prospect_id);
        const visibleSelected = allVisibleIds.filter(id => selectedIds.has(id)).length;
        const allSelected = visibleSelected === allVisibleIds.length;
        const someSelected = visibleSelected > 0 && !allSelected;
        const Icon = allSelected ? CheckSquare : someSelected ? MinusSquare : Square;
        const label = allSelected
          ? `Deselect all ${allVisibleIds.length}`
          : someSelected
          ? `${visibleSelected} of ${allVisibleIds.length} selected; select all`
          : `Select all ${allVisibleIds.length} visible`;
        return (
          <button
            type="button"
            onClick={() => {
              if (allSelected) clearSelection();
              else setSelectedIds(new Set(allVisibleIds));
            }}
            className="flex items-center gap-2 text-[12px] font-medium px-2 py-1.5 rounded-md transition-all"
            style={{
              color: visibleSelected > 0 ? "var(--accent)" : "var(--text-secondary)",
              background: visibleSelected > 0 ? "var(--accent-muted)" : "transparent",
              border: `1px solid ${visibleSelected > 0 ? "var(--accent-border)" : "var(--border-default)"}`,
            }}
          >
            <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
            {label}
          </button>
        );
      })()}

      {/* Content */}
      {isError ? (
        <Card className="flex flex-col items-center justify-center h-64 text-center p-8">
          <AlertCircle className="h-6 w-6 mb-3" style={{ color: "var(--danger)" }} />
          <p className="font-medium text-[13px]" style={{ color: "var(--text-primary)" }}>
            Failed to load follow-ups
          </p>
          <p className="text-[13px]" style={{ color: "var(--text-secondary)" }}>
            Check API key or server.
          </p>
        </Card>
      ) : isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <Card key={i} className="h-20 animate-pulse" style={{ background: "var(--bg-tertiary)", opacity: 0.4 }} />
          ))}
        </div>
      ) : filteredThreads.length === 0 ? (
        <Card className="flex flex-col items-center justify-center h-64 text-center p-8" style={{ borderStyle: "dashed" }}>
          <Send className="h-6 w-6 mb-3" style={{ color: "var(--text-tertiary)" }} />
          <p className="font-medium text-[13px]" style={{ color: "var(--text-primary)" }}>
            No AntiGhosting threads found
          </p>
          <p className="text-[13px]" style={{ color: "var(--text-secondary)" }}>
            Adjust filters, or label a Gmail thread with the AntiGhosting label and mark it from the candidates page.
          </p>
        </Card>
      ) : (
        <div className="space-y-2">
          {filteredThreads.map((thread, idx) => {
            const isExpanded = expandedThread === thread.prospect_id;

            return (
              <Card
                key={thread.prospect_id}
                className="overflow-hidden"
                style={{
                  animation: `fadeUp 0.25s ease both`,
                  animationDelay: `${Math.min(idx, 15) * 0.03}s`,
                  borderColor: thread.followup_paused ? "var(--warning-border)" : undefined,
                }}
              >
                {/* ── Thread summary row ── */}
                <div
                  className="flex items-center gap-4 px-4 py-3 cursor-pointer"
                  style={{ minHeight: "56px" }}
                  onClick={() => setExpandedThread(isExpanded ? null : thread.prospect_id)}
                >
                  {/* B9b.11: Selection checkbox */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleSelected(thread.prospect_id);
                    }}
                    className="flex items-center justify-center transition-all"
                    style={{
                      width: "20px",
                      height: "20px",
                      flexShrink: 0,
                      color: selectedIds.has(thread.prospect_id) ? "var(--accent)" : "var(--text-tertiary)",
                    }}
                    aria-label={selectedIds.has(thread.prospect_id) ? "Deselect prospect" : "Select prospect"}
                    title={selectedIds.has(thread.prospect_id) ? "Deselect" : "Select for bulk action"}
                  >
                    {selectedIds.has(thread.prospect_id)
                      ? <CheckSquare className="h-4 w-4" strokeWidth={1.75} />
                      : <Square className="h-4 w-4" strokeWidth={1.5} />}
                  </button>

                  {/* Chevron */}
                  <div style={{ color: "var(--text-tertiary)", flexShrink: 0 }}>
                    {isExpanded
                      ? <ChevronUp className="h-4 w-4" />
                      : <ChevronDown className="h-4 w-4" />}
                  </div>

                  {/* Prospect info */}
                  <div className="min-w-0 flex-1" style={{ maxWidth: "240px" }}>
                    <p className="font-medium text-[13px] truncate" style={{ color: "var(--text-primary)" }}>
                      {thread.prospect_name}
                    </p>
                    <div className="flex items-center gap-2">
                      <p className="text-[12px] truncate" style={{ color: "var(--text-secondary)" }}>
                        {thread.company || thread.email}
                      </p>
                      <span className="text-[10px] font-mono flex-shrink-0" style={{ color: "var(--text-tertiary)" }}>
                        {thread.stages.length > 0 ? new Date(thread.stages[0].created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : ""}
                      </span>
                    </div>
                  </div>

                  {/* Cycle pill */}
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <CyclePill current={thread.current_cycle} total={thread.total_cycles} />
                  </div>

                  {/* Stage progress dots */}
                  <div className="flex-shrink-0">
                    <StageProgress thread={thread} />
                  </div>

                  {/* Stage counter */}
                  <div className="flex-shrink-0 text-[12px] font-mono w-16 text-center" style={{ color: "var(--text-secondary)" }}>
                    {thread.current_stage}/{thread.max_followups}
                  </div>

                  {/* Status / countdown */}
                  <div className="flex-shrink-0 w-48">
                    {thread.next_followup && !thread.followup_paused && !thread.replied && thread.next_followup.status !== "pending_approval" ? (
                      <div className="flex items-center gap-2">
                        <Clock className="h-3 w-3 flex-shrink-0" style={{ color: "var(--text-tertiary)" }} />
                        <CountdownTimer scheduledAt={thread.next_followup.scheduled_at} />
                        <span className="text-[11px]" style={{ color: "var(--text-tertiary)" }}>
                          till F{thread.next_followup.stage}
                        </span>
                      </div>
                    ) : (
                      <StatusSummary thread={thread} />
                    )}
                  </div>

                  {/* Quick actions */}
                  <div className="flex items-center gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
                    {!thread.replied && !thread.all_done && (
                      <Button
                        variant="ghost" size="sm"
                        onClick={() => handleTogglePause(thread.prospect_id, thread.followup_paused)}
                        disabled={togglingPauseId === thread.prospect_id}
                        title={thread.followup_paused ? "Resume followups" : "Stop sending followups"}
                        style={{ color: thread.followup_paused ? "var(--success)" : "var(--danger)" }}
                      >
                        {togglingPauseId === thread.prospect_id
                          ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          : thread.followup_paused
                          ? <Play className="h-3.5 w-3.5" />
                          : <Square className="h-3.5 w-3.5" />}
                      </Button>
                    )}

                    {/* B9b.10: add-stage-now. Hidden when paused — operator must explicitly resume first. */}
                    {!thread.replied && !thread.all_done && !thread.followup_paused && (
                      <Button
                        variant="ghost" size="sm"
                        onClick={() => handleAddStage(thread.prospect_id)}
                        disabled={addingStageId === thread.prospect_id}
                        title="Queue the next stage for immediate dispatch"
                        style={{ color: "var(--accent)" }}
                      >
                        {addingStageId === thread.prospect_id
                          ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          : <Plus className="h-3.5 w-3.5" />}
                      </Button>
                    )}

                    <Button
                      variant="ghost" size="sm"
                      onClick={() => setViewingOriginalFor(thread)}
                      title="View the original email this AntiGhosting campaign is reviving"
                      style={{ color: "var(--text-tertiary)" }}
                    >
                      <MoreHorizontal className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                {/* ── Expanded detail panel ── */}
                {isExpanded && (
                  <div className="px-4 pb-4" style={{ borderTop: "1px solid var(--border-default)" }}>
                    {/* Thread subject */}
                    <div className="pt-3 pb-2 mb-3" style={{ borderBottom: "1px solid var(--border-default)" }}>
                      <span
                        className="font-medium uppercase tracking-[0.04em] block mb-1"
                        style={{ fontSize: "10px", color: "var(--text-tertiary)" }}
                      >
                        SUBJECT
                      </span>
                      <p className="text-[13px]" style={{ color: "var(--text-primary)" }}>
                        {thread.original_subject || "\u2014"}
                      </p>
                      <div className="flex items-center gap-3 mt-1.5">
                        <span className="text-[11px]" style={{ color: "var(--text-tertiary)" }}>
                          {thread.email}
                        </span>
                      </div>
                    </div>

                    {/* Stage list */}
                    <div className="space-y-2">
                      {thread.stages.map(stage => {
                        const isPreviewOpen = expandedPreview === stage.id;
                        const statusColor =
                          stage.status === "sent" ? "var(--success)"
                          : stage.status === "queued" || stage.status === "generating" ? "var(--warning)"
                          : stage.status === "pending_approval" ? "var(--accent)"
                          : stage.status === "failed" ? "var(--danger)"
                          : "var(--text-tertiary)";

                        return (
                          <div key={stage.id}>
                            <div
                              className="flex items-center gap-3 rounded-md px-3 py-2"
                              style={{ background: "var(--bg-tertiary)" }}
                            >
                              <div className="font-mono text-[12px] font-semibold w-8 text-center flex-shrink-0" style={{ color: statusColor }}>
                                F{stage.stage}
                              </div>
                              <div className="flex-shrink-0">
                                <span className="text-[11px] font-semibold uppercase tracking-[0.04em]" style={{ color: statusColor }}>
                                  {stage.status === "pending_approval" ? "PENDING" : stage.status.toUpperCase()}
                                </span>
                              </div>
                              <div className="flex-1 text-[12px]" style={{ color: "var(--text-secondary)" }}>
                                {stage.sent_at ? (
                                  <span className="font-mono">
                                    Sent {format(new Date(stage.sent_at), "MMM d, yyyy HH:mm")}
                                  </span>
                                ) : stage.status === "queued" || stage.status === "generating" ? (
                                  <span className="font-mono">
                                    Scheduled {format(new Date(stage.scheduled_at), "MMM d, yyyy HH:mm")}
                                  </span>
                                ) : stage.status === "pending_approval" ? (
                                  <span className="font-mono">Ready for review</span>
                                ) : (
                                  <span className="font-mono">
                                    {format(new Date(stage.scheduled_at), "MMM d, yyyy HH:mm")}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-1 flex-shrink-0">
                                {(stage.generated_body || stage.generated_subject) && (
                                  <Button
                                    variant="ghost" size="sm"
                                    onClick={() => setExpandedPreview(isPreviewOpen ? null : stage.id)}
                                    style={{ color: "var(--text-tertiary)", padding: "4px 8px" }}
                                  >
                                    {isPreviewOpen ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
                                  </Button>
                                )}
                              </div>
                            </div>

                            {/* Email preview */}
                            {isPreviewOpen && (stage.generated_body || stage.generated_subject) && (
                              <div
                                className="ml-11 mt-1 mb-1 p-3 rounded-md"
                                style={{ background: "var(--bg-elevated)", border: "1px solid var(--border-default)" }}
                              >
                                {stage.generated_subject && (
                                  <div className="mb-2">
                                    <span className="font-medium uppercase tracking-[0.04em] block mb-0.5" style={{ fontSize: "10px", color: "var(--text-tertiary)" }}>SUBJECT</span>
                                    <p className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>{stage.generated_subject}</p>
                                  </div>
                                )}
                                {stage.generated_body && (
                                  <div>
                                    <span className="font-medium uppercase tracking-[0.04em] block mb-0.5" style={{ fontSize: "10px", color: "var(--text-tertiary)" }}>BODY</span>
                                    <div className="text-[12px] leading-relaxed whitespace-pre-wrap" style={{ color: "var(--text-primary)" }}>
                                      {stage.generated_body}
                                    </div>
                                  </div>
                                )}
                                {stage.error_message && (
                                  <div className="mt-2 text-[11px]" style={{ color: "var(--danger)" }}>
                                    Error: {stage.error_message}
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>

                    {/* Detail panel actions (B9b.9 + B9b.10) */}
                    {!thread.replied && !thread.all_done && (
                      <div className="flex items-center gap-2 mt-3 pt-3" style={{ borderTop: "1px solid var(--border-default)" }}>
                        {!thread.followup_paused && (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleAddStage(thread.prospect_id)}
                            disabled={addingStageId === thread.prospect_id}
                            className="gap-1.5" style={{ color: "var(--accent)" }}
                          >
                            {addingStageId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
                            Send next stage now
                          </Button>
                        )}
                        {thread.followup_paused ? (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleTogglePause(thread.prospect_id, true)}
                            disabled={togglingPauseId === thread.prospect_id}
                            className="gap-1.5" style={{ color: "var(--success)" }}
                          >
                            {togglingPauseId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
                            Resume followups
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleTogglePause(thread.prospect_id, false)}
                            disabled={togglingPauseId === thread.prospect_id}
                            className="gap-1.5" style={{ color: "var(--danger)" }}
                          >
                            {togglingPauseId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Square className="h-3.5 w-3.5" />}
                            Stop all followups
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      {viewingOriginalFor && (
        <OriginalEmailModal
          thread={viewingOriginalFor}
          onClose={() => setViewingOriginalFor(null)}
        />
      )}

      {/* B9b.11: Floating bulk-action bar; appears when 1+ rows are selected. */}
      {selectedIds.size > 0 && (
        <div
          className="fixed left-1/2 z-30 flex items-center gap-3 px-4 py-3 rounded-lg shadow-lg"
          style={{
            bottom: "24px",
            transform: "translateX(-50%)",
            background: "var(--bg-elevated)",
            border: "1px solid var(--accent-border)",
            boxShadow: "0 8px 24px rgba(0,0,0,0.4)",
            minWidth: "420px",
          }}
        >
          <span className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>
            <span className="font-mono font-semibold" style={{ color: "var(--accent)" }}>{selectedIds.size}</span>
            {" "}selected
          </span>
          <div className="flex-1" />
          <Button
            size="sm"
            onClick={handleBulkPause}
            disabled={bulkPausing || bulkResuming}
            className="gap-1.5"
            style={{ color: "var(--danger)", borderColor: "var(--danger-border)" }}
          >
            {bulkPausing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Square className="h-3.5 w-3.5" />}
            Pause all
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleBulkResume}
            disabled={bulkPausing || bulkResuming}
            className="gap-1.5"
            style={{ color: "var(--success)", borderColor: "var(--success-border)" }}
          >
            {bulkResuming ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
            Resume all
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={clearSelection}
            disabled={bulkPausing || bulkResuming}
          >
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  OriginalEmailModal                                                 */
/* ------------------------------------------------------------------ */

function OriginalEmailModal({
  thread,
  onClose,
}: {
  thread: EmailThread;
  onClose: () => void;
}) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const gmailUrl = thread.gmail_thread_id
    ? `https://mail.google.com/mail/u/0/#all/${thread.gmail_thread_id}`
    : null;

  const sentLabel = thread.original_sent_at
    ? format(new Date(thread.original_sent_at), "PPP p")
    : null;

  const hasBody = !!(thread.original_body && thread.original_body.trim());
  const hasSummary = !!(thread.original_body_summary && thread.original_body_summary.trim());

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.6)" }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-2xl rounded-lg flex flex-col"
        style={{
          background: "var(--surface-raised)",
          border: "1px solid var(--border-default)",
          maxHeight: "85vh",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div
          className="flex items-center justify-between px-5 py-3"
          style={{ borderBottom: "1px solid var(--border-default)" }}
        >
          <div className="flex items-center gap-2">
            <Mail className="h-4 w-4" style={{ color: "var(--text-tertiary)" }} />
            <span
              className="font-medium uppercase tracking-[0.04em]"
              style={{ fontSize: "11px", color: "var(--text-tertiary)" }}
            >
              ORIGINAL EMAIL
            </span>
          </div>
          <Button
            variant="ghost" size="sm" onClick={onClose}
            style={{ color: "var(--text-tertiary)" }}
            title="Close (Esc)"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Meta */}
        <div className="px-5 py-3" style={{ borderBottom: "1px solid var(--border-default)" }}>
          <div className="grid grid-cols-[80px_1fr] gap-x-3 gap-y-1.5 text-[12px]">
            <span style={{ color: "var(--text-tertiary)" }}>To</span>
            <span style={{ color: "var(--text-primary)" }}>
              {thread.prospect_name && thread.prospect_name !== "Unknown"
                ? `${thread.prospect_name} <${thread.email}>`
                : thread.email}
            </span>
            {thread.company && (
              <>
                <span style={{ color: "var(--text-tertiary)" }}>Company</span>
                <span style={{ color: "var(--text-primary)" }}>{thread.company}</span>
              </>
            )}
            {sentLabel && (
              <>
                <span style={{ color: "var(--text-tertiary)" }}>Sent</span>
                <span style={{ color: "var(--text-primary)" }}>{sentLabel}</span>
              </>
            )}
            <span style={{ color: "var(--text-tertiary)" }}>Subject</span>
            <span className="font-medium" style={{ color: "var(--text-primary)" }}>
              {thread.original_subject || "\u2014"}
            </span>
          </div>
        </div>

        {/* Body */}
        <div className="px-5 py-4 overflow-y-auto flex-1">
          {hasBody ? (
            <pre
              className="whitespace-pre-wrap font-sans text-[13px] leading-relaxed"
              style={{ color: "var(--text-primary)", margin: 0 }}
            >
              {thread.original_body}
            </pre>
          ) : hasSummary ? (
            <div>
              <p
                className="text-[11px] uppercase tracking-[0.04em] mb-2"
                style={{ color: "var(--text-tertiary)" }}
              >
                TOPIC SUMMARY (full body not captured for this prospect)
              </p>
              <p className="text-[13px] leading-relaxed" style={{ color: "var(--text-primary)" }}>
                {thread.original_body_summary}
              </p>
            </div>
          ) : (
            <p
              className="text-[12px] italic"
              style={{ color: "var(--text-tertiary)" }}
            >
              Original email content is not available for this prospect. It was synced before body capture was enabled.
              {gmailUrl && " You can open the thread in Gmail using the link below."}
            </p>
          )}
        </div>

        {/* Footer */}
        {gmailUrl && (
          <div
            className="px-5 py-3 flex justify-end"
            style={{ borderTop: "1px solid var(--border-default)" }}
          >
            <a
              href={gmailUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 text-[12px] font-medium"
              style={{ color: "var(--accent)" }}
            >
              Open in Gmail
              <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
'''

# ---- Backend anchors ----

IMPORT_OLD = 'import { and, asc, desc, eq, sql } from "drizzle-orm";'
IMPORT_NEW = 'import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";'

EXPORT_ANCHOR = "export default router;"
PAUSE_BULK_MARKER = "B9b.11: POST /api/anti-ghosting/prospect/pause-bulk"
RESUME_BULK_MARKER = "B9b.11: POST /api/anti-ghosting/prospect/resume-bulk"

PAUSE_BULK_HANDLER = '''
// ====================================================================
// B9b.11: POST /api/anti-ghosting/prospect/pause-bulk
// ====================================================================
// Mirrors /api/context/prospect/pause-bulk with SCOPE=anti_ghosting.
// Restricts the operation to AG prospects, sets followupPaused=true on
// each, and cancels any currently active (queued/generating/drafted)
// follow-ups via the shared scheduler helper.
router.post("/prospect/pause-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }

  try {
    const SCOPE = eq(prospectsTable.app, "anti_ghosting");

    const eligible = await db
      .select({ id: prospectsTable.id })
      .from(prospectsTable)
      .where(and(SCOPE, inArray(prospectsTable.id, ids)));
    const eligibleIds = eligible.map((r) => r.id);

    if (eligibleIds.length === 0) {
      res.json({
        success: true,
        total: ids.length,
        paused: 0,
        cancelled_queued: 0,
        sent_prospect_ids: [],
      });
      return;
    }

    await db
      .update(prospectsTable)
      .set({ followupPaused: true })
      .where(and(SCOPE, inArray(prospectsTable.id, eligibleIds)));

    const { cancelActiveFollowupsForProspects } = await import("../services/scheduler");
    const cancelled = await cancelActiveFollowupsForProspects(
      eligibleIds,
      "Bulk pause from AntiGhosting UI.",
    );

    logger.info(
      { totalRequested: ids.length, paused: eligibleIds.length, cancelled },
      "AG bulk pause completed",
    );

    res.json({
      success: true,
      total: ids.length,
      paused: eligibleIds.length,
      cancelled_queued: cancelled,
      sent_prospect_ids: eligibleIds,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "POST /anti-ghosting/prospect/pause-bulk failed");
    res.status(500).json({ error: msg });
  }
});

'''

RESUME_BULK_HANDLER = '''
// ====================================================================
// B9b.11: POST /api/anti-ghosting/prospect/resume-bulk
// ====================================================================
// No direct context analog. Resumes paused AG prospects in bulk:
//   - Filters to AG + non-replied prospects.
//   - Sets followupPaused=false on those.
//   - For each, computes nextStage from sent stages in the current cycle.
//   - Queues a new follow-up at scheduledAt = NOW + 7d (matching the
//     per-prospect resume cadence in B9b.9 v2).
//   - try/catch around each INSERT swallows UNIQUE collisions
//     (cancelled rows from a prior pause occupying the slot) so the
//     bulk operation doesn't bail on the first conflict.
router.post("/prospect/resume-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }

  try {
    const SCOPE = eq(prospectsTable.app, "anti_ghosting");
    const MAX_AG_STAGES_PER_CYCLE = 3;
    const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

    // Pull candidate prospects (AG-scoped). Filter replied in JS so the
    // query works regardless of whether `replied` is integer (0/1) or
    // boolean in Drizzle's mapping.
    const candidates = await db
      .select({
        id: prospectsTable.id,
        cycle: prospectsTable.cycle,
        replied: prospectsTable.replied,
      })
      .from(prospectsTable)
      .where(and(SCOPE, inArray(prospectsTable.id, ids)));

    const eligible = candidates.filter((p) => !p.replied);
    const eligibleIds = eligible.map((p) => p.id);

    if (eligibleIds.length === 0) {
      res.json({
        success: true,
        total: ids.length,
        resumed: 0,
        queued: 0,
        skipped_replied: candidates.length,
      });
      return;
    }

    // Unpause all eligible prospects in one UPDATE.
    await db
      .update(prospectsTable)
      .set({ followupPaused: false })
      .where(and(SCOPE, inArray(prospectsTable.id, eligibleIds)));

    // Per prospect: compute nextStage and queue. Per-prospect
    // try/catch isolates UNIQUE collisions so one bad slot doesn't
    // abort the whole batch.
    let queuedCount = 0;
    let cycleCompleteCount = 0;
    let collisionCount = 0;

    for (const prospect of eligible) {
      const currentCycle = prospect.cycle ?? 1;

      const sentRows = await db
        .select({ stage: followupsTable.stage })
        .from(followupsTable)
        .where(and(
          eq(followupsTable.prospectId, prospect.id),
          eq(followupsTable.cycle, currentCycle),
          eq(followupsTable.status, "sent"),
        ));

      const sentStages = sentRows.map((r) => r.stage);
      const nextStage = sentStages.length > 0 ? Math.max(...sentStages) + 1 : 1;

      if (nextStage > MAX_AG_STAGES_PER_CYCLE) {
        cycleCompleteCount++;
        continue;
      }

      try {
        await db.insert(followupsTable).values({
          prospectId: prospect.id,
          stage: nextStage,
          cycle: currentCycle,
          status: "queued",
          scheduledAt: new Date(Date.now() + SEVEN_DAYS_MS),
        });
        queuedCount++;
      } catch (insertErr) {
        collisionCount++;
        logger.warn(
          { err: insertErr, prospectId: prospect.id, nextStage, currentCycle },
          "AG resume-bulk INSERT collided with existing row",
        );
      }
    }

    logger.info(
      {
        totalRequested: ids.length,
        eligible: eligibleIds.length,
        queued: queuedCount,
        cycleComplete: cycleCompleteCount,
        collisions: collisionCount,
      },
      "AG bulk resume completed",
    );

    res.json({
      success: true,
      total: ids.length,
      resumed: eligibleIds.length,
      queued: queuedCount,
      cycle_complete: cycleCompleteCount,
      collisions: collisionCount,
      skipped_replied: candidates.length - eligibleIds.length,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "POST /anti-ghosting/prospect/resume-bulk failed");
    res.status(500).json({ error: msg });
  }
});

'''


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def info(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker=None):
    check = marker if marker is not None else new
    if check in text:
        skip(f"{label} already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found: {old[:80]!r}")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    info(f"{label}: updated")
    return text.replace(old, new, 1), True


def insert_before_unique(text, anchor, insert, label, marker):
    if marker in text:
        skip(f"{label} already present")
        return text, False
    count = text.count(anchor)
    if count == 0:
        fail(f"{label}: anchor not found: {anchor!r}")
    info(f"{label}: inserted")
    return text.replace(anchor, insert.lstrip("\n") + "\n" + anchor, 1), True


def patch_backend():
    if not BACKEND.exists():
        fail(f"backend not found: {BACKEND}")
    text = BACKEND.read_text(encoding="utf-8")
    original = text

    # 1. Extend drizzle-orm import.
    text, _ = replace_unique(text, IMPORT_OLD, IMPORT_NEW, "drizzle-orm import (inArray)")

    # 2. Insert pause-bulk handler.
    text, _ = insert_before_unique(
        text, EXPORT_ANCHOR, PAUSE_BULK_HANDLER, "pause-bulk handler",
        marker=PAUSE_BULK_MARKER,
    )

    # 3. Insert resume-bulk handler.
    text, _ = insert_before_unique(
        text, EXPORT_ANCHOR, RESUME_BULK_HANDLER, "resume-bulk handler",
        marker=RESUME_BULK_MARKER,
    )

    if text != original:
        BACKEND.write_text(text, encoding="utf-8")
        info(f"wrote {BACKEND.relative_to(WORKSPACE)}")
    else:
        skip("backend already patched")


def patch_frontend():
    if not FRONTEND.parent.exists():
        fail(f"dashboard pages dir does not exist: {FRONTEND.parent}")
    if FRONTEND.exists() and FRONTEND.read_text(encoding="utf-8") == TSX_CONTENT:
        skip(f"{FRONTEND.relative_to(WORKSPACE)} already matches")
        return
    action = "overwrote" if FRONTEND.exists() else "created"
    FRONTEND.write_text(TSX_CONTENT, encoding="utf-8")
    info(f"{action} {FRONTEND.relative_to(WORKSPACE)}")


def main():
    patch_backend()
    patch_frontend()
    print()
    print("B9b.11 bulk pause/resume applied.")


if __name__ == "__main__":
    main()
