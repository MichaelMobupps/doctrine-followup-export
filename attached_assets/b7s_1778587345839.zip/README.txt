B7s — admin activity rollup endpoint for Email Followuper
==========================================================

Adds `GET /api/admin/activity` — a read-only rollup of the
`followup_usage` table that B7r populates. Mirrors the Email
Prospector's `/admin/activity` shape, adapted for the Followuper's
event-based attribution model.

Files written (1 new):
  - artifacts/api-server/src/routes/admin-activity.ts

Files patched (1):
  - artifacts/api-server/src/routes/index.ts (import + mount)

Endpoint shape:
  GET /api/admin/activity
    Auth: X-API-Key (same as /admin/salvage, /admin/digest/*)
    Query params (all optional):
      user_id  — restrict to one user
      app      — "doctrine" | "context"
      since    — ISO timestamp; default = now - 7 days
      until    — ISO timestamp; default = now
    Response:
      window, filter, active_generations, totals (window-level),
      users (filter-list), user_totals (per-user with by_app/by_stage/by_model),
      events (most recent 200 with user+prospect join)

Safety:
  - Read-only: no writes, no side effects, no migration
  - Auth-gated: X-API-Key required
  - Hardened against bad query params (invalid dates → default window)
  - Empty table returns clean zeros, not 500

---

PROMPT FOR THE REPLIT AGENT
---------------------------

> Apply the b7s patch from ~/b7s.zip.
>
> Step 1: run this single bash block in the shell, exactly as-is:
>
> ```
> set -e
> cd ~/workspace
> rm -rf /tmp/b7s && mkdir -p /tmp/b7s
> unzip -o ~/b7s.zip -d /tmp/b7s
> node /tmp/b7s/apply-b7s.mjs
> ./source-code/sync.sh
> pnpm --filter @workspace/api-server run build
> echo "B7s applied. Ready to restart the workflow."
> ```
>
> Step 2: restart the api-server workflow.
>
> Step 3: wait until the server logs "Server listening port: 8080".
>
> Step 4: smoke-test the new endpoint locally with this curl. The
> command must return HTTP 200 and a JSON body. Show me the response
> (truncate `events` to 3 if long):
>
> ```
> curl -s -H "X-API-Key: $ADDON_API_KEY" http://localhost:8080/api/admin/activity | head -c 4000
> ```
>
> Do not do anything else. Do not edit any files. Do not modify
> the bash block. Paste the exact output back to me.

---

POST-DEPLOY VERIFICATION (production)
-------------------------------------

After deploy, hit the production endpoint:

```
curl -s -H "X-API-Key: $ADDON_API_KEY" \
  "https://doctrine-followupv-2.replit.app/api/admin/activity" \
  | head -c 4000
```

What "good" looks like:
  - HTTP 200
  - `window.since` is about 7 days ago, `window.until` is now
  - `totals.cost_usd` is a number (likely small while only the
    Send-Now test row exists; will grow as cron-driven generation
    fills the table)
  - `user_totals[]` has one entry for userId=2 (your Send-Now test)
  - `events[]` has the same 2 rows you already saw in the table
  - `active_generations` is 0 (no row currently in "generating" status)

Filter examples:
  ?user_id=2              # only Michael's events
  ?app=context            # only Context-based follow-ups
  ?since=2026-05-12T00:00:00Z  # only today

If everything looks right, we move to B7t — the dashboard page that
reads from this endpoint and renders the per-user table + event ledger
that Prospector's Activity Log shows today.
