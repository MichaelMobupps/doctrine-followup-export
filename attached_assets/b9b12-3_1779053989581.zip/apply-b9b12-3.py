#!/usr/bin/env python3
"""
B9b.12.3 - AG send-now full parity with Doctrine.

Backend (anti-ghosting.ts):
  A1: Rewrite /followup-now/:id to mirror Doctrine — drop replied/
      paused/active-stage/cycle-complete defenses, use aggressive
      retry loop bumping stage on UNIQUE collision, force-send via
      processDueFollowups({forceSend: true}).
  A2: Add /followup/send-bulk endpoint mirroring Doctrine's pattern
      (25-cap, per-prospect loop, returns {sent, failed[], total}).

Frontend (anti-ghosting-pipeline.tsx):
  F1: Remove conditional wrapper on inline row + button (always visible).
  F2: Restructure detail panel — Send-now always visible, pause/resume
      individually state-gated (mirrors Doctrine's pattern).
  F3: Add bulkSending state after bulkResuming.
  F4: Add handleBulkSend function before handleBulkPause.
  F5: Rewrite bulk action bar — insert Send all button first, all
      existing buttons' disabled prop now includes bulkSending.

Behavior change: + button always visible regardless of replied/paused/
all_done state. Backend force-sends. Matches Doctrine exactly.

Idempotent. All anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ROUTE = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"
PIPELINE = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-pipeline.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# BACKEND
# ====================================================================

# A1: Replace /followup-now/:id entire function body
A1_OLD = '''router.post("/followup-now/:id", async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "invalid prospect id" });
    return;
  }

  try {
    const [prospect] = await db
      .select()
      .from(prospectsTable)
      .where(and(eq(prospectsTable.id, id), eq(prospectsTable.app, "anti_ghosting")))
      .limit(1);

    if (!prospect) {
      res.status(404).json({ error: "anti_ghosting prospect not found" });
      return;
    }
    if (prospect.replied) {
      res.status(400).json({ error: "Prospect already replied" });
      return;
    }
    if (prospect.followupPaused) {
      res.status(400).json({
        error: "Campaign is paused. Resume the campaign first before queueing the next stage.",
      });
      return;
    }

    const currentCycle = prospect.cycle ?? 1;
    const MAX_AG_STAGES_PER_CYCLE = 3;

    const existingFollowups = await db
      .select({ stage: followupsTable.stage, status: followupsTable.status })
      .from(followupsTable)
      .where(and(
        eq(followupsTable.prospectId, id),
        eq(followupsTable.cycle, currentCycle),
      ));

    const sentStages = existingFollowups.filter(f => f.status === "sent").map(f => f.stage);
    const activeStages = existingFollowups
      .filter(f => ["queued", "generating", "pending_approval", "drafted"].includes(f.status))
      .sort((a, b) => a.stage - b.stage);

    if (activeStages.length > 0) {
      res.status(400).json({
        error: `A stage is already active (F${activeStages[0].stage}, ${activeStages[0].status}). Cancel it first or wait for it to send.`,
      });
      return;
    }

    const nextStage = sentStages.length > 0 ? Math.max(...sentStages) + 1 : 1;

    if (nextStage > MAX_AG_STAGES_PER_CYCLE) {
      res.status(400).json({
        error: "Cycle complete (3/3 stages sent). Re-mark the thread in Gmail to start a new cycle.",
      });
      return;
    }

    // scheduledAt = NOW. Dispatcher cron will fire within ~15 min.
    const scheduledAt = new Date();

    try {
      await db.insert(followupsTable).values({
        prospectId: id,
        stage: nextStage,
        cycle: currentCycle,
        status: "queued",
        scheduledAt,
      });
      logger.info({ prospectId: id, stage: nextStage }, "AG add-stage-now queued");
      res.json({
        success: true,
        queued_stage: nextStage,
        message: `F${nextStage} queued for immediate dispatch`,
      });
    } catch (insertErr) {
      // UNIQUE collision on (prospect_id, cycle, stage). Same swallow
      // pattern as resume \u2014 log and return informative response so the
      // operator can see something needs reconciling.
      logger.warn({ err: insertErr, prospectId: id, nextStage, currentCycle },
        "AG followup-now INSERT collided with existing row");
      res.status(409).json({
        error: `Stage F${nextStage} slot is occupied by an existing row (likely a cancelled row from a prior pause). The dispatcher cron should reconcile within 15 min; if not, contact support.`,
      });
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err, prospectId: id }, "POST /anti-ghosting/followup-now/:id failed");
    res.status(500).json({ error: msg });
  }
});'''

A1_NEW = '''// B9b.12.3: rewritten to mirror Doctrine's /followup-now exactly.
// Defense-in-depth checks (replied/paused/cycle-complete) removed; the
// + button is the user's explicit override and force-sends regardless.
// Aggressive retry bumps stage on UNIQUE collision so stale cancelled
// rows from prior pauses don't wedge us.
router.post("/followup-now/:id", async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "invalid prospect id" });
    return;
  }

  try {
    const [prospect] = await db
      .select()
      .from(prospectsTable)
      .where(and(eq(prospectsTable.id, id), eq(prospectsTable.app, "anti_ghosting")))
      .limit(1);

    if (!prospect) {
      res.status(404).json({ error: "anti_ghosting prospect not found" });
      return;
    }
    if (!prospect.userId) {
      res.status(400).json({ error: "Prospect has no associated user" });
      return;
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, prospect.userId))
      .limit(1);
    if (!user?.googleRefreshToken || !user?.isConnected) {
      res.status(400).json({ error: "User Gmail not connected" });
      return;
    }

    const currentCycle = prospect.cycle ?? 1;
    const now = new Date();

    const allFollowups = await db
      .select({ stage: followupsTable.stage })
      .from(followupsTable)
      .where(and(
        eq(followupsTable.prospectId, id),
        eq(followupsTable.cycle, currentCycle),
      ));

    let nextStage = allFollowups.length > 0
      ? Math.max(...allFollowups.map(f => f.stage)) + 1
      : 1;

    let insertedFollowupId: number | null = null;
    const MAX_ATTEMPTS = 50;
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      const inserted = await db
        .insert(followupsTable)
        .values({
          prospectId: id,
          stage: nextStage,
          cycle: currentCycle,
          status: "queued",
          scheduledAt: now,
        })
        .onConflictDoNothing()
        .returning({ id: followupsTable.id });

      if (inserted[0]?.id) {
        insertedFollowupId = inserted[0].id;
        break;
      }
      nextStage++;
    }

    if (!insertedFollowupId) {
      res.status(500).json({
        error: `Could not reserve a follow-up stage after ${MAX_ATTEMPTS} attempts. Please retry.`,
      });
      return;
    }

    const { processDueFollowups } = await import("../services/scheduler");
    const result = await processDueFollowups({ followupId: insertedFollowupId, forceSend: true });

    logger.info(
      { prospectId: id, stage: nextStage, sent: result.sent, failed: result.failed },
      "AG followup-now processed",
    );

    res.json({
      success: true,
      queued_stage: nextStage,
      sent: result.sent,
      failed: result.failed,
      message: `F${nextStage} dispatched`,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err, prospectId: id }, "POST /anti-ghosting/followup-now/:id failed");
    res.status(500).json({ error: msg });
  }
});

// B9b.12.3: bulk send-now mirroring Doctrine's /followup/send-bulk.
// Same 25-prospect cap, same per-row retry logic, same response shape.
router.post("/followup/send-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }
  if (ids.length > 25) {
    res.status(400).json({ error: "Bulk send limited to 25 prospects per call" });
    return;
  }

  const { processDueFollowups } = await import("../services/scheduler");
  const sent: number[] = [];
  const failed: Array<{ prospectId: number; error: string }> = [];

  for (const prospectId of ids) {
    try {
      const [prospect] = await db
        .select()
        .from(prospectsTable)
        .where(and(eq(prospectsTable.id, prospectId), eq(prospectsTable.app, "anti_ghosting")))
        .limit(1);
      if (!prospect) { failed.push({ prospectId, error: "prospect not found" }); continue; }
      if (!prospect.userId) { failed.push({ prospectId, error: "prospect has no associated user" }); continue; }

      const [user] = await db
        .select()
        .from(usersTable)
        .where(eq(usersTable.id, prospect.userId))
        .limit(1);
      if (!user?.googleRefreshToken || !user?.isConnected) {
        failed.push({ prospectId, error: "user Gmail not connected" });
        continue;
      }

      const currentCycle = prospect.cycle ?? 1;
      const allFollowups = await db
        .select({ stage: followupsTable.stage })
        .from(followupsTable)
        .where(and(
          eq(followupsTable.prospectId, prospectId),
          eq(followupsTable.cycle, currentCycle),
        ));

      let nextStage = allFollowups.length > 0
        ? Math.max(...allFollowups.map(f => f.stage)) + 1
        : 1;

      let insertedFollowupId: number | null = null;
      const MAX_ATTEMPTS = 50;
      for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
        const inserted = await db
          .insert(followupsTable)
          .values({
            prospectId,
            stage: nextStage,
            cycle: currentCycle,
            status: "queued",
            scheduledAt: new Date(),
          })
          .onConflictDoNothing()
          .returning({ id: followupsTable.id });

        if (inserted[0]?.id) { insertedFollowupId = inserted[0].id; break; }
        nextStage++;
      }

      if (!insertedFollowupId) {
        failed.push({ prospectId, error: "could not reserve a stage after 50 attempts" });
        continue;
      }

      const result = await processDueFollowups({ followupId: insertedFollowupId, forceSend: true });
      if (result.sent > 0) {
        sent.push(prospectId);
      } else if (result.failed > 0) {
        failed.push({ prospectId, error: "send failed in scheduler" });
      } else {
        // Followup got reserved + queued but processDueFollowups didn't act
        // on it (e.g. claimed by another worker). Treat as queued.
        sent.push(prospectId);
      }
    } catch (err) {
      failed.push({
        prospectId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  res.json({ sent: sent.length, failed, total: ids.length });
});'''


# ====================================================================
# FRONTEND
# ====================================================================

# F1: Inline row + button — remove !replied && !all_done && !paused wrapper
F1_OLD = '''                    {/* B9b.10: add-stage-now. Hidden when paused \u2014 operator must explicitly resume first. */}
                    {!thread.replied && !thread.all_done && !thread.followup_paused && (
                      <Button
                        variant="ghost" size="sm"
                        onClick={() => handleAddStage(thread.prospect_id)}
                        disabled={addingStageId === thread.prospect_id}
                        title="Queue the next stage for immediate dispatch"
                        style={{ color: "var(--accent)" }}
                      >
                        {addingStageId === thread.prospect_id
                          ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          : <Plus className="h-3.5 w-3.5" />}
                      </Button>
                    )}'''

F1_NEW = '''                    {/* B9b.12.3: + always visible (mirrors Doctrine). Backend force-sends regardless of state. */}
                    <Button
                      variant="ghost" size="sm"
                      onClick={() => handleAddStage(thread.prospect_id)}
                      disabled={addingStageId === thread.prospect_id}
                      title="Add and send next stage now"
                      style={{ color: "var(--accent)" }}
                    >
                      {addingStageId === thread.prospect_id
                        ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                        : <Plus className="h-3.5 w-3.5" />}
                    </Button>'''


# F2: Detail panel — restructure (send-now always; pause/resume state-gated)
F2_OLD = '''                    {/* Detail panel actions (B9b.9 + B9b.10) */}
                    {!thread.replied && !thread.all_done && (
                      <div className="flex items-center gap-2 mt-3 pt-3" style={{ borderTop: "1px solid var(--border-default)" }}>
                        {!thread.followup_paused && (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleAddStage(thread.prospect_id)}
                            disabled={addingStageId === thread.prospect_id}
                            className="gap-1.5" style={{ color: "var(--accent)" }}
                          >
                            {addingStageId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
                            Send next stage now
                          </Button>
                        )}
                        {thread.followup_paused ? (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleTogglePause(thread.prospect_id, true)}
                            disabled={togglingPauseId === thread.prospect_id}
                            className="gap-1.5" style={{ color: "var(--success)" }}
                          >
                            {togglingPauseId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
                            Resume followups
                          </Button>
                        ) : (
                          <Button
                            variant="ghost" size="sm"
                            onClick={() => handleTogglePause(thread.prospect_id, false)}
                            disabled={togglingPauseId === thread.prospect_id}
                            className="gap-1.5" style={{ color: "var(--danger)" }}
                          >
                            {togglingPauseId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Square className="h-3.5 w-3.5" />}
                            Stop all followups
                          </Button>
                        )}
                      </div>
                    )}'''

F2_NEW = '''                    {/* B9b.12.3: detail panel \u2014 Send-now always visible, pause/resume state-gated (mirrors Doctrine). */}
                    <div className="flex items-center gap-2 mt-3 pt-3" style={{ borderTop: "1px solid var(--border-default)" }}>
                      <Button
                        variant="ghost" size="sm"
                        onClick={() => handleAddStage(thread.prospect_id)}
                        disabled={addingStageId === thread.prospect_id}
                        className="gap-1.5" style={{ color: "var(--accent)" }}
                      >
                        {addingStageId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
                        Send next stage now
                      </Button>
                      {!thread.replied && !thread.followup_paused && (
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => handleTogglePause(thread.prospect_id, false)}
                          disabled={togglingPauseId === thread.prospect_id}
                          className="gap-1.5" style={{ color: "var(--danger)" }}
                        >
                          {togglingPauseId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Square className="h-3.5 w-3.5" />}
                          Stop all followups
                        </Button>
                      )}
                      {thread.followup_paused && !thread.replied && (
                        <Button
                          variant="ghost" size="sm"
                          onClick={() => handleTogglePause(thread.prospect_id, true)}
                          disabled={togglingPauseId === thread.prospect_id}
                          className="gap-1.5" style={{ color: "var(--success)" }}
                        >
                          {togglingPauseId === thread.prospect_id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
                          Resume followups
                        </Button>
                      )}
                    </div>'''


# F3: bulkSending state
F3_OLD = '''  const [bulkResuming, setBulkResuming] = useState(false);'''

F3_NEW = '''  const [bulkResuming, setBulkResuming] = useState(false);
  // B9b.12.3: bulk send-now state.
  const [bulkSending, setBulkSending] = useState(false);'''


# F4: handleBulkSend function (insert before handleBulkPause)
F4_OLD = '''  async function handleBulkPause() {'''

F4_NEW = '''  // B9b.12.3: bulk send-now mirroring Doctrine. Calls /followup/send-bulk.
  async function handleBulkSend() {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm(`Send next-stage follow-up now for ${ids.length} prospect${ids.length !== 1 ? "s" : ""}? This bypasses the schedule.`)) return;
    setBulkSending(true);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(`${base}api/anti-ghosting/followup/send-bulk`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
        body: JSON.stringify({ prospectIds: ids }),
      });
      const data = await res.json();
      if (!res.ok) {
        showFeedback(data.error || "Bulk send failed", true);
        return;
      }
      const failedCount = Array.isArray(data.failed) ? data.failed.length : 0;
      const sentCount = data.sent || 0;
      const summary = failedCount > 0
        ? `Sent ${sentCount} of ${data.total}; ${failedCount} failed`
        : `Sent ${sentCount} of ${data.total}`;
      showFeedback(summary, failedCount > 0);
      clearSelection();
      invalidateAll();
    } catch (err: any) {
      showFeedback(err.message || "Bulk send failed", true);
    } finally {
      setBulkSending(false);
    }
  }

  async function handleBulkPause() {'''


# F5: Bulk bar — replace entire block with Send all + updated disabled props
F5_OLD = '''          <Button
            size="sm"
            onClick={handleBulkPause}
            disabled={bulkPausing || bulkResuming}
            className="gap-1.5"
            style={{ color: "var(--danger)", borderColor: "var(--danger-border)" }}
          >
            {bulkPausing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Square className="h-3.5 w-3.5" />}
            Pause all
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleBulkResume}
            disabled={bulkPausing || bulkResuming}
            className="gap-1.5"
            style={{ color: "var(--success)", borderColor: "var(--success-border)" }}
          >
            {bulkResuming ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
            Resume all
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={clearSelection}
            disabled={bulkPausing || bulkResuming}
          >
            <X className="h-3.5 w-3.5" />
          </Button>'''

F5_NEW = '''          {/* B9b.12.3: Send all button + updated disabled props on existing buttons. */}
          <Button
            size="sm"
            onClick={handleBulkSend}
            disabled={bulkSending || bulkPausing || bulkResuming}
            className="gap-1.5"
          >
            {bulkSending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
            Send all
          </Button>
          <Button
            size="sm"
            onClick={handleBulkPause}
            disabled={bulkPausing || bulkResuming || bulkSending}
            className="gap-1.5"
            style={{ color: "var(--danger)", borderColor: "var(--danger-border)" }}
          >
            {bulkPausing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Square className="h-3.5 w-3.5" />}
            Pause all
          </Button>
          <Button
            size="sm"
            variant="secondary"
            onClick={handleBulkResume}
            disabled={bulkPausing || bulkResuming || bulkSending}
            className="gap-1.5"
            style={{ color: "var(--success)", borderColor: "var(--success-border)" }}
          >
            {bulkResuming ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
            Resume all
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={clearSelection}
            disabled={bulkPausing || bulkResuming || bulkSending}
          >
            <X className="h-3.5 w-3.5" />
          </Button>'''


def patch_route():
    if not ROUTE.exists():
        fail(f"route not found: {ROUTE}")
    text = ROUTE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "rewrite /followup-now + insert /followup/send-bulk",
        marker="B9b.12.3: rewritten to mirror Doctrine",
    )

    if text != original:
        ROUTE.write_text(text, encoding="utf-8")
        ok(f"wrote {ROUTE.relative_to(WORKSPACE)}")
    else:
        skip("route already patched")


def patch_pipeline():
    if not PIPELINE.exists():
        fail(f"pipeline not found: {PIPELINE}")
    text = PIPELINE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, F1_OLD, F1_NEW,
        "inline row + button always visible",
        marker="B9b.12.3: + always visible (mirrors Doctrine)",
    )

    text, _ = replace_unique(
        text, F2_OLD, F2_NEW,
        "detail panel restructure",
        marker="B9b.12.3: detail panel",
    )

    text, _ = replace_unique(
        text, F3_OLD, F3_NEW,
        "add bulkSending state",
        marker="B9b.12.3: bulk send-now state",
    )

    text, _ = replace_unique(
        text, F4_OLD, F4_NEW,
        "add handleBulkSend function",
        marker="B9b.12.3: bulk send-now mirroring Doctrine. Calls",
    )

    text, _ = replace_unique(
        text, F5_OLD, F5_NEW,
        "bulk bar — add Send all + update disabled props",
        marker="B9b.12.3: Send all button + updated disabled props",
    )

    if text != original:
        PIPELINE.write_text(text, encoding="utf-8")
        ok(f"wrote {PIPELINE.relative_to(WORKSPACE)}")
    else:
        skip("pipeline already patched")


def main():
    patch_route()
    patch_pipeline()
    print()
    print("B9b.12.3 send-now full parity applied.")


if __name__ == "__main__":
    main()
