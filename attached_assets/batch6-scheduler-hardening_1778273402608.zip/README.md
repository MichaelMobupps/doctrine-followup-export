# Batch 6 — Scheduler hardening

## What this batch does

Closes the four spam-reputation gaps identified in the May 8 audit:

**A. Per-user send rate limiter.** Before each cron-driven send, count the
user's followups with status='sent' in the last hour and last 24 hours. If
either cap is hit, defer the row (status stays 'queued') to the next tick.
Caps are env-driven, defaults safe for free Gmail:

- `DOCTRINE_HOURLY_SEND_CAP` default 30
- `DOCTRINE_DAILY_SEND_CAP` default 200

For Workspace accounts (~2000/day actual limit) you can bump to ~60/h, ~1500/d
via Replit Secrets without a redeploy.

**B. Send-window enforcement at SEND time.** Until now, `sendDays` and
`sendHourStart..End` were only honored at scheduling time. If a row's
`scheduledAt` was inside-window but the cron didn't actually fire it until
out-of-window (clock drift, deploy backlog, missed tick), the row fired
anyway. Phase 6 adds a check after user fetch and before the atomic claim:
if `now` is outside the user's window, defer the row.

**C. Bulk Send-Now cap 100 → 25.** Bulk Send uses `forceSend=true` per row,
which bypasses the rate limiter — so the call-level cap is the only ceiling
on burst volume. Lowered to 25 to keep one-call bursts under Gmail's
intermittent-burst tolerance.

**D. Input validation.** PUT `/api/gmail/accounts/:id/settings` now rejects:
- `sendDays: []` — must contain at least one valid day
- `sendHourEnd <= sendHourStart` — must form a non-empty interval

Both return 400 with a clear error message instead of silently letting the
bad config through.

**E. UTC pin at boot + UTC variants in timing math.** `index.ts` sets
`process.env.TZ = "UTC"` before any module imports and asserts the resolved
Intl timezone is UTC. `timingEngine.ts` switched all clock math to
`setUTCHours/getUTCDay/setUTCDate` so behavior is timezone-free regardless
of host configuration.

**Cleanup.** Glob-removes any `*.batch*.bak` file under api-server. Catches
the `routes/doctrine.ts.batch3b.bak` that Batch 4's hardcoded list missed,
and any future stragglers.

## What this batch does NOT do

- **Does not change forceSend semantics.** Single-prospect Send Now still
  bypasses both the window and the rate limiter — it's an explicit user
  action, treated as trusted. The bulk endpoint also uses forceSend per
  row, but is rate-limited via the call cap (gap C).
- **Does not add per-user customizable caps.** Caps are env-var defaults
  applied to all users. Per-user override (e.g. `users.daily_send_cap`
  column) is a follow-up if you want it.
- **Does not surface budget state in the UI.** The data is queryable via
  the existing followups table; a `GET /api/doctrine/rate-limit-status/:userId`
  endpoint can be added later to show "Today: 47/200 sent" in the Activity
  Log.
- **Does not change the cron cadence.** The 5 existing crons are
  untouched. Audit PASS 7 verifies all 5 schedule strings still resolve.

## Files in this bundle

| File | Purpose |
|---|---|
| `apply-batch6.mjs` | Code patch: 9 idempotent str_replace operations + 2 payload installs + glob cleanup + 12 self-verifies. |
| `audit-batch6.mjs` | Beautiful-Squidward harness: 3 rounds × 9 passes = 117 assertions. |
| `payload/lib/sendBudget.ts` | NEW. `checkSendBudget({userId})` reads followups counts and gates against env caps. |
| `payload/lib/scheduleWindow.ts` | NEW. `isInSendWindow(user, now)` UTC-explicit window check. |

No DB migration. No new packages. No schema changes.

## Operating defaults baked in

- `API_BASE = artifacts/api-server/src`
- No DB build step (db package has no build script).
- Dashboard untouched by this batch but agents may build it anyway —
  harmless.

## Manual verification after deploy

```bash
# 1. Confirm the two new lib files exist
ls -la artifacts/api-server/src/lib/sendBudget.ts \
       artifacts/api-server/src/lib/scheduleWindow.ts

# 2. Confirm UTC pin is on the very first lines of index.ts
head -20 artifacts/api-server/src/index.ts | grep "TZ"
# expect: process.env.TZ = "UTC";

# 3. Boot log should still show the same 5-cron line as before
# (Batch 6 does not touch cron.ts):
#   "Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50,
#    draft-stall @00:30, weekly-digest @Tue 00:00 UTC, fast-tick @*/3"

# 4. Test input validation with a bad PUT
# (replace YOUR_API_KEY and ACCOUNT_ID):
curl -X PUT "$REPL_URL/api/gmail/accounts/ACCOUNT_ID/settings" \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -d '{"sendDays": []}'
# expect HTTP 400: "sendDays must contain at least one valid day..."

curl -X PUT "$REPL_URL/api/gmail/accounts/ACCOUNT_ID/settings" \
  -H "Content-Type: application/json" \
  -H "x-api-key: YOUR_API_KEY" \
  -d '{"sendHourStart": 18, "sendHourEnd": 8}'
# expect HTTP 400: "sendHourStart and sendHourEnd must satisfy..."

# 5. Test bulk cap
# Sending 26 prospect IDs should return 400.
```

## Tuning the rate caps

If the defaults are too tight or too loose, change them per-deploy via
Replit Secrets without code changes:

| Env var | Default | Free Gmail (~150/day) | Workspace (~2000/day) |
|---|---|---|---|
| `DOCTRINE_HOURLY_SEND_CAP` | 30 | 30 | 60 |
| `DOCTRINE_DAILY_SEND_CAP` | 200 | 100 | 1500 |

The cap counts all `status='sent'` rows in the last hour/day for the user,
across all stages and all prospects. So if you want to allow a one-time
catch-up burst, temporarily raise the caps, then lower again.

## What rate-limited follow-ups look like in logs

When the budget check defers a row:

```
[level=warn] Send budget exceeded — deferring follow-up to next tick
  followupId: 1234
  prospectId: 5678
  userId: 1
  reason: hourly_cap
  sentLastHour: 30
  hourlyCap: 30
  sentToday: 47
  dailyCap: 200
```

When the window check defers a row:

```
[level=info] Outside send window — deferring follow-up to next tick
  followupId: 1234
  prospectId: 5678
  reason: hour_2_outside_8_18
  utcDay: 2
  utcHour: 2
```

Filter for these in the api-server logs to see what's deferring and how often.
A handful per night is normal (rows that landed at the boundary). Sustained
deferrals during business hours indicates the cap is biting.

## Roll-forward note

Forward-only batch. To revert, the agent would need to:

1. Restore the original `index.ts` (drop the UTC pin block).
2. Revert `timingEngine.ts` to `setHours/getDay` — but this is strictly
   less safe; don't actually do this.
3. Remove the gate blocks in `scheduler.ts`.
4. Remove the validation blocks in `gmail-auth.ts`.
5. Restore bulk cap from 25 → 100 in `doctrine.ts`.
6. Delete `lib/sendBudget.ts` and `lib/scheduleWindow.ts`.

Or use git revert.
