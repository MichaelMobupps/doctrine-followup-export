#!/usr/bin/env bash
# uninstall.sh — revert the prompt-injection hardening using the latest backup.
# Usage: bash uninstall.sh [api_server_dir]
set -euo pipefail
say(){ printf "%s\n" "$*"; }
die(){ printf "ERROR: %s\n" "$*" >&2; exit 1; }

if [ "${1:-}" != "" ]; then API_DIR="$1"; else
  HIT="$(find . -type f -path '*/services/replySentiment.ts' 2>/dev/null | head -1 || true)"
  [ -n "$HIT" ] || die "Pass the api-server dir: bash uninstall.sh artifacts/api-server"
  API_DIR="$(cd "$(dirname "$HIT")/.." && pwd)"
fi
[ -d "$API_DIR/services" ] || die "Not an api-server dir: $API_DIR"

BK="$(ls -1d "$API_DIR"/.pi-backup-* 2>/dev/null | sort | head -1 || true)"
[ -n "$BK" ] || die "No backup found under $API_DIR (.pi-backup-*). MANUAL CLEANUP NEEDED."
say "Restoring from oldest (pristine) backup: $BK"

for f in "$BK"/services/*.ts; do
  base="$(basename "$f")"
  cp "$f" "$API_DIR/services/$base"
  say "restored services/$base"
done

for p in "$API_DIR/lib/promptInjection.ts" "$API_DIR/tests/promptInjection.test.ts"; do
  if [ -f "$p" ] && grep -q "promptInjection" "$p" 2>/dev/null; then rm -f "$p"; say "removed ${p#$API_DIR/}"; fi
done

say "Done. The hardening is removed. Backup left in place at $BK"
say "Next: Restart, then Republish."
