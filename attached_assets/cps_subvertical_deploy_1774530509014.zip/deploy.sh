#!/bin/bash
set -e
WORKSPACE="/home/runner/workspace"

echo "=== CPS Sub-Vertical Deploy ==="

# ── 1. Replace verticalClassifier.ts ──
echo "1/8 Replacing verticalClassifier.ts..."
cp /tmp/cps_deploy/verticalClassifier.ts "$WORKSPACE/artifacts/api-server/src/lib/verticalClassifier.ts"

# ── 2. Add sub_vertical column to prospects schema ──
echo "2/8 Patching prospects schema..."
cd "$WORKSPACE"
SCHEMA="$WORKSPACE/lib/db/src/schema/prospects.ts"
if grep -q "subVertical" "$SCHEMA"; then
  echo "  Already has subVertical, skipping"
else
  sed -i 's/vertical: text("vertical").notNull().default("non_gaming_ua"),/vertical: text("vertical").notNull().default("non_gaming_ua"),\n  subVertical: text("sub_vertical"),/' "$SCHEMA"
  echo "  Added subVertical column to schema"
fi

# ── 3. Push DB migration ──
echo "3/8 Running DB migration..."
cd "$WORKSPACE/lib/db"
npx drizzle-kit push --force --config ./drizzle.config.ts 2>&1 || echo "  drizzle-kit push failed, trying raw SQL..."
# Fallback: raw SQL
if command -v psql &>/dev/null && [ -n "$DATABASE_URL" ]; then
  echo "ALTER TABLE prospects ADD COLUMN IF NOT EXISTS sub_vertical TEXT;" | psql "$DATABASE_URL" 2>/dev/null || true
fi

# ── 4. Patch gmailSync.ts ──
echo "4/8 Patching gmailSync.ts..."
SYNC="$WORKSPACE/artifacts/api-server/src/services/gmailSync.ts"
# Patch syncForUser: destructure inferVertical result
sed -i "s/const vertical = inferVertical(msg.labels, msg.subject, msg.body).vertical;/const { vertical, subVertical } = inferVertical(msg.labels, msg.subject, msg.body);/g" "$SYNC"
# Patch insert: add subVertical after vertical (both occurrences)
sed -i '/^        vertical,$/{ n; s/^        product: inferProduct(vertical),$/        subVertical,\n        product: inferProduct(vertical),/ }' "$SYNC"
# Check if already patched
if grep -q "subVertical," "$SYNC"; then
  echo "  gmailSync.ts patched"
else
  echo "  WARNING: gmailSync.ts may need manual review"
fi

# ── 5. Patch followupPrompts.ts ──
echo "5/8 Patching followupPrompts.ts..."
PROMPTS="$WORKSPACE/artifacts/api-server/src/services/followupPrompts.ts"
# Add sub_vertical to interface
if grep -q "sub_vertical" "$PROMPTS"; then
  echo "  Already has sub_vertical, skipping interface patch"
else
  sed -i 's/  vertical: string;/  vertical: string;\n  sub_vertical: string | null;/' "$PROMPTS"
fi
# Replace CPS label
sed -i 's/cps: "CPS \/ Fintech Performance",/cps: "CPS Web Performance",/' "$PROMPTS"
# Add cpsSubLabels map and update VERTICAL line
python3 << 'PYEOF'
import re

filepath = "/home/runner/workspace/artifacts/api-server/src/services/followupPrompts.ts"
with open(filepath, "r") as f:
    content = f.read()

# Only patch if not already patched
if "cpsSubLabels" not in content:
    cps_sub_labels = '''
  const cpsSubLabels: Record<string, string> = {
    cps_ecommerce: "E-commerce & Retail (CPS web performance for online retail, confirmed purchases, product sales)",
    cps_classifieds: "Classifieds & Marketplaces (CPS web performance for listing submissions, seller leads)",
    cps_fintech: "Fintech & Financial Services (CPS performance for banking, trading, lending, payments)",
    cps_travel: "Travel & Hospitality (CPS performance for bookings, reservations, travel conversions)",
    cps_food_delivery: "Food & Delivery (CPS performance for order completions, restaurant/grocery delivery)",
    cps_subscription: "Subscription & SaaS (CPS performance for trial-to-paid, subscriber acquisition)",
    cps_education: "Education & EdTech (CPS performance for course enrollments, student acquisition)",
    cps_health_wellness: "Health & Wellness (CPS performance for telehealth, fitness, pharmacy conversions)",
    cps_utilities_telco: "Utilities & Telco (CPS performance for plan signups, SIM activations)",
    cps_automotive: "Automotive (CPS performance for car sales leads, test drive bookings, auto conversions)",
    cps_real_estate: "Real Estate & Property (CPS performance for property leads, listing engagement)",
    cps_dating_social: "Dating & Social (CPS performance for premium subscriptions, match conversions)",
    cps_gaming_iap: "Gaming In-App Purchase (CPS performance on purchase events, payer conversions)",
  };'''
    
    # Insert cpsSubLabels after retargeting line
    content = content.replace(
        '    retargeting: "Mobile Retargeting",\n  };',
        '    retargeting: "Mobile Retargeting",\n  };\n' + cps_sub_labels
    )
    
    # Update VERTICAL line
    content = content.replace(
        'VERTICAL: ${verticalLabels[ctx.vertical] || ctx.vertical}',
        'VERTICAL: ${ctx.sub_vertical && cpsSubLabels[ctx.sub_vertical] ? cpsSubLabels[ctx.sub_vertical] : (verticalLabels[ctx.vertical] || ctx.vertical)}'
    )
    
    with open(filepath, "w") as f:
        f.write(content)
    print("  followupPrompts.ts patched with cpsSubLabels")
else:
    print("  Already has cpsSubLabels, skipping")
PYEOF

# ── 6. Patch scheduler.ts ──
echo "6/8 Patching scheduler.ts..."
SCHED="$WORKSPACE/artifacts/api-server/src/services/scheduler.ts"
# Add subVertical to select
if grep -q "subVertical: prospectsTable.subVertical" "$SCHED"; then
  echo "  Already patched, skipping"
else
  sed -i 's/vertical: prospectsTable.vertical,/vertical: prospectsTable.vertical,\n      subVertical: prospectsTable.subVertical,/' "$SCHED"
  sed -i 's/vertical: item.vertical,/vertical: item.vertical,\n        sub_vertical: item.subVertical || null,/' "$SCHED"
  echo "  scheduler.ts patched"
fi

# ── 7. Patch email-inspector.ts ──
echo "7/8 Patching email-inspector.ts..."
INSP="$WORKSPACE/artifacts/api-server/src/routes/email-inspector.ts"
# Capture subVertical from inferVertical
sed -i 's/const { vertical, reason: verticalReason } = inferVertical(labelNames, subject, body);/const { vertical, subVertical, reason: verticalReason } = inferVertical(labelNames, subject, body);/' "$INSP"
# Add subVertical to detection response
if grep -q "subVertical," "$INSP"; then
  echo "  Already patched, skipping"
else
  sed -i 's/            vertical,/            vertical,\n            subVertical,/' "$INSP"
  echo "  email-inspector.ts patched"
fi

# ── 8. Patch doctrine.ts routes — add sub_vertical to API responses ──
echo "8/8 Patching doctrine.ts API responses..."
DOCTRINE="$WORKSPACE/artifacts/api-server/src/routes/doctrine.ts"
python3 << 'PYEOF2'
filepath = "/home/runner/workspace/artifacts/api-server/src/routes/doctrine.ts"
with open(filepath, "r") as f:
    content = f.read()

changes = 0

# Update verticalLabels map
if '"CPS / Fintech"' in content:
    content = content.replace('"CPS / Fintech"', '"CPS"')
    changes += 1

# Add subVertical to prospects select if not there
if "subVertical: prospectsTable.subVertical" not in content:
    # Add after vertical select in prospects query
    content = content.replace(
        "      vertical: prospectsTable.vertical,\n      product: prospectsTable.product,",
        "      vertical: prospectsTable.vertical,\n      subVertical: prospectsTable.subVertical,\n      product: prospectsTable.product,",
        1  # only first occurrence (prospects endpoint)
    )
    changes += 1

# Add sub_vertical to prospect response objects
if "sub_vertical: row.subVertical" not in content:
    content = content.replace(
        "      vertical: row.vertical,\n      product: row.product,",
        "      vertical: row.vertical,\n      sub_vertical: row.subVertical || null,\n      product: row.product,"
    )
    changes += 1

# Add sub_vertical to by-thread response
if "sub_vertical: p.subVertical" not in content:
    content = content.replace(
        "    vertical: p.vertical,\n    product: p.product,",
        "    vertical: p.vertical,\n    sub_vertical: p.subVertical || null,\n    product: p.product,"
    )
    changes += 1

with open(filepath, "w") as f:
    f.write(content)
print(f"  doctrine.ts: {changes} patches applied")
PYEOF2

# ── 9. Update dashboard display labels ──
echo "9/9 Patching dashboard vertical labels..."
# Email inspector
EINSP="$WORKSPACE/artifacts/dashboard/src/pages/email-inspector.tsx"
if [ -f "$EINSP" ]; then
  sed -i 's/cps: "CPS \/ Fintech",/cps: "CPS",/' "$EINSP"
  echo "  email-inspector.tsx label updated"
fi
# Prospects page
PROSP="$WORKSPACE/artifacts/dashboard/src/pages/prospects.tsx"
if [ -f "$PROSP" ]; then
  sed -i 's/>CPS \/ Fintech</>CPS</' "$PROSP"
  echo "  prospects.tsx labels updated"
fi

# ── 10. Regenerate API types ──
echo "Regenerating API types..."
cd "$WORKSPACE"
npx openapi-typescript lib/api-spec/openapi.yaml -o lib/api-client/src/generated.ts 2>/dev/null || true

# ── 11. Sync source-code ──
echo "Syncing source-code..."
bash source-code/sync.sh 2>&1

echo ""
echo "=== DONE ==="
echo "CPS sub-vertical classification deployed."
echo "New prospects synced from Gmail will get sub_vertical assigned."
echo "Existing CPS prospects will show sub_vertical = null until re-synced."
