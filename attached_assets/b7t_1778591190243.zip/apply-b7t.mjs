// B7t apply script.
//
// Adds the admin activity dashboard page:
//   - NEW    artifacts/dashboard/src/pages/admin-activity.tsx
//   - PATCH  artifacts/dashboard/src/App.tsx (import + route)
//   - PATCH  artifacts/dashboard/src/components/layout.tsx (nav link)
//
// Read-only page. Consumes /api/admin/activity (B7s endpoint).
// No backend changes. No DB changes.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";
const PATCH_DIR = path.dirname(new URL(import.meta.url).pathname);

async function copyFile(src, dst) {
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
  console.log(`wrote: ${dst}`);
}

async function patchFile(relativePath, edits) {
  const absPath = path.join(WORKSPACE, relativePath);
  let content;
  try { content = await fs.readFile(absPath, "utf8"); }
  catch (err) { throw new Error(`Cannot read ${absPath}: ${err.message}`); }
  let applied = 0, alreadyApplied = 0;
  for (const edit of edits) {
    if (edit.marker && content.includes(edit.marker)) {
      console.log(`  [skip] ${edit.name} (already applied)`);
      alreadyApplied++; continue;
    }
    const occurrences = content.split(edit.search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Edit "${edit.name}" NOT FOUND in ${relativePath}. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Edit "${edit.name}" matched ${occurrences} times in ${relativePath}. Need a more specific anchor.`);
    }
    content = content.replace(edit.search, edit.replace);
    applied++;
    console.log(`  [ok]   ${edit.name}`);
  }
  if (applied > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${relativePath} (applied ${applied}, skipped ${alreadyApplied})`);
  } else {
    console.log(`no-op: ${relativePath} (all ${alreadyApplied} edits already applied)`);
  }
}

// ============================================================
// Step 1: copy the new page file.
// ============================================================
async function copyNewFiles() {
  await copyFile(
    path.join(PATCH_DIR, "files/admin-activity.tsx"),
    path.join(WORKSPACE, "artifacts/dashboard/src/pages/admin-activity.tsx"),
  );
}

// ============================================================
// Step 2: App.tsx — import + route.
// ============================================================
const APP_EDITS = [
  {
    name: "App.tsx: import AdminActivity",
    marker: "B7t: admin activity dashboard",
    search: `import ActivityLog from "@/pages/activity-log";
import NotFound from "@/pages/not-found";`,
    replace: `import ActivityLog from "@/pages/activity-log";
// B7t: admin activity dashboard (per-LLM-call usage ledger).
import AdminActivity from "@/pages/admin-activity";
import NotFound from "@/pages/not-found";`,
  },
  {
    name: "App.tsx: route for /admin-activity",
    marker: "B7t: route admin-activity",
    search: `      <Route path="/activity" component={ActivityLog} />`,
    replace: `      <Route path="/activity" component={ActivityLog} />
      {/* B7t: route admin-activity — per-LLM-call cost & token ledger. */}
      <Route path="/admin-activity" component={AdminActivity} />`,
  },
];

// ============================================================
// Step 3: layout.tsx — nav link (visible on doctrine routes only;
// it's a cross-product admin view, but the simpler placement is
// alongside the existing Activity Log entry in the doctrine nav).
// ============================================================
const LAYOUT_EDITS = [
  {
    name: "layout.tsx: import BarChart3 icon",
    marker: "B7t: BarChart3 import",
    search: `import { Eye, LogOut, Workflow, Radio, Activity, Settings as SettingsIcon, ArrowLeftRight } from "lucide-react";`,
    replace: `// B7t: BarChart3 import for the Admin Activity nav entry.
import { Eye, LogOut, Workflow, Radio, Activity, Settings as SettingsIcon, ArrowLeftRight, BarChart3 } from "lucide-react";`,
  },
  {
    name: "layout.tsx: add nav entry for doctrine (Admin Activity)",
    marker: "B7t: nav doctrine admin-activity",
    search: `        { name: "Activity Log", href: "/activity", icon: Activity },
      ];`,
    replace: `        { name: "Activity Log", href: "/activity", icon: Activity },
        // B7t: nav doctrine admin-activity. Cross-product LLM cost ledger.
        { name: "Admin Activity", href: "/admin-activity", icon: BarChart3 },
      ];`,
  },
  {
    name: "layout.tsx: add nav entry for context (Admin Activity)",
    marker: "B7t: nav context admin-activity",
    search: `        { name: "Activity Log", href: "/context/activity", icon: Activity },
      ]`,
    replace: `        { name: "Activity Log", href: "/context/activity", icon: Activity },
        // B7t: nav context admin-activity. Same URL as doctrine since the
        // page itself is cross-product (filter shows both apps).
        { name: "Admin Activity", href: "/admin-activity", icon: BarChart3 },
      ]`,
  },
];

// ============================================================
// Main.
// ============================================================
async function main() {
  console.log("B7t: admin activity dashboard page for Email Followuper\n");

  console.log("[1/3] copying admin-activity.tsx");
  await copyNewFiles();
  console.log();

  console.log("[2/3] artifacts/dashboard/src/App.tsx — import + route");
  await patchFile("artifacts/dashboard/src/App.tsx", APP_EDITS);
  console.log();

  console.log("[3/3] artifacts/dashboard/src/components/layout.tsx — nav link");
  await patchFile("artifacts/dashboard/src/components/layout.tsx", LAYOUT_EDITS);
  console.log();

  console.log("B7t applied. Next: build dashboard, restart workflow.");
  console.log("Page will be live at /admin-activity (linked from sidebar).");
}

main().catch((err) => {
  console.error("\nB7t apply failed:", err.message);
  process.exit(1);
});
