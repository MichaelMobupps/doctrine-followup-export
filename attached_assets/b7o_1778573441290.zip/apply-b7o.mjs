// B7o apply script.
// Writes the new admin-salvage route into the live api-server src tree
// and updates routes/index.ts to register it. Idempotent.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";
const PATCH_DIR = path.dirname(new URL(import.meta.url).pathname);

const TARGETS = [
  {
    from: path.join(PATCH_DIR, "routes/admin-salvage.ts"),
    to: path.join(WORKSPACE, "artifacts/api-server/src/routes/admin-salvage.ts"),
  },
  {
    from: path.join(PATCH_DIR, "routes/index.ts"),
    to: path.join(WORKSPACE, "artifacts/api-server/src/routes/index.ts"),
  },
];

async function main() {
  for (const { from, to } of TARGETS) {
    await fs.mkdir(path.dirname(to), { recursive: true });
    await fs.copyFile(from, to);
    console.log(`wrote: ${to}`);
  }
  console.log("\nB7o files applied to artifacts/api-server/src/");
  console.log("Next: build api-server, restart workflow, then run the dry-run curl.");
}

main().catch((err) => {
  console.error("B7o apply failed:", err);
  process.exit(1);
});
