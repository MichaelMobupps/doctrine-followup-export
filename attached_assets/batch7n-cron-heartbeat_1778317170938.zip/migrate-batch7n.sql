-- Phase 7n migration: cron_heartbeats table.
-- Run once: psql "$DATABASE_URL" -f migrate-batch7n.sql
--
-- Idempotent: IF NOT EXISTS on both table and index. Safe to re-run.

CREATE TABLE IF NOT EXISTS cron_heartbeats (
  id SERIAL PRIMARY KEY,
  tick_name TEXT NOT NULL,
  fired_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  outcome TEXT NOT NULL,
  duration_ms INTEGER NOT NULL DEFAULT 0,
  details JSONB
);

-- Optimizes "show recent heartbeats for tick X" and "show all recent
-- heartbeats" queries. fired_at DESC because liveness queries are
-- always ordered newest-first.
CREATE INDEX IF NOT EXISTS idx_cron_heartbeats_tick_fired_at
  ON cron_heartbeats (tick_name, fired_at DESC);
