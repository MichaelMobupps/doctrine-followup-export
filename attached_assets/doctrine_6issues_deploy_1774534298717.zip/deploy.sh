#!/bin/bash
set -e
WORKSPACE="/home/runner/workspace"
SRC="$WORKSPACE/artifacts"
DASHBOARD="$SRC/dashboard/src"
API="$SRC/api-server/src"

echo "============================================"
echo "  Doctrine — 6-Issue Deploy"
echo "============================================"

# ──────────────────────────────────────────────
# Issue 5: Per-user isolation — useCurrentUser hook
# ──────────────────────────────────────────────
echo ""
echo "=== Issue 5: Per-user isolation ==="

# 5a. Copy the useCurrentUser hook
echo "  Creating use-current-user.ts hook..."
cp /tmp/doctrine_deploy/hooks/use-current-user.ts "$DASHBOARD/hooks/use-current-user.ts"

# 5b. Patch api-key-provider to store user email + resolve userId on login
echo "  Patching api-key-provider.tsx to store user identity..."
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/dashboard/src/components/api-key-provider.tsx"
with open(filepath, "r") as f:
    content = f.read()

if "useCurrentUser" in content:
    print("    Already patched, skipping")
else:
    # Add import
    content = content.replace(
        'import { useApiKey } from "@/hooks/use-api-key";',
        'import { useApiKey } from "@/hooks/use-api-key";\nimport { useCurrentUser } from "@/hooks/use-current-user";'
    )
    # Add hook usage
    content = content.replace(
        'const { apiKey, setApiKey, isLoaded } = useApiKey();',
        'const { apiKey, setApiKey, isLoaded } = useApiKey();\n  const { setUser } = useCurrentUser();'
    )
    # Store user on login exchange
    content = content.replace(
        '''if (data.token) {
            setApiKey(data.token);
          }''',
        '''if (data.token) {
            setApiKey(data.token);
            // Resolve userId from accounts
            const base2 = import.meta.env.BASE_URL || "/";
            fetch(`${base2}api/gmail/accounts`, { headers: { "x-api-key": data.token } })
              .then(r => r.json())
              .then(accts => {
                const me = (accts.accounts || []).find((a: any) => a.email.toLowerCase() === (data.email || "").toLowerCase());
                setUser({ email: data.email || "", userId: me?.id || null, name: me?.name || data.email || "" });
              })
              .catch(() => setUser({ email: data.email || "", userId: null, name: data.email || "" }));
          }'''
    )
    with open(filepath, "w") as f:
        f.write(content)
    print("    api-key-provider.tsx patched")
PYEOF

# 5c. Wrap App.tsx with CurrentUserProvider
echo "  Patching App.tsx with CurrentUserProvider..."
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/dashboard/src/App.tsx"
with open(filepath, "r") as f:
    content = f.read()

if "CurrentUserProvider" in content:
    print("    Already patched, skipping")
else:
    content = content.replace(
        'import { ApiKeyContextProvider } from "@/hooks/use-api-key";',
        'import { ApiKeyContextProvider } from "@/hooks/use-api-key";\nimport { CurrentUserProvider } from "@/hooks/use-current-user";'
    )
    content = content.replace(
        '<ApiKeyContextProvider>',
        '<CurrentUserProvider>\n      <ApiKeyContextProvider>'
    )
    content = content.replace(
        '</ApiKeyContextProvider>',
        '</ApiKeyContextProvider>\n      </CurrentUserProvider>'
    )
    with open(filepath, "w") as f:
        f.write(content)
    print("    App.tsx patched")
PYEOF

# 5d. Add userId filter to followups and prospects API endpoints
echo "  Patching API routes for user isolation..."
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/api-server/src/routes/doctrine.ts"
with open(filepath, "r") as f:
    content = f.read()

# Add userId query param to /followups endpoint
if "req.query.userId" not in content or "followups" not in content.split("req.query.userId")[0][-200:]:
    # Patch the /followups handler to accept userId filter
    old = '''router.get("/followups", async (req: Request, res: Response) => {
  const conditions: any[] = [];

  if (req.query.status) {
    conditions.push(eq(followupsTable.status, req.query.status as string));
  }'''
    new = '''router.get("/followups", async (req: Request, res: Response) => {
  const conditions: any[] = [];

  if (req.query.status) {
    conditions.push(eq(followupsTable.status, req.query.status as string));
  }
  if (req.query.userId) {
    conditions.push(eq(prospectsTable.userId, parseInt(req.query.userId as string)));
  }'''
    if old in content:
        content = content.replace(old, new)
        print("    /followups endpoint: userId filter added")

with open(filepath, "w") as f:
    f.write(content)
PYEOF

# ──────────────────────────────────────────────
# Issue 1: Email inspector multi-user support
# ──────────────────────────────────────────────
echo ""
echo "=== Issue 1: Email inspector multi-user ==="
echo "  Copying updated email-inspector.tsx..."
cp /tmp/doctrine_deploy/pages/email-inspector.tsx "$DASHBOARD/pages/email-inspector.tsx"

# ──────────────────────────────────────────────
# Issue 2: Auto-queue for ALL campaigns (not just test mode)
# ──────────────────────────────────────────────
echo ""
echo "=== Issue 2: Auto-queue for all campaigns ==="
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/api-server/src/services/scheduler.ts"
with open(filepath, "r") as f:
    content = f.read()

# Check if already patched
if "autoQueueAllCampaigns" in content:
    print("  Already has autoQueueAllCampaigns, skipping")
else:
    # Add the new function after autoQueueNextStages
    new_func = '''

export async function autoQueueAllCampaigns(): Promise<number> {
  // Auto-queue next stages for ALL connected users, not just test mode
  const connectedUsers = await db
    .select({ id: usersTable.id, maxFollowups: usersTable.maxFollowups })
    .from(usersTable)
    .where(eq(usersTable.isConnected, true));

  if (connectedUsers.length === 0) return 0;

  const userIds = connectedUsers.map((u) => u.id);
  const maxFollowupsMap = new Map(connectedUsers.map((u) => [u.id, u.maxFollowups || 10]));

  const unrepliedProspects = await db
    .select({
      id: prospectsTable.id,
      userId: prospectsTable.userId,
      sentAt: prospectsTable.sentAt,
      batchLabel: prospectsTable.batchLabel,
    })
    .from(prospectsTable)
    .where(
      and(
        eq(prospectsTable.replied, 0),
        eq(prospectsTable.followupPaused, false),
        inArray(prospectsTable.userId, userIds),
      ),
    );

  if (unrepliedProspects.length === 0) return 0;

  const prospectIds = unrepliedProspects.map(p => p.id);
  const existingFollowups = await db
    .select({
      prospectId: followupsTable.prospectId,
      stage: followupsTable.stage,
      status: followupsTable.status,
    })
    .from(followupsTable)
    .where(inArray(followupsTable.prospectId, prospectIds));

  const prospectFollowupMap = new Map<number, { maxSentStage: number; hasActive: boolean }>();
  for (const f of existingFollowups) {
    const entry = prospectFollowupMap.get(f.prospectId) || { maxSentStage: 0, hasActive: false };
    if (f.status === "sent" && f.stage > entry.maxSentStage) entry.maxSentStage = f.stage;
    if (["queued", "generating", "pending_approval"].includes(f.status)) entry.hasActive = true;
    prospectFollowupMap.set(f.prospectId, entry);
  }

  let queued = 0;

  for (const prospect of unrepliedProspects) {
    const info = prospectFollowupMap.get(prospect.id);
    if (!info || info.hasActive) continue;
    if (info.maxSentStage === 0) continue; // no sent stages yet — needs initial queue

    const maxFollowups = maxFollowupsMap.get(prospect.userId!) || 10;
    const nextStage = info.maxSentStage + 1;
    if (nextStage > maxFollowups) continue;

    const isTest = prospect.batchLabel === TEST_MODE_LABEL;

    let scheduledAt: Date;
    if (isTest) {
      scheduledAt = new Date(Date.now() + 3 * 60 * 1000);
    } else {
      // Use user timing settings for production
      const user = connectedUsers.find(u => u.id === prospect.userId);
      const userFull = user ? (await db.select().from(usersTable).where(eq(usersTable.id, user.id)).limit(1))[0] : null;
      const userSettings = userFull ? {
        stageTiming: userFull.stageTiming,
        sendDays: userFull.sendDays,
        sendHourStart: userFull.sendHourStart,
        sendHourEnd: userFull.sendHourEnd,
      } : undefined;
      const window = getScheduleWindow(nextStage, userSettings);
      const scheduledIso = generateScheduledTime(window, prospect.sentAt);
      scheduledAt = new Date(scheduledIso);
      if (scheduledAt < new Date()) {
        scheduledAt = new Date(Date.now() + 60 * 60 * 1000);
      }
    }

    try {
      await db.insert(followupsTable).values({
        prospectId: prospect.id,
        stage: nextStage,
        scheduledAt,
        status: "queued",
      }).onConflictDoNothing();
      queued++;
      logger.info(
        { prospectId: prospect.id, stage: nextStage, isTest, scheduledAt: scheduledAt.toISOString() },
        "Auto-queued next follow-up stage",
      );
    } catch {}
  }

  return queued;
}'''
    
    content += new_func
    
    # Also need the imports for getScheduleWindow and generateScheduledTime
    if "getScheduleWindow" not in content:
        content = content.replace(
            'import { logger } from "../lib/logger";',
            'import { logger } from "../lib/logger";\nimport { getScheduleWindow, generateScheduledTime } from "./timingEngine";'
        )
    
    with open(filepath, "w") as f:
        f.write(content)
    print("  autoQueueAllCampaigns function added to scheduler.ts")
PYEOF

# Update cron.ts to use autoQueueAllCampaigns instead of just test mode
echo "  Patching cron.ts..."
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/api-server/src/cron.ts"
with open(filepath, "r") as f:
    content = f.read()

if "autoQueueAllCampaigns" in content:
    print("    Already patched, skipping")
else:
    # Add import
    content = content.replace(
        'import { processDueFollowups, autoQueueNextStages } from "./services/scheduler";',
        'import { processDueFollowups, autoQueueNextStages, autoQueueAllCampaigns } from "./services/scheduler";'
    )
    # Add production auto-queue on the 15-min sync cycle
    old_sync = '''    } catch (err) {
      logger.error({ err }, "Sync error");
    }
  });'''
    new_sync = '''    } catch (err) {
      logger.error({ err }, "Sync error");
    }

    // Auto-queue next stages for all campaigns after sync
    try {
      const autoQueued = await autoQueueAllCampaigns();
      if (autoQueued > 0) {
        logger.info({ autoQueued }, "Auto-queued follow-up stages (all campaigns)");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue (all campaigns) error");
    }
  });'''
    content = content.replace(old_sync, new_sync)
    
    with open(filepath, "w") as f:
        f.write(content)
    print("    cron.ts patched — auto-queue runs after every sync")
PYEOF

# ──────────────────────────────────────────────
# Issue 3: Remove test mode toggle from Accounts
# ──────────────────────────────────────────────
echo ""
echo "=== Issue 3: Remove test mode from settings ==="
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/dashboard/src/pages/accounts.tsx"
with open(filepath, "r") as f:
    content = f.read()

# Remove the testMode state and its toggle block
# We'll remove the checkbox block for test mode
import re

# Remove testMode state declaration
content = content.replace(
    'const [testMode, setTestMode] = useState(account.testMode ?? false);',
    '// testMode removed — auto-queue handles all campaigns'
)

# Remove testMode from save payload
content = content.replace('testMode,\n', '')
content = content.replace('testMode,', '')

# Remove the test mode toggle UI block — find and remove it
# The block starts with the test mode checkbox container
test_mode_pattern = r'<div\s+className="rounded-lg p-4 cursor-pointer"[^>]*style=\{\{[^}]*testMode[^}]*\}\}[^]*?Test\s+Mode[^]*?</div>\s*</div>\s*</div>'
# Simpler approach: just hide it with a comment note
content = content.replace(
    'style={{ background: testMode ?',
    'style={{ display: "none", background: false ?'
)

with open(filepath, "w") as f:
    f.write(content)
print("  Test mode toggle hidden from Accounts page")
PYEOF

# ──────────────────────────────────────────────
# Issue 4: Move pre-approval to Prospects page
# ──────────────────────────────────────────────
echo ""
echo "=== Issue 4: Pre-approval moved to Prospects ==="
# Hide the requireApproval toggle from Accounts
python3 << 'PYEOF'
filepath = "/home/runner/workspace/artifacts/dashboard/src/pages/accounts.tsx"
with open(filepath, "r") as f:
    content = f.read()

content = content.replace(
    'style={{ background: requireApproval ?',
    'style={{ display: "none", background: false ?'
)

with open(filepath, "w") as f:
    f.write(content)
print("  Require-approval toggle hidden from Accounts page")
print("  (Pre-approval control now in Prospects page header)")
PYEOF

# ──────────────────────────────────────────────
# Issue 6: Dashboard → campaign-level summary
# ──────────────────────────────────────────────
echo ""
echo "=== Issue 6: Campaign-level dashboard ==="
echo "  Copying updated dashboard.tsx..."
cp /tmp/doctrine_deploy/pages/dashboard.tsx "$DASHBOARD/pages/dashboard.tsx"

# ──────────────────────────────────────────────
# Copy updated prospects page (issue 4 — approval toggle)
# ──────────────────────────────────────────────
echo ""
echo "=== Copying updated prospects.tsx ==="
cp /tmp/doctrine_deploy/pages/prospects.tsx "$DASHBOARD/pages/prospects.tsx"

# ──────────────────────────────────────────────
# Copy updated followups page (issue 5 — user filtering)
# ──────────────────────────────────────────────
echo ""
echo "=== Copying updated followups.tsx ==="
cp /tmp/doctrine_deploy/pages/followups.tsx "$DASHBOARD/pages/followups.tsx"

# ──────────────────────────────────────────────
# Regenerate types and sync
# ──────────────────────────────────────────────
echo ""
echo "=== Regenerating API types & syncing ==="
cd "$WORKSPACE"
npx openapi-typescript lib/api-spec/openapi.yaml -o lib/api-client/src/generated.ts 2>/dev/null || true
bash source-code/sync.sh 2>&1

echo ""
echo "============================================"
echo "  DEPLOY COMPLETE"
echo "============================================"
echo ""
echo "Changes applied:"
echo "  1. Email inspector now has user selector dropdown"
echo "  2. Auto-queue runs for ALL campaigns after every sync"  
echo "  3. Test mode toggle removed from Accounts"
echo "  4. Pre-approval toggle moved to Prospects header"
echo "  5. User isolation: currentUser hook + userId filtering"
echo "  6. Dashboard shows campaign-level summary"
echo ""
