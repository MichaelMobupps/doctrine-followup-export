# Batch B8c — Typecheck Residuals Cleanup

**Scope.** Eliminate the 11 typecheck errors that survived B8b. After this ship, `pnpm --filter @workspace/api-server run typecheck` exits 0 and future batches start from a fully green baseline. No runtime behaviour changes.

## Three categories addressed

### Category 1 — `req.query` string-or-array narrowing (4 errors)

`doctrine.ts:1210,1282`, `gmail-auth.ts:204,228` pass `req.query.X` to functions expecting `string`. Express types `req.query` values as `string | string[] | ParsedQs | ParsedQs[] | undefined`. The fix is to cast each offending site to `string` — matching the existing codebase pattern (see `doctrine.ts:110`, `:173`, `:179`, `:692`, etc. which already use `as string`).

Applied via a surgical Python regex in the bash block (the live file at line 1210+ contains code added beyond what's in the source-code mirror, so a full-file replacement would be guessing). The script:
- Targets only the 4 specific line numbers
- Pattern `req.query.<identifier>` not already cast or wrapped
- Replaces with `(req.query.<identifier> as string)`
- Idempotent — negative lookahead prevents double-wrapping on re-runs
- Self-reporting — prints before/after for each line

### Category 2 — `email-inspector.ts:370` overload mismatch + 5 cascading anys

Line 370 has the same `req.query.X` pattern, but the target type is `string | undefined` (not `string`). Fix is the same shape with a wider cast: `(req.query.X as string | undefined)`. The cascading implicit-any errors at lines 376, 378, 381, 398, 414 are downstream of the line-370 overload failure — once line 370 picks the right overload, TS resolves the surrounding variables (`msg`, `h`, `id`, `m`) to their proper types and the 7006 errors disappear automatically.

Applied via the same Python script with a per-target-type table so line 370 gets `string | undefined` cast while the others get `string`.

### Category 3 — `threadReader.ts:139` direction enum mismatch (my B9a issue)

drizzle-zod's `createInsertSchema` does not preserve the column-level `.$type<ThreadMessageDirection>()` annotation. The zod-derived `z.infer<...>` widens `direction` back to plain `string`. Drizzle's native `.values()` type (used inside `db.insert(...).values(...)`) still requires the narrowed `"inbound" | "outbound"` and rejects the wider `string`.

Fix: switch `InsertThreadMessage` from `z.infer<typeof insertThreadMessageSchema>` to `typeof threadMessagesTable.$inferInsert`. Drizzle's native inference preserves `$type` annotations end-to-end. The zod schema is kept exported (`insertThreadMessageSchema`) for use in B9b's marking endpoint runtime validation.

Single line change in `lib/db/src/schema/thread-messages.ts`.

## Risk surface

1. **No runtime change.** All three fixes are type-only.
2. **Idempotency.** The Python regex uses negative lookahead `(?!\s+as\s+\w)` so re-running the bash block after a successful first run produces no further changes. Already-cast sites are left alone.
3. **Cascading-any prediction is high-confidence but not certain.** If the 5 downstream lines in email-inspector.ts still emit errors after line 370 is fixed, the bash block surfaces them and we'd need a follow-up. Most likely they collapse to zero.
4. **The B9a unit test still passes** because it does not import `InsertThreadMessage` — only `classifyDirection` and `extractBodyText`, which are unaffected.
5. **Downstream consumers of `InsertThreadMessage`.** Only `threadReader.ts:buildInsertRow` uses it (B9a's only consumer). The new type is strictly narrower (preserves enum) than the previous; any value that satisfied the old type also satisfies the new type, so no caller breaks.

## Layout

```
batch-b8c-typecheck-residuals/
|-- README.md
`-- db/
    `-- schema/
        `-- thread-messages.ts   (replace — Cat 3 fix only)
```

Cat 1 & 2 fixes are applied via the Python script embedded in the deploy bash block.

After applying, `lib/db/dist` needs another rebuild because thread-messages.ts changed. The bash block triggers this automatically via `tsc -b` (the B8b typecheck script).

No workflow restart needed — type-only changes. `source-code/sync.sh` IS needed since the schema source file (`lib/db/src/schema/thread-messages.ts`) changes, and route files (`doctrine.ts`, `gmail-auth.ts`, `email-inspector.ts`) change.
