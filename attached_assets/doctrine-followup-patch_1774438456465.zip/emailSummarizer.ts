/**
 * Summarizes a cold outreach email body into a short context blurb
 * suitable for follow-up generation.
 *
 * The goal is to capture WHAT was pitched and the core value prop
 * in 1-2 sentences, so the follow-up writer knows the thread context
 * without being tempted to reproduce the original pitch verbatim.
 */

import { anthropic } from "@workspace/integrations-anthropic-ai";
import { logger } from "../lib/logger";

const SUMMARIZE_SYSTEM = `You are a concise email summarizer. Given a cold outreach email body, extract the core pitch in 1-2 sentences.

RULES:
- Output ONLY the summary, no preamble, no quotes, no labels.
- Capture: what product/service was offered, what specific value proposition was made, and what action was requested.
- Use neutral third-person language: "Pitched [X] for [Y], highlighting [Z]."
- Maximum 80 words. Shorter is better.
- Do NOT reproduce original phrasing. Restate in your own words.
- If the email mentions specific metrics, campaigns, or competitor comparisons, note the topic but not the exact numbers or claims.`;

/**
 * Summarize a cold email body into a follow-up-safe context blurb.
 *
 * Falls back to a truncated version of the raw body if the LLM call fails,
 * to avoid blocking the sync pipeline.
 */
export async function summarizeOriginalEmail(body: string): Promise<string> {
  if (!body || body.trim().length < 30) {
    return body.trim();
  }

  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 200,
      system: SUMMARIZE_SYSTEM,
      messages: [{ role: "user", content: body.slice(0, 1000) }],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (textBlock && textBlock.type === "text" && textBlock.text.trim().length > 10) {
      return textBlock.text.trim();
    }
  } catch (err) {
    logger.warn({ err }, "Email summarization failed, using truncated body");
  }

  // Fallback: first 200 chars with a truncation marker
  return body.slice(0, 200).trim() + (body.length > 200 ? "..." : "");
}
