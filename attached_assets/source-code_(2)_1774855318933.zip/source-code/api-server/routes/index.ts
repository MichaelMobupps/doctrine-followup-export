import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import doctrineRouter from "./doctrine";
import gmailAuthRouter from "./gmail-auth";
import emailInspectorRouter from "./email-inspector";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(gmailAuthRouter);
router.use(doctrineRouter);
router.use(emailInspectorRouter);

export default router;
