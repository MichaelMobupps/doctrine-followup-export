# Batch B8c.2 — req.params Cast Injection

**Scope.** Complete the typecheck cleanup. Address the 21 errors that survived B8c and B8c.1 by casting `req.params.<ident>` to `string` at every site in the 5 affected route files. The earlier two attempts (B8c, B8c.1) both targeted `req.query.X`, but the real failures are on `req.params.<id>` — the Express 5 + @types/express setup in this codebase widens `req.params.<key>` to `string | string[]` rather than the documented `string`.

## Why req.params is widened

Unusual but real. In standard Express 4 + @types/express, `req.params` is `ParamsDictionary` and property access returns `string`. This codebase resolves `req.params.X` to `string | string[]`, which means either:
- A custom `Express.Request` augmentation in a `.d.ts` file
- A `Router<P>` generic instantiated with the wider type somewhere in middleware
- A package-version mismatch between Express, @types/express, and the qs library

I do not have the type-augmentation chain visible from this side. Investigating and fixing the root cause would resolve all 21 errors with a single edit, but requires another diagnostic round on `*.d.ts` files, middleware, and tsconfig `types` resolution. **Logged as a follow-up; this batch ships the surface fix.**

The surface fix matches the existing codebase pattern: `as string` casts at the call site. The codebase already does this for `req.query.X` in many places (e.g. `doctrine.ts:110,173,179,692`). Applying the same convention to `req.params.<ident>` is consistent.

## What the script does

`scripts/fix-req-params-casts.py` scans 5 files for every `req.params.<ident>` occurrence not already wrapped in `String(...)` or cast with `as <word>`, and wraps each with `(... as string)`.

File-scan rather than line-targeted (B8c.1 was bitten by stale line numbers from a typecheck snapshot that drifted between sessions). The regex is narrow — only matches `req.params.<ident>` as a member access, not `req.params` as a whole object, not destructured locals, not `req.body` or `req.headers` or any other `req.X`.

**Behavioural test results** (synthetic fixtures covering 6 representative patterns):
- Simple `parseInt(req.params.id)` → wrapped ✓
- Already-cast `req.params.id as string` → SKIPPED ✓
- Already wrapped `String(req.params.id)` → SKIPPED ✓
- Boolean check `if (req.params.id)` → wrapped (harmless) ✓
- Property access `.length` → wrapped, still works ✓
- Object-literal property value (email-inspector pattern) → wrapped ✓
- Idempotent re-run → 0 sites ✓

## Risk surface

1. **All edits are type-only.** Cast assertions are erased at runtime; esbuild output is unchanged.
2. **The regex is narrow.** Only `req.params.<ident>` member access patterns. Cannot match `req.query`, `req.body`, `req.headers`, destructured locals, or `req.params` used as a whole object.
3. **Idempotency.** Re-runs are NOOP because the negative lookahead skips already-cast sites.
4. **Files outside the 5-file allowlist are untouched.** Other route files might have `req.params.id` usages too, but if they didn't error in typecheck they don't need wrapping. Going broader would be unnecessary churn.
5. **Email-inspector line-370 cascading anys.** Once the line-370 `req.params.threadId` is cast, the googleapis overload resolves to the correct return type variant, and the implicit-any errors at lines 376/378/381/398/414 are expected to collapse. If any survive, they are real separate issues to address in a follow-up.

## Follow-up flagged (not in this batch)

**Root-cause fix on `req.params` typing.** A single edit to wherever the `Request` type is augmented (or the `Router` generic is widened) would clean up all 21 call sites at once. Worth doing eventually for code clarity, but requires investigation I can't do without seeing the `.d.ts` augmentations and middleware Router declarations in the live workspace. Defer until something forces the issue.

## Layout

```
batch-b8c2-req-params-casts/
|-- README.md
`-- scripts/
    `-- fix-req-params-casts.py
```

No source-file replacements in this batch — the script applies all edits directly to live route files. Mirror sync IS needed (5 route source files change). No workflow restart — type-only.
