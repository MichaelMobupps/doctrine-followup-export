#!/usr/bin/env node
/**
 * apply-batch7e.mjs — Phase 7e (Context Pipeline UI).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Three concerns:
 *   1. Reshape /api/context/followups response to match doctrine's
 *      snake_case shape with all original_* / max_followups / etc fields.
 *   2. Add a new /api/context/cancel-followup endpoint that takes
 *      { followup_ids: [] } (the existing /cancel is whole-prospect).
 *   3. Replace dashboard/pages/context-pipeline.tsx (placeholder from
 *      7d) with a Pipeline clone retargeted to /api/context/* with the
 *      vertical filter and queue-batch UI removed, and the typed
 *      api-client-react hooks replaced with raw fetch + 30s polling.
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src DASH_BASE=artifacts/dashboard/src \
 *     node apply-batch7e.mjs
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync } from "fs";
import { join } from "path";

const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const log  = (msg) => console.log(`[apply-batch7e] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7e] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const contextRoutePath = join(API_BASE, "routes", "context.ts");
const pipelinePath     = join(DASH_BASE, "pages", "pipeline.tsx");
const ctxPipelinePath  = join(DASH_BASE, "pages", "context-pipeline.tsx");

// ============================================================
// Step 1: Reshape /api/context/followups response
// ============================================================
log("Step 1: Reshape /api/context/followups response...");

strReplace(
  contextRoutePath,
  `router.get("/followups", async (req: Request, res: Response) => {
  try {
    const conds = [SCOPE];
    if (req.query.userId) conds.push(eq(prospectsTable.userId, parseInt(req.query.userId as string)));
    if (req.query.email)  conds.push(eq(prospectsTable.email, String(req.query.email)));

    const rows = await db
      .select({
        followupId: followupsTable.id,
        prospectId: followupsTable.prospectId,
        stage: followupsTable.stage,
        status: followupsTable.status,
        scheduledAt: followupsTable.scheduledAt,
        sentAt: followupsTable.sentAt,
        generatedSubject: followupsTable.generatedSubject,
        generatedBody: followupsTable.generatedBody,
        gmailMessageId: followupsTable.gmailMessageId,
        draftMessageId: followupsTable.draftMessageId,
        errorMessage: followupsTable.errorMessage,
        prospectName: prospectsTable.prospectName,
        company: prospectsTable.company,
        email: prospectsTable.email,
        subject: prospectsTable.subject,
        gmailThreadId: prospectsTable.gmailThreadId,
        replied: prospectsTable.replied,
        followupPaused: prospectsTable.followupPaused,
        userFollowupMode: usersTable.followupMode,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .leftJoin(usersTable, eq(prospectsTable.userId, usersTable.id))
      .where(and(...conds))
      .orderBy(desc(followupsTable.scheduledAt))
      .limit(500);

    res.json(rows);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});`,
  `// Phase 7e: reshape to match the doctrine /api/followups response shape
// (snake_case keys + original_* fields + max_followups + created_at).
// The Context Pipeline UI consumes the same FollowupRow type as the
// Doctrine Pipeline UI; keeping the wire format identical means the
// UI components don't need to fork on product.
router.get("/followups", async (req: Request, res: Response) => {
  try {
    const conds = [SCOPE];
    if (req.query.userId) conds.push(eq(prospectsTable.userId, parseInt(req.query.userId as string)));
    if (req.query.email)  conds.push(eq(prospectsTable.email, String(req.query.email)));

    const rows = await db
      .select({
        id: followupsTable.id,
        prospectId: followupsTable.prospectId,
        stage: followupsTable.stage,
        status: followupsTable.status,
        scheduledAt: followupsTable.scheduledAt,
        generatedBody: followupsTable.generatedBody,
        generatedSubject: followupsTable.generatedSubject,
        sentAt: followupsTable.sentAt,
        gmailMessageId: followupsTable.gmailMessageId,
        errorMessage: followupsTable.errorMessage,
        createdAt: followupsTable.createdAt,
        prospectName: prospectsTable.prospectName,
        company: prospectsTable.company,
        email: prospectsTable.email,
        vertical: prospectsTable.vertical,
        originalSubject: prospectsTable.subject,
        originalBodySummary: prospectsTable.originalBodySummary,
        originalBody: prospectsTable.originalBody,
        originalLanguage: prospectsTable.originalLanguage,
        originalSentAt: prospectsTable.sentAt,
        gmailThreadId: prospectsTable.gmailThreadId,
        followupPaused: prospectsTable.followupPaused,
        replied: prospectsTable.replied,
        userMaxFollowups: usersTable.maxFollowups,
        userFollowupMode: usersTable.followupMode,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .leftJoin(usersTable, eq(prospectsTable.userId, usersTable.id))
      .where(and(...conds))
      .orderBy(asc(followupsTable.scheduledAt))
      .limit(500);

    const result = rows.map((r) => ({
      id: r.id,
      prospect_id: r.prospectId,
      stage: r.stage,
      status: r.status,
      scheduled_at: r.scheduledAt.toISOString(),
      generated_body: r.generatedBody,
      generated_subject: r.generatedSubject,
      sent_at: r.sentAt?.toISOString() || null,
      gmail_message_id: r.gmailMessageId,
      error_message: r.errorMessage,
      created_at: r.createdAt.toISOString(),
      prospect_name: r.prospectName,
      company: r.company,
      email: r.email,
      vertical: r.vertical,
      original_subject: r.originalSubject,
      original_body_summary: r.originalBodySummary,
      original_body: r.originalBody,
      original_language: r.originalLanguage,
      original_sent_at: r.originalSentAt?.toISOString() || null,
      gmail_thread_id: r.gmailThreadId,
      followup_paused: r.followupPaused,
      replied: r.replied,
      max_followups: r.userMaxFollowups ?? 3,
      followup_mode: r.userFollowupMode ?? "auto_send",
    }));

    res.json(result);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});`,
  "context.ts: reshape /followups response",
  `// Phase 7e: reshape to match the doctrine /api/followups response shape`
);

// ============================================================
// Step 2: Add /cancel-followup endpoint
// ============================================================
log("Step 2: Add /cancel-followup endpoint...");

strReplace(
  contextRoutePath,
  `router.post("/cancel", async (req: Request, res: Response) => {`,
  `// Phase 7e: cancel specific follow-ups by id (single-stage cancellation
// from the Context Pipeline UI). Mirrors the doctrine /cancel contract.
router.post("/cancel-followup", async (req: Request, res: Response) => {
  try {
    const { followup_ids } = req.body;

    if (!Array.isArray(followup_ids) || followup_ids.length === 0) {
      res.status(400).json({ error: "Missing followup_ids" });
      return;
    }

    // Defense-in-depth: only cancel follow-ups whose prospect is app='context'.
    const result = await db
      .update(followupsTable)
      .set({ status: "cancelled" })
      .where(
        and(
          inArray(followupsTable.id, followup_ids),
          eq(followupsTable.status, "queued"),
          inArray(
            followupsTable.prospectId,
            db.select({ id: prospectsTable.id }).from(prospectsTable).where(SCOPE),
          ),
        ),
      );

    res.json({ cancelled: result.rowCount || 0 });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

router.post("/cancel", async (req: Request, res: Response) => {`,
  "context.ts: add /cancel-followup endpoint",
  `router.post("/cancel-followup", async (req: Request, res: Response) => {`
);

// ============================================================
// Step 3: Replace context-pipeline.tsx placeholder with Pipeline clone
// ============================================================
log("Step 3: Build context-pipeline.tsx from pipeline.tsx...");

const placeholderMarker = "Pipeline UI ships in Phase 7e";
// Use a marker that ONLY appears after the transformations land — the
// component name "ContextPipeline" alone collides with the 7d placeholder.
const cloneMarker        = "// Phase 7e: ContextPipeline — clone of pipeline.tsx retargeted to";

const ctxCurrent = readFileOrFail(ctxPipelinePath);
if (ctxCurrent.includes(cloneMarker)) {
  log(`  [=] context-pipeline.tsx (already cloned)`);
} else if (ctxCurrent.includes(placeholderMarker)) {
  if (!existsSync(pipelinePath)) fail(`Source pipeline.tsx not found at ${pipelinePath}`);
  copyFileSync(pipelinePath, ctxPipelinePath);
  log(`  [+] Copied pipeline.tsx → context-pipeline.tsx (will transform next)`);
} else if (ctxCurrent.includes("export default function Pipeline()")) {
  // Mid-state: file is a copy of pipeline.tsx but transforms haven't all
  // landed. Leave it alone — the str_replaces below will pick up where
  // they left off.
  log(`  [~] context-pipeline.tsx (partial transform — resuming)`);
} else {
  fail(`context-pipeline.tsx is in an unexpected state — neither placeholder nor pipeline-clone nor transform marker present`);
}

// ----- Transform 1: drop @tanstack/react-query useQueryClient import line -----
strReplace(
  ctxPipelinePath,
  `import React, { useState, useMemo, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { format, formatDistanceToNow, isPast } from "date-fns";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";
import { useGetFollowups, useCancelFollowups, useQueueBatch } from "@workspace/api-client-react";
import { Card, Button, Badge, Select, Modal, Input } from "@/components/ui";
import {
  Send, AlertCircle, Check, X, ChevronDown, ChevronUp, Loader2,
  Pause, Play, Plus, Clock, Ban, Square, Eye, EyeOff, MoreHorizontal, Mail, ExternalLink,
  Layers, CheckSquare, MinusSquare,
} from "lucide-react";`,
  `// Phase 7e: ContextPipeline — clone of pipeline.tsx retargeted to
// /api/context/* endpoints. The vertical filter and queue-batch UI
// are removed. Data fetching uses raw fetch + setInterval polling
// (no @workspace/api-client-react hooks for the context surface).
import React, { useState, useMemo, useEffect } from "react";
import { format } from "date-fns";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";
import { Card, Button, Select } from "@/components/ui";
import {
  Send, AlertCircle, Check, X, ChevronDown, ChevronUp, Loader2,
  Pause, Play, Plus, Clock, Ban, Square, Eye, EyeOff, MoreHorizontal, Mail, ExternalLink,
  CheckSquare, MinusSquare,
} from "lucide-react";`,
  "ctx-pipeline: trim imports",
  `// Phase 7e: ContextPipeline — clone of pipeline.tsx retargeted to`
);

// ----- Transform 2: rename component to ContextPipeline + drop queryClient -----
strReplace(
  ctxPipelinePath,
  `export default function Pipeline() {
  const { apiKey } = useApiKey();
  const { user: currentUser } = useCurrentUser();
  const queryClient = useQueryClient();
  const requestOpts = { request: { headers: { "x-api-key": apiKey || "" } } };`,
  `export default function ContextPipeline() {
  const { apiKey } = useApiKey();
  const { user: currentUser } = useCurrentUser();`,
  "ctx-pipeline: rename component, drop queryClient",
  `export default function ContextPipeline()`
);

// ----- Transform 3: drop vertical-filter state (filterVertical) -----
strReplace(
  ctxPipelinePath,
  `  const [filterState, setFilterState] = useState<string>("all");
  const [filterVertical, setFilterVertical] = useState<string>("all");`,
  `  // Phase 7e: filterVertical state removed.
  const [filterState, setFilterState] = useState<string>("all");`,
  "ctx-pipeline: drop filterVertical state",
  `// Phase 7e: filterVertical state removed.`
);

// ----- Transform 4: drop queue-batch state -----
strReplace(
  ctxPipelinePath,
  `  const [isQueueModalOpen, setIsQueueModalOpen] = useState(false);
  const [queueVertical, setQueueVertical] = useState("all");
  const [queueDate, setQueueDate] = useState("");
  const [queueStage, setQueueStage] = useState("1");

  // Multi-select state for bulk actions (Batch 2)`,
  `  // Phase 7e: queue-batch UI is doctrine-specific; removed for context.

  // Multi-select state for bulk actions (Batch 2)`,
  "ctx-pipeline: drop queue-batch state",
  `// Phase 7e: queue-batch UI is doctrine-specific; removed for context.`
);

// ----- Transform 5: replace useGetFollowups / useCancelFollowups / useQueueBatch
//        with raw-fetch + setInterval + refetchTrigger -----
strReplace(
  ctxPipelinePath,
  `  const { data: followups, isLoading, isError } = useGetFollowups(
    { ...(currentUser?.userId ? { userId: String(currentUser.userId) } : {}) },
    { ...requestOpts, query: { enabled: !!apiKey, refetchInterval: 30000 } }
  );

  const cancelMutation = useCancelFollowups({
    ...requestOpts,
    mutation: { onSuccess: () => invalidateAll() },
  });

  const queueBatchMutation = useQueueBatch({
    ...requestOpts,
    mutation: {
      onSuccess: (data: any) => {
        const queued = data?.queued ?? 0;
        showFeedback(\`Queued \${queued} follow-up\${queued !== 1 ? "s" : ""}\`);
        setIsQueueModalOpen(false);
        invalidateAll();
      },
      onError: () => showFeedback("Failed to queue batch", true),
    },
  });

  const handleQueueBatch = (e: React.FormEvent) => {
    e.preventDefault();
    queueBatchMutation.mutate({
      data: {
        stage: parseInt(queueStage),
        ...(queueVertical !== "all" ? { vertical: queueVertical } : {}),
        ...(queueDate ? { sent_date: queueDate } : {}),
      },
    });
  };`,
  `  // Phase 7e: raw-fetch data layer for the context flow. 30s poll
  // interval matches the doctrine refetchInterval. \`refetchTrigger\`
  // bumps after every mutation to force an immediate refetch.
  const [followups, setFollowups] = useState<FollowupRow[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [refetchTrigger, setRefetchTrigger] = useState(0);

  useEffect(() => {
    if (!apiKey) return;
    let cancelled = false;

    async function fetchFollowups() {
      try {
        const base = import.meta.env.BASE_URL || "/";
        const url = currentUser?.userId
          ? \`\${base}api/context/followups?userId=\${currentUser.userId}\`
          : \`\${base}api/context/followups\`;
        const res = await fetch(url, { headers: { "x-api-key": apiKey || "" } });
        if (cancelled) return;
        if (!res.ok) { setIsError(true); setIsLoading(false); return; }
        const data = await res.json();
        if (cancelled) return;
        setFollowups(Array.isArray(data) ? data : []);
        setIsError(false);
        setIsLoading(false);
      } catch {
        if (!cancelled) { setIsError(true); setIsLoading(false); }
      }
    }

    fetchFollowups();
    const interval = setInterval(fetchFollowups, 30000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [apiKey, currentUser?.userId, refetchTrigger]);

  // Cancel one queued follow-up by id. Mirrors the doctrine cancelMutation
  // contract \`{ followup_ids: [...] }\` — handled by /api/context/cancel-followup.
  async function cancelStageById(stageId: number) {
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(\`\${base}api/context/cancel-followup\`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-api-key": apiKey || "" },
        body: JSON.stringify({ followup_ids: [stageId] }),
      });
      if (!res.ok) {
        showFeedback("Failed to cancel follow-up", true);
        return;
      }
      showFeedback("Cancelled");
      invalidateAll();
    } catch {
      showFeedback("Failed to cancel follow-up", true);
    }
  }`,
  "ctx-pipeline: replace typed hooks with raw fetch",
  `// Phase 7e: raw-fetch data layer for the context flow. 30s poll`
);

// ----- Transform 6: invalidateAll uses refetchTrigger -----
strReplace(
  ctxPipelinePath,
  `  function invalidateAll() {
    queryClient.invalidateQueries({ queryKey: ["/api/followups"] });
    queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
    queryClient.invalidateQueries({ queryKey: ["/api/prospects"] });
  }`,
  `  function invalidateAll() {
    // Phase 7e: bump refetchTrigger to force the polling effect to re-fire.
    setRefetchTrigger((t) => t + 1);
  }`,
  "ctx-pipeline: invalidateAll via refetchTrigger",
  `// Phase 7e: bump refetchTrigger to force the polling effect to re-fire.`
);

// ----- Transform 7: filteredThreads — drop the filterVertical condition -----
strReplace(
  ctxPipelinePath,
  `  const filteredThreads = useMemo(() => {
    return threads.filter(t => {
      if (filterState === "active" && (t.all_done || t.followup_paused || t.replied)) return false;
      if (filterState === "paused" && !t.followup_paused) return false;
      if (filterState === "completed" && !t.all_done) return false;
      if (filterState === "pending" && !t.stages.some(s => s.status === "pending_approval")) return false;
      if (filterVertical !== "all" && t.vertical !== filterVertical) return false;
      return true;
    });
  }, [threads, filterState, filterVertical]);`,
  `  const filteredThreads = useMemo(() => {
    // Phase 7e: vertical filter removed for context flow.
    return threads.filter(t => {
      if (filterState === "active" && (t.all_done || t.followup_paused || t.replied)) return false;
      if (filterState === "paused" && !t.followup_paused) return false;
      if (filterState === "completed" && !t.all_done) return false;
      if (filterState === "pending" && !t.stages.some(s => s.status === "pending_approval")) return false;
      return true;
    });
  }, [threads, filterState]);`,
  "ctx-pipeline: filteredThreads drop vertical filter",
  `// Phase 7e: vertical filter removed for context flow.`
);

// ----- Transform 8: API URLs in handlers -----
strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/followup/send-bulk\`, {`,
  `      const res = await fetch(\`\${base}api/context/followup/send-bulk\`, {`,
  "ctx-pipeline: URL /followup/send-bulk → /context/...",
  `\${base}api/context/followup/send-bulk`
);

strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/prospect/pause-bulk\`, {`,
  `      const res = await fetch(\`\${base}api/context/prospect/pause-bulk\`, {`,
  "ctx-pipeline: URL /prospect/pause-bulk → /context/...",
  `\${base}api/context/prospect/pause-bulk`
);

strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/prospect/\${prospectId}/\${endpoint}\`, {`,
  `      const res = await fetch(\`\${base}api/context/prospect/\${prospectId}/\${endpoint}\`, {`,
  "ctx-pipeline: URL /prospect/:id/{pause|resume} → /context/...",
  `\${base}api/context/prospect/\${prospectId}/\${endpoint}`
);

strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/followup-now/\${prospectId}\`, {`,
  `      const res = await fetch(\`\${base}api/context/followup-now/\${prospectId}\`, {`,
  "ctx-pipeline: URL /followup-now/:prospectId → /context/...",
  `\${base}api/context/followup-now/\${prospectId}`
);

// /prospect/:id/resume appears twice — once in handleTogglePause (resolved by /prospect/:id/${endpoint})
// and once in handleResumeStalled. The second is a literal /resume URL.
strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/prospect/\${prospectId}/resume\`, {`,
  `      const res = await fetch(\`\${base}api/context/prospect/\${prospectId}/resume\`, {`,
  "ctx-pipeline: URL /prospect/:id/resume (handleResumeStalled) → /context/...",
  `\${base}api/context/prospect/\${prospectId}/resume`
);

strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/followups/\${id}/approve\`, {`,
  `      const res = await fetch(\`\${base}api/context/followups/\${id}/approve\`, {`,
  "ctx-pipeline: URL /followups/:id/approve → /context/...",
  `\${base}api/context/followups/\${id}/approve`
);

strReplace(
  ctxPipelinePath,
  `      const res = await fetch(\`\${base}api/followups/\${id}/reject\`, {`,
  `      const res = await fetch(\`\${base}api/context/followups/\${id}/reject\`, {`,
  "ctx-pipeline: URL /followups/:id/reject → /context/...",
  `\${base}api/context/followups/\${id}/reject`
);

// ----- Transform 9: title text -----
strReplace(
  ctxPipelinePath,
  `        <h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>
          Pipeline
        </h1>`,
  `        <h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>
          Context Pipeline
        </h1>`,
  "ctx-pipeline: title text",
  `>
          Context Pipeline
        </h1>`
);

// ----- Transform 10: replace the header counters block to drop "Queue follow-ups" button -----
strReplace(
  ctxPipelinePath,
  `          <Button onClick={() => setIsQueueModalOpen(true)} className="gap-2">
            <Layers className="h-4 w-4" />
            Queue follow-ups
          </Button>
        </div>
      </div>`,
  `          {/* Phase 7e: Queue follow-ups button removed (doctrine-specific). */}
        </div>
      </div>`,
  "ctx-pipeline: drop Queue-follow-ups button",
  `{/* Phase 7e: Queue follow-ups button removed (doctrine-specific). */}`
);

// ----- Transform 11: drop the vertical filter Select block from the filters row -----
strReplace(
  ctxPipelinePath,
  `        <div className="w-48">
          <label
            className="block mb-1.5 font-medium uppercase tracking-[0.04em]"
            style={{ fontSize: "11px", color: "var(--text-tertiary)" }}
          >
            VERTICAL
          </label>
          <Select value={filterVertical} onChange={e => setFilterVertical(e.target.value)}>
            <option value="all">All verticals</option>
            <option value="gaming_ua">Gaming UA</option>
            <option value="non_gaming_ua">Non-Gaming UA</option>
            <option value="cps">CPS</option>
            <option value="retargeting">Retargeting</option>
          </Select>
        </div>
      </div>`,
  `        {/* Phase 7e: VERTICAL filter removed (doctrine-specific). */}
      </div>`,
  "ctx-pipeline: drop VERTICAL filter Select",
  `{/* Phase 7e: VERTICAL filter removed (doctrine-specific). */}`
);

// ----- Transform 12: replace cancelMutation.mutate(...) with cancelStageById(...) -----
strReplace(
  ctxPipelinePath,
  `                                {stage.status === "queued" && (
                                  <Button
                                    variant="ghost" size="sm"
                                    onClick={() => {
                                      if (confirm("Cancel this queued followup?")) {
                                        cancelMutation.mutate({ data: { followup_ids: [stage.id] } });
                                      }
                                    }}
                                    style={{ color: "var(--text-tertiary)", padding: "4px 8px" }}
                                    title="Cancel this stage"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                )}`,
  `                                {stage.status === "queued" && (
                                  <Button
                                    variant="ghost" size="sm"
                                    onClick={() => {
                                      if (confirm("Cancel this queued followup?")) {
                                        cancelStageById(stage.id);
                                      }
                                    }}
                                    style={{ color: "var(--text-tertiary)", padding: "4px 8px" }}
                                    title="Cancel this stage"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                )}`,
  "ctx-pipeline: cancelMutation → cancelStageById",
  `cancelStageById(stage.id);`
);

// ----- Transform 13: drop the queue-batch <Modal> block -----
strReplace(
  ctxPipelinePath,
  `      <Modal
        isOpen={isQueueModalOpen}
        onClose={() => setIsQueueModalOpen(false)}
        title="Queue follow-ups batch"
        description="Schedule follow-ups for unreplied prospects."
      >
        <form onSubmit={handleQueueBatch} className="space-y-5 mt-4">
          <div className="space-y-1.5">
            <label className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>Target Vertical</label>
            <Select value={queueVertical} onChange={e => setQueueVertical(e.target.value)}>
              <option value="all">All verticals</option>
              <option value="gaming_ua">Gaming UA</option>
              <option value="non_gaming_ua">Non-Gaming UA</option>
              <option value="cps">CPS</option>
              <option value="retargeting">Retargeting</option>
            </Select>
          </div>

          <div className="space-y-1.5">
            <label className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>Initial Sent Date</label>
            <Input
              type="date"
              value={queueDate}
              onChange={e => setQueueDate(e.target.value)}
              className="w-full [color-scheme:dark]"
            />
            <p className="text-[11px]" style={{ color: "var(--text-tertiary)" }}>Leave blank to target all dates.</p>
          </div>

          <div className="space-y-1.5">
            <label className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>Follow-up Stage</label>
            <Select value={queueStage} onChange={e => setQueueStage(e.target.value)} required>
              <option value="1">Stage 1</option>
              <option value="2">Stage 2</option>
              <option value="3">Stage 3</option>
            </Select>
          </div>

          {queueBatchMutation.isError && (
            <div className="p-3 rounded-lg flex items-center gap-2 text-[13px]" style={{ background: "var(--danger-muted)", color: "var(--danger)", border: "1px solid var(--danger-border)" }}>
              <AlertCircle className="h-4 w-4" />
              Failed to queue batch.
            </div>
          )}

          <div className="pt-4 flex gap-3 justify-end" style={{ borderTop: "1px solid var(--border-default)" }}>
            <Button type="button" variant="ghost" onClick={() => setIsQueueModalOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={queueBatchMutation.isPending}>
              Queue follow-ups
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}`,
  `      {/* Phase 7e: Queue-batch modal removed (doctrine-specific). */}
    </div>
  );
}`,
  "ctx-pipeline: drop queue-batch Modal",
  `{/* Phase 7e: Queue-batch modal removed (doctrine-specific). */}`
);

// ----- Transform 14: empty-state copy — drop "queue a batch from Prospects" -----
strReplace(
  ctxPipelinePath,
  `          <p className="text-[13px]" style={{ color: "var(--text-secondary)" }}>
            Adjust filters or queue a batch from Prospects.
          </p>`,
  `          <p className="text-[13px]" style={{ color: "var(--text-secondary)" }}>
            Adjust filters or label a Gmail thread with the Context label.
          </p>`,
  "ctx-pipeline: empty-state copy",
  `Adjust filters or label a Gmail thread with the Context label.`
);

// ----- Transform 15: drop the VERTICAL_LABELS rendering line in the expanded view -----
strReplace(
  ctxPipelinePath,
  `                        <span className="text-[11px]" style={{ color: "var(--text-tertiary)" }}>
                          {VERTICAL_LABELS[thread.vertical] || thread.vertical}
                        </span>`,
  `                        {/* Phase 7e: vertical label hidden — context prospects don't carry one. */}`,
  "ctx-pipeline: drop vertical label render",
  `{/* Phase 7e: vertical label hidden — context prospects don't carry one. */}`
);

// ============================================================
// Step 4: Self-verify
// ============================================================
log("Step 4: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Backend
expectInFile(contextRoutePath, `// Phase 7e: reshape to match the doctrine /api/followups response shape`, "V1  context.ts /followups reshape");
expectInFile(contextRoutePath, `original_subject: r.originalSubject,`, "V2  /followups returns snake_case original_subject");
expectInFile(contextRoutePath, `max_followups: r.userMaxFollowups ?? 3,`, "V3  /followups returns max_followups");
expectInFile(contextRoutePath, `router.post("/cancel-followup"`, "V4  /cancel-followup endpoint");
expectInFile(contextRoutePath, `// Defense-in-depth: only cancel follow-ups whose prospect is app='context'.`, "V5  /cancel-followup gate");

// Frontend — file is now the clone
expectInFile(ctxPipelinePath, `export default function ContextPipeline()`, "V6  ContextPipeline component name");
expectInFile(ctxPipelinePath, `Context Pipeline\n        </h1>`, "V7  title text");
expectInFile(ctxPipelinePath, `api/context/followups`, "V8  followups URL");
expectInFile(ctxPipelinePath, `api/context/followup/send-bulk`, "V9  send-bulk URL");
expectInFile(ctxPipelinePath, `api/context/prospect/pause-bulk`, "V10 pause-bulk URL");
expectInFile(ctxPipelinePath, `api/context/followup-now/`, "V11 followup-now URL");
expectInFile(ctxPipelinePath, `api/context/followups/\${id}/approve`, "V12 approve URL");
expectInFile(ctxPipelinePath, `api/context/followups/\${id}/reject`, "V13 reject URL");
expectInFile(ctxPipelinePath, `api/context/cancel-followup`, "V14 cancel-followup URL");
expectInFile(ctxPipelinePath, `cancelStageById(stage.id);`, "V15 cancel handler wired");
expectInFile(ctxPipelinePath, `setRefetchTrigger`, "V16 refetchTrigger present");

// Things that MUST be absent (regression)
expectNotInFile(ctxPipelinePath, `useGetFollowups`, "V17 useGetFollowups removed");
expectNotInFile(ctxPipelinePath, `useCancelFollowups`, "V18 useCancelFollowups removed");
expectNotInFile(ctxPipelinePath, `useQueueBatch`, "V19 useQueueBatch removed");
expectNotInFile(ctxPipelinePath, `useQueryClient`, "V20 useQueryClient removed");
expectNotInFile(ctxPipelinePath, `setIsQueueModalOpen(true)`, "V21 Queue-follow-ups button onClick removed");
expectNotInFile(ctxPipelinePath, `setFilterVertical`, "V22 filterVertical state-setter removed");
expectNotInFile(ctxPipelinePath, `<Modal`, "V23 Modal usage removed");
expectNotInFile(ctxPipelinePath, `queueBatchMutation`, "V24 queueBatchMutation removed");
expectNotInFile(ctxPipelinePath, `cancelMutation.mutate(`, "V25 cancelMutation.mutate() call removed");
expectNotInFile(ctxPipelinePath, `Pipeline UI ships in Phase 7e`, "V26 Placeholder marker gone");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7e patch applied. /api/context/followups returns the same");
log("shape as the doctrine endpoint. /api/context/cancel-followup is");
log("live. dashboard ContextPipeline is the real Pipeline clone, not");
log("a placeholder.");
log("================================================================");
