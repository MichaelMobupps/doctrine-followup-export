export const TEST_MODE_LABEL = "followup app test";
