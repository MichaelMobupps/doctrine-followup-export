#!/usr/bin/env node
/**
 * audit-batch7c.mjs — Beautiful-Squidward audit for Phase 7c.
 * 3 rounds × 9 passes = 27 checks per round. Every pass hard-asserts.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DB_BASE  = process.env.DB_BASE  || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7c] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7c] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const doctrineSrc = read(join(API_BASE, "routes", "doctrine.ts"));
const contextSrc  = read(join(API_BASE, "routes", "context.ts"));
const indexSrc    = read(join(API_BASE, "routes", "index.ts"));
const schedulerSrc = read(join(API_BASE, "services", "scheduler.ts"));
const gmailSyncSrc = read(join(API_BASE, "services", "gmailSync.ts"));
const anthropicSrc = read(join(API_BASE, "lib", "anthropic.ts"));
const prospectsSchemaSrc = read(join(DB_BASE, "schema", "prospects.ts"));
const usersSchemaSrc = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: SCOPE_DOCTRINE constant exists
  log(`-- PASS 1: SCOPE_DOCTRINE constant exists --`);
  pass(
    `SCOPE_DOCTRINE constant declared in doctrine.ts`,
    /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineSrc)
  );
  pass(
    `SCOPE_DOCTRINE referenced ≥30 times`,
    (doctrineSrc.split("SCOPE_DOCTRINE").length - 1) >= 30
  );
  pass(
    `Phase 7c comment present`,
    /Phase 7c: app-scoping/.test(doctrineSrc)
  );

  // PASS 2: every prospect by-id lookup is scoped
  log(`-- PASS 2: by-id prospect lookups are scoped --`);
  // Helper: find every line with `eq(prospectsTable.id, ` and verify
  // an SCOPE_DOCTRINE appears within 3 lines before or after.
  const lines = doctrineSrc.split("\n");
  let scopedById = 0, totalById = 0;
  for (let i = 0; i < lines.length; i++) {
    if (!/eq\(prospectsTable\.id,/.test(lines[i])) continue;
    // Skip lines that are part of a join condition like `eq(followupsTable.prospectId, prospectsTable.id)`
    if (/followupsTable\.prospectId, prospectsTable\.id/.test(lines[i])) continue;
    // Skip lines defining labelConditions per-user (eq(prospectsTable.userId, u.id))
    if (/labelConditions/.test(lines[Math.max(0, i - 1)])) continue;
    totalById++;
    const window = lines.slice(Math.max(0, i - 2), Math.min(lines.length, i + 3)).join("\n");
    if (window.includes("SCOPE_DOCTRINE")) scopedById++;
  }
  pass(`Every direct prospects.id lookup is scoped (${scopedById}/${totalById})`, scopedById === totalById && totalById > 0);

  // PASS 3: every direct prospects.userId filter is reachable from a SCOPE_DOCTRINE
  log(`-- PASS 3: prospects.userId filters reachable from a scope --`);
  let scopedByUser = 0, totalByUser = 0;
  const naked3 = [];
  for (let i = 0; i < lines.length; i++) {
    if (!/(eq|inArray)\(prospectsTable\.userId/.test(lines[i])) continue;
    // Skip join conditions
    if (/leftJoin|innerJoin/.test(lines[i])) continue;
    // Skip labelConditions construction (per-user batch-label match — not
    // a filter; gets OR'd into a SCOPE_DOCTRINE-protected where below).
    if (/labelConditions/.test(lines[Math.max(0, i - 1)]) || /labelConditions/.test(lines[Math.max(0, i - 2)])) continue;
    totalByUser++;
    // Wide window: 60 lines back (covers conditions[] seeded with SCOPE_DOCTRINE
    // at the top of /prospects and /followups list endpoints; covers labelConditions
    // → where() distance in /campaign/queue and /campaign/launch).
    const window = lines.slice(Math.max(0, i - 60), Math.min(lines.length, i + 5)).join("\n");
    if (window.includes("SCOPE_DOCTRINE")) {
      scopedByUser++;
    } else {
      naked3.push(`L${i + 1}: ${lines[i].trim()}`);
    }
  }
  if (naked3.length > 0) {
    log(`UNSCOPED prospects.userId references:`);
    for (const n of naked3) log(`    ${n}`);
  }
  pass(`Every direct prospects.userId filter has SCOPE_DOCTRINE within reach (${scopedByUser}/${totalByUser})`, scopedByUser === totalByUser && totalByUser > 0);

  // PASS 4: campaign endpoints (queue/launch/status/stop) all scoped
  log(`-- PASS 4: campaign endpoints scoped --`);
  pass(`/campaign/status group is scoped`, /\.where\(and\(SCOPE_DOCTRINE, inArray\(prospectsTable\.userId!, userIds\)\)\)\s*\n\s*\.groupBy\(prospectsTable\.userId, prospectsTable\.batchLabel\)/.test(doctrineSrc));
  pass(`/campaign/status actionable is scoped`, /and\(\s*SCOPE_DOCTRINE,\s*\n\s*eq\(prospectsTable\.replied, 0\),\s*\n\s*eq\(prospectsTable\.followupPaused, false\),\s*\n\s*inArray\(prospectsTable\.userId!, userIds\)/.test(doctrineSrc));
  pass(`/campaign/queue + /campaign/launch are scoped`, (doctrineSrc.match(/and\(\s*SCOPE_DOCTRINE,\s*\n\s*eq\(prospectsTable\.replied, 0\),\s*\n\s*eq\(prospectsTable\.followupPaused, false\),\s*\n\s*or\(\.\.\.labelConditions\)/g) || []).length >= 2);
  pass(`/campaign/stop global has where(SCOPE_DOCTRINE)`, /\.from\(prospectsTable\)\s*\n\s*\.where\(SCOPE_DOCTRINE\);\s*\n\s*cancelledCount = await cancelActiveFollowupsForProspects/.test(doctrineSrc));

  // PASS 5: /stats prospect + followup queries scoped
  log(`-- PASS 5: /stats endpoint scoped --`);
  pass(`/stats prospectConditions includes SCOPE_DOCTRINE`, /Phase 7c: always scope to doctrine, optionally narrow by user\.\s*\n\s*const prospectConditions = userIdFilter\s*\n\s*\? and\(SCOPE_DOCTRINE, eq\(prospectsTable\.userId, userIdFilter\)\)\s*\n\s*: SCOPE_DOCTRINE;/.test(doctrineSrc));
  pass(`/stats followup join — both branches scoped`, (doctrineSrc.match(/\.innerJoin\(prospectsTable, eq\(followupsTable\.prospectId, prospectsTable\.id\)\)\s*\n\s*\.where\((and\(SCOPE_DOCTRINE,|SCOPE_DOCTRINE\))/g) || []).length >= 2);

  // PASS 6: list endpoints (/prospects, /followups) seed conditions[] with SCOPE_DOCTRINE
  log(`-- PASS 6: list endpoints scoped via conditions[] seed --`);
  pass(`/prospects conditions[] seeded`, /\/\/ Phase 7c: scope all returned prospects to the doctrine app\.\s*\n\s*const conditions: any\[\] = \[SCOPE_DOCTRINE\];/.test(doctrineSrc));
  pass(`/followups conditions[] seeded`, /\/\/ Phase 7c: scope to doctrine via the prospects inner-join\.\s*\n\s*const conditions: any\[\] = \[SCOPE_DOCTRINE\];/.test(doctrineSrc));

  // PASS 7: approve/reject followup endpoints scoped
  log(`-- PASS 7: /approve and /reject scoped --`);
  pass(`/approve SELECT scoped`, /\.where\(and\(SCOPE_DOCTRINE, eq\(followupsTable\.id, followupId\), eq\(followupsTable\.status, "pending_approval"\)\)\)/.test(doctrineSrc));
  pass(`/reject UPDATE has sub-select gate`, /Phase 7c: gate by prospect\.app via sub-select/.test(doctrineSrc));
  pass(`/reject sub-select uses SCOPE_DOCTRINE`, /db\.select\(\{ id: prospectsTable\.id \}\)\.from\(prospectsTable\)\.where\(SCOPE_DOCTRINE\)/.test(doctrineSrc));

  // PASS 8: B7b (context) regression — context routes mounted, scope filter unchanged
  log(`-- PASS 8: B7b regression — context routes intact --`);
  pass(`routes/context.ts uses SCOPE constant`, /const SCOPE = eq\(prospectsTable\.app, "context"\)/.test(contextSrc));
  pass(`/context router mounted in routes/index.ts`, /router\.use\("\/context", contextRouter\)/.test(indexSrc));
  pass(`scheduler dispatches by app`, /item\.app === "context"/.test(schedulerSrc));
  pass(`gmailSync scans both labels`, /contextLabel/.test(gmailSyncSrc));

  // PASS 9: B7a + B5 + B6 regression
  log(`-- PASS 9: B7a/B6/B5 regression --`);
  pass(`prospects.app column exists`, /app:\s*text\("app"\)\.\$type<ProspectApp>\(\)\.notNull\(\)\.default\("doctrine"\)/.test(prospectsSchemaSrc));
  pass(`prospects.app type enum + per-app index`, /ProspectApp/.test(prospectsSchemaSrc) && /idx_prospects_app/.test(prospectsSchemaSrc));
  pass(`users.contextLabel column exists`, /contextLabel:\s*text\("context_label"\)\.notNull\(\)\.default\("Context Followuper"\)/.test(usersSchemaSrc));
  pass(`B5 model constants present`, /MODEL_SUMMARIZER\b/.test(anthropicSrc) && /MODEL_DRAFT_GENERATOR\b/.test(anthropicSrc) && /MODEL_CRITIC\b/.test(anthropicSrc) && /MODEL_REWRITER\b/.test(anthropicSrc));
  pass(`B5 context model constants present`, /MODEL_CONTEXT_GENERATOR\b/.test(anthropicSrc) && /MODEL_CONTEXT_CRITIC\b/.test(anthropicSrc) && /MODEL_CONTEXT_REWRITER\b/.test(anthropicSrc));
  pass(`B6 send budget present`, /checkSendBudget/.test(read(join(API_BASE, "lib", "sendBudget.ts"))));
  pass(`B6 send window present`, /isInSendWindow/.test(read(join(API_BASE, "lib", "scheduleWindow.ts"))));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
