#!/usr/bin/env node
/**
 * migrate-batch7a.mjs — Phase 7a (Context Based foundation) DB migration.
 *
 * Idempotent. Transactional. Re-runs are no-ops.
 *
 * Adds two columns and one CHECK constraint:
 *
 *   prospects.app text NOT NULL DEFAULT 'doctrine'
 *     CHECK (app IN ('doctrine', 'context'))
 *   users.context_label text NOT NULL DEFAULT 'Context Followuper'
 *
 * Existing prospects rows automatically backfill to 'doctrine' via the
 * column default. No separate UPDATE pass is needed (PostgreSQL writes
 * the default into existing rows as a metadata-only operation on modern
 * PG versions, which Replit's Neon database is).
 *
 * The CHECK constraint blocks invalid `app` values at the DB level — a
 * second line of defense behind the application-level enum type.
 *
 * Usage:
 *   DATABASE_URL=postgres://... node migrate-batch7a.mjs
 */

import pg from "pg";

const { Client } = pg;

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("ERROR: DATABASE_URL is not set.");
  process.exit(1);
}

async function columnExists(client, table, column) {
  const res = await client.query(
    `SELECT 1 FROM information_schema.columns
       WHERE table_name = $1 AND column_name = $2 LIMIT 1`,
    [table, column],
  );
  return res.rowCount > 0;
}

async function constraintExists(client, table, constraintName) {
  const res = await client.query(
    `SELECT 1 FROM information_schema.table_constraints
       WHERE table_name = $1 AND constraint_name = $2 LIMIT 1`,
    [table, constraintName],
  );
  return res.rowCount > 0;
}

async function run() {
  const client = new Client({ connectionString: DATABASE_URL });
  await client.connect();

  try {
    await client.query("BEGIN");

    // ---- Step 1: prospects.app ------------------------------------------
    if (await columnExists(client, "prospects", "app")) {
      console.log("[=] prospects.app already exists; skipping ADD.");
    } else {
      await client.query(`
        ALTER TABLE prospects
        ADD COLUMN app text NOT NULL DEFAULT 'doctrine'
      `);
      console.log("[+] Added prospects.app (default 'doctrine'); existing rows backfilled.");
    }

    // ---- Step 2: prospects.app CHECK constraint ------------------------
    const checkName = "prospects_app_check";
    if (await constraintExists(client, "prospects", checkName)) {
      console.log(`[=] CHECK constraint ${checkName} already exists; skipping ADD.`);
    } else {
      await client.query(`
        ALTER TABLE prospects
        ADD CONSTRAINT ${checkName}
        CHECK (app IN ('doctrine', 'context'))
      `);
      console.log(`[+] Added CHECK constraint ${checkName} (app IN doctrine, context).`);
    }

    // ---- Step 3: users.context_label -----------------------------------
    if (await columnExists(client, "users", "context_label")) {
      console.log("[=] users.context_label already exists; skipping ADD.");
    } else {
      await client.query(`
        ALTER TABLE users
        ADD COLUMN context_label text NOT NULL DEFAULT 'Context Followuper'
      `);
      console.log("[+] Added users.context_label (default 'Context Followuper').");
    }

    await client.query("COMMIT");
    console.log("[OK] Transaction committed.");

    // ---- Verification report -------------------------------------------
    const appDist = await client.query(`
      SELECT app, COUNT(*)::int AS cnt
      FROM prospects
      GROUP BY app
      ORDER BY app
    `);
    console.log("\n--- prospects.app distribution ---");
    if (appDist.rows.length === 0) {
      console.log("  (no prospects in table yet)");
    } else {
      for (const row of appDist.rows) {
        console.log(`  app=${row.app.padEnd(10)} → ${row.cnt} prospects`);
      }
    }

    const colCheck = await client.query(`
      SELECT table_name, column_name, data_type, is_nullable, column_default
      FROM information_schema.columns
      WHERE (table_name = 'prospects' AND column_name = 'app')
         OR (table_name = 'users'     AND column_name = 'context_label')
      ORDER BY table_name, column_name
    `);
    console.log("\n--- Column verification ---");
    for (const row of colCheck.rows) {
      console.log(
        `  ${row.table_name}.${row.column_name.padEnd(15)} ${row.data_type.padEnd(8)} ` +
        `nullable=${row.is_nullable.padEnd(3)} default=${row.column_default || "(none)"}`,
      );
    }

    const constraintCheck = await client.query(`
      SELECT constraint_name, check_clause
      FROM information_schema.check_constraints
      WHERE constraint_name = 'prospects_app_check'
    `);
    console.log("\n--- CHECK constraint verification ---");
    if (constraintCheck.rows.length === 0) {
      console.log("  (no prospects_app_check found — UNEXPECTED)");
    } else {
      for (const row of constraintCheck.rows) {
        console.log(`  ${row.constraint_name}: ${row.check_clause}`);
      }
    }

    console.log("\n[DONE] Batch 7a migration complete.");
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    console.error("[FAIL] Migration error; transaction rolled back.");
    console.error(err);
    process.exitCode = 1;
  } finally {
    await client.end();
  }
}

run();
