import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { db, prospectsTable, followupsTable, usersTable } from "@workspace/db";
import { and, eq, sql, inArray, desc } from "drizzle-orm";
import { logger } from "../lib/logger";

/**
 * Context Based Followuper routes — Phase 7b.
 *
 * Mounted under /api/context/*. Mirrors the essential Doctrine routes
 * but scoped to prospects with app='context'. Sales-specific endpoints
 * (taxonomy filters, vertical-based stats, MMP-related actions) are
 * intentionally omitted — they have no place in the context flow.
 *
 * The 7c UI will consume these endpoints. After 7c ships, doctrine
 * routes will receive a parallel app='doctrine' filter so the two
 * products are visually isolated. Until then, the Context flow is
 * functional but the Doctrine UI may show context prospects mixed in.
 */

const router: IRouter = Router();

function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const key = req.headers["x-api-key"];
  const expected = process.env.ADDON_API_KEY;

  if (!expected) {
    res.status(500).json({ error: "ADDON_API_KEY not set" });
    return;
  }

  if (!key || key !== expected) {
    res.status(401).json({ error: "Invalid API key" });
    return;
  }

  next();
}

router.use(authMiddleware);

// All prospect queries are scoped to app='context' via this constant. If
// a request includes ?userId=N, it's also scoped to that user.
const SCOPE = eq(prospectsTable.app, "context");

// ====================================================================
// GET /context/stats — pipeline counts
// ====================================================================
router.get("/stats", async (req: Request, res: Response) => {
  try {
    const userIdFilter = req.query.userId ? parseInt(req.query.userId as string) : null;

    const prospectConds = [SCOPE];
    if (userIdFilter) prospectConds.push(eq(prospectsTable.userId, userIdFilter));

    const prospectStats = await db
      .select({
        totalSent: sql<number>`count(*)::int`,
        unreplied: sql<number>`sum(case when ${prospectsTable.replied} = 0 then 1 else 0 end)::int`,
        replied: sql<number>`sum(case when ${prospectsTable.replied} = 1 then 1 else 0 end)::int`,
      })
      .from(prospectsTable)
      .where(and(...prospectConds));

    const followupConds = [SCOPE];
    if (userIdFilter) followupConds.push(eq(prospectsTable.userId, userIdFilter));

    const followupStats = await db
      .select({
        queuedFollowups: sql<number>`sum(case when ${followupsTable.status} = 'queued' then 1 else 0 end)::int`,
        sentFollowups: sql<number>`sum(case when ${followupsTable.status} = 'sent' then 1 else 0 end)::int`,
        draftedFollowups: sql<number>`sum(case when ${followupsTable.status} = 'drafted' then 1 else 0 end)::int`,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(...followupConds));

    const ps = prospectStats[0];
    const fs = followupStats[0];

    res.json({
      total_sent: Number(ps?.totalSent) || 0,
      unreplied: Number(ps?.unreplied) || 0,
      replied: Number(ps?.replied) || 0,
      queued_followups: Number(fs?.queuedFollowups) || 0,
      sent_followups: Number(fs?.sentFollowups) || 0,
      drafted_followups: Number(fs?.draftedFollowups) || 0,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// GET /context/prospects — list of prospects (mirrors GET /prospects)
// ====================================================================
router.get("/prospects", async (req: Request, res: Response) => {
  try {
    const conds = [SCOPE];
    if (req.query.userId) conds.push(eq(prospectsTable.userId, parseInt(req.query.userId as string)));
    if (req.query.email) conds.push(eq(prospectsTable.email, String(req.query.email)));

    const rows = await db
      .select()
      .from(prospectsTable)
      .leftJoin(usersTable, eq(prospectsTable.userId, usersTable.id))
      .where(and(...conds))
      .orderBy(desc(prospectsTable.sentAt))
      .limit(500);

    res.json(rows);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// GET /context/followups — list with prospect data (Pipeline source)
// ====================================================================
router.get("/followups", async (req: Request, res: Response) => {
  try {
    const conds = [SCOPE];
    if (req.query.userId) conds.push(eq(prospectsTable.userId, parseInt(req.query.userId as string)));
    if (req.query.email)  conds.push(eq(prospectsTable.email, String(req.query.email)));

    const rows = await db
      .select({
        followupId: followupsTable.id,
        prospectId: followupsTable.prospectId,
        stage: followupsTable.stage,
        status: followupsTable.status,
        scheduledAt: followupsTable.scheduledAt,
        sentAt: followupsTable.sentAt,
        generatedSubject: followupsTable.generatedSubject,
        generatedBody: followupsTable.generatedBody,
        gmailMessageId: followupsTable.gmailMessageId,
        draftMessageId: followupsTable.draftMessageId,
        errorMessage: followupsTable.errorMessage,
        prospectName: prospectsTable.prospectName,
        company: prospectsTable.company,
        email: prospectsTable.email,
        subject: prospectsTable.subject,
        gmailThreadId: prospectsTable.gmailThreadId,
        replied: prospectsTable.replied,
        followupPaused: prospectsTable.followupPaused,
        userFollowupMode: usersTable.followupMode,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .leftJoin(usersTable, eq(prospectsTable.userId, usersTable.id))
      .where(and(...conds))
      .orderBy(desc(followupsTable.scheduledAt))
      .limit(500);

    res.json(rows);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/process — trigger the dispatcher (cron also runs this)
// ====================================================================
router.post("/process", async (_req: Request, res: Response) => {
  try {
    const { processDueFollowups } = await import("../services/scheduler");
    const result = await processDueFollowups();
    res.json(result);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/sync — trigger Gmail sync for all connected users
//   - With { email }: sync only that user via syncEmailsForUser
//   - Without:        sync all connected users via syncEmails
// ====================================================================
router.post("/sync", async (req: Request, res: Response) => {
  try {
    const email = req.body?.email ? String(req.body.email) : undefined;
    if (email) {
      const { syncEmailsForUser } = await import("../services/gmailSync");
      const result = await syncEmailsForUser(email);
      res.json(result);
    } else {
      const { syncEmails } = await import("../services/gmailSync");
      const result = await syncEmails();
      res.json(result);
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// Helper: ensure a prospect exists AND belongs to the context app.
// Doctrine prospects are not addressable via /api/context/* routes.
// ====================================================================
async function loadContextProspect(prospectId: number) {
  const rows = await db
    .select()
    .from(prospectsTable)
    .where(and(SCOPE, eq(prospectsTable.id, prospectId)))
    .limit(1);
  return rows[0] || null;
}

// ====================================================================
// POST /context/followup-now/:prospectId — Send Now (single)
// ====================================================================
router.post("/followup-now/:prospectId", async (req: Request, res: Response) => {
  const prospectId = parseInt(req.params.prospectId);
  if (isNaN(prospectId)) { res.status(400).json({ error: "Invalid prospect ID" }); return; }

  try {
    const prospect = await loadContextProspect(prospectId);
    if (!prospect) { res.status(404).json({ error: "Context prospect not found" }); return; }
    if (!prospect.userId) { res.status(400).json({ error: "Prospect has no associated user" }); return; }

    const user = await db.select().from(usersTable).where(eq(usersTable.id, prospect.userId)).limit(1);
    if (!user[0]?.googleRefreshToken || !user[0]?.isConnected) {
      res.status(400).json({ error: "User Gmail not connected" }); return;
    }

    const now = new Date();
    const allFollowups = await db
      .select({ stage: followupsTable.stage })
      .from(followupsTable)
      .where(eq(followupsTable.prospectId, prospectId));

    let nextStage = allFollowups.length > 0 ? Math.max(...allFollowups.map((f) => f.stage)) + 1 : 1;

    let insertedFollowupId: number | null = null;
    const MAX_ATTEMPTS = 50;
    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
      const inserted = await db
        .insert(followupsTable)
        .values({ prospectId, stage: nextStage, status: "queued", scheduledAt: now })
        .onConflictDoNothing()
        .returning({ id: followupsTable.id });
      if (inserted[0]?.id) { insertedFollowupId = inserted[0].id; break; }
      nextStage++;
    }

    if (!insertedFollowupId) {
      res.status(500).json({ error: `Could not reserve a follow-up stage after ${MAX_ATTEMPTS} attempts.` });
      return;
    }

    const { processDueFollowups } = await import("../services/scheduler");
    const result = await processDueFollowups({ followupId: insertedFollowupId, forceSend: true });

    res.json({
      success: true,
      stage_queued: nextStage,
      immediate_result: result,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/followup/send-bulk — Bulk Send (capped at 25 per B6)
// ====================================================================
router.post("/followup/send-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }
  if (ids.length > 25) {
    res.status(400).json({ error: "Bulk send limited to 25 prospects per call" });
    return;
  }

  const { processDueFollowups } = await import("../services/scheduler");
  const sent: number[] = [];
  const failed: Array<{ prospectId: number; error: string }> = [];

  for (const prospectId of ids) {
    try {
      const prospect = await loadContextProspect(prospectId);
      if (!prospect) { failed.push({ prospectId, error: "context prospect not found" }); continue; }
      if (!prospect.userId) { failed.push({ prospectId, error: "no user" }); continue; }

      const user = await db.select().from(usersTable).where(eq(usersTable.id, prospect.userId)).limit(1);
      if (!user[0]?.googleRefreshToken || !user[0]?.isConnected) {
        failed.push({ prospectId, error: "user Gmail not connected" }); continue;
      }

      const allFollowups = await db
        .select({ stage: followupsTable.stage })
        .from(followupsTable)
        .where(eq(followupsTable.prospectId, prospectId));

      let nextStage = allFollowups.length > 0 ? Math.max(...allFollowups.map((f) => f.stage)) + 1 : 1;

      let insertedFollowupId: number | null = null;
      for (let attempt = 0; attempt < 50; attempt++) {
        const inserted = await db.insert(followupsTable).values({
          prospectId, stage: nextStage, status: "queued", scheduledAt: new Date(),
        }).onConflictDoNothing().returning({ id: followupsTable.id });
        if (inserted[0]?.id) { insertedFollowupId = inserted[0].id; break; }
        nextStage++;
      }

      if (!insertedFollowupId) { failed.push({ prospectId, error: "could not reserve stage" }); continue; }

      const result = await processDueFollowups({ followupId: insertedFollowupId, forceSend: true });
      if (result.sent > 0 || result.drafted > 0) sent.push(prospectId);
      else if (result.failed > 0) failed.push({ prospectId, error: "send failed" });
      else sent.push(prospectId);
    } catch (err) {
      failed.push({ prospectId, error: err instanceof Error ? err.message : String(err) });
    }
  }

  logger.info(
    { app: "context", requested: ids.length, sent: sent.length, failed: failed.length },
    "Context bulk send-now completed",
  );

  res.json({ success: true, total: ids.length, sent: sent.length, failed, sent_prospect_ids: sent });
});

// ====================================================================
// POST /context/followups/:id/approve — for review_in_app mode
// ====================================================================
router.post("/followups/:id/approve", async (req: Request, res: Response) => {
  const followupId = parseInt(req.params.id);
  if (isNaN(followupId)) { res.status(400).json({ error: "Invalid followup ID" }); return; }

  try {
    // Verify the followup belongs to a context prospect
    const rows = await db
      .select({
        followupId: followupsTable.id,
        status: followupsTable.status,
        prospectId: followupsTable.prospectId,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(SCOPE, eq(followupsTable.id, followupId)))
      .limit(1);

    if (!rows[0]) { res.status(404).json({ error: "Context follow-up not found" }); return; }
    if (rows[0].status !== "pending_approval") {
      res.status(400).json({ error: `Cannot approve follow-up with status '${rows[0].status}'` }); return;
    }

    // Flip to queued so the next process tick fires it (with budget+window gating from B6).
    await db
      .update(followupsTable)
      .set({ status: "queued", scheduledAt: new Date() })
      .where(eq(followupsTable.id, followupId));

    const { processDueFollowups } = await import("../services/scheduler");
    const result = await processDueFollowups({ followupId, forceSend: true });

    res.json({ success: true, immediate_result: result });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/followups/:id/reject — for review_in_app mode
// ====================================================================
router.post("/followups/:id/reject", async (req: Request, res: Response) => {
  const followupId = parseInt(req.params.id);
  if (isNaN(followupId)) { res.status(400).json({ error: "Invalid followup ID" }); return; }

  try {
    const rows = await db
      .select({
        followupId: followupsTable.id,
        status: followupsTable.status,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(SCOPE, eq(followupsTable.id, followupId)))
      .limit(1);

    if (!rows[0]) { res.status(404).json({ error: "Context follow-up not found" }); return; }

    await db
      .update(followupsTable)
      .set({ status: "cancelled", errorMessage: "Rejected via review-in-app." })
      .where(eq(followupsTable.id, followupId));

    res.json({ success: true });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/prospect/:id/pause — pause campaign for a prospect
// ====================================================================
router.post("/prospect/:id/pause", async (req: Request, res: Response) => {
  const prospectId = parseInt(req.params.id);
  if (isNaN(prospectId)) { res.status(400).json({ error: "Invalid prospect ID" }); return; }

  try {
    const prospect = await loadContextProspect(prospectId);
    if (!prospect) { res.status(404).json({ error: "Context prospect not found" }); return; }

    await db.update(prospectsTable).set({ followupPaused: true }).where(eq(prospectsTable.id, prospectId));

    const { cancelActiveFollowupsForProspects } = await import("../services/scheduler");
    const cancelled = await cancelActiveFollowupsForProspects(
      [prospectId],
      "Campaign paused; active follow-up cancelled.",
    );

    res.json({ success: true, paused: 1, cancelled_queued: cancelled });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/prospect/:id/resume — resume campaign for a prospect
// ====================================================================
router.post("/prospect/:id/resume", async (req: Request, res: Response) => {
  const prospectId = parseInt(req.params.id);
  if (isNaN(prospectId)) { res.status(400).json({ error: "Invalid prospect ID" }); return; }

  try {
    const prospect = await loadContextProspect(prospectId);
    if (!prospect) { res.status(404).json({ error: "Context prospect not found" }); return; }
    if (prospect.replied) { res.status(400).json({ error: "Prospect already replied" }); return; }

    await db.update(prospectsTable).set({ followupPaused: false }).where(eq(prospectsTable.id, prospectId));

    const { requeueStalledDraftForProspect } = await import("../services/scheduler");
    const stalledRequeue = await requeueStalledDraftForProspect(prospectId);

    res.json({
      success: true,
      resumed: 1,
      stalled_requeued: stalledRequeue.requeued,
      stalled_stage: stalledRequeue.stage,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/prospect/pause-bulk — bulk pause
// ====================================================================
router.post("/prospect/pause-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }

  try {
    // Restrict to context-only prospects.
    const contextOnly = await db
      .select({ id: prospectsTable.id })
      .from(prospectsTable)
      .where(and(SCOPE, inArray(prospectsTable.id, ids)));
    const contextIds = contextOnly.map((r) => r.id);

    if (contextIds.length === 0) {
      res.json({ success: true, total: ids.length, paused: 0, cancelled_queued: 0, sent_prospect_ids: [] });
      return;
    }

    await db.update(prospectsTable).set({ followupPaused: true }).where(inArray(prospectsTable.id, contextIds));

    const { cancelActiveFollowupsForProspects } = await import("../services/scheduler");
    const cancelled = await cancelActiveFollowupsForProspects(contextIds, "Bulk pause from Context UI.");

    res.json({
      success: true,
      total: ids.length,
      paused: contextIds.length,
      cancelled_queued: cancelled,
      sent_prospect_ids: contextIds,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// POST /context/cancel — cancel queued follow-ups for selected prospects
// ====================================================================
router.post("/cancel", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }

  try {
    const contextOnly = await db
      .select({ id: prospectsTable.id })
      .from(prospectsTable)
      .where(and(SCOPE, inArray(prospectsTable.id, ids)));
    const contextIds = contextOnly.map((r) => r.id);

    if (contextIds.length === 0) {
      res.json({ success: true, cancelled: 0 });
      return;
    }

    const { cancelActiveFollowupsForProspects } = await import("../services/scheduler");
    const cancelled = await cancelActiveFollowupsForProspects(contextIds, "Cancelled via Context UI.");

    res.json({ success: true, cancelled });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// GET /context/campaign/status — Activity Log data
// ====================================================================
router.get("/campaign/status", async (req: Request, res: Response) => {
  try {
    const userIdFilter = req.query.userId ? parseInt(req.query.userId as string) : null;

    const conds = [SCOPE];
    if (userIdFilter) conds.push(eq(prospectsTable.userId, userIdFilter));

    const recentFollowups = await db
      .select({
        followupId: followupsTable.id,
        prospectId: followupsTable.prospectId,
        stage: followupsTable.stage,
        status: followupsTable.status,
        scheduledAt: followupsTable.scheduledAt,
        sentAt: followupsTable.sentAt,
        errorMessage: followupsTable.errorMessage,
        prospectName: prospectsTable.prospectName,
        company: prospectsTable.company,
        email: prospectsTable.email,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(...conds))
      .orderBy(desc(followupsTable.scheduledAt))
      .limit(200);

    res.json({ followups: recentFollowups });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

export default router;
