#!/usr/bin/env node
/**
 * audit-batch7b.mjs — Beautiful-Squidward audit for Phase 7b.
 * 3 rounds × 9 passes per round.
 *
 * Verifies the Context Based backend pipeline:
 *   PASS 1: New service + routes files exist with correct exports
 *   PASS 2: Three MODEL_CONTEXT_* constants exported from lib/anthropic.ts
 *   PASS 3: Scheduler dispatcher branches on prospects.app
 *   PASS 4: gmailSync scans both labels, tags inserts, forwards contextLabel
 *   PASS 5: routes/index.ts mounts contextRouter under /context
 *   PASS 6: routes/context.ts is correctly scoped to app='context'
 *   PASS 7: ZERO regression — Phase 6 gates still in scheduler
 *   PASS 8: Cron line still has all five jobs
 *   PASS 9: Cleanliness — no .bak files, no doctrine route mutations
 *
 * Run AFTER apply-batch7b.mjs.
 *
 * Env: API_BASE = path to api-server src (default: artifacts/api-server/src)
 */

import { existsSync, readFileSync, readdirSync, statSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const promptsPath        = join(API_BASE, "services", "contextFollowupPrompts.ts");
const generatorPath      = join(API_BASE, "services", "contextFollowupGenerator.ts");
const contextRoutesPath  = join(API_BASE, "routes",   "context.ts");
const anthropicLibPath   = join(API_BASE, "lib",      "anthropic.ts");
const schedulerPath      = join(API_BASE, "services", "scheduler.ts");
const gmailSyncPath      = join(API_BASE, "services", "gmailSync.ts");
const routesIndexPath    = join(API_BASE, "routes",   "index.ts");
const doctrineRoutesPath = join(API_BASE, "routes",   "doctrine.ts");
const cronPath           = join(API_BASE, "cron.ts");

let totalPasses = 0;
let totalFails = 0;
const failureMessages = [];

function read(path) {
  if (!existsSync(path)) throw new Error(`File missing: ${path}`);
  return readFileSync(path, "utf-8");
}
function check(label, condition, detail = "") {
  totalPasses++;
  if (condition) {
    console.log(`    [PASS] ${label}`);
  } else {
    totalFails++;
    failureMessages.push(`${label}${detail ? " — " + detail : ""}`);
    console.log(`    [FAIL] ${label}${detail ? " — " + detail : ""}`);
  }
}
function countIn(path, needle) {
  return read(path).split(needle).length - 1;
}
function walkAll(dir) {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const n of readdirSync(dir)) {
    const full = join(dir, n);
    const st = statSync(full);
    if (st.isDirectory()) out.push(...walkAll(full));
    else if (st.isFile()) out.push(full);
  }
  return out;
}

function runOneRound(roundNum) {
  console.log(`\n--- Round ${roundNum} ---`);

  // PASS 1: New files exist with correct exports
  console.log(`  PASS 1: New service + routes files`);
  check("1a. contextFollowupPrompts.ts exists", existsSync(promptsPath));
  check("1b. CONTEXT_GENERATOR_SYSTEM exported",
    read(promptsPath).includes(`export const CONTEXT_GENERATOR_SYSTEM`));
  check("1c. CONTEXT_CRITIC_SYSTEM exported",
    read(promptsPath).includes(`export const CONTEXT_CRITIC_SYSTEM`));
  check("1d. CONTEXT_REWRITER_SYSTEM exported",
    read(promptsPath).includes(`export const CONTEXT_REWRITER_SYSTEM`));
  check("1e. contextFollowupGenerator.ts exists", existsSync(generatorPath));
  check("1f. generateContextFollowup exported",
    read(generatorPath).includes(`export async function generateContextFollowup`));
  check("1g. routes/context.ts exists", existsSync(contextRoutesPath));

  // PASS 2: Three MODEL_CONTEXT_* constants in lib/anthropic.ts
  console.log(`  PASS 2: MODEL_CONTEXT_* constants`);
  const lib = read(anthropicLibPath);
  check("2a. MODEL_CONTEXT_GENERATOR set to claude-sonnet-4-6",
    /export const MODEL_CONTEXT_GENERATOR:\s*"claude-sonnet-4-6"\s*=\s*"claude-sonnet-4-6";/.test(lib));
  check("2b. MODEL_CONTEXT_CRITIC set to claude-opus-4-7",
    /export const MODEL_CONTEXT_CRITIC:\s*"claude-opus-4-7"\s*=\s*"claude-opus-4-7";/.test(lib));
  check("2c. MODEL_CONTEXT_REWRITER set to claude-sonnet-4-6",
    /export const MODEL_CONTEXT_REWRITER:\s*"claude-sonnet-4-6"\s*=\s*"claude-sonnet-4-6";/.test(lib));
  // Existing 4 model constants from B5 must still be present
  check("2d. existing MODEL_SUMMARIZER (B5) still present",
    /export const MODEL_SUMMARIZER:/.test(lib));
  check("2e. existing MODEL_DRAFT_GENERATOR (B5) still present",
    /export const MODEL_DRAFT_GENERATOR:/.test(lib));
  check("2f. existing MODEL_CRITIC (B5) still present",
    /export const MODEL_CRITIC:/.test(lib));
  check("2g. existing MODEL_REWRITER (B5) still present",
    /export const MODEL_REWRITER:/.test(lib));
  // PASS 4 ALSO checks the generator imports those constants — tested below

  // PASS 3: Scheduler dispatcher branches on prospects.app
  console.log(`  PASS 3: Scheduler dispatcher`);
  const sched = read(schedulerPath);
  check("3a. scheduler imports generateContextFollowup",
    sched.includes(`import { generateContextFollowup } from "./contextFollowupGenerator";`));
  check("3b. scheduler still imports generateFollowupEmail (doctrine path preserved)",
    sched.includes(`generateFollowupEmail`));
  check("3c. scheduler SELECTs prospects.app in due-rows query",
    sched.includes(`app: prospectsTable.app,`));
  check("3d. scheduler branches generation on item.app === \"context\"",
    sched.includes(`item.app === "context"`));
  check("3e. scheduler routes context branch to generateContextFollowup",
    /item\.app === "context"\s*\?\s*await generateContextFollowup\(ctx\)\s*:\s*await generateFollowupEmail\(ctx\)/.test(sched));

  // PASS 4: gmailSync scans both labels and tags inserts
  console.log(`  PASS 4: gmailSync wiring`);
  const gs = read(gmailSyncPath);
  check("4a. syncForUser type accepts contextLabel",
    /async function syncForUser\(user:\s*\{[^}]*contextLabel:\s*string;/s.test(gs));
  check("4b. doctrineLabels parsed from doctrineLabel",
    gs.includes(`const doctrineLabels = user.doctrineLabel.split(",")`));
  check("4c. contextLabels parsed from contextLabel (with || guard)",
    gs.includes(`const contextLabels = (user.contextLabel || "").split(",")`));
  check("4d. ensureLabelsExist receives the union of both label sets",
    gs.includes(`await ensureLabelsExist(allLabels, gmail);`));
  check("4e. fetchLabeledSentEmails called separately for each bucket",
    countIn(gmailSyncPath, `await fetchLabeledSentEmails(`) >= 2);
  check("4f. doctrine bucket tag",
    gs.includes(`taggedMessages.push({ msg: m, app: "doctrine" })`));
  check("4g. context bucket tag",
    gs.includes(`taggedMessages.push({ msg: m, app: "context" })`));
  check("4h. insert chooses batchLabel by app",
    gs.includes(`app === "context" ? user.contextLabel : user.doctrineLabel`));
  check("4i. insert sets app field",
    /app,\s*\n\s*sentAt: new Date\(msg\.date\),/.test(gs));
  check("4j. call site 1 forwards contextLabel",
    countIn(gmailSyncPath, `// Phase 7b: forward the user's context label into syncForUser.`) === 1);
  check("4k. call site 2 forwards contextLabel (loop)",
    countIn(gmailSyncPath, `// Phase 7b: forward the user's context label into syncForUser (loop).`) === 1);
  // SAFETY: there must be NO remaining naked `doctrineLabel: user.doctrineLabel,` followed by
  // a closing `});` without contextLabel — that would indicate a missed call site.
  check("4l. no orphan call site missing contextLabel",
    !/doctrineLabel: user\.doctrineLabel,\s*\}\)\;\s*\n.*?\n.*?return\s/s.test(gs.replace(/\/\/.+/g, "")));

  // PASS 5: routes/index mounts contextRouter under /context
  console.log(`  PASS 5: routes/index wiring`);
  const ri = read(routesIndexPath);
  check("5a. imports contextRouter",
    ri.includes(`import contextRouter from "./context";`));
  check("5b. mounts under /context path prefix",
    ri.includes(`router.use("/context", contextRouter);`));
  check("5c. existing doctrine mount still present (no accidental removal)",
    ri.includes(`router.use(doctrineRouter);`));

  // PASS 6: routes/context.ts is scoped to app='context'
  console.log(`  PASS 6: context routes scoping`);
  const cr = read(contextRoutesPath);
  check("6a. SCOPE constant defined as eq(prospectsTable.app, \"context\")",
    /const SCOPE = eq\(prospectsTable\.app,\s*"context"\)/.test(cr));
  check("6b. SCOPE applied in queries (multiple uses)",
    countIn(contextRoutesPath, `SCOPE`) >= 6);
  check("6c. uses inline authMiddleware (matches doctrine.ts pattern)",
    cr.includes(`function authMiddleware(req: Request, res: Response, next: NextFunction)`) &&
    cr.includes(`router.use(authMiddleware);`));
  check("6d. /sync uses correct exported functions",
    cr.includes(`syncEmailsForUser`) && cr.includes(`syncEmails`));
  check("6e. bulk send-now hard-capped at 25 (B6 inheritance)",
    cr.includes(`Bulk send limited to 25 prospects per call`));
  check("6f. has GET /stats, GET /followups, POST /followup-now/:prospectId, POST /followup/send-bulk",
    cr.includes(`router.get("/stats"`) &&
    cr.includes(`router.get("/followups"`) &&
    cr.includes(`router.post("/followup-now/:prospectId"`) &&
    cr.includes(`router.post("/followup/send-bulk"`));

  // PASS 7: ZERO regression — B6 gates and B5 model migrations preserved
  console.log(`  PASS 7: B6/B5 regression checks`);
  check("7a. scheduler still imports isInSendWindow (B6)",
    sched.includes(`import { isInSendWindow }`));
  check("7b. scheduler still imports checkSendBudget (B6)",
    sched.includes(`import { checkSendBudget }`));
  check("7c. Phase 6 gate A (window) still present",
    sched.includes(`Phase 6 gate A: send-window enforcement`));
  check("7d. Phase 6 gate B (budget) still present",
    sched.includes(`Phase 6 gate B: per-user send rate limiter`));
  check("7e. emailSummarizer.ts still uses MODEL_SUMMARIZER (B5 migration)",
    read(join(API_BASE, "services", "emailSummarizer.ts")).includes(`MODEL_SUMMARIZER`));
  check("7f. followupGenerator.ts still uses MODEL_DRAFT_GENERATOR/MODEL_CRITIC/MODEL_REWRITER (B5)",
    (() => {
      const f = read(join(API_BASE, "services", "followupGenerator.ts"));
      return f.includes(`MODEL_DRAFT_GENERATOR`) && f.includes(`MODEL_CRITIC`) && f.includes(`MODEL_REWRITER`);
    })());

  // PASS 8: Cron stability
  console.log(`  PASS 8: Cron stability`);
  const cron = read(cronPath);
  check("8a. sync+auto-queue cron */15 still present", cron.includes(`cron.schedule("*/15 * * * *"`));
  check("8b. main process cron 5,20,35,50",            cron.includes(`cron.schedule("5,20,35,50 * * * *"`));
  check("8c. draft-stall cron 30 0",                   cron.includes(`cron.schedule("30 0 * * *"`));
  check("8d. weekly-digest cron Tue 00:00",            cron.includes(`cron.schedule("0 0 * * 2"`));
  check("8e. fast-tick cron */3",                      cron.includes(`cron.schedule("*/3 * * * *"`));

  // PASS 9: Cleanliness + doctrine routes untouched (deferred to 7c)
  console.log(`  PASS 9: Cleanliness + doctrine route preservation`);
  const allFiles = walkAll(API_BASE);
  const bakFiles = allFiles.filter((f) => f.endsWith(".bak"));
  check("9a. zero .bak files in api-server tree", bakFiles.length === 0, bakFiles.join(", "));
  // The doctrine route filter is explicitly deferred to 7c. Verify
  // doctrine.ts has NO app-scoped filter yet.
  const dr = read(doctrineRoutesPath);
  check("9b. doctrine.ts NOT yet filtered to app='doctrine' (deferred to 7c)",
    !/eq\(prospectsTable\.app,\s*"doctrine"\)/.test(dr));
  check("9c. doctrine.ts still imports the same set of services (no accidental removal)",
    dr.includes(`from "../services/gmailSync"`) &&
    dr.includes(`from "../services/scheduler"`));
  check("9d. generator imports MODEL_CONTEXT_* from lib/anthropic",
    read(generatorPath).includes(`MODEL_CONTEXT_GENERATOR, MODEL_CONTEXT_CRITIC, MODEL_CONTEXT_REWRITER`));
  // The B6 helper modules must still be present
  check("9e. lib/sendBudget.ts still present (B6)",
    existsSync(join(API_BASE, "lib", "sendBudget.ts")));
  check("9f. lib/scheduleWindow.ts still present (B6)",
    existsSync(join(API_BASE, "lib", "scheduleWindow.ts")));
}

console.log("================================================================");
console.log("Batch 7b audit — 3 rounds × 9 passes (Beautiful-Squidward)");
console.log("================================================================");

for (let round = 1; round <= 3; round++) {
  runOneRound(round);
}

console.log("");
console.log("================================================================");
console.log(`Total: ${totalPasses - totalFails}/${totalPasses} passed across 3 rounds.`);
if (totalFails > 0) {
  console.log(`FAILURES (${totalFails}):`);
  for (const m of failureMessages) console.log(`  - ${m}`);
  console.log("================================================================");
  process.exit(1);
} else {
  console.log("All passes succeeded across all 3 rounds.");
  console.log("================================================================");
}
