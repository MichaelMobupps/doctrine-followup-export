#!/usr/bin/env python3
r"""
B9b.4.1 — fix the missed import in gmailSync.ts.

B9b.4's import patch anchored on `import { syncThreadFromGmail } from
"./threadReader";` which doesn't exist in gmailSync.ts. The
syncThreadFromGmail symbol IS imported in the codebase, but by
routes/anti-ghosting.ts directly, not via gmailSync. My mistake.

The second B9b.4 edit (call site + logger + return) applied correctly,
so the file currently references the unimported symbol — TS2304. This
hotfix adds the missing import. One surgical edit.

Anchored on `import { logger } from "../lib/logger";` — a single-line
import that's reliably present in the file.

Idempotent.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    print("\n--- artifacts/api-server/src/services/gmailSync.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/services/gmailSync.ts",
        [
            (
                'import { logger } from "../lib/logger";\n',
                'import { logger } from "../lib/logger";\n'
                '// B9b.4: AntiGhosting auto-ingest orchestrator. Lists labeled\n'
                '// threads and ingests each unmarked one via the shared service.\n'
                'import { ingestAntiGhostingLabeledThreads } from "./antiGhostingIngest";\n',
                "add ingestAntiGhostingLabeledThreads import (B9b.4.1)",
            ),
        ],
    )

    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {a}")
    print(f"  Already-applied:   {b}")
    print(f"  Warnings:          {w}")
    if w > 0:
        print("  Warning fired — see WARN line above.")
        return 2
    if a + b < 1:
        print("  No edit took effect.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
