#!/usr/bin/env node
// apply-batch-resume-bulk.mjs
//
// Adds a "Resume all" bulk action to the Pipeline page (frontend) and a
// matching POST /prospect/resume-bulk endpoint (backend).
//
// Idempotent: every operation is sentinel-gated. Safe to re-run.
//
// Env overrides:
//   API_BASE   default: artifacts/api-server/src
//   DASH_BASE  default: artifacts/dashboard/src

import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const DOCTRINE_TS = join(API_BASE, "routes/doctrine.ts");
const PIPELINE_TSX = join(DASH_BASE, "pages/pipeline.tsx");

let opsApplied = 0;
let opsSkipped = 0;

function read(path) {
  if (!existsSync(path)) {
    console.error(`FATAL: file not found: ${path}`);
    process.exit(1);
  }
  return readFileSync(path, "utf8");
}

function write(path, content) {
  writeFileSync(path, content, "utf8");
}

function op(label, condition, mutate) {
  if (!condition()) {
    console.log(`  SKIP  ${label} (sentinel present)`);
    opsSkipped++;
    return;
  }
  mutate();
  console.log(`  APPLY ${label}`);
  opsApplied++;
}

/* ===================================================================== */
/*  Op 1 — Insert POST /prospect/resume-bulk into doctrine.ts            */
/* ===================================================================== */

console.log("\n[doctrine.ts] inserting resume-bulk endpoint");

const RESUME_BULK_ROUTE = `router.post("/prospect/resume-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }

  try {
    const prospects = await db
      .select()
      .from(prospectsTable)
      .where(and(SCOPE_DOCTRINE, inArray(prospectsTable.id, ids)));

    const eligible = prospects.filter((p) => !p.replied);
    const skipped_replied = prospects.length - eligible.length;
    const not_found = ids.length - prospects.length;

    if (eligible.length === 0) {
      res.json({
        success: true,
        requested: ids.length,
        resumed: 0,
        requeued_stalled: 0,
        queued_new: 0,
        skipped_replied,
        not_found,
      });
      return;
    }

    const eligibleIds = eligible.map((p) => p.id);

    await db
      .update(prospectsTable)
      .set({ followupPaused: false })
      .where(and(SCOPE_DOCTRINE, inArray(prospectsTable.id, eligibleIds)));

    const uniqueUserIds = Array.from(
      new Set(eligible.map((p) => p.userId).filter((u): u is number => typeof u === "number" && u > 0)),
    );
    const userMap = new Map<number, typeof usersTable.$inferSelect>();
    if (uniqueUserIds.length > 0) {
      const users = await db.select().from(usersTable).where(inArray(usersTable.id, uniqueUserIds));
      for (const u of users) userMap.set(u.id, u);
    }

    const allFollowups = await db
      .select({
        prospectId: followupsTable.prospectId,
        stage: followupsTable.stage,
        status: followupsTable.status,
        sentAt: followupsTable.sentAt,
      })
      .from(followupsTable)
      .where(inArray(followupsTable.prospectId, eligibleIds));

    const followupsByProspect = new Map<number, typeof allFollowups>();
    for (const f of allFollowups) {
      const arr = followupsByProspect.get(f.prospectId);
      if (arr) arr.push(f);
      else followupsByProspect.set(f.prospectId, [f]);
    }

    let requeued_stalled = 0;
    let queued_new = 0;

    for (const p of eligible) {
      const user = p.userId ? userMap.get(p.userId) : null;
      const maxFollowups = getFollowupCap(user?.maxFollowups);

      const existing = followupsByProspect.get(p.id) || [];
      const sentRows = existing.filter((f) => f.status === "sent");
      const sentStages = sentRows.map((f) => f.stage);
      const activeStages = existing.filter((f) =>
        ["queued", "generating", "pending_approval", "drafted"].includes(f.status),
      );

      const stalledRequeue = await requeueStalledDraftForProspect(p.id);
      if (stalledRequeue.requeued) {
        requeued_stalled++;
        continue;
      }

      if (activeStages.length === 0) {
        const nextStage = sentStages.length > 0 ? Math.max(...sentStages) + 1 : 1;
        if (maxFollowups === null || nextStage <= maxFollowups) {
          const userSettings: UserTimingSettings | undefined = user ? {
            stageTiming: user.stageTiming,
            draftStageTiming: user.draftStageTiming,
            sendDays: user.sendDays,
            sendHourStart: user.sendHourStart,
            sendHourEnd: user.sendHourEnd,
          } : undefined;
          const lastSentAt = sentRows.length > 0
            ? sentRows.reduce((a, b) => (a.stage > b.stage ? a : b)).sentAt
            : null;
          const scheduledAt = computeNextStageScheduledAt({
            stage: nextStage,
            initialSentAt: p.sentAt,
            lastFollowupSentAt: lastSentAt,
            userSettings,
            mode: user?.followupMode === "draft_in_gmail" ? "draft_in_gmail" : "auto_send",
          });

          try {
            await db.insert(followupsTable).values({
              prospectId: p.id,
              stage: nextStage,
              scheduledAt,
              status: "queued",
            });
            queued_new++;
          } catch {
            // Concurrent insert race (autoQueue cron tick + this resume).
            // Matches single-prospect /resume tolerance — silently swallow.
          }
        }
      }
    }

    logger.info(
      { requested: ids.length, resumed: eligible.length, requeued_stalled, queued_new, skipped_replied, not_found },
      "Bulk resume completed",
    );

    res.json({
      success: true,
      requested: ids.length,
      resumed: eligible.length,
      requeued_stalled,
      queued_new,
      skipped_replied,
      not_found,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

`;

{
  let doctrine = read(DOCTRINE_TS);
  const sentinel = `router.post("/prospect/resume-bulk"`;
  // Anchor: insert immediately before the single-prospect resume route.
  // This co-locates pause-bulk / resume-bulk / single-resume / single-pause.
  const anchor = `router.post("/prospect/:id/resume"`;

  op(
    `insert POST /prospect/resume-bulk`,
    () => !doctrine.includes(sentinel),
    () => {
      const idx = doctrine.indexOf(anchor);
      if (idx === -1) {
        throw new Error(`anchor not found in ${DOCTRINE_TS}: ${anchor}`);
      }
      doctrine = doctrine.slice(0, idx) + RESUME_BULK_ROUTE + doctrine.slice(idx);
      write(DOCTRINE_TS, doctrine);
    },
  );
}

/* ===================================================================== */
/*  Op 2..6 — pipeline.tsx                                                */
/* ===================================================================== */

console.log("\n[pipeline.tsx] adding Resume all bulk action");

let pipeline = read(PIPELINE_TSX);

/* ---- Op 2 — bulkResuming state ---- */

op(
  `add bulkResuming state`,
  () => !pipeline.includes("bulkResuming"),
  () => {
    const target = `  const [bulkPausing, setBulkPausing] = useState(false);\n`;
    if (!pipeline.includes(target)) throw new Error("anchor not found: bulkPausing state");
    pipeline = pipeline.replace(
      target,
      target + `  const [bulkResuming, setBulkResuming] = useState(false);\n`,
    );
  },
);

/* ---- Op 3 — handleBulkResume function ---- */

const HANDLE_BULK_RESUME = `
  async function handleBulkResume() {
    const ids = Array.from(selectedIds);
    if (ids.length === 0) return;
    if (!confirm(\`Resume campaigns for \${ids.length} prospect\${ids.length !== 1 ? "s" : ""}? Paused prospects will be unpaused; stalled drafts will be requeued and next-stage follow-ups will be queued where appropriate.\`)) return;
    setBulkResuming(true);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(\`\${base}api/prospect/resume-bulk\`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
        body: JSON.stringify({ prospectIds: ids }),
      });
      const data = await res.json();
      if (!res.ok) {
        showFeedback(data.error || "Bulk resume failed", true);
        return;
      }
      const resumed = data.resumed || 0;
      const requested = data.requested || ids.length;
      const requeued = data.requeued_stalled || 0;
      const queued = data.queued_new || 0;
      const skipped = data.skipped_replied || 0;
      const parts = [\`Resumed \${resumed} of \${requested}\`];
      if (requeued > 0) parts.push(\`requeued \${requeued} stalled\`);
      if (queued > 0) parts.push(\`queued \${queued} new\`);
      if (skipped > 0) parts.push(\`skipped \${skipped} replied\`);
      showFeedback(parts.join(" — "));
      clearSelection();
      invalidateAll();
    } catch (err: any) {
      showFeedback(err.message || "Bulk resume failed", true);
    } finally {
      setBulkResuming(false);
    }
  }
`;

op(
  `add handleBulkResume function`,
  () => !pipeline.includes("handleBulkResume"),
  () => {
    // Anchor: end of handleBulkPause, marked by its closing finally block.
    // We insert immediately after the closing brace of handleBulkPause.
    const anchor = `      setBulkPausing(false);\n    }\n  }\n`;
    if (!pipeline.includes(anchor)) throw new Error("anchor not found: end of handleBulkPause");
    pipeline = pipeline.replace(anchor, anchor + HANDLE_BULK_RESUME);
  },
);

/* ---- Op 4 — bump minWidth on bulk-action bar ---- */

op(
  `bump bulk-action bar minWidth 420 -> 500`,
  () => pipeline.includes(`minWidth: "420px",`),
  () => {
    pipeline = pipeline.replace(`minWidth: "420px",`, `minWidth: "500px",`);
  },
);

/* ---- Op 5 — update disabled props on existing bulk buttons to include bulkResuming ---- */

op(
  `extend disabled on Send all button`,
  () => pipeline.includes(`disabled={bulkSending || bulkPausing}\n            className="gap-1.5"\n          >\n            {bulkSending ?`),
  () => {
    pipeline = pipeline.replace(
      `disabled={bulkSending || bulkPausing}\n            className="gap-1.5"\n          >\n            {bulkSending ?`,
      `disabled={bulkSending || bulkPausing || bulkResuming}\n            className="gap-1.5"\n          >\n            {bulkSending ?`,
    );
  },
);

op(
  `extend disabled on Pause all button`,
  () => pipeline.includes(`disabled={bulkSending || bulkPausing}\n            className="gap-1.5"\n            style={{ color: "var(--warning)"`),
  () => {
    pipeline = pipeline.replace(
      `disabled={bulkSending || bulkPausing}\n            className="gap-1.5"\n            style={{ color: "var(--warning)"`,
      `disabled={bulkSending || bulkPausing || bulkResuming}\n            className="gap-1.5"\n            style={{ color: "var(--warning)"`,
    );
  },
);

op(
  `extend disabled on close (X) button`,
  () => pipeline.includes(`onClick={clearSelection}\n            disabled={bulkSending || bulkPausing}\n          >\n            <X`),
  () => {
    pipeline = pipeline.replace(
      `onClick={clearSelection}\n            disabled={bulkSending || bulkPausing}\n          >\n            <X`,
      `onClick={clearSelection}\n            disabled={bulkSending || bulkPausing || bulkResuming}\n          >\n            <X`,
    );
  },
);

/* ---- Op 6 — insert Resume all button between Pause all and the close X ---- */

const RESUME_ALL_BUTTON = `          <Button
            size="sm"
            variant="secondary"
            onClick={handleBulkResume}
            disabled={bulkSending || bulkPausing || bulkResuming}
            className="gap-1.5"
            style={{ color: "var(--success)", borderColor: "var(--success-border)" }}
          >
            {bulkResuming ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
            Resume all
          </Button>
`;

op(
  `insert Resume all button into bulk-action bar`,
  () => !pipeline.includes("Resume all"),
  () => {
    // Anchor: the close (X) button. Insert Resume all right before it so the
    // bar reads [N selected] [Send all] [Pause all] [Resume all] [X].
    const anchor = `          <Button
            size="sm"
            variant="ghost"
            onClick={clearSelection}
            disabled={bulkSending || bulkPausing || bulkResuming}
          >
            <X className="h-3.5 w-3.5" />
          </Button>`;
    if (!pipeline.includes(anchor)) throw new Error("anchor not found: close (X) button (run Op 5 first)");
    pipeline = pipeline.replace(anchor, RESUME_ALL_BUTTON + anchor);
  },
);

write(PIPELINE_TSX, pipeline);

/* ===================================================================== */

console.log(`\nDone. Applied ${opsApplied}, skipped ${opsSkipped}.`);
