# Opus 4.8 critic upgrade + Anti-Ghosting Activity Log & Admin Cost

Full-file replacements. Paths below are artifacts paths (payload mirrors
`artifacts/<pkg>/src/`). `ship.sh` backs up, copies, gates, builds, mirrors.

## Part A — Opus 4.8 on all three critic stages

Adaptive thinking on high effort. Opus 4.8 accepts only adaptive thinking
(`thinking: {type:"adaptive"}`); a manual `budget_tokens` returns 400. The
`effort` control lives in `output_config: {effort:"high"}`.

- `api-server/src/lib/anthropic.ts`
  - `MODEL_CRITIC`, `MODEL_CONTEXT_CRITIC`, `MODEL_ANTI_GHOSTING_CRITIC`:
    `claude-opus-4-7` -> `claude-opus-4-8`.
  - Added `OPUS_REASONING` constant + `withOpusReasoning()` helper. The helper
    merges the reasoning fields and carries one documented cast.
- `api-server/src/lib/pricing.ts`: added `claude-opus-4-8` at `$5 / $25` per
  1M (unchanged from 4.7).
- Critic call sites wrapped with `withOpusReasoning()` and given thinking
  headroom on `max_tokens`:
  - `services/followupGenerator.ts` (Doctrine): 8192 -> 16000.
  - `services/contextFollowupGenerator.ts` (Context): 4096 -> 12000.
  - `services/antiGhostingFollowupGenerator.ts` (Anti-Ghosting): 4096 -> 12000.

SDK note: the pinned `@anthropic-ai/sdk@^0.65.0` predates the `effort` /
`output_config` / adaptive-thinking types (they ship in >= 0.100). The helper
keeps the SDK pinned and routes the merge through one localized cast; the
fields still serialize and reach the API. Verified to pass `tsc --strict`
against the real 0.65 types. To move to first-class types later, bump the SDK
and drop the cast in `withOpusReasoning()`.

Cost: high-effort adaptive thinking bills thinking tokens at the output rate
($25/1M). Critic calls cost more per run than today. The raised `max_tokens`
is headroom; actual spend tracks real thinking length.

## Part B — Anti-Ghosting Activity Log

- `api-server/src/routes/anti-ghosting.ts`: added `GET /campaign/status`
  scoped to `app='anti_ghosting'`. Returns the same shape as the Doctrine /
  Context status. `paused` and `actionable` are not gated on `replied=0`
  (Anti-Ghosting re-engages threads after replies, matching the scheduler);
  `unreplied` stays the `replied=0` count so the page's derived
  `replied = total - unreplied` reads correctly.
- `dashboard/src/pages/anti-ghosting-activity.tsx` (NEW): clone of
  `context-activity.tsx` retargeted to `api/anti-ghosting/campaign/status`,
  label field `anti_ghosting_label`, title "Anti-Ghosting Activity Log".
- `dashboard/src/App.tsx`: route `/anti-ghosting/activity`.
- `dashboard/src/components/layout.tsx`: "Activity Log" nav item in the
  Anti-Ghosting product.

## Part C — Anti-Ghosting Admin Cost (scoped page + shared filter)

Cost tracking already lands in `followup_usage` tagged `anti_ghosting`
(usage context + tracker labels + scheduler wrap are already in place). The
gaps were the filter whitelist and the missing nav entry.

- `api-server/src/routes/admin-activity.ts` and
  `api-server/src/routes/admin-activity-report.ts`: whitelist
  `anti_ghosting` in the `app` filter.
- `dashboard/src/pages/admin-activity.tsx`:
  - Optional `lockedApp` prop. When set, the page is scoped to that product,
    the App filter is hidden, and the title reads "Anti-Ghosting · Admin
    Activity".
  - Shared filter gains the "Anti-Ghosting" option; "Both" relabeled "All".
- `dashboard/src/App.tsx`: route `/anti-ghosting/admin-activity` renders
  `<AdminActivity lockedApp="anti_ghosting" />`.
- `dashboard/src/components/layout.tsx`: "Admin Activity" nav item in the
  Anti-Ghosting product.

## Post-deploy smoke

    curl -s -H "x-api-key: $ADDON_API_KEY" \
      http://localhost:80/api/anti-ghosting/campaign/status | head -c 400
