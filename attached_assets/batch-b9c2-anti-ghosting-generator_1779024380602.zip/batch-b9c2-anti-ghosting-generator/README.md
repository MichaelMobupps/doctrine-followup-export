# Batch B9c.2 — AntiGhosting Generator + Scheduler Dispatch

**Scope.** Land the actual AntiGhosting follow-up generation pipeline and wire it into the scheduler's dispatcher. After this batch ships, AntiGhosting prospects whose `scheduledAt` matures will dispatch through a proper three-call writer/critic/rewriter pipeline using AntiGhosting-specific prompts, with live thread re-read at dispatch time.

This is the second half of the B9c split:
- **B9c.1** (shipped): infrastructure — F1 status fix + scheduler exclusion gate
- **B9c.2** (this): generator + dispatcher integration, removing the B9c.1 gate

## What ships

### New file: `services/antiGhostingFollowupPrompts.ts`

Prompt module — ~350 lines. Exports:

- `AntiGhostingFollowupContext` interface (the ctx shape the generator takes).
- `ANTI_GHOSTING_GENERATOR_SYSTEM` — writer system prompt enforcing the **ACKNOWLEDGE → BRIDGE → ASK** structure, tone tiers (`lt_30d` / `30d_to_6mo` / `gt_6mo`), stage differentiation (F1 soft / F2 direct / F3 close-the-loop), forbidden phrases, language consistency, 5-sentence body cap.
- `ANTI_GHOSTING_CRITIC_SYSTEM` — critic system prompt scoring 7 dimensions: `acknowledge_quality`, `bridge_legitimacy`, `ask_specificity`, `tone_tier_match`, `forbidden_phrase`, `language_consistency`, `structural_completeness`.
- `ANTI_GHOSTING_REWRITER_SYSTEM` — rewriter system prompt repeating constraints + addressing critic feedback.
- `ANTI_GHOSTING_FORBIDDEN_PHRASES` — exact-match list (`"just checking in"`, `"just wanted to follow up"`, `"bumping this up"`, `"wanted to touch base"`, `"hope this finds you well"`, plus close variants). `"circling back"` is deliberately allowed.
- `getAntiGhostingGeneratorUserPrompt(ctx)`, `getAntiGhostingCriticUserPrompt(ctx, draft)`, `getAntiGhostingRewriterUserPrompt(ctx, draft, critique)` — user message builders.
- `computeDaysSinceSeedTier(sentAt, now)` — pure tier classifier (also re-used by the scheduler).

### New file: `services/antiGhostingFollowupGenerator.ts`

3-call pipeline — ~210 lines. Mirrors `contextFollowupGenerator.ts` exactly in shape:

1. `generateAntiGhostingDraft` — Sonnet writer call, JSON-only output, 2-attempt retry on parse failure.
2. `critiqueAntiGhostingDraft` — Opus critic call. Failure here is non-fatal; ship the draft with a warning.
3. `rewriteAntiGhostingDraft` — Sonnet rewriter call. Falls back to original draft if rewriter output is malformed.
4. `generateAntiGhostingFollowup` — orchestrator. Combines deterministic doctrineLint pre-flight (Latin-token-leak detector) with the LLM critique, then dispatches to the rewriter if needed.

Every return path runs through `finalize()` which applies the B8a `stripClosingFromBody` so the LLM-generated sign-off doesn't duplicate Gmail's auto-appended signature.

### New file: `tests/test-anti-ghosting-prompts-b9c2.ts`

33 unit tests covering:
- `computeDaysSinceSeedTier` boundary behaviour (1d / 29d / 30d / 90d / 179d / 180d / 365d).
- Generator user prompt rendering: identity, last-inbound anchor, tier guidance, cycle awareness, stage labels, previous-followups formatting, thread chronological ordering with direction labels.
- Critic user prompt rendering: draft inclusion, parameter exposure, last-inbound truncation at 500 chars.
- Rewriter user prompt rendering: critic issues + suggestions as bullets, fallback to "(none flagged)".
- Forbidden phrase catalogue: required entries present, `"circling back"` NOT in list, system prompts enumerate every forbidden phrase, critic system mentions every score dimension.

Sandbox tsc: clean. Sandbox test run: 33/33 pass.

### Modified file: `lib/anthropic.ts`

Adds three model constant aliases for AntiGhosting:
- `MODEL_ANTI_GHOSTING_GENERATOR` = `"claude-sonnet-4-6"`
- `MODEL_ANTI_GHOSTING_CRITIC` = `"claude-opus-4-7"`
- `MODEL_ANTI_GHOSTING_REWRITER` = `"claude-sonnet-4-6"`

Same models as Context for now. Aliases let us swap independently later without touching call sites.

### Modified file: `lib/usageContext.ts`

Widens `UsageAttribution.app` from `"doctrine" | "context"` to `"doctrine" | "context" | "anti_ghosting"` so the scheduler can attribute usage correctly.

### Modified file: `services/scheduler.ts` (7 surgical edits)

1. **Imports** — adds `generateAntiGhostingFollowup`, `computeDaysSinceSeedTier`, `AntiGhostingFollowupContext`, `parseGmailThread`, `getGmailForUser`.
2. **Dispatcher SELECT** — adds `cycle: followupsTable.cycle` so the row payload carries cycle info.
3. **Exclusion filter removed** — the B9c.1 `ne(prospectsTable.app, "anti_ghosting")` line that gated dispatch is deleted. AntiGhosting prospects now dispatch.
4. **previousFollowups cycle scoping** — adds `eq(followupsTable.cycle, item.cycle)` to the WHERE. Critical for renewals (cycle ≥ 2): without this, prior-cycle followups would leak into the current cycle's context. Doctrine/context have cycle=1 default so this is a no-op for them.
5. **AntiGhosting context build** — inserted before the existing `const ctx: FollowupContext` block. When `item.app === "anti_ghosting"`, builds a `Gmail` client via `getGmailForUser`, calls `parseGmailThread` for a **live thread re-read**, computes the `days_since_seed_tier`, and assembles an `AntiGhostingFollowupContext`. Failures throw and let the outer per-row catch handle them; the row stays `"queued"` for retry.
6. **runWithUsageContext widening** — `app` discriminator now selects `"anti_ghosting" | "context" | "doctrine"`.
7. **Dispatch ternary** — widened to a three-branch conditional. `anti_ghosting` calls `generateAntiGhostingFollowup(antiGhostingCtx)`; everything else uses the existing path.

All scheduler edits are applied by the patch script with NEW-first idempotency. Re-running is a no-op.

## Risk surface

1. **Live thread re-read couples dispatch to Gmail availability.** If a user's Gmail OAuth has expired, the AntiGhosting dispatch for their prospects will fail (logged, row stays queued). Doctrine/context dispatch is unaffected. Acceptable — a stale-token user shouldn't be sending automated re-engagement anyway, and the failure surfaces in logs for the operator to re-authenticate.

2. **Critic JSON parse failures fall back to the original draft.** Matches the existing context flow's safety net. If the draft itself is bad, the deterministic doctrineLint pre-flight still runs as a backstop.

3. **The forbidden-phrase rule is enforced by the critic only, not by a deterministic post-check.** A critic miss could let a forbidden phrase through. Mitigations: (a) the writer system prompt enumerates every forbidden phrase explicitly, (b) the rewriter system prompt also enumerates them, (c) the critic dimension `forbidden_phrase` is `1` (automatic fail) when present. Deterministic post-check is a B9c.3 hardening if needed after observing real output.

4. **No new schema changes.** B9a laid every column/table. B9b's status bug was fixed in B9c.1.

5. **Cycle scoping on `previousFollowups`** is a behavioural change to the existing doctrine/context dispatch. Strictly speaking it's a no-op for them (cycle=1 default), but it's worth flagging that *if* a doctrine/context prospect ever had cycle ≥ 2 by some manual DB edit, this change would alter the context they see. No such rows exist today; mentioned for completeness.

## Idempotency

The patch script uses a NEW-first check (skip if post-edit state already present) plus a special case for deletion edits (empty NEW): for deletions, it checks OLD's presence directly. Verified across two synthetic-fixture test runs: first run 9 FIX, second run 9 SKIP, no double-insertion, deletion correctly applied once.

## Layout

```
batch-b9c2-anti-ghosting-generator/
|-- README.md
|-- api-server/
|   |-- services/
|   |   |-- antiGhostingFollowupPrompts.ts   (new)
|   |   `-- antiGhostingFollowupGenerator.ts (new)
|   `-- tests/
|       `-- test-anti-ghosting-prompts-b9c2.ts (new)
`-- scripts/
    `-- apply-b9c2.py                         (patches anthropic.ts, usageContext.ts, scheduler.ts)
```

Mirror sync IS needed (new + modified source files). Workflow restart IS needed (scheduler imports change; in-process dispatcher state needs reload).

## Deferred

- **Deterministic post-check for forbidden phrases.** B9c.3 if observed misses warrant it.
- **Pause + renewal + notifications.** B9d.
- **Live re-read for doctrine/context too.** Not in scope — they don't need it.
- **Dashboard marking UI.** Still B9b.1; can ship at any point now that the backend is end-to-end functional.
- **AntiGhosting parity Settings.** B9e (or folded into B9d).
