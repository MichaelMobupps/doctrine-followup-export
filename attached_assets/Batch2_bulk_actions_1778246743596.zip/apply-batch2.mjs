#!/usr/bin/env node
/**
 * Batch 2 — Bulk Send All / Pause All
 *
 * What this does:
 *   1. Adds two new backend endpoints to routes/doctrine.ts:
 *        POST /doctrine/followup/send-bulk    body { prospectIds: number[] }
 *        POST /doctrine/prospect/pause-bulk   body { prospectIds: number[] }
 *      Both wrap the existing single-row logic. send-bulk loops per prospect
 *      with per-row error reporting; pause-bulk uses single-statement bulk
 *      UPDATEs via inArray() since the per-row logic is just two writes.
 *
 *   2. Replaces the dashboard Pipeline page with the Batch 2 version:
 *        - Per-row checkbox in each thread Card
 *        - Select-all toggle in the filter row
 *        - Floating action bar appears at the bottom when 1+ rows selected
 *          with "Send all", "Pause all", and clear-selection buttons
 *
 *   3. Hard cap of 100 prospectIds per bulk-send call. No cap on pause-bulk
 *      (it's two cheap UPDATEs regardless of size).
 *
 * Idempotent: every step checks for an "already applied" anchor before
 * writing. Re-running is a no-op.
 */
import fs from "node:fs";
import path from "node:path";
import url from "node:url";

const SCRIPT_DIR = path.dirname(url.fileURLToPath(import.meta.url));
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";

const PIPELINE_DST = path.join(DASH_BASE, "pages/pipeline.tsx");
const PIPELINE_SRC = path.join(SCRIPT_DIR, "payload/pages/pipeline.tsx");
const DOCTRINE     = path.join(API_BASE, "routes/doctrine.ts");

let changed = 0;
let skipped = 0;

function read(p) {
  if (!fs.existsSync(p)) {
    console.error(`[fail] file not found: ${p}`);
    process.exit(1);
  }
  return fs.readFileSync(p, "utf8");
}
function write(p, s) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, s, "utf8");
}

function copyOnce(label, srcPath, dstPath) {
  if (!fs.existsSync(srcPath)) {
    console.error(`  [fail] ${label}: payload missing at ${srcPath}`);
    process.exit(1);
  }
  const expected = read(srcPath);
  if (fs.existsSync(dstPath) && read(dstPath) === expected) {
    console.log(`  [skip] ${label} (already in place)`);
    skipped++;
    return;
  }
  write(dstPath, expected);
  console.log(`  [ok] ${label}`);
  changed++;
}

function replaceOnce(filePath, label, oldStr, newStr) {
  const src = read(filePath);
  if (src.includes(newStr)) {
    console.log(`  [skip] ${label} (already applied)`);
    skipped++;
    return;
  }
  const occurrences = src.split(oldStr).length - 1;
  if (occurrences === 0) {
    console.error(`  [fail] ${label}: anchor not found`);
    console.error(`         expected:\n${oldStr.split("\n").slice(0, 3).join("\n")}...`);
    process.exit(1);
  }
  if (occurrences > 1) {
    console.error(`  [fail] ${label}: anchor matched ${occurrences} times — must be unique`);
    process.exit(1);
  }
  write(filePath, src.replace(oldStr, newStr));
  console.log(`  [ok] ${label}`);
  changed++;
}

// ---------- 1. Install new pipeline.tsx ----------

console.log(`\n[1/2] ${PIPELINE_DST}`);
copyOnce("install pipeline.tsx (Batch 2)", PIPELINE_SRC, PIPELINE_DST);

// ---------- 2. Add bulk endpoints to doctrine.ts ----------

console.log(`\n[2/2] ${DOCTRINE}`);

// Anchor at the cancel route, which sits at a stable point near the other
// prospect-mutation routes. Insert the two bulk routes immediately before it.
const BULK_ROUTES = `// ---------- Batch 2: bulk endpoints ----------

router.post("/followup/send-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }
  if (ids.length > 100) {
    res.status(400).json({ error: "Bulk send limited to 100 prospects per call" });
    return;
  }

  const { processDueFollowups } = await import("../services/scheduler");
  const sent: number[] = [];
  const failed: Array<{ prospectId: number; error: string }> = [];

  for (const prospectId of ids) {
    try {
      const prospect = await db.select().from(prospectsTable).where(eq(prospectsTable.id, prospectId)).limit(1);
      if (!prospect[0]) { failed.push({ prospectId, error: "prospect not found" }); continue; }
      const p = prospect[0];
      if (!p.userId) { failed.push({ prospectId, error: "prospect has no associated user" }); continue; }

      const user = await db.select().from(usersTable).where(eq(usersTable.id, p.userId)).limit(1);
      if (!user[0]?.googleRefreshToken || !user[0]?.isConnected) {
        failed.push({ prospectId, error: "user Gmail not connected" }); continue;
      }

      // Reserve next stage slot via insert+conflict-retry, same pattern as
      // /followup-now/:prospectId. Without this we race any row already
      // sitting on the next stage slot and hit uq_followups_prospect_stage.
      const allFollowups = await db
        .select({ stage: followupsTable.stage })
        .from(followupsTable)
        .where(eq(followupsTable.prospectId, prospectId));

      let nextStage = allFollowups.length > 0
        ? Math.max(...allFollowups.map(f => f.stage)) + 1
        : 1;

      let insertedFollowupId: number | null = null;
      const MAX_ATTEMPTS = 50;
      for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
        const inserted = await db.insert(followupsTable).values({
          prospectId,
          stage: nextStage,
          status: "queued",
          scheduledAt: new Date(),
        }).onConflictDoNothing().returning({ id: followupsTable.id });

        if (inserted[0]?.id) { insertedFollowupId = inserted[0].id; break; }
        nextStage++;
      }

      if (!insertedFollowupId) {
        failed.push({ prospectId, error: "could not reserve a stage after 50 attempts" });
        continue;
      }

      const result = await processDueFollowups({ followupId: insertedFollowupId, forceSend: true });
      if (result.sent > 0) {
        sent.push(prospectId);
      } else if (result.failed > 0) {
        failed.push({ prospectId, error: "send failed in scheduler" });
      } else {
        // Followup got reserved + queued but processDueFollowups didn't act
        // on it (e.g. claimed by another worker). Treat as queued.
        sent.push(prospectId);
      }
    } catch (err) {
      failed.push({
        prospectId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  logger.info(
    { requested: ids.length, sent: sent.length, failed: failed.length },
    "Bulk send-now completed",
  );

  res.json({
    success: true,
    total: ids.length,
    sent: sent.length,
    failed,
    sent_prospect_ids: sent,
  });
});

router.post("/prospect/pause-bulk", async (req: Request, res: Response) => {
  const raw = (req.body && (req.body as any).prospectIds) || [];
  const ids = Array.isArray(raw)
    ? raw.map((v: unknown) => Number(v)).filter((n: number) => Number.isFinite(n) && n > 0)
    : [];
  if (ids.length === 0) {
    res.status(400).json({ error: "prospectIds must be a non-empty array of positive integers" });
    return;
  }

  try {
    const pausedResult = await db
      .update(prospectsTable)
      .set({ followupPaused: true })
      .where(inArray(prospectsTable.id, ids));

    const cancelledResult = await db
      .update(followupsTable)
      .set({ status: "cancelled" })
      .where(and(
        inArray(followupsTable.prospectId, ids),
        eq(followupsTable.status, "queued"),
      ));

    logger.info(
      { requested: ids.length, paused: pausedResult.rowCount || 0, cancelled: cancelledResult.rowCount || 0 },
      "Bulk pause completed",
    );

    res.json({
      success: true,
      requested: ids.length,
      paused: pausedResult.rowCount || 0,
      cancelled_queued: cancelledResult.rowCount || 0,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

`;

replaceOnce(
  DOCTRINE,
  "insert bulk routes before /cancel",
  `router.post("/cancel", async (req: Request, res: Response) => {`,
  BULK_ROUTES + `router.post("/cancel", async (req: Request, res: Response) => {`,
);

// ---------- Verify ----------

console.log(`\n[verify]`);

const finalPipeline = read(PIPELINE_DST);
const finalDoctrine = read(DOCTRINE);

const checks = [
  [finalPipeline.includes("selectedIds"),                                                "pipeline.tsx: selection state present"],
  [finalPipeline.includes("handleBulkSend"),                                             "pipeline.tsx: bulk send handler"],
  [finalPipeline.includes("handleBulkPause"),                                            "pipeline.tsx: bulk pause handler"],
  [finalPipeline.includes("api/followup/send-bulk"),                                     "pipeline.tsx: calls /followup/send-bulk"],
  [finalPipeline.includes("api/prospect/pause-bulk"),                                    "pipeline.tsx: calls /prospect/pause-bulk"],
  [finalPipeline.includes("CheckSquare"),                                                "pipeline.tsx: CheckSquare icon imported"],
  [(finalPipeline.match(/<Square /g) || []).length >= 1,                                 "pipeline.tsx: Square icon used (unselected state)"],
  [finalDoctrine.includes(`router.post("/followup/send-bulk"`),                          "doctrine.ts: /followup/send-bulk route"],
  [finalDoctrine.includes(`router.post("/prospect/pause-bulk"`),                         "doctrine.ts: /prospect/pause-bulk route"],
  [finalDoctrine.includes(`Bulk send-now completed`),                                    "doctrine.ts: send-bulk logger line present"],
  [finalDoctrine.includes(`Bulk pause completed`),                                       "doctrine.ts: pause-bulk logger line present"],
  [(finalDoctrine.match(/router\.post\("\/cancel"/g) || []).length === 1,                "doctrine.ts: original /cancel route still present, exactly once"],
];

let failed = 0;
for (const [ok, label] of checks) {
  console.log(`  ${ok ? "[ok]" : "[fail]"} ${label}`);
  if (!ok) failed++;
}

console.log(`\nsummary: ${changed} change(s) applied, ${skipped} skipped (already applied)`);
if (failed > 0) {
  console.error(`verify: ${failed} check(s) failed`);
  process.exit(1);
}
console.log("verify: all checks passed");
