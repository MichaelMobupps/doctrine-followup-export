#!/usr/bin/env node
/**
 * apply-batch7e-hotfix1.mjs — Hotfix for Phase 7e.
 *
 * Bug: Batch 7e reshaped /api/context/followups to use
 *   .orderBy(asc(followupsTable.scheduledAt))
 * for parity with doctrine, but did not add `asc` to the drizzle-orm
 * import in routes/context.ts. Result: GET /api/context/followups
 * returns {"error":"asc is not defined"} at runtime.
 *
 * Fix: extend the existing drizzle-orm named-import line to include `asc`.
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src node apply-batch7e-hotfix1.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[hotfix-7e-1] ${msg}`);
const fail = (msg) => { console.error(`[hotfix-7e-1] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const contextRoutePath = join(API_BASE, "routes", "context.ts");

log("Adding `asc` to drizzle-orm import in routes/context.ts...");

strReplace(
  contextRoutePath,
  `import { and, eq, sql, inArray, desc } from "drizzle-orm";`,
  `import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";`,
  "context.ts: add asc to drizzle-orm import",
  `import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";`
);

// Self-verify
log("Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

expectInFile(contextRoutePath, `import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";`,
  "V1 asc included in drizzle-orm import");
expectInFile(contextRoutePath, `.orderBy(asc(followupsTable.scheduledAt))`,
  "V2 the asc() call site that the import services");

// Confirm no leftover legacy form
const final = readFileOrFail(contextRoutePath);
if (/import \{ and, eq, sql, inArray, desc \} from "drizzle-orm";/.test(final)) {
  fail(`Legacy import line still present`);
}
log(`  [OK] V3 legacy import line removed`);

log("");
log("================================================================");
log("Hotfix applied. /api/context/followups should resolve `asc` after");
log("api-server rebuild + restart.");
log("================================================================");
