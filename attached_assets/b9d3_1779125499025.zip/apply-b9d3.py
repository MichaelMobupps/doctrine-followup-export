#!/usr/bin/env python3
"""
B9d.3 - Card + Badge + Input + Select polish.

Four anchors in components/ui.tsx:
  A1: Card           - add shadow-sm for depth (visible on AG light bg,
                       near-invisible on Doctrine/Context dark bg).
  A2: Badge          - pill shape (rounded-full) + slight padding bump
                       (px-2.5) for modern indicator feel.
  A3: Input          - replace the inline onFocus/onBlur style hack with
                       CSS-class focus state (focus:border + focus:ring).
                       Identical visual, cleaner code, user-supplied
                       onFocus/onBlur handlers now flow through naturally.
  A4: Select         - same cleanup as Input.

Visual deltas inherit through tokens, so AG light theme + Doctrine/
Context dark theme all benefit without per-product code.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: Card - add shadow-sm
# ====================================================================
A1_OLD = '''export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("rounded-lg", className)}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...props}
  />
);'''

A1_NEW = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("rounded-lg shadow-sm", className)}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...props}
  />
);'''


# ====================================================================
# A2: Badge - pill shape + padding bump
# ====================================================================
A2_OLD = '''        "inline-flex items-center rounded px-2 py-0.5 font-medium font-mono",'''

A2_NEW = '''        // B9d.3: pill shape + slight padding bump for modern indicator feel.
        "inline-flex items-center rounded-full px-2.5 py-0.5 font-medium font-mono",'''


# ====================================================================
# A3: Input - CSS-class focus state
# ====================================================================
A3_OLD = '''    return (
      <input
        ref={ref}
        className={cn(
          "flex h-9 w-full rounded-md px-3 py-2 text-[13px] transition-all duration-150 placeholder:text-[var(--text-tertiary)] focus:outline-none disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        style={{
          background: "var(--bg-primary)",
          border: "1px solid var(--border-default)",
          color: "var(--text-primary)",
        }}
        onFocus={(e) => {
          e.target.style.borderColor = "var(--accent)";
          e.target.style.boxShadow = "0 0 0 2px var(--accent-muted)";
          props.onFocus?.(e);
        }}
        onBlur={(e) => {
          e.target.style.borderColor = "var(--border-default)";
          e.target.style.boxShadow = "none";
          props.onBlur?.(e);
        }}
        {...props}
      />
    );'''

A3_NEW = '''    return (
      // B9d.3: focus state via CSS classes - replaces inline onFocus/onBlur style mutation.
      <input
        ref={ref}
        className={cn(
          "flex h-9 w-full rounded-md px-3 py-2 text-[13px] transition-all duration-200",
          "bg-[var(--bg-primary)] text-[var(--text-primary)] border border-[var(--border-default)]",
          "placeholder:text-[var(--text-tertiary)]",
          "focus:outline-none focus:border-[var(--accent)] focus:ring-2 focus:ring-[var(--accent-muted)]",
          "disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        {...props}
      />
    );'''


# ====================================================================
# A4: Select - same cleanup as Input
# ====================================================================
A4_OLD = '''    return (
      <select
        ref={ref}
        className={cn(
          "flex h-9 w-full appearance-none rounded-md px-3 py-2 text-[13px] transition-all duration-150 focus:outline-none disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        style={{
          background: "var(--bg-primary)",
          border: "1px solid var(--border-default)",
          color: "var(--text-primary)",
        }}
        onFocus={(e) => {
          e.target.style.borderColor = "var(--accent)";
          e.target.style.boxShadow = "0 0 0 2px var(--accent-muted)";
          props.onFocus?.(e);
        }}
        onBlur={(e) => {
          e.target.style.borderColor = "var(--border-default)";
          e.target.style.boxShadow = "none";
          props.onBlur?.(e);
        }}
        {...props}
      />
    );'''

A4_NEW = '''    return (
      // B9d.3: focus state via CSS classes - replaces inline onFocus/onBlur style mutation.
      <select
        ref={ref}
        className={cn(
          "flex h-9 w-full appearance-none rounded-md px-3 py-2 text-[13px] transition-all duration-200",
          "bg-[var(--bg-primary)] text-[var(--text-primary)] border border-[var(--border-default)]",
          "focus:outline-none focus:border-[var(--accent)] focus:ring-2 focus:ring-[var(--accent-muted)]",
          "disabled:cursor-not-allowed disabled:opacity-50",
          className
        )}
        {...props}
      />
    );'''


def main():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: Card add shadow",
        marker="B9d.3: subtle shadow for depth",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: Badge pill shape",
        marker="B9d.3: pill shape",
    )

    text, _ = replace_unique(
        text, A3_OLD, A3_NEW,
        "A3: Input CSS-class focus",
        marker="<input\n        ref={ref}\n        className={cn(\n          \"flex h-9 w-full rounded-md px-3 py-2 text-[13px] transition-all duration-200\"",
    )

    text, _ = replace_unique(
        text, A4_OLD, A4_NEW,
        "A4: Select CSS-class focus",
        marker="<select\n        ref={ref}\n        className={cn(\n          \"flex h-9 w-full appearance-none rounded-md px-3 py-2 text-[13px] transition-all duration-200\"",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")

    print()
    print("B9d.3 card/badge/input/select polish applied.")


if __name__ == "__main__":
    main()
