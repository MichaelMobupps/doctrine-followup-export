#!/usr/bin/env node
/**
 * apply-batch7g.mjs — Phase 7g (Context Email Inspector backend).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * One concern only: add /api/context/gmail/sent-emails to context.ts.
 * Frontend ContextEmailInspector clone ships in 7h.
 *
 * The new endpoint mirrors /api/gmail/sent-emails (defined in
 * routes/email-inspector.ts) but with these differences:
 *
 *   1. Labels resolved per-user from users.contextLabel (the value
 *      the user set in Settings) — not from the server-wide
 *      DOCTRINE_LABELS env var.
 *   2. Response uses hasContextLabel / matchedContextLabels /
 *      withContextLabel field names.
 *   3. DB cross-reference filters prospects WHERE app='context' so
 *      doctrine prospects don't false-positive against context
 *      Inspector results.
 *   4. Vertical inference is skipped — context prospects don't carry
 *      verticals. detection.vertical / subVertical / verticalReason
 *      return empty strings.
 *
 * The /api/gmail/thread/:threadId endpoint stays shared between
 * products (a Gmail thread is product-agnostic).
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src node apply-batch7g.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[apply-batch7g] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7g] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const contextRoutePath = join(API_BASE, "routes", "context.ts");

// ============================================================
// Step 1: Extend imports
// ============================================================
log("Step 1: Extend imports in context.ts...");

strReplace(
  contextRoutePath,
  `import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { db, prospectsTable, followupsTable, usersTable } from "@workspace/db";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { logger } from "../lib/logger";`,
  `import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { google, gmail_v1 } from "googleapis";
import { db, prospectsTable, followupsTable, usersTable } from "@workspace/db";
import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { getGmailForUser } from "../services/gmailClient";
import { logger } from "../lib/logger";
// Phase 7g: googleapis + getGmailForUser imports for /gmail/sent-emails.`,
  "context.ts: extend imports for inspector",
  `// Phase 7g: googleapis + getGmailForUser imports for /gmail/sent-emails.`
);

// ============================================================
// Step 2: Inline helpers (mirror email-inspector.ts module-private fns)
// ============================================================
log("Step 2: Inline helpers...");

strReplace(
  contextRoutePath,
  `// All prospect queries are scoped to app='context' via this constant. If
// a request includes ?userId=N, it's also scoped to that user.
const SCOPE = eq(prospectsTable.app, "context");

// Phase 7f: shared helper inlined for the /campaign/status aggregation.
// Mirrors the doctrine.ts copy (3 lines, no good place to extract yet).
function getFollowupCap(maxFollowups?: number | null): number | null {
  return typeof maxFollowups === "number" && maxFollowups > 0 ? maxFollowups : null;
}`,
  `// All prospect queries are scoped to app='context' via this constant. If
// a request includes ?userId=N, it's also scoped to that user.
const SCOPE = eq(prospectsTable.app, "context");

// Phase 7f: shared helper inlined for the /campaign/status aggregation.
// Mirrors the doctrine.ts copy (3 lines, no good place to extract yet).
function getFollowupCap(maxFollowups?: number | null): number | null {
  return typeof maxFollowups === "number" && maxFollowups > 0 ? maxFollowups : null;
}

// Phase 7g: helpers for /gmail/sent-emails (Context Email Inspector).
// Mirror the module-private helpers in routes/email-inspector.ts.
// Future cleanup: extract to a shared lib once a third consumer exists.

function getLegacyGmail(): gmail_v1.Gmail {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
  );
  auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
  return google.gmail({ version: "v1", auth });
}

async function getGmailForRequest(req: Request): Promise<{ gmail: gmail_v1.Gmail; senderEmail: string }> {
  const userId = req.query.userId ? parseInt(req.query.userId as string) : null;

  if (userId) {
    const users = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    if (users.length > 0 && users[0].googleRefreshToken && users[0].isConnected) {
      return {
        gmail: getGmailForUser({ refreshToken: users[0].googleRefreshToken, email: users[0].email }),
        senderEmail: users[0].email.toLowerCase(),
      };
    }
  }

  return {
    gmail: getLegacyGmail(),
    senderEmail: (process.env.SENDER_EMAIL || "").toLowerCase(),
  };
}

function extractEmail(headerValue: string): string {
  const match = headerValue.match(/<([^>]+)>/) || headerValue.match(/([^\\s,]+@[^\\s,]+)/);
  return match ? match[1].trim() : headerValue.trim();
}

function extractName(headerValue: string): string {
  const match = headerValue.match(/^"?([^"<]+)"?\\s*</);
  if (match) return match[1].trim();
  const email = extractEmail(headerValue);
  return email.split("@")[0].replace(/[._-]/g, " ");
}

function isWithinSyncWindow(timestamp: number): boolean {
  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  return timestamp >= sixtyDaysAgo.getTime();
}`,
  "context.ts: inline gmail-inspector helpers",
  `// Phase 7g: helpers for /gmail/sent-emails (Context Email Inspector).`
);

// ============================================================
// Step 3: Add the /gmail/sent-emails handler
// ============================================================
log("Step 3: Add /gmail/sent-emails handler...");

// Anchor: insert just before the existing /campaign/status handler so
// the sent-emails handler sits in a sensible place (between /cancel and
// /campaign/status). The anchor is the comment block that introduces
// /campaign/status.
strReplace(
  contextRoutePath,
  `// Phase 7f: rich per-user campaign aggregation matching the doctrine
// shape so the Context Activity Log UI clone can consume it without
// any divergence from activity-log.tsx beyond the label-field rename
// (doctrine_label → context_label).`,
  `// Phase 7g: Context Email Inspector backend. Returns sent emails from
// the user's Gmail with hasContextLabel flagging, plus a DB
// cross-reference scoped to app='context'. Mirrors the structure of
// /api/gmail/sent-emails (in routes/email-inspector.ts) but does NOT
// run vertical inference — context prospects don't carry verticals.
router.get("/gmail/sent-emails", async (req: Request, res: Response) => {
  try {
    const { gmail, senderEmail } = await getGmailForRequest(req);
    const maxResults = Math.min(parseInt(req.query.limit as string) || 30, 50);

    // Resolve labels from the user's contextLabel setting (per-user),
    // not from a global env var. If no userId is given or the user has
    // no contextLabel set, fall back to "Context Followuper".
    const userIdForLabels = req.query.userId ? parseInt(req.query.userId as string) : null;
    let contextLabelStr = "Context Followuper";
    if (userIdForLabels) {
      const u = await db
        .select({ contextLabel: usersTable.contextLabel })
        .from(usersTable)
        .where(eq(usersTable.id, userIdForLabels))
        .limit(1);
      if (u.length > 0 && u[0].contextLabel) contextLabelStr = u[0].contextLabel;
    }
    const contextLabels = contextLabelStr.split(",").map((l) => l.trim()).filter(Boolean);

    const allLabelsRes = await gmail.users.labels.list({ userId: "me" });
    const allLabels = allLabelsRes.data.labels || [];
    const labelNameMap: Record<string, string> = {};
    const contextLabelIds: string[] = [];
    for (const label of allLabels) {
      if (label.id && label.name) {
        labelNameMap[label.id] = label.name;
        const nameLower = label.name.toLowerCase();
        if (contextLabels.some((cl) => nameLower === cl.toLowerCase() || nameLower.startsWith(cl.toLowerCase() + "/"))) {
          contextLabelIds.push(label.id);
        }
      }
    }

    let q = "in:sent";
    if (req.query.search) {
      q += \` \${req.query.search}\`;
    }

    const listRes = await gmail.users.messages.list({
      userId: "me",
      q,
      maxResults,
    });

    const items = listRes.data.messages || [];
    const emails: any[] = [];

    for (const item of items) {
      if (!item.id) continue;
      try {
        const msgRes = await gmail.users.messages.get({
          userId: "me",
          id: item.id,
          format: "full",
        });

        const msg = msgRes.data;
        if (!msg.id || !msg.threadId) continue;

        const headers = msg.payload?.headers || [];
        const getHeader = (name: string) =>
          headers.find((h) => h.name?.toLowerCase() === name.toLowerCase())?.value || "";

        let body = "";
        const parts = msg.payload?.parts || [];
        if (msg.payload?.mimeType === "text/plain" && msg.payload?.body?.data) {
          body = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
        } else {
          for (const part of parts) {
            if (part.mimeType === "text/plain" && part.body?.data) {
              body = Buffer.from(part.body.data, "base64").toString("utf-8");
              break;
            }
          }
        }
        if (!body) {
          let htmlBody = "";
          if (msg.payload?.mimeType === "text/html" && msg.payload?.body?.data) {
            htmlBody = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
          } else {
            for (const part of parts) {
              if (part.mimeType === "text/html" && part.body?.data) {
                htmlBody = Buffer.from(part.body.data, "base64").toString("utf-8");
                break;
              }
            }
          }
          if (htmlBody) {
            body = htmlBody
              .replace(/<style[^>]*>[\\s\\S]*?<\\/style>/gi, "")
              .replace(/<script[^>]*>[\\s\\S]*?<\\/script>/gi, "")
              .replace(/<br\\s*\\/?>/gi, "\\n")
              .replace(/<\\/p>/gi, "\\n")
              .replace(/<\\/div>/gi, "\\n")
              .replace(/<[^>]+>/g, "")
              .replace(/&nbsp;/g, " ")
              .replace(/&amp;/g, "&")
              .replace(/&lt;/g, "<")
              .replace(/&gt;/g, ">")
              .replace(/&quot;/g, '"')
              .replace(/&#39;/g, "'")
              .replace(/\\n{3,}/g, "\\n\\n")
              .trim();
          }
        }

        const labelIds = msg.labelIds || [];
        const labelNames = labelIds.map((id) => labelNameMap[id] || id);
        const hasContextLabel = labelIds.some((id) => contextLabelIds.includes(id));
        const matchedContextLabels = labelIds
          .filter((id) => contextLabelIds.includes(id))
          .map((id) => labelNameMap[id] || id);

        const to = getHeader("To");
        const subject = getHeader("Subject");
        const from = getHeader("From");
        const date = getHeader("Date");
        const recipientEmail = extractEmail(to);
        const recipientName = extractName(to);
        const timestamp = parseInt(msg.internalDate || "0");

        const isSentByMe = senderEmail ? from.toLowerCase().includes(senderEmail) : false;
        const withinSyncWindow = isWithinSyncWindow(timestamp);

        const wouldBePickedUp = hasContextLabel && isSentByMe && withinSyncWindow;

        const reasons: string[] = [];
        if (!isSentByMe) reasons.push("Not sent by configured sender email");
        if (!hasContextLabel) reasons.push("Missing context label");
        if (!withinSyncWindow) reasons.push("Outside 60-day sync window");

        emails.push({
          id: msg.id,
          threadId: msg.threadId,
          from,
          to,
          recipientEmail,
          recipientName,
          subject,
          snippet: msg.snippet || "",
          bodyPreview: body.slice(0, 800).trim(),
          date,
          timestamp,
          labelIds,
          labelNames,
          hasContextLabel,
          matchedContextLabels,
          isSentByMe,
          detection: {
            wouldBePickedUp,
            whyNot: wouldBePickedUp ? [] : reasons,
            // Phase 7g: vertical inference skipped for context — context
            // prospects don't carry verticals. Empty strings keep the UI
            // shape stable.
            vertical: "",
            subVertical: "",
            verticalReason: "",
            withinSyncWindow,
            company: recipientEmail ? (recipientEmail.split("@")[1]?.split(".")[0] || "") : "",
          },
        });
      } catch (err) {
        logger.error({ err, messageId: item.id }, "Context email inspector — failed to fetch message");
      }
    }

    // DB cross-reference. Same query shape as doctrine but gated on
    // app='context' so doctrine prospects don't false-positive.
    const messageIds = emails.map((e) => e.id);
    const threadIds = [...new Set(emails.map((e) => e.threadId).filter(Boolean))];
    const dbByMessageId: Record<string, any> = {};
    const dbByThreadId: Record<string, any> = {};
    if (messageIds.length > 0) {
      const rows = await db
        .select({
          gmailMessageId: prospectsTable.gmailMessageId,
          gmailThreadId: prospectsTable.gmailThreadId,
          id: prospectsTable.id,
          replied: prospectsTable.replied,
        })
        .from(prospectsTable)
        .where(and(SCOPE, inArray(prospectsTable.gmailMessageId, messageIds)));
      for (const row of rows) {
        if (row.gmailMessageId) dbByMessageId[row.gmailMessageId] = row;
      }
    }
    if (threadIds.length > 0) {
      const threadRows = await db
        .select({
          gmailMessageId: prospectsTable.gmailMessageId,
          gmailThreadId: prospectsTable.gmailThreadId,
          id: prospectsTable.id,
          replied: prospectsTable.replied,
        })
        .from(prospectsTable)
        .where(and(SCOPE, inArray(prospectsTable.gmailThreadId, threadIds)));
      for (const row of threadRows) {
        if (row.gmailThreadId && !dbByThreadId[row.gmailThreadId]) {
          dbByThreadId[row.gmailThreadId] = row;
        }
      }
    }

    const enrichedEmails = emails.map((e) => {
      const directMatch = dbByMessageId[e.id];
      const threadMatch = dbByThreadId[e.threadId];
      const dbRecord = directMatch || threadMatch;
      const matchType = directMatch ? "message" : threadMatch ? "thread" : null;
      return {
        ...e,
        inDatabase: !!dbRecord,
        ...(dbRecord ? { dbRecord: { ...dbRecord, matchType } } : {}),
      };
    });

    res.json({
      emails: enrichedEmails,
      meta: {
        total: enrichedEmails.length,
        withContextLabel: enrichedEmails.filter((e) => e.hasContextLabel).length,
        inDatabase: enrichedEmails.filter((e) => e.inDatabase).length,
        wouldBePickedUp: enrichedEmails.filter((e) => e.detection.wouldBePickedUp).length,
        contextLabelIds,
        contextLabels,
      },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "Context email inspector error");
    res.status(500).json({ error: msg });
  }
});

// Phase 7f: rich per-user campaign aggregation matching the doctrine
// shape so the Context Activity Log UI clone can consume it without
// any divergence from activity-log.tsx beyond the label-field rename
// (doctrine_label → context_label).`,
  "context.ts: add /gmail/sent-emails handler",
  `// Phase 7g: Context Email Inspector backend. Returns sent emails from`
);

// ============================================================
// Step 4: Self-verify
// ============================================================
log("Step 4: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Imports
expectInFile(contextRoutePath, `import { google, gmail_v1 } from "googleapis";`, "V1  googleapis import");
expectInFile(contextRoutePath, `import { getGmailForUser } from "../services/gmailClient";`, "V2  getGmailForUser import");

// Helpers
expectInFile(contextRoutePath, `function getLegacyGmail(): gmail_v1.Gmail {`, "V3  getLegacyGmail helper");
expectInFile(contextRoutePath, `async function getGmailForRequest(req: Request): Promise<{ gmail: gmail_v1.Gmail; senderEmail: string }> {`, "V4  getGmailForRequest helper");
expectInFile(contextRoutePath, `function extractEmail(headerValue: string): string {`, "V5  extractEmail helper");
expectInFile(contextRoutePath, `function extractName(headerValue: string): string {`, "V6  extractName helper");
expectInFile(contextRoutePath, `function isWithinSyncWindow(timestamp: number): boolean {`, "V7  isWithinSyncWindow helper");

// Handler
expectInFile(contextRoutePath, `router.get("/gmail/sent-emails"`, "V8  /gmail/sent-emails route declared");
expectInFile(contextRoutePath, `let contextLabelStr = "Context Followuper";`, "V9  contextLabel default fallback");
expectInFile(contextRoutePath, `contextLabel: usersTable.contextLabel,`, "V10 contextLabel projected from users");
expectInFile(contextRoutePath, `const hasContextLabel = labelIds.some(`, "V11 hasContextLabel computed");
expectInFile(contextRoutePath, `const matchedContextLabels = labelIds`, "V12 matchedContextLabels computed");
expectInFile(contextRoutePath, `const wouldBePickedUp = hasContextLabel && isSentByMe && withinSyncWindow;`, "V13 wouldBePickedUp uses context");
expectInFile(contextRoutePath, `if (!hasContextLabel) reasons.push("Missing context label");`, "V14 missing-label reason text");
expectInFile(contextRoutePath, `vertical: "",`, "V15 empty vertical (skipped inference)");
expectInFile(contextRoutePath, `.where(and(SCOPE, inArray(prospectsTable.gmailMessageId, messageIds)));`, "V16 messageId DB cross-ref scoped to context");
expectInFile(contextRoutePath, `.where(and(SCOPE, inArray(prospectsTable.gmailThreadId, threadIds)));`, "V17 threadId DB cross-ref scoped to context");
expectInFile(contextRoutePath, `withContextLabel: enrichedEmails.filter((e) => e.hasContextLabel).length,`, "V18 meta.withContextLabel");
expectInFile(contextRoutePath, `contextLabelIds,`, "V19 meta.contextLabelIds");

// Things that MUST be absent (regression / no doctrine bleed-through)
expectNotInFile(contextRoutePath, `hasDoctrineLabel`, "V20 hasDoctrineLabel field absent");
expectNotInFile(contextRoutePath, `matchedDoctrineLabels`, "V21 matchedDoctrineLabels field absent");
expectNotInFile(contextRoutePath, `withDoctrineLabel`, "V22 withDoctrineLabel field absent");
expectNotInFile(contextRoutePath, `process.env.DOCTRINE_LABELS`, "V23 DOCTRINE_LABELS env var not used");
expectNotInFile(contextRoutePath, `inferVertical`, "V24 vertical inference not used");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7g patch applied. /api/context/gmail/sent-emails is live.");
log("Per-user contextLabel resolution. DB cross-ref scoped to context.");
log("Frontend ContextEmailInspector clone ships in 7h.");
log("================================================================");
