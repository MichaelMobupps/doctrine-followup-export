# Followuper v4 Round-2 — Universal native-style detectors

TypeScript twin of Prospector v4 Round-2. Three new detectors generalize
Denise's BR-PT review feedback into universal native-business-style checks
across every language the v4 layer covers.

## What this fixes

Three failure modes universal to every language v4 handles:

1. **Repeating discourse markers** — same "worth mentioning"-class sentence
   starter used 2+ times in one email.
2. **Semicolons without connectors** — clause coherence after `;` in
   Romance/Germanic/Slavic/English business prose.
3. **Non-reflexive Romance verbs** — bare verb where Romance business prose
   expects the reflexive form.

## The 3 new detectors

| Detector | Languages | Severity |
|---|---|---|
| REPEATING-DISCOURSE-MARKER | en, pt, pt-BR, es, fr, de, it, nl, ja, zh, ko, ar, he, ru, uk, tr, hi, pl, cs, hu, ro, sv, no, nb, da, fi (26 langs) | block |
| SEMICOLON-NO-CONNECTOR | en, pt, pt-BR, es, fr, de, it, nl, ru, uk, pl, cs, hu, ro, sv, no, nb, da, fi (17 langs; OFF for ja/zh/ko/th/ar/he/fa/ur/hi/bn/vi/id/ms/fil/tr/el) | block |
| NON-REFLEXIVE-ROMANCE-VERB | pt, pt-BR, es, fr, it | block |

The semicolon detector skips `;\n` (newline immediately after) to avoid false
positives on PT/ES/IT bullet-list style.

## File inventory

```
followuper-nativeness-v4r2/
  README.md                                            # this file
  audit_v44.sh                                         # 5-round audit (29 checks)
  patches/apply_patches.py                             # 7 ops, idempotent
  api-server/tests/test-nativeness-v4-round2.ts        # 40 tests (node:test)
  v44Detectors.ts                                      # TS source for inject
```

## The 7 operations

1. NewFile `api-server/tests/test-nativeness-v4-round2.ts` (40 tests)
2. Patch `nativenessV4.ts` — inject 3 detectors + 3 vocabulary tables + extend `NativenessV4Report` interface
3. Patch `nativenessV4.ts` — extend `findAllNativenessViolationsV4` aggregator
4. Patch `nativenessV4.ts` — extend `hasAnyViolationV4`
5. Patch `doctrineLint.ts` — emit 3 new lint codes
6. Patch `followupPrompts.ts` — add criteria 13i, 13j, 13k to critic prompt
7. Patch `test-nativeness-v4.ts` — extend expected-keys list (legitimate test update for new report shape)

Compatible with v4-baseline AND v4.3 hotfix (different files).

## Deploy procedure (Replit Doctrine Follow-up monorepo)

```bash
# From monorepo root
python3 /path/to/followuper-nativeness-v4r2/patches/apply_patches.py artifacts/

# Build
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/dashboard run build

# Run combined test sweep
cd artifacts/api-server
pnpm exec tsx --test \
    tests/test-nativeness-v3.ts \
    tests/test-nativeness-v4.ts \
    tests/test-nativeness-v4-round2.ts \
    tests/test-doctrine-hardening.ts
# Expected: 182 tests pass (24 v3 + 46 v4 + 40 v4 Round-2 + 72 doctrine hardening)

# Sync artifacts/ → source-code/
cd /path/to/monorepo && bash source-code/sync.sh
```

`@workspace/db` has no build step (skip). API key env var: `$ADDON_API_KEY`. Smoke tests target `localhost:80`.

## Rollback procedure

```bash
cd artifacts/api-server
for f in lib/nativenessV4 lib/doctrineLint services/followupPrompts tests/test-nativeness-v4; do
    cp ${f}.ts.v4r2_backup ${f}.ts && rm ${f}.ts.v4r2_backup
done
rm tests/test-nativeness-v4-round2.ts
```

## Audit

```
PASS: 29 / FAIL: 0 / WARN: 0
Status: GO-FOR-SHIP
```

- Round 1: 7/7 fresh, 7/7 idempotent, 4 backups byte-identical
- Round 2: 182 tests pass (incl 40 v4 Round-2 tests)
- Round 3: nativenessV4 + doctrineLint + followupPrompts load clean
- Round 4: 3 aggregator keys present, Denise email fires all 3 detectors, 3 lint codes in doctrineLint, 3 criteria in followupPrompts
- Round 5: Line deltas within budget; nativenessV3 / languageNativeness / doctrineRules byte-identical; rollback clean
