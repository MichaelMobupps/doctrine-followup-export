#!/usr/bin/env python3
"""
apply_patches.py — Followuper v4 Round-3 (volume calibration validation).

Followuper is a follow-up generator. It does NOT generate fresh volume
numbers (that's the Prospector's job). Its role with v4r3 is to VALIDATE
volume claims in follow-up emails using the same calibration logic.

Operations:
  1. NewFile lib/volumeCalibration.ts (TS port of Prospector calibration)
  2. NewFile tests/test-volume-calibration-v4r3.ts
  3. Patch doctrineLint.ts to emit VOLUME-MARKET-FLOOR and FUNNEL-COHERENCE
  4. Patch followupPrompts.ts to add criterion 14 to critic
"""

import shutil
import sys
from pathlib import Path


class Op:
    def __init__(self, name, path):
        self.name = name
        self.path = path
    def apply(self, root): raise NotImplementedError


class NewFile(Op):
    def __init__(self, name, path, content):
        super().__init__(name, path)
        self.content = content

    def apply(self, root):
        target = root / self.path
        if target.exists():
            existing = target.read_text(encoding="utf-8")
            if existing == self.content:
                return ("SKIP", f"{self.path} already installed (byte-identical)")
            return ("FAIL", f"{self.path} exists but differs from payload")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(self.content, encoding="utf-8")
        return ("OK", f"{self.path} installed ({len(self.content)} bytes)")


class Patch(Op):
    def __init__(self, name, path, anchor, marker, new_text, expected_count=1):
        super().__init__(name, path)
        self.anchor = anchor
        self.marker = marker
        self.new_text = new_text
        self.expected_count = expected_count

    def apply(self, root):
        target = root / self.path
        if not target.exists():
            return ("FAIL", f"{self.path} not found")
        text = target.read_text(encoding="utf-8")
        actual = text.count(self.marker)
        if actual >= self.expected_count:
            return ("SKIP", f"{self.path}: marker present {actual}x (>= {self.expected_count})")
        if self.anchor not in text:
            return ("FAIL", f"{self.path}: anchor not found AND marker count {actual} < {self.expected_count}")
        backup = target.with_suffix(target.suffix + ".v4r3_backup")
        if not backup.exists():
            shutil.copy2(target, backup)
        new_text = text.replace(self.anchor, self.new_text, 1)
        target.write_text(new_text, encoding="utf-8")
        return ("OK", f"{self.path}: anchor patched (marker now {new_text.count(self.marker)}x)")


SCRIPT_DIR = Path(__file__).resolve().parent
PAYLOAD_DIR = SCRIPT_DIR.parent

_CALIB_SRC = (PAYLOAD_DIR / "api-server" / "lib" / "volumeCalibration.ts").read_text(encoding="utf-8")
_TEST_FILE = (PAYLOAD_DIR / "api-server" / "tests" / "test-volume-calibration-v4r3.ts").read_text(encoding="utf-8")


# ============================================================================
# Op 3 — Patch doctrineLint.ts to emit VOLUME-MARKET-FLOOR + FUNNEL-COHERENCE
# ============================================================================

LINT_ANCHOR = """  // v4 Round-2: NON-REFLEXIVE-ROMANCE-VERB"""

LINT_NEW = """  // v4r3: VOLUME-MARKET-FLOOR + FUNNEL-COHERENCE
  // Deterministic checks that scan the email body for volume claims and
  // validate against the v4r3 calibration module.
  try {
    const { extractVolumeClaims, computeVolumeFloor, getMarketTier } =
      require("./volumeCalibration");
    const claims = extractVolumeClaims(body || "");
    if (claims.length > 0) {
      const market = (languageTag && languageTag.includes("-"))
        ? languageTag.split("-")[1]
        : "";
      // We don't have vertical/event in this scope — caller passes them
      // in via metadata if available. Default to conservative values that
      // still catch the worst Cars24-style failures.
      const vertical = "";  // unknown
      const namedEvent = "install";  // most common default
      const floor = computeVolumeFloor(market, vertical, namedEvent);
      for (const claim of claims) {
        if (claim.number > 0 && claim.number < floor) {
          const tier = getMarketTier(market);
          issues.push(
            `VOLUME-MARKET-FLOOR \\u2014 claimed ${claim.number}/day ` +
            `for ${namedEvent} in ${market || "unknown market"} ` +
            `(tier-${tier}) is below plausibility floor of ${floor}/day. ` +
            `Context: "${claim.context.slice(0, 60)}".`
          );
          suggestions.push(
            `For tier-${tier} markets, volume claims should match the ` +
            `market's scale. Consider revising upward or anchoring on a ` +
            `different metric (CVR, retention rate, ROAS) instead.`
          );
          matches.push(String(claim.number));
        }
      }
    }
  } catch (e) {
    // volumeCalibration module not yet installed or runtime error — skip
  }

  // v4 Round-2: NON-REFLEXIVE-ROMANCE-VERB"""

LINT_MARKER = "v4r3: VOLUME-MARKET-FLOOR"


# ============================================================================
# Op 4 — Add criterion 14 to followupPrompts critic
# ============================================================================

CRITIC_ANCHOR = """13h. LOANWORD INCONSISTENCY (adtech-heavy languages)."""

CRITIC_NEW = """14. VOLUME PLAUSIBILITY CHECK (v4r3 universal layer, severity: block, applies to EVERY email that quotes daily volume numbers). 14a. FUNNEL COHERENCE: Two volume numbers cannot be at the same magnitude across funnel depths. Install volume must exceed deep-funnel event volume by 2x or more. \"500 installs and 500 first deposits\" is incoherent — conversion rate from install to deposit is typically 5-15%, so 500 installs implies 25-75 deposits, not 500. If the email quotes equal/near-equal volumes for events at different funnel depths, score language_naturalness 1-2 and set needs_rewrite=true. 14b. MARKET SCALE FLOOR: Volume claims must match the market's scale. Tier-S markets (India, China, Indonesia, US, Brazil) have install floors of 2000-5000/day for major brands — quoting 500/day for Cars24 in India is below noise floor. Tier-C markets (Singapore, Israel, Netherlands) have much smaller scale — Cars24-scale numbers in Singapore are overstated. Floor formula: floor = vertical_base * funnel_multiplier * market_multiplier * 0.5, where vertical_base is install-band low (1500 hypercasual, 300 ecommerce, 200 fintech, etc.), funnel_multiplier is 1.0 for install/signup down to 0.05 for approved_loan/issued_advance, and market_multiplier is 15 for tier-S, 5 for tier-A, 2 for tier-B, 1 for tier-C. The deterministic linter emits VOLUME-MARKET-FLOOR for this case. If the email's volume claim is below floor or above 6x ceiling, score language_naturalness 1-2 and set needs_rewrite=true. 13h. LOANWORD INCONSISTENCY (adtech-heavy languages)."""

CRITIC_MARKER = "14. VOLUME PLAUSIBILITY CHECK"


OPS = [
    NewFile(
        name="install volumeCalibration.ts module",
        path="api-server/lib/volumeCalibration.ts",
        content=_CALIB_SRC,
    ),
    NewFile(
        name="install v4r3 test suite",
        path="api-server/tests/test-volume-calibration-v4r3.ts",
        content=_TEST_FILE,
    ),
    Patch(
        name="doctrineLint: emit VOLUME-MARKET-FLOOR check",
        path="api-server/lib/doctrineLint.ts",
        anchor=LINT_ANCHOR,
        marker=LINT_MARKER,
        new_text=LINT_NEW,
    ),
    Patch(
        name="followupPrompts: add criterion 14 (volume plausibility)",
        path="api-server/services/followupPrompts.ts",
        anchor=CRITIC_ANCHOR,
        marker=CRITIC_MARKER,
        new_text=CRITIC_NEW,
    ),
]


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    print(f"Followuper v4 Round-3 — applying {len(OPS)} operations")
    print(f"Target root: {root}\n")
    counts = {"OK": 0, "SKIP": 0, "FAIL": 0}
    for op in OPS:
        try:
            status, msg = op.apply(root)
        except Exception as exc:
            status, msg = ("FAIL", f"{type(exc).__name__}: {exc}")
        counts[status] = counts.get(status, 0) + 1
        sigil = {"OK": "  OK  ", "SKIP": " SKIP ", "FAIL": " FAIL "}[status]
        print(f"[{sigil}] {op.name}")
        print(f"         {msg}")
    print(f"\nSummary: {counts['OK']} OK, {counts['SKIP']} SKIP, {counts['FAIL']} FAIL")
    if counts["FAIL"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
