/**
 * Summarizes a cold outreach email body into a short context blurb
 * suitable for follow-up generation.
 *
 * The goal is to capture WHAT was pitched and the core value prop
 * in 1-2 sentences, so the follow-up writer knows the thread context
 * without being tempted to reproduce the original pitch verbatim.
 */

import { anthropic } from "@workspace/integrations-anthropic-ai";
import { logger } from "../lib/logger";

const SUMMARIZE_SYSTEM = `You are a concise email summarizer. Given a cold outreach email body, extract the core pitch in 1-2 sentences.

RULES:
- Output ONLY valid JSON, no preamble, no markdown fences.
- Return: {"summary": "...", "language": "..."}
- "summary": Capture what product/service was offered, what value proposition was made, and what action was requested. Use neutral third-person language: "Pitched [X] for [Y], highlighting [Z]." Maximum 80 words. Shorter is better. Do NOT reproduce original phrasing. Restate in your own words. If the email mentions specific metrics, campaigns, or competitor comparisons, note the topic but not the exact numbers or claims.
- "language": The ISO 639-1 language code of the email body (e.g., "en", "ja", "ko", "zh", "de", "fr", "es", "pt", "ru", "he", "ar"). Detect based on the actual text, not the names or domains mentioned. If the body is primarily in Japanese, return "ja". If primarily English, return "en". Etc.`;

export interface SummarizeResult {
  summary: string;
  language: string;
}

function detectLanguageFallback(text: string): string {
  const sample = text.slice(0, 500);
  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(sample)) return "ja";
  if (/[\uAC00-\uD7AF\u1100-\u11FF]/.test(sample)) return "ko";
  if (/[\u4E00-\u9FFF]/.test(sample) && !/[\u3040-\u309F\u30A0-\u30FF]/.test(sample)) return "zh";
  if (/[\u0590-\u05FF]/.test(sample)) return "he";
  if (/[\u0600-\u06FF]/.test(sample)) return "ar";
  if (/[\u0400-\u04FF]/.test(sample)) return "ru";
  return "en";
}

export async function summarizeOriginalEmail(body: string): Promise<SummarizeResult> {
  if (!body || body.trim().length < 30) {
    return { summary: body.trim(), language: detectLanguageFallback(body) };
  }

  try {
    const response = await anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 300,
      system: SUMMARIZE_SYSTEM,
      messages: [{ role: "user", content: body.slice(0, 1000) }],
    });

    const textBlock = response.content.find((b) => b.type === "text");
    if (textBlock && textBlock.type === "text" && textBlock.text.trim().length > 10) {
      try {
        const raw = textBlock.text.replace(/```json\s*|```/g, "").trim();
        const parsed = JSON.parse(raw);
        if (parsed.summary && parsed.language) {
          return { summary: parsed.summary.trim(), language: parsed.language.trim().toLowerCase() };
        }
        if (typeof parsed === "string" || parsed.summary) {
          return {
            summary: (parsed.summary || textBlock.text).trim(),
            language: detectLanguageFallback(body),
          };
        }
      } catch {
        return { summary: textBlock.text.trim(), language: detectLanguageFallback(body) };
      }
    }
  } catch (err) {
    logger.warn({ err }, "Email summarization failed, using truncated body");
  }

  const summary = body.slice(0, 200).trim() + (body.length > 200 ? "..." : "");
  return { summary, language: detectLanguageFallback(body) };
}
