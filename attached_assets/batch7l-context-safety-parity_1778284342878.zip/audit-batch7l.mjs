#!/usr/bin/env node
/**
 * audit-batch7l.mjs — Beautiful-Squidward audit for Phase 7l.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7l] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7l] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const ctxInspectorSrc   = read(join(DASH_BASE, "pages", "context-inspector.tsx"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

// Extract specific handler blocks from context.ts for targeted assertions.
function extractHandler(src, postPattern) {
  // Anchor-based: grab from the matching router.post(...) line until the matching `});` line.
  const re = new RegExp(`router\\.post\\(${postPattern}[\\s\\S]*?^\\}\\);$`, "m");
  const m = src.match(re);
  return m ? m[0] : "";
}

const pauseBlock     = extractHandler(ctxRouteSrc, `"\\/prospect\\/:id\\/pause"`);
const resumeBlock    = extractHandler(ctxRouteSrc, `"\\/prospect\\/:id\\/resume"`);
const pauseBulkBlock = extractHandler(ctxRouteSrc, `"\\/prospect\\/pause-bulk"`);

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: imports
  log(`-- PASS 1: timingEngine imports --`);
  pass(`Phase 7l import comment`, /Phase 7l: timingEngine helpers for \/prospect\/:id\/resume parity with doctrine\./.test(ctxRouteSrc));
  pass(`computeNextStageScheduledAt imported from timingEngine`, /import \{ computeNextStageScheduledAt \} from "\.\.\/services\/timingEngine";/.test(ctxRouteSrc));
  pass(`UserTimingSettings type imported from timingEngine`, /import type \{ UserTimingSettings \} from "\.\.\/services\/timingEngine";/.test(ctxRouteSrc));

  // PASS 2: Gap A — pause handler
  log(`-- PASS 2: Gap A pause handler --`);
  pass(`Pause handler block extracted`, pauseBlock.length > 0);
  pass(`Pause has Phase 7l Gap A comment`, /Phase 7l Gap A: SCOPE in WHERE makes this a single atomic op/.test(pauseBlock));
  pass(`Pause UPDATE WHERE includes SCOPE`, /set\(\{ followupPaused: true \}\)\.where\(and\(SCOPE, eq\(prospectsTable\.id, prospectId\)\)\)/.test(pauseBlock));
  pass(`Pause has no unconditional WHERE pattern`, !/\.where\(eq\(prospectsTable\.id, prospectId\)\)/.test(pauseBlock));

  // PASS 3: Gap A — pause-bulk handler
  log(`-- PASS 3: Gap A pause-bulk handler --`);
  pass(`Pause-bulk block extracted`, pauseBulkBlock.length > 0);
  pass(`Pause-bulk has Phase 7l Gap A comment`, /Phase 7l Gap A: contextIds was already SCOPE-filtered by the prior SELECT,/.test(pauseBulkBlock));
  pass(`Pause-bulk UPDATE WHERE includes SCOPE`, /set\(\{ followupPaused: true \}\)\.where\(and\(SCOPE, inArray\(prospectsTable\.id, contextIds\)\)\)/.test(pauseBulkBlock));
  pass(`Pause-bulk no unconditional inArray WHERE`, !/\.where\(inArray\(prospectsTable\.id, contextIds\)\)\s*;/.test(pauseBulkBlock));

  // PASS 4: Gap A — resume handler UPDATE
  log(`-- PASS 4: Gap A resume handler UPDATE --`);
  pass(`Resume block extracted`, resumeBlock.length > 0);
  pass(`Resume has Phase 7l Gap A comment`, /Phase 7l Gap A: SCOPE-gated UPDATE for the same defense-in-depth reason/.test(resumeBlock));
  pass(`Resume UPDATE WHERE includes SCOPE`, /set\(\{ followupPaused: false \}\)\.where\(and\(SCOPE, eq\(prospectsTable\.id, prospectId\)\)\)/.test(resumeBlock));

  // PASS 5: Gap B — resume immediately queues next stage
  log(`-- PASS 5: Gap B resume next-stage logic --`);
  pass(`Resume has Phase 7l Gap B comment`, /Phase 7l Gap B: parity with doctrine \/prospect\/:id\/resume/.test(resumeBlock));
  pass(`Resume reads max_followups via getFollowupCap`, /const maxFollowups = getFollowupCap\(user\?\.maxFollowups\);/.test(resumeBlock));
  pass(`Resume queries existing follow-ups`, /const existingFollowups = await db[\s\S]*?\.from\(followupsTable\)[\s\S]*?\.where\(eq\(followupsTable\.prospectId, prospectId\)\);/.test(resumeBlock));
  pass(`Resume splits sent vs active stages`, /sentRows = existingFollowups\.filter\(\(f\) => f\.status === "sent"\)/.test(resumeBlock) &&
                                              /activeStages = existingFollowups\.filter\(\(f\) => \["queued", "generating", "pending_approval", "drafted"\]\.includes\(f\.status\)\)/.test(resumeBlock));
  pass(`Resume computes scheduledAt via timingEngine`, /scheduledAt = computeNextStageScheduledAt\(\{[\s\S]*?stage: nextStage,[\s\S]*?initialSentAt: prospect\.sentAt,[\s\S]*?\}\)/.test(resumeBlock));
  pass(`Resume inserts queued follow-up`, /await db\.insert\(followupsTable\)\.values\(\{[\s\S]*?prospectId,[\s\S]*?stage: nextStage,[\s\S]*?status: "queued",[\s\S]*?\}\)/.test(resumeBlock));

  // PASS 6: response shape
  log(`-- PASS 6: response shape --`);
  pass(`Resume response includes queued_stage`, /queued_stage,/.test(resumeBlock));
  pass(`Resume response includes max_followups`, /max_followups: maxFollowups \?\? 0,/.test(resumeBlock));
  pass(`Resume preserves stalled_requeued`, /stalled_requeued: stalledRequeue\.requeued,/.test(resumeBlock));
  pass(`Resume preserves stalled_stage`, /stalled_stage: stalledRequeue\.stage,/.test(resumeBlock));

  // PASS 7: race-safety + branch logic
  log(`-- PASS 7: race-safety + branch logic --`);
  pass(`Stalled re-queue branch sets queued_stage`, /if \(stalledRequeue\.requeued\) \{\s*\n\s*queued_stage = stalledRequeue\.stage;/.test(resumeBlock));
  pass(`Active-stages-zero branch checks max cap`, /else if \(activeStages\.length === 0\) \{[\s\S]*?if \(maxFollowups === null \|\| nextStage <= maxFollowups\)/.test(resumeBlock));
  pass(`Insert wrapped in try/catch for race against autoQueue`, /try \{\s*\n\s*await db\.insert\(followupsTable\)\.values\(\{[\s\S]*?\}\);\s*\n\s*queued_stage = nextStage;\s*\n\s*\} catch \{/.test(resumeBlock));
  pass(`Existing requeueStalledDraftForProspect call preserved`, /const stalledRequeue = await requeueStalledDraftForProspect\(prospectId\);/.test(resumeBlock));

  // PASS 8: doctrine NOT regressed
  log(`-- PASS 8: doctrine resume unchanged --`);
  pass(`Doctrine /resume still uses SCOPE_DOCTRINE in UPDATE`,
       /router\.post\("\/prospect\/:id\/resume"[\s\S]*?\.update\(prospectsTable\)[\s\S]*?\.set\(\{ followupPaused: false \}\)[\s\S]*?\.where\(and\(SCOPE_DOCTRINE, eq\(prospectsTable\.id, prospectId\)\)\)/.test(doctrineRouteSrc));
  pass(`Doctrine /pause still uses SCOPE_DOCTRINE in UPDATE`,
       /router\.post\("\/prospect\/:id\/pause"[\s\S]*?\.update\(prospectsTable\)[\s\S]*?\.set\(\{ followupPaused: true \}\)[\s\S]*?\.where\(and\(SCOPE_DOCTRINE, eq\(prospectsTable\.id, prospectId\)\)\)/.test(doctrineRouteSrc));
  pass(`Doctrine /pause-bulk still uses SCOPE_DOCTRINE`,
       /router\.post\("\/prospect\/pause-bulk"[\s\S]*?\.where\(and\(SCOPE_DOCTRINE, inArray\(prospectsTable\.id, ids\)\)\)/.test(doctrineRouteSrc));

  // PASS 9: B7e–B7k regression
  log(`-- PASS 9: B7e–B7k regression --`);
  pass(`B7e: /context/cancel-followup endpoint`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7g: /context/gmail/sent-emails endpoint`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`B7i: /context/my/activity endpoint`, /router\.get\("\/my\/activity"/.test(ctxRouteSrc));
  pass(`B7i: layout.tsx product-aware activity URL`, /const activityPath = onContext \? "api\/context\/my\/activity" : "api\/my\/activity";/.test(layoutSrc));
  pass(`B7j: doctrine /api/stats includes drafted_followups`, /drafted_followups: Number\(fs\?\.draftedFollowups\) \|\| 0,/.test(doctrineRouteSrc));
  pass(`B7j: ctx-inspector vertical badge gated`, /\{vertLabel && <Badge variant="outline">\{vertLabel\}<\/Badge>\}/.test(ctxInspectorSrc));
  pass(`B7k: doctrine /sync auto_queued field`, /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(doctrineRouteSrc));
  pass(`B7k: context /sync auto_queued field`, (ctxRouteSrc.match(/res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/g) || []).length >= 1);
  pass(`B7c: SCOPE_DOCTRINE constant present`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`B7b: /context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7a: users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
