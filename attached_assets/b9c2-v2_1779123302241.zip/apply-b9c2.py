#!/usr/bin/env python3
"""
B9c.2 - Seed email selection: the headline AntiGhosting feature.

The user-facing change makes the AG inspector visibly distinctive vs.
Doctrine/Context: a prominent "Manage Context for Follow-ups" CTA, an
always-visible "CURRENT SEED EMAIL" summary inside the thread panel,
and per-outbound-message "Use as seed" actions to override the
validator's auto-pick.

Spec lock-ins:
  Q1=(a): in-flight queued followups are left alone; the cron picks
         up the new seed when it generates the body.
  Q2=(no): seed selection is only available on AG-in-DB threads (the
         prospect must exist). The button is gated on data.prospect
         being non-null.

Backend (anti-ghosting.ts):
  A1: New POST /prospect/:id/set-seed endpoint.
      - Validates: AG-scoped prospect exists; user has Gmail; new
        gmailMessageId is in same thread; new seed is outbound.
      - Updates prospectsTable.gmailMessageId.
      - Returns 409 on UNIQUE collision (gmailMessageId already used
        by another prospect across the table).
      - Mirrors ingestAntiGhostingThread's override validation rules.

Frontend (anti-ghosting-inspector.tsx):
  F1: Add settingSeedId state + handleUseAsSeed handler in ThreadView.
      Optimistic update + rollback on failure.
  F2: SEED summary banner at top of the thread message list (only
      when data.prospect is non-null + a seed message is present).
  F3: Per-message slot now toggles between "CURRENT SEED" badge and
      "Use as seed" button (outbound + !isSeed + data.prospect).
  F4: Restyle + rename the entry-point button. "View thread" becomes
      "Manage Context for Follow-ups" with prominent primary-accent
      styling, full-width, larger size.

Idempotent. All anchors uniqueness-checked.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ROUTE = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"
INSPECTOR = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-inspector.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# BACKEND: A1 - new POST /prospect/:id/set-seed endpoint
# ====================================================================
A1_OLD = '''// B9c.1a: GET /api/anti-ghosting/thread/:gmailThreadId/messages'''

A1_NEW = '''// B9c.2: POST /api/anti-ghosting/prospect/:id/set-seed
// Operator override for the AI's context anchor on an AG prospect. Mirrors
// ingestAntiGhostingThread's overrideSeedMessageId validation: target
// message must exist in the same thread AND must be outbound (sent by
// the user). In-flight queued followups are left alone per Q1(a) \u2014 the
// cron will pick up the new seed when it generates each body.
router.post("/prospect/:id/set-seed", async (req: Request, res: Response) => {
  const id = parseInt(String(req.params.id), 10);
  if (!Number.isFinite(id)) {
    res.status(400).json({ error: "invalid prospect id" });
    return;
  }
  const newSeed = req.body && typeof req.body.gmailMessageId === "string"
    ? req.body.gmailMessageId
    : null;
  if (!newSeed) {
    res.status(400).json({ error: "missing or invalid gmailMessageId in body" });
    return;
  }

  try {
    const [prospect] = await db
      .select()
      .from(prospectsTable)
      .where(and(eq(prospectsTable.id, id), eq(prospectsTable.app, "anti_ghosting")))
      .limit(1);
    if (!prospect) {
      res.status(404).json({ error: "anti_ghosting prospect not found" });
      return;
    }
    if (!prospect.userId) {
      res.status(400).json({ error: "prospect has no associated user" });
      return;
    }
    if (!prospect.gmailThreadId) {
      res.status(400).json({ error: "prospect has no associated gmail thread" });
      return;
    }
    if (prospect.gmailMessageId === newSeed) {
      // Already the seed \u2014 noop, return success.
      res.json({ success: true, newSeedMessageId: newSeed, noop: true });
      return;
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.id, prospect.userId))
      .limit(1);
    if (!user?.googleRefreshToken || !user?.isConnected) {
      res.status(400).json({ error: "user Gmail not connected" });
      return;
    }
    const gmail = getGmailForUser({
      refreshToken: user.googleRefreshToken,
      email: user.email,
    });

    // Validate: the new seed must live in this thread and be outbound.
    const messages = await parseGmailThread(gmail, prospect.gmailThreadId, user.email);
    const target = messages.find((m) => m.id === newSeed);
    if (!target) {
      res.status(400).json({ error: `gmailMessageId ${newSeed} not found in thread ${prospect.gmailThreadId}` });
      return;
    }
    if (classifyDirection(target.fromHeader, user.email) !== "outbound") {
      res.status(400).json({ error: "seed must be an outbound (sent-by-user) message" });
      return;
    }

    try {
      await db
        .update(prospectsTable)
        .set({ gmailMessageId: newSeed })
        .where(eq(prospectsTable.id, id));
    } catch (updateErr) {
      const msg = updateErr instanceof Error ? updateErr.message : String(updateErr);
      // UNIQUE constraint on gmailMessageId is table-wide, so another
      // prospect (any app) holding this id will collide.
      if (msg.toLowerCase().includes("unique") || msg.toLowerCase().includes("duplicate")) {
        logger.warn({ prospectId: id, newSeed, oldSeed: prospect.gmailMessageId },
          "AG set-seed UNIQUE collision");
        res.status(409).json({ error: "This message is already used as the anchor for another prospect" });
        return;
      }
      throw updateErr;
    }

    logger.info(
      { prospectId: id, oldSeed: prospect.gmailMessageId, newSeed },
      "AG seed updated",
    );
    res.json({ success: true, newSeedMessageId: newSeed });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err, prospectId: id }, "POST /anti-ghosting/prospect/:id/set-seed failed");
    res.status(500).json({ error: msg });
  }
});

// B9c.1a: GET /api/anti-ghosting/thread/:gmailThreadId/messages'''


# ====================================================================
# FRONTEND: F1 - add state + handler inside ThreadView
# Anchor on the isError state line so we sit right after the existing
# data-fetching state.
# ====================================================================
F1_OLD = '''  const [isError, setIsError] = useState(false);

  useEffect(() => {'''

F1_NEW = '''  const [isError, setIsError] = useState(false);
  // B9c.2: per-message in-flight tracking for "Use as seed" clicks +
  // surface backend errors inline rather than as a global error state.
  const [settingSeedId, setSettingSeedId] = useState<string | null>(null);
  const [seedError, setSeedError] = useState<string | null>(null);

  async function handleUseAsSeed(messageId: string) {
    if (!data?.prospect?.id) return;
    const oldSeedId = data.prospect.currentSeedMessageId;
    setSettingSeedId(messageId);
    setSeedError(null);
    // Optimistic: flip isSeed locally so the UI reacts instantly.
    setData((prev: any) => prev ? {
      ...prev,
      prospect: { ...prev.prospect, currentSeedMessageId: messageId },
      messages: prev.messages?.map((m: any) => ({ ...m, isSeed: m.id === messageId })),
    } : prev);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(`${base}api/anti-ghosting/prospect/${data.prospect.id}/set-seed`, {
        method: "POST",
        headers: { "x-api-key": apiKey || "", "Content-Type": "application/json" },
        body: JSON.stringify({ gmailMessageId: messageId }),
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        // Rollback
        setData((prev: any) => prev ? {
          ...prev,
          prospect: { ...prev.prospect, currentSeedMessageId: oldSeedId },
          messages: prev.messages?.map((m: any) => ({ ...m, isSeed: m.id === oldSeedId })),
        } : prev);
        setSeedError(body?.error || `Failed to update seed (${res.status})`);
      }
    } catch (err: any) {
      // Rollback on network error
      setData((prev: any) => prev ? {
        ...prev,
        prospect: { ...prev.prospect, currentSeedMessageId: oldSeedId },
        messages: prev.messages?.map((m: any) => ({ ...m, isSeed: m.id === oldSeedId })),
      } : prev);
      setSeedError(err?.message || "Failed to update seed");
    } finally {
      setSettingSeedId(null);
    }
  }

  useEffect(() => {'''


# ====================================================================
# FRONTEND: F2 - SEED summary banner at top of thread message list
# Anchor on the existing "X messages REPLY" line container's opening.
# ====================================================================
F2_OLD = '''    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
      <div className="flex items-center gap-3 text-[11px] mb-2" style={{ color: "var(--text-secondary)" }}>
        <span>{data.messages?.length ?? 0} message{(data.messages?.length ?? 0) !== 1 ? "s" : ""}</span>'''

F2_NEW = '''    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
      {/* B9c.2: prominent SEED EMAIL summary so operators see at a glance which message anchors the AI. */}
      {data.prospect && (() => {
        const seed = data.messages?.find((m: any) => m.isSeed);
        if (!seed) return null;
        return (
          <div className="rounded-lg p-3 mb-2" style={{ background: "var(--accent-muted)", border: "1px solid var(--accent-border)" }}>
            <p className="font-medium uppercase tracking-[0.04em] mb-1" style={{ fontSize: "10px", color: "var(--accent)" }}>
              Current Seed Email \u2014 Anchors AI Context for F1/F2/F3
            </p>
            <div className="text-[12px]" style={{ color: "var(--text-primary)" }}>
              {seed.direction === "outbound" ? "Me" : (seed.fromName || seed.fromHeader)}
              {" \u2014 "}
              <span style={{ color: "var(--text-secondary)" }}>
                {seed.sentAt ? format(new Date(seed.sentAt), "MMM d, HH:mm") : ""}
              </span>
            </div>
            <p className="text-[11px] mt-1.5" style={{ color: "var(--text-tertiary)" }}>
              Click "Use as seed" on any of your outbound messages below to retarget the AI.
            </p>
          </div>
        );
      })()}
      {seedError && (
        <div className="rounded-lg p-2.5 mb-2 text-[12px]" style={{ background: "var(--danger-muted)", border: "1px solid var(--danger-border)", color: "var(--danger)" }}>
          {seedError}
        </div>
      )}
      <div className="flex items-center gap-3 text-[11px] mb-2" style={{ color: "var(--text-secondary)" }}>
        <span>{data.messages?.length ?? 0} message{(data.messages?.length ?? 0) !== 1 ? "s" : ""}</span>'''


# ====================================================================
# FRONTEND: F3 - per-message slot: badge OR Use-as-seed button
# Anchor on the existing isSeed badge block from B9c.1b.
# ====================================================================
F3_OLD = '''              {msg.isSeed && (
                <Badge variant="success" className="text-[10px] uppercase tracking-wide flex-shrink-0">SEED</Badge>
              )}'''

F3_NEW = '''              {msg.isSeed ? (
                <Badge variant="success" className="text-[10px] uppercase tracking-wide flex-shrink-0">CURRENT SEED</Badge>
              ) : (msg.direction === "outbound" && data.prospect) ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleUseAsSeed(msg.id)}
                  disabled={settingSeedId === msg.id}
                  className="text-[10px] h-6 px-2 flex-shrink-0"
                >
                  {settingSeedId === msg.id
                    ? <Loader2 className="h-3 w-3 animate-spin" />
                    : "Use as seed"}
                </Button>
              ) : null}'''


# ====================================================================
# FRONTEND: F4 - restyle + rename the entry-point button
# Anchor on the existing "View thread" Button JSX.
# ====================================================================
F4_OLD = '''                <Button
                  variant="secondary"
                  size="sm"
                  onClick={(e) => { e.stopPropagation(); setShowThread(!showThread); }}
                  className="gap-2 text-[12px]"
                >
                  <MessageSquare className="h-3 w-3" />
                  {showThread ? "Hide thread" : "View thread"}
                </Button>'''

F4_NEW = '''                {/* B9c.2: prominent CTA \u2014 this is the headline AntiGhosting interaction. */}
                <Button
                  size="default"
                  onClick={(e) => { e.stopPropagation(); setShowThread(!showThread); }}
                  className="gap-2 w-full font-medium text-[13px]"
                  style={{ background: "var(--accent)", color: "white", borderColor: "var(--accent)" }}
                >
                  <MessageSquare className="h-4 w-4" />
                  {showThread ? "Hide Context Manager" : "Manage Context for Follow-ups"}
                </Button>'''


def patch_route():
    if not ROUTE.exists():
        fail(f"route not found: {ROUTE}")
    text = ROUTE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: insert POST /prospect/:id/set-seed",
        marker="B9c.2: POST /api/anti-ghosting/prospect/:id/set-seed",
    )

    if text != original:
        ROUTE.write_text(text, encoding="utf-8")
        ok(f"wrote {ROUTE.relative_to(WORKSPACE)}")
    else:
        skip("route already patched")


def patch_inspector():
    if not INSPECTOR.exists():
        fail(f"inspector not found: {INSPECTOR}")
    text = INSPECTOR.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, F1_OLD, F1_NEW,
        "F1: state + handleUseAsSeed handler",
        marker="B9c.2: per-message in-flight tracking",
    )

    text, _ = replace_unique(
        text, F2_OLD, F2_NEW,
        "F2: SEED summary banner + error display",
        marker="B9c.2: prominent SEED EMAIL summary",
    )

    text, _ = replace_unique(
        text, F3_OLD, F3_NEW,
        "F3: per-message badge or Use-as-seed button",
        marker=">CURRENT SEED</Badge>",
    )

    text, _ = replace_unique(
        text, F4_OLD, F4_NEW,
        "F4: prominent entry-point button rename",
        marker="B9c.2: prominent CTA",
    )

    if text != original:
        INSPECTOR.write_text(text, encoding="utf-8")
        ok(f"wrote {INSPECTOR.relative_to(WORKSPACE)}")
    else:
        skip("inspector already patched")


def main():
    patch_route()
    patch_inspector()
    print()
    print("B9c.2 seed selection applied.")


if __name__ == "__main__":
    main()
