# Doctrine Follow-up — round 4: Shift-click range select

Apply after round 3. Dashboard-only, one file (`dashboard/pages/pipeline.tsx`).

## Run it
```bash
cd /home/runner/workspace && rm -rf _fixes4 && python3 -c "import zipfile; zipfile.ZipFile('doctrine-followup-fixes-round4.zip').extractall('_fixes4')" && bash _fixes4/apply-fixes.sh
```

## What it does
On the Pipeline page, click one row's checkbox, then hold **Shift** and click
another row's checkbox — every row between them is selected in one motion. Then
use Resume / Pause on the selection. No more ticking boxes one by one.

- The anchor is the last row you clicked without Shift.
- Range is resolved against the current visible (filtered/sorted) order, so it
  still works after you filter or sort. If the anchor scrolled out of the
  filtered set, it falls back to a normal single toggle.
- "Select all" and the existing bulk Resume/Pause are unchanged.
- A "Tip: Shift-click to select a range" hint sits next to Select all.

Doctrine pipeline only (the page in your screenshot). Say the word to port the
same behavior to the Context and Anti-Ghosting pipelines.
