#!/usr/bin/env python3
r"""
B9b.4 — AntiGhosting auto-ingest from labeled threads.

Pivots AntiGhosting from operator-Mark-button-driven to label-driven
auto-ingest, matching how Doctrine and Context handle their labels.
The operator's manual step is applying the AntiGhosting label in
Gmail; the next sync cycle then auto-ingests labeled threads that
pass the three validators.

Three pieces:

  1. NEW services/antiGhostingIngest.ts — copied into place. Exports
     ingestAntiGhostingThread, ingestAntiGhostingLabeledThreads,
     resolveAntiGhostingLabelIds, getAlreadyMarkedThreadIds, plus the
     IngestResult type. ~370 lines.

  2. routes/anti-ghosting.ts — full file replacement. POST /mark now
     calls ingestAntiGhostingThread under the hood. GET /candidates
     imports the moved helpers. Response shapes preserved verbatim
     for backward compat with the dashboard.

  3. services/gmailSync.ts — 2 surgical edits. Adds one import and
     wraps the final logger.info + return inside syncForUser with the
     ingestAntiGhostingLabeledThreads call.

Behavior change worth noting:

  getAlreadyMarkedThreadIds in the new service queries
  prospectsTable.gmailThreadId DIRECTLY rather than B9b's JOIN through
  threadMessagesTable. The JOIN missed prospects whose
  syncThreadFromGmail failed (non-fatal try/catch in B9b), so those
  threads could be re-marked → duplicate prospects. The direct query
  catches them. Latent B9b bug fixed.

Idempotency: generalized NEW-substring-of-OLD check on the gmailSync
edits; file installs are unconditional (overwrite-in-place).
"""

import os
import shutil
import sys

ROOT = os.getcwd()
BATCH_DIR = os.path.dirname(os.path.abspath(__file__))
SOURCE_DIR = os.path.normpath(os.path.join(BATCH_DIR, "..", "api-server"))


def copy_into_place(source_rel: str, dest_rel: str) -> bool:
    src = os.path.join(SOURCE_DIR, source_rel)
    dst = os.path.join(ROOT, dest_rel)
    if not os.path.isfile(src):
        print(f"  ERROR: batch source missing: {src}")
        return False
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copyfile(src, dst)
    size = os.path.getsize(dst)
    print(f"  COPY {source_rel} -> {dest_rel}  ({size:,} bytes)")
    return True


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    # ─────────────────────────────────────────────────────────────
    # 1. Install the new service module + rewritten route handler.
    # ─────────────────────────────────────────────────────────────
    print("\n--- File install ---")
    if not copy_into_place(
        "services/antiGhostingIngest.ts",
        "artifacts/api-server/src/services/antiGhostingIngest.ts",
    ):
        return 2
    if not copy_into_place(
        "routes/anti-ghosting.ts",
        "artifacts/api-server/src/routes/anti-ghosting.ts",
    ):
        return 2

    # ─────────────────────────────────────────────────────────────
    # 2. Patch services/gmailSync.ts (2 edits).
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/api-server/src/services/gmailSync.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/services/gmailSync.ts",
        [
            # ─────────────────────────────────────────────────────
            # Edit 1: Add the ingest helper import. Anchored on
            # threadReader's existing import line — natural neighbour.
            # ─────────────────────────────────────────────────────
            (
                'import { syncThreadFromGmail } from "./threadReader";\n',
                'import { syncThreadFromGmail } from "./threadReader";\n'
                '// B9b.4: AntiGhosting auto-ingest orchestrator. Lists labeled\n'
                '// threads and ingests each unmarked one via the shared service.\n'
                'import { ingestAntiGhostingLabeledThreads } from "./antiGhostingIngest";\n',
                "add ingestAntiGhostingLabeledThreads import",
            ),
            # ─────────────────────────────────────────────────────
            # Edit 2: Wrap the final logger.info + return in syncForUser
            # with the AntiGhosting ingest call. Includes ingest counts
            # in the existing log line + adds the new count to `synced`.
            # ─────────────────────────────────────────────────────
            (
                '  logger.info(\n'
                '    {\n'
                '      synced,\n'
                '      skipped,\n'
                '      conflicts,\n'
                '      repliesDetected,\n'
                '      draftsSent: draftDetection.draftsSent,\n'
                '      customOutbounds: draftDetection.customOutbounds,\n'
                '      userId: user.id,\n'
                '    },\n'
                '    "Sync complete for user",\n'
                '  );\n'
                '  return { synced, repliesDetected };\n'
                '}\n',
                '  // B9b.4: AntiGhosting auto-ingest pass. Threads tagged with\n'
                '  // the user\'s AntiGhosting label become anti_ghosting prospects.\n'
                '  // Errors don\'t fail the whole sync — doctrine/context above\n'
                '  // is already done and shouldn\'t be invalidated by a labeling\n'
                '  // flow problem. Counts roll into the synced total.\n'
                '  let antiGhostingIngested = 0;\n'
                '  try {\n'
                '    const antiGhostResult = await ingestAntiGhostingLabeledThreads({\n'
                '      userId: user.id,\n'
                '      gmail,\n'
                '      userEmail: user.email,\n'
                '      antiGhostingLabel: user.antiGhostingLabel,\n'
                '    });\n'
                '    antiGhostingIngested = antiGhostResult.ingested;\n'
                '  } catch (err) {\n'
                '    logger.error({ err, userId: user.id }, "AntiGhosting ingest pass threw — continuing sync");\n'
                '  }\n'
                '\n'
                '  logger.info(\n'
                '    {\n'
                '      synced: synced + antiGhostingIngested,\n'
                '      skipped,\n'
                '      conflicts,\n'
                '      repliesDetected,\n'
                '      draftsSent: draftDetection.draftsSent,\n'
                '      customOutbounds: draftDetection.customOutbounds,\n'
                '      antiGhostingIngested,\n'
                '      userId: user.id,\n'
                '    },\n'
                '    "Sync complete for user",\n'
                '  );\n'
                '  return { synced: synced + antiGhostingIngested, repliesDetected };\n'
                '}\n',
                "add AntiGhosting ingest call + update logger + return",
            ),
        ],
    )

    expected = 2
    seen = a + b
    print(f"\n=== Summary ===")
    print(f"  Files installed:   2 (antiGhostingIngest.ts, anti-ghosting.ts)")
    print(f"  Patch edits:       {a}")
    print(f"  Already-applied:   {b}")
    print(f"  Warnings:          {w}")
    print(f"  Expected edits:    {expected} (seen {seen})")
    if w > 0:
        print("  At least one edit could not be applied. Inspect WARN lines.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
