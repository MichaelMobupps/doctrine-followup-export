# Batch B9c.1 — Scheduler Infrastructure (Pre-Generator)

**Scope.** Two-file, three-edit batch. Lands the infrastructure changes that B9c's generator depends on, *plus* a safety gate that prevents the dispatcher from running anti_ghosting prospects through the wrong generator while B9c.2 is in flight. No new files, no new generator yet.

## The two bugs being addressed

### Bug 1: B9b's followup status was wrong

B9b's `/mark` endpoint inserts the F1 row with `status="scheduled"`. The scheduler dispatches rows with `status="queued"` (the existing convention — `followups.status` defaults to `"queued"` per the schema, and `scheduler.ts:58` filters by that exact value). My B9b rows would sit in `"scheduled"` forever and never dispatch.

Fix: change the insert in `routes/anti-ghosting.ts` from `status: "scheduled"` to `status: "queued"`.

### Bug 2: With the status fix alone, the dispatcher would call the wrong generator

Once `status="queued"`, the dispatcher will pick anti_ghosting rows and run them through `scheduler.ts:281-283`:

```typescript
() => item.app === "context"
  ? generateContextFollowup(ctx)
  : generateFollowupEmail(ctx),  // <-- doctrine fallback
```

`item.app === "anti_ghosting"` falls through to the Doctrine generator (which knows nothing about re-engagement structure, daysSinceSeed tone tiers, or the ACKNOWLEDGE→BRIDGE→ASK shape). Result: wrong-voice content sent to a real prospect. B9c.2's real third branch fixes this properly; B9c.1 ships an interim *exclusion filter* to prevent the bad path during the window.

Fix: add `ne(prospectsTable.app, "anti_ghosting")` to the dispatcher's conditions array in `scheduler.ts`. Plus add `ne` to the drizzle-orm import.

The exclusion stays in place until B9c.2 ships the real generator. Removing it is the second-to-last step of B9c.2 (after the third dispatch branch is wired).

## Why split B9c into .1 and .2

The original B9c plan was a single batch: prompts module + generator + scheduler integration + usageContext widening. That's ~500 lines of new content (prompts) plus three sibling files. Two costs in shipping it as one:

1. **Prompt-engineering iteration is its own loop.** The writer/critic/rewriter prompts will need adjustment after observing real output. Bundling them with infrastructure makes that iteration coupled to infra changes.
2. **B9b shipped two latent bugs.** Smaller batches mean smaller blast radius if the next ship has its own surprises.

B9c.1 is two edits across two files — small enough to land cleanly. B9c.2 carries the actual product value (the LLM pipeline) and gets full attention.

## Idempotency

The patch script checks for the post-edit state *before* trying to match the pre-edit state. This matters for the exclusion-filter edit specifically: its `new` content is a superset of its `old` content (we're inserting alongside the existing lines, not replacing them). Without the NEW-first check, re-runs would double-insert. Verified across two test runs in the audit.

Reporting:
- `FIX` — edit applied
- `SKIP` — already in the post-edit state (idempotent re-run)
- `WARN` — neither pattern found (the live file has drifted; manual triage needed)

## Layout

```
batch-b9c1-scheduler-infrastructure/
|-- README.md
`-- scripts/
    `-- apply-b9c1.py
```

No source-file replacements in the bundle — all edits applied directly to the live files via the script. Mirror sync IS needed (route source files + scheduler change). Workflow restart IS needed (the scheduler's dispatcher loop is in-process; needs the new conditions array to take effect).

## Risk surface

1. **Type-only changes to scheduler** — the import addition and conditions push are both standard drizzle patterns. The `ne` function exists in drizzle-orm and is a one-to-one analog of `eq`.
2. **No runtime behavior change for doctrine or context prospects** — the new condition only filters out `app="anti_ghosting"` rows; everything else is unaffected.
3. **No new dependencies** — `ne` was already in the workspace's drizzle-orm version, just not imported into scheduler.ts yet.
4. **No schema changes.**
5. **No tests added/changed** — the unit suites still pass (B9b's 15 tests, B9a's 15 tests). Integration testing the exclusion filter would require a seeded anti_ghosting prospect; defer to B9c.2 when there's a real generator to exercise end-to-end.

## What lands in B9c.2

- `services/antiGhostingFollowupPrompts.ts` — writer/critic/rewriter system prompts + user-prompt builders parameterised by stage and `daysSinceSeedTier`.
- `services/antiGhostingFollowupGenerator.ts` — 3-call pipeline mirroring `contextFollowupGenerator.ts`.
- `services/scheduler.ts` — REMOVE the B9c.1 exclusion filter, ADD a third dispatch branch: `item.app === "anti_ghosting" ? generateAntiGhostingFollowup(ctx) : ...`.
- `lib/usageContext.ts` — widen `UsageAttribution.app` union to include `"anti_ghosting"`.
- `tests/test-anti-ghosting-prompts-b9c2.ts` — unit tests for prompt assembly + critic rules.

The exclusion filter REMOVAL in B9c.2 is the gate-flip moment. After that lands, marked anti_ghosting prospects will dispatch correctly.
