// B7v apply script.
//
// Adds auto-refresh, live in-flight indicator, "Updated Ns ago"
// status, and visibility-aware polling to the Admin Activity page.
//
// Single file replacement. No backend changes. No deps. No migration.
// Strictly a frontend UX upgrade on top of B7u.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";
const PATCH_DIR = path.dirname(new URL(import.meta.url).pathname);

async function copyFile(src, dst) {
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
  console.log(`wrote: ${dst}`);
}

async function main() {
  console.log("B7v: auto-refresh + live indicator for Admin Activity\n");

  console.log("[1/1] replace artifacts/dashboard/src/pages/admin-activity.tsx");
  await copyFile(
    path.join(PATCH_DIR, "files/pages/admin-activity.tsx"),
    path.join(WORKSPACE, "artifacts/dashboard/src/pages/admin-activity.tsx"),
  );

  console.log("\nB7v applied. Next: build dashboard, restart workflow.");
}

main().catch((err) => {
  console.error("\nB7v apply failed:", err.message);
  process.exit(1);
});
