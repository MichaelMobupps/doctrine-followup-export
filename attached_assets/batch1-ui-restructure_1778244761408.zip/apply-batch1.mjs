#!/usr/bin/env node
/**
 * Batch 1 — UI restructure
 *
 * What this does:
 *   1. Copies payload/pages/pipeline.tsx into dashboard/src/pages/pipeline.tsx.
 *      The Pipeline page replaces both the old Prospects and Follow-ups pages.
 *      It keeps the card-list-with-expandable-stages layout from Followups and
 *      adds the vertical filter + "Queue follow-ups" batch modal from Prospects.
 *
 *   2. Updates dashboard/src/App.tsx so that /, /prospects, and /followups all
 *      render the new Pipeline component. The old prospects.tsx and followups.tsx
 *      files are left untouched on disk so we have a one-cycle rollback path —
 *      they are simply no longer routed.
 *
 *   3. Updates dashboard/src/components/layout.tsx:
 *        - Sidebar nav drops to 4 items: Pipeline, Email Inspector, Activity Log, Settings.
 *        - Settings gets its own visually-separated section at the bottom of the
 *          sidebar above Sign out, with a gear icon and accent-colored treatment.
 *        - "Pipeline" uses the Workflow icon at the top of the nav list.
 *
 * Idempotent: every step checks for an "already applied" anchor before writing.
 * Re-running is a no-op.
 */
import fs from "node:fs";
import path from "node:path";
import url from "node:url";

const SCRIPT_DIR = path.dirname(url.fileURLToPath(import.meta.url));
const SRC_BASE = process.env.SRC_BASE || "artifacts/dashboard/src";

const PIPELINE_DST   = path.join(SRC_BASE, "pages/pipeline.tsx");
const PIPELINE_SRC   = path.join(SCRIPT_DIR, "payload/pages/pipeline.tsx");
const APP_TSX        = path.join(SRC_BASE, "App.tsx");
const LAYOUT_TSX     = path.join(SRC_BASE, "components/layout.tsx");

let changed = 0;
let skipped = 0;

function read(p) {
  if (!fs.existsSync(p)) {
    console.error(`[fail] file not found: ${p}`);
    process.exit(1);
  }
  return fs.readFileSync(p, "utf8");
}
function write(p, s) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, s, "utf8");
}

function copyOnce(label, srcPath, dstPath) {
  if (!fs.existsSync(srcPath)) {
    console.error(`  [fail] ${label}: payload missing at ${srcPath}`);
    process.exit(1);
  }
  const expected = read(srcPath);
  if (fs.existsSync(dstPath) && read(dstPath) === expected) {
    console.log(`  [skip] ${label} (already in place)`);
    skipped++;
    return;
  }
  write(dstPath, expected);
  console.log(`  [ok] ${label}`);
  changed++;
}

function replaceOnce(filePath, label, oldStr, newStr) {
  const src = read(filePath);
  if (src.includes(newStr)) {
    console.log(`  [skip] ${label} (already applied)`);
    skipped++;
    return;
  }
  const occurrences = src.split(oldStr).length - 1;
  if (occurrences === 0) {
    console.error(`  [fail] ${label}: anchor not found`);
    console.error(`         expected:\n${oldStr.split("\n").slice(0, 4).join("\n")}...`);
    process.exit(1);
  }
  if (occurrences > 1) {
    console.error(`  [fail] ${label}: anchor matched ${occurrences} times — must be unique`);
    process.exit(1);
  }
  write(filePath, src.replace(oldStr, newStr));
  console.log(`  [ok] ${label}`);
  changed++;
}

// ---------- 1. Drop in pipeline.tsx ----------

console.log(`\n[1/3] ${PIPELINE_DST}`);
copyOnce("install pipeline.tsx", PIPELINE_SRC, PIPELINE_DST);

// ---------- 2. App.tsx — route /, /prospects, /followups, /pipeline to Pipeline ----------

console.log(`\n[2/3] ${APP_TSX}`);

replaceOnce(
  APP_TSX,
  "import Pipeline page",
  `import Prospects from "@/pages/prospects";
import Followups from "@/pages/followups";
import EmailInspector from "@/pages/email-inspector";`,
  `import Prospects from "@/pages/prospects";
import Followups from "@/pages/followups";
import Pipeline from "@/pages/pipeline";
import EmailInspector from "@/pages/email-inspector";`,
);

replaceOnce(
  APP_TSX,
  "route old paths to Pipeline",
  `      <Route path="/" component={Prospects} />
      <Route path="/prospects" component={Prospects} />
      <Route path="/followups" component={Followups} />`,
  `      <Route path="/" component={Pipeline} />
      <Route path="/pipeline" component={Pipeline} />
      <Route path="/prospects" component={Pipeline} />
      <Route path="/followups" component={Pipeline} />`,
);

// ---------- 3. layout.tsx — drop Prospects/Followups, add Pipeline, promote Settings ----------

console.log(`\n[3/3] ${LAYOUT_TSX}`);

// 3a. Update lucide-react icon imports — drop Users/Send (Prospects/Followups), add Settings (gear)
replaceOnce(
  LAYOUT_TSX,
  "icon imports",
  `import { Users, Send, Eye, UserPlus, LogOut, Workflow, Radio, Activity } from "lucide-react";`,
  `import { Eye, LogOut, Workflow, Radio, Activity, Settings as SettingsIcon } from "lucide-react";`,
);

// 3b. Replace navItems list — drop Prospects + Follow-ups, replace with Pipeline; drop Settings (it gets its own section)
replaceOnce(
  LAYOUT_TSX,
  "nav items list",
  `  const navItems = [
    { name: "Prospects", href: "/", icon: Users },
    { name: "Follow-ups", href: "/followups", icon: Send },
    { name: "Email Inspector", href: "/inspector", icon: Eye },
    { name: "Activity Log", href: "/activity", icon: Activity },
    { name: "Settings", href: "/accounts", icon: UserPlus },
  ];`,
  `  const navItems = [
    { name: "Pipeline", href: "/", icon: Workflow },
    { name: "Email Inspector", href: "/inspector", icon: Eye },
    { name: "Activity Log", href: "/activity", icon: Activity },
  ];

  const isSettingsActive = location === "/accounts";`,
);

// 3c. Insert promoted Settings section into the sidebar bottom area, just before the activity card
replaceOnce(
  LAYOUT_TSX,
  "promoted settings section",
  `        <div className="p-3 mt-auto space-y-2">
          {/* Live activity indicator */}`,
  `        <div className="p-3 mt-auto space-y-2">
          {/* Promoted Settings entry — visually separated, accent treatment */}
          <Link href="/accounts" className="block">
            <div
              className="flex items-center gap-2.5 px-3 py-3 rounded-md text-[13px] font-semibold transition-all duration-150"
              style={{
                background: isSettingsActive ? "var(--accent-muted)" : "var(--bg-tertiary)",
                border: \`1px solid \${isSettingsActive ? "var(--accent-border)" : "var(--border-default)"}\`,
                color: isSettingsActive ? "var(--accent)" : "var(--text-primary)",
              }}
            >
              <SettingsIcon className="h-4 w-4" strokeWidth={1.75} />
              Settings
            </div>
          </Link>

          {/* Live activity indicator */}`,
);

// ---------- Verify ----------

console.log(`\n[verify]`);

const finalApp = read(APP_TSX);
const finalLayout = read(LAYOUT_TSX);
const finalPipeline = read(PIPELINE_DST);

const checks = [
  [finalApp.includes(`import Pipeline from "@/pages/pipeline"`),                                   "App.tsx: Pipeline imported"],
  [finalApp.includes(`<Route path="/" component={Pipeline} />`),                                   "App.tsx: / -> Pipeline"],
  [finalApp.includes(`<Route path="/prospects" component={Pipeline} />`),                          "App.tsx: /prospects -> Pipeline"],
  [finalApp.includes(`<Route path="/followups" component={Pipeline} />`),                          "App.tsx: /followups -> Pipeline"],
  [finalApp.includes(`<Route path="/pipeline" component={Pipeline} />`),                           "App.tsx: /pipeline -> Pipeline"],
  [finalLayout.includes(`Settings as SettingsIcon`),                                               "layout.tsx: Settings icon imported"],
  [!finalLayout.includes(`{ name: "Prospects",`),                                                  "layout.tsx: Prospects nav item removed"],
  [!finalLayout.includes(`{ name: "Follow-ups",`),                                                 "layout.tsx: Follow-ups nav item removed"],
  [finalLayout.includes(`{ name: "Pipeline", href: "/", icon: Workflow }`),                        "layout.tsx: Pipeline nav item added"],
  [finalLayout.includes(`Promoted Settings entry`),                                                "layout.tsx: promoted Settings section present"],
  [finalLayout.includes(`isSettingsActive`),                                                       "layout.tsx: settings active state wired"],
  [finalPipeline.includes(`export default function Pipeline()`),                                   "pipeline.tsx: component renamed"],
  [finalPipeline.includes(`filterVertical`),                                                       "pipeline.tsx: vertical filter present"],
  [finalPipeline.includes(`queueBatchMutation`),                                                   "pipeline.tsx: queue batch mutation wired"],
  [finalPipeline.includes(`isQueueModalOpen`),                                                     "pipeline.tsx: queue modal state present"],
  [finalPipeline.includes(`useQueueBatch`),                                                        "pipeline.tsx: useQueueBatch imported"],
  [(finalPipeline.match(/<Modal/g) || []).length >= 1,                                             "pipeline.tsx: Modal rendered"],
];

let failed = 0;
for (const [ok, label] of checks) {
  console.log(`  ${ok ? "[ok]" : "[fail]"} ${label}`);
  if (!ok) failed++;
}

console.log(`\nsummary: ${changed} change(s) applied, ${skipped} skipped (already applied)`);
if (failed > 0) {
  console.error(`verify: ${failed} check(s) failed`);
  process.exit(1);
}
console.log("verify: all checks passed");
