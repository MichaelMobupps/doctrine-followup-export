#!/usr/bin/env python3
r"""
B9c.2.1 — hotfix for B9c.2 typecheck residuals.

Two corrective edits. Both anchored on unique text; idempotent
NEW-first plus the deletion-aware special case from B9c.2.

Errors being fixed:

  src/services/antiGhostingFollowupGenerator.ts:
    - error TS2345: '"anti_ghosting_generator"' not assignable to GeneratorLabel
    - error TS2345: '"anti_ghosting_critic"' not assignable to GeneratorLabel
    - error TS2345: '"anti_ghosting_rewriter"' not assignable to GeneratorLabel

    Cause: GeneratorLabel lives in lib/usageTracker.ts as a string
    union. B9c.2 widened UsageAttribution.app but missed this
    sibling type that the recordUsageBestEffort() second parameter
    requires. Edit 1 below widens it.

  src/services/scheduler.ts:
    - error TS2300: Duplicate identifier 'getGmailForUser'.

    Cause: B9c.2's import block ended with a standalone
    `import { getGmailForUser } from "./gmailClient";` line — but
    getGmailForUser was already imported as part of the existing
    multi-line import block from "./gmailClient" at the top of the
    file. Edit 2 below removes the duplicate line, keeping the
    other 5 imports from the B9c.2 block.

Usage: python3 apply-b9c2-1.py  (from the workspace root)
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        if new == "":
            # Deletion edit (empty NEW would trivially match every string).
            if old in content:
                content = content.replace(old, "", 1)
                print(f"  FIX  {path}: {label} (deletion)")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — deletion already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    totals = [0, 0, 0]

    # ─────────────────────────────────────────────────────────────
    # Edit 1: lib/usageTracker.ts — widen GeneratorLabel union
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/api-server/src/lib/usageTracker.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/lib/usageTracker.ts",
        [
            (
                'export type GeneratorLabel =\n'
                '  | "draft"\n'
                '  | "critic"\n'
                '  | "rewriter"\n'
                '  | "context_generator"\n'
                '  | "context_critic"\n'
                '  | "context_rewriter";\n',
                'export type GeneratorLabel =\n'
                '  | "draft"\n'
                '  | "critic"\n'
                '  | "rewriter"\n'
                '  | "context_generator"\n'
                '  | "context_critic"\n'
                '  | "context_rewriter"\n'
                '  // B9c.2.1: AntiGhosting flow uses its own labels so usage rows\n'
                '  // are attributable per product. Same shape as context_* labels.\n'
                '  | "anti_ghosting_generator"\n'
                '  | "anti_ghosting_critic"\n'
                '  | "anti_ghosting_rewriter";\n',
                "widen GeneratorLabel union with 3 anti_ghosting labels",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ─────────────────────────────────────────────────────────────
    # Edit 2: services/scheduler.ts — remove duplicate import line
    #
    # NB. Expressed as a pure DELETION (empty NEW) rather than
    # "replace 2-line OLD with 1-line NEW". The latter would trip
    # the NEW-first idempotency check because NEW (1 line) is a
    # substring of OLD (2 lines) — same trap as the B9c.1
    # exclusion-filter deletion. The deletion-aware special case
    # in patch_file handles empty NEW correctly.
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/api-server/src/services/scheduler.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/services/scheduler.ts",
        [
            (
                'import { getGmailForUser } from "./gmailClient";\n',
                '',
                "remove duplicate standalone getGmailForUser import",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ─────────────────────────────────────────────────────────────
    # Summary
    # ─────────────────────────────────────────────────────────────
    expected = 2
    seen = totals[0] + totals[1]
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {totals[0]}")
    print(f"  Already-applied:   {totals[1]}")
    print(f"  Warnings:          {totals[2]}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if totals[2] > 0:
        print(f"  At least one edit could not be applied. Inspect WARN lines.")
        return 2
    if seen < expected:
        print(f"  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
