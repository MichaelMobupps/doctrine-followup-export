import React, { useEffect } from "react";
import { useLocation } from "wouter";
import { Workflow, MessageSquare, ArrowRight } from "lucide-react";

const STORAGE_KEY = "doctrine.lastProduct";

/**
 * Product picker. Two cards (Sales Doctrine vs Context Based).
 * Remembers the last choice in localStorage so the next visit can
 * deep-link the user back to their last product.
 *
 * Phase 7d ships this as an explicit `/picker` route. It is reachable
 * via the "Switch product" link in the sidebar. The default landing
 * remains `/` → Pipeline (doctrine) — no behavior change for users
 * who already have the Doctrine UI bookmarked.
 */
export default function Picker() {
  const [, navigate] = useLocation();

  // Auto-redirect if the user landed here with ?from=switcher and has
  // a remembered choice. Otherwise show the picker UI.
  useEffect(() => {
    // No auto-redirect — the user explicitly requested the picker by
    // navigating to /picker. Auto-redirecting would defeat the point.
  }, []);

  const choose = (product: "doctrine" | "context") => {
    try { localStorage.setItem(STORAGE_KEY, product); } catch {}
    if (product === "doctrine") navigate("/");
    else navigate("/context/pipeline");
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] py-12">
      <div className="text-center mb-10">
        <h1 className="text-2xl font-semibold tracking-tight mb-2" style={{ color: "var(--text-primary)" }}>
          Choose a follow-up flow
        </h1>
        <p className="text-[14px]" style={{ color: "var(--text-secondary)" }}>
          Two flows share the same engine. Pick the one you want to work in.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-3xl w-full">
        {/* Doctrine card */}
        <button
          onClick={() => choose("doctrine")}
          className="text-left rounded-lg p-6 transition-all duration-200 group"
          style={{
            background: "var(--bg-secondary)",
            border: "1px solid var(--border-default)",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = "rgba(59,130,246,0.40)";
            e.currentTarget.style.background = "var(--bg-tertiary)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = "var(--border-default)";
            e.currentTarget.style.background = "var(--bg-secondary)";
          }}
        >
          <div
            className="w-10 h-10 rounded-md flex items-center justify-center mb-4"
            style={{ background: "rgba(59,130,246,0.10)", color: "#3b82f6" }}
          >
            <Workflow className="w-5 h-5" strokeWidth={1.75} />
          </div>
          <h2 className="text-[16px] font-semibold tracking-tight mb-2" style={{ color: "var(--text-primary)" }}>
            Sales Doctrine Followuper
          </h2>
          <p className="text-[13px] leading-relaxed mb-5" style={{ color: "var(--text-secondary)" }}>
            Outbound SDR flow. Structured doctrine framework, verticals, MAFO positioning,
            multi-stage cadence. Best for cold outreach to publishers and advertisers.
          </p>
          <div className="flex items-center gap-1.5 text-[13px] font-medium" style={{ color: "#3b82f6" }}>
            Open Doctrine
            <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5" strokeWidth={2} />
          </div>
        </button>

        {/* Context card */}
        <button
          onClick={() => choose("context")}
          className="text-left rounded-lg p-6 transition-all duration-200 group"
          style={{
            background: "var(--bg-secondary)",
            border: "1px solid var(--border-default)",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.borderColor = "rgba(245,158,11,0.40)";
            e.currentTarget.style.background = "var(--bg-tertiary)";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.borderColor = "var(--border-default)";
            e.currentTarget.style.background = "var(--bg-secondary)";
          }}
        >
          <div
            className="w-10 h-10 rounded-md flex items-center justify-center mb-4"
            style={{ background: "rgba(245,158,11,0.10)", color: "#f59e0b" }}
          >
            <MessageSquare className="w-5 h-5" strokeWidth={1.75} />
          </div>
          <h2 className="text-[16px] font-semibold tracking-tight mb-2" style={{ color: "var(--text-primary)" }}>
            Context Based Followuper
          </h2>
          <p className="text-[13px] leading-relaxed mb-5" style={{ color: "var(--text-secondary)" }}>
            Reply-driven flow. Drafts a short, context-faithful follow-up from any labelled
            email thread. No marketing layer, no doctrine — tone, language, and content
            mirror the original conversation.
          </p>
          <div className="flex items-center gap-1.5 text-[13px] font-medium" style={{ color: "#f59e0b" }}>
            Open Context
            <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-0.5" strokeWidth={2} />
          </div>
        </button>
      </div>
    </div>
  );
}
