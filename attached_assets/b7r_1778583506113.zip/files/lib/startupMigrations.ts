// B7r: startup migration for the followup_usage table.
//
// Run once at server boot, BEFORE the cron jobs start so the first
// follow-up generation never races against table creation. Uses raw
// SQL with CREATE TABLE IF NOT EXISTS so re-runs are no-ops.
//
// This is a pragmatic choice. The "proper" Drizzle Kit migration
// flow (drizzle-kit generate + drizzle-kit migrate) requires a
// developer to run two commands; doing it at server start removes
// that gap and keeps deploy-time work down to "build + restart".
//
// If the migration fails, we log loudly but DO NOT crash the boot
// process. The activity-log feature degrades to "no new rows
// captured" until the table comes up; the rest of the app works.

import { pool } from "@workspace/db";
import { logger } from "./logger";

const STATEMENTS: string[] = [
  `CREATE TABLE IF NOT EXISTS followup_usage (
    id SERIAL PRIMARY KEY,
    followup_id INTEGER,
    prospect_id INTEGER,
    user_id INTEGER,
    app TEXT NOT NULL,
    stage INTEGER NOT NULL,
    label TEXT NOT NULL,
    model TEXT NOT NULL,
    input_tokens INTEGER NOT NULL DEFAULT 0,
    output_tokens INTEGER NOT NULL DEFAULT 0,
    cache_creation_tokens INTEGER NOT NULL DEFAULT 0,
    cache_read_tokens INTEGER NOT NULL DEFAULT 0,
    web_searches INTEGER NOT NULL DEFAULT 0,
    cost_usd NUMERIC(12, 6) NOT NULL DEFAULT 0,
    generated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`,
  `CREATE INDEX IF NOT EXISTS idx_followup_usage_user ON followup_usage(user_id)`,
  `CREATE INDEX IF NOT EXISTS idx_followup_usage_followup ON followup_usage(followup_id)`,
  `CREATE INDEX IF NOT EXISTS idx_followup_usage_prospect ON followup_usage(prospect_id)`,
  `CREATE INDEX IF NOT EXISTS idx_followup_usage_generated_at ON followup_usage(generated_at)`,
  `CREATE INDEX IF NOT EXISTS idx_followup_usage_app ON followup_usage(app)`,
];

export async function runStartupMigrations(): Promise<void> {
  try {
    for (const stmt of STATEMENTS) {
      await pool.query(stmt);
    }
    logger.info("B7r: followup_usage table ready");
  } catch (err) {
    logger.error({ err }, "B7r: startup migration failed (activity log will be inaccurate until resolved)");
  }
}
