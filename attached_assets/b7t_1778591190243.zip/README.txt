B7t — admin activity dashboard page for Email Followuper
=========================================================

Adds a new dashboard page at /admin-activity that consumes the
/api/admin/activity endpoint (B7s). Renders:
  - Stat cards (events, total cost, in-flight, active users)
  - Filters (window / user / app)
  - Per-user totals table with row-expand (by_app/by_stage/by_model)
  - Recent events table (200-cap from the endpoint)

Files written (1 new):
  - artifacts/dashboard/src/pages/admin-activity.tsx

Files patched (2):
  - artifacts/dashboard/src/App.tsx          (import + route)
  - artifacts/dashboard/src/components/layout.tsx (nav link)

The page is read-only. No mutations. No auto-refresh in this batch
(deferred to B7v). No Excel export (B7u). No admin pause/resume (B7u).

Audit results (this batch was tested against real React + Vite):
  - TypeScript strict compile: 0 errors
  - Vite production build: 1512 modules, 0 errors, 0 warnings
  - jsdom render with mock data: all UI elements present
  - Empty prospect_name fallback verified: shows "Prospect #N"
  - Apply script idempotent: clean first run, full skip second run

---

PROMPT FOR THE REPLIT AGENT
---------------------------

> Apply the b7t patch from ~/b7t.zip.
>
> Step 1: run this single bash block in the shell, exactly as-is:
>
> ```
> set -e
> cd ~/workspace
> rm -rf /tmp/b7t && mkdir -p /tmp/b7t
> unzip -o ~/b7t.zip -d /tmp/b7t
> node /tmp/b7t/apply-b7t.mjs
> ./source-code/sync.sh
> pnpm --filter @workspace/dashboard run build
> echo "B7t applied. Ready to restart the workflow."
> ```
>
> Step 2: restart the api-server workflow (the dashboard is served
> by the same workflow as the api).
>
> Step 3: wait until the server logs "Server listening port: 8080".
>
> Step 4: confirm the dashboard built clean. Show me the last 10 lines
> of the api-server workflow log after restart.
>
> Do not do anything else. Do not edit any files. Do not modify the
> bash block. Paste the exact output back to me.

---

POST-DEPLOY VERIFICATION
------------------------

After deploy, open the dashboard in your browser:

  https://doctrine-followupv-2.replit.app/admin-activity

You should see:
  - A sidebar with a new "Admin Activity" link (BarChart3 icon)
  - 4 stat cards at the top
  - A per-user table showing only your own row (1 follow-up, $0.045)
  - Click the row → expanded view shows by_app / by_stage / by_model
  - Below: 2 events (the draft + critic from Send-Now)
  - Filters: change Window to "Last 24h" — same data should show
  - Filter User → "Michael Goder" — same 1 user shows
  - Filter App → "Context" — empty state ("No events in this window")

If anything looks wrong (page blank, console errors, filters broken),
open browser devtools, copy the network response from
/api/admin/activity, and paste it back with a screenshot.

When verified, we move to B7u (Excel export + admin pause/resume) or
B7v (live in-flight counter + auto-refresh) — whichever you prioritize.
