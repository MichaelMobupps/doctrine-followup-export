B7u — Excel export + admin pause/resume for Email Followuper
==============================================================

This is the biggest batch in the activity-log series. Adds two new
operational capabilities to the admin dashboard:

  1. Excel download: full XLSX report with 6 sheets covering Summary,
     Per User, Per Model, Per Stage, Events (up to 5000), and a
     Pricing Reference snapshot.

  2. Per-user admin pause/resume: pause a user from the dashboard
     and the scheduler skips them entirely until resumed. Existing
     queued follow-ups stay in queued status; nothing is cancelled.

Files written (3 new):
  - artifacts/api-server/src/routes/admin-activity-report.ts (Excel)
  - artifacts/api-server/src/routes/admin-user-controls.ts (pause/resume)
  - artifacts/dashboard/src/pages/admin-activity.tsx (replaces B7t version)

Files patched (7):
  - lib/db/src/schema/users.ts                            (+pausedByAdmin column)
  - artifacts/api-server/src/lib/startupMigrations.ts     (+ALTER TABLE users)
  - artifacts/api-server/src/services/scheduler.ts        (skip paused users x2)
  - artifacts/api-server/src/routes/admin-activity.ts     (+paused_by_admin in users[])
  - artifacts/api-server/src/routes/index.ts              (mount 2 new routers)
  - artifacts/api-server/package.json                     (+xlsx dep)

Safety:
  - ALTER TABLE ADD COLUMN IF NOT EXISTS is idempotent. Re-running the
    startup migration after the column exists is a clean no-op.
  - New users default to paused_by_admin=false. No existing user is
    affected until explicitly paused.
  - Scheduler changes are filters that exclude paused users. With no
    pauses set, behavior is identical to pre-B7u.
  - Excel endpoint is read-only. Pause/resume endpoints require
    X-API-Key auth.

Audit results (this batch was tested against live Postgres + live
Express server + Vite production build + jsdom render):
  - Apply script idempotent: 13 ops on first run, full skip on second
  - ALTER TABLE migration: confirmed idempotent (PG NOTICE "skipping")
  - Pause endpoint: live POST returned correct shape, DB flipped flag
  - Resume endpoint: live POST returned correct shape, DB flipped flag
  - Invalid user id → 400, non-existent → 404, no auth → 401
  - GET /admin/activity returned paused_by_admin in users[]
  - Excel download: 30KB file, "Microsoft Excel 2007+" signature,
    6 sheets, correct totals, filter (app=context) returns 2 events
  - TypeScript strict: 0 errors across all routes and the page
  - Vite production build: 1512 modules, 164KB bundle, 0 errors
  - JSDOM render with paused user: paused badge, Resume button,
    Pause button on non-paused user, Download Excel button all present
  - Brace balance preserved on all 9 patched/new files
  - api-server/package.json: valid JSON after the xlsx add

---

PROMPT FOR THE REPLIT AGENT
---------------------------

> Apply the b7u patch from ~/b7u.zip.
>
> Step 1: run this single bash block in the shell, exactly as-is.
> Note: this batch adds the xlsx dependency, so `pnpm install` is
> required before building.
>
> ```
> set -e
> cd ~/workspace
> rm -rf /tmp/b7u && mkdir -p /tmp/b7u
> unzip -o ~/b7u.zip -d /tmp/b7u
> node /tmp/b7u/apply-b7u.mjs
> pnpm install
> ./source-code/sync.sh
> pnpm --filter @workspace/api-server run build
> pnpm --filter @workspace/dashboard run build
> echo "B7u applied. Ready to restart the workflow."
> ```
>
> Step 2: restart the api-server workflow.
>
> Step 3: wait until the server logs "Server listening port: 8080".
>
> Step 4: show me the last 30 lines of the api-server log. I want to
> see the line "B7r/B7u: migrations applied (followup_usage table,
> users.paused_by_admin)" appear once. That confirms both migrations ran.
>
> Step 5: smoke-test the new pause endpoint with this curl:
>
> ```
> curl -s -X POST -H "X-API-Key: $ADDON_API_KEY" \
>   http://localhost:8080/api/admin/users/2/resume
> ```
>
> Should return {"paused":false,"user":{...}}. This is a no-op since
> user 2 isn't paused yet, but confirms the endpoint is mounted.
>
> Step 6: smoke-test the Excel endpoint with this curl:
>
> ```
> curl -s -o /tmp/b7u-test.xlsx -w "HTTP %{http_code}  Size:%{size_download} bytes\n" \
>   -H "X-API-Key: $ADDON_API_KEY" \
>   http://localhost:8080/api/admin/activity-report
> file /tmp/b7u-test.xlsx
> ```
>
> Should return HTTP 200 and Size > 5000. `file` output should mention
> "Microsoft Excel 2007+".
>
> Do not do anything else. Paste each curl's output back to me.

---

POST-DEPLOY VERIFICATION (browser)
----------------------------------

After deploy, open https://doctrine-followupv-2.replit.app/admin-activity

You should see:
  - "Download Excel" button in the top-right (next to Refresh)
  - A new "Actions" column in the Per-User Totals table
  - A "Pause" button on your row (since you're not paused)
  - Click "Download Excel" — should download an .xlsx file
  - Open it: 6 sheets, your data in "Per User" and "Events"

To test pause without affecting your own follow-ups, pause a test
account first or wait until another user has rows in the per-user
table.

After this verifies, B7v is next: live in-flight counter + auto-refresh.
