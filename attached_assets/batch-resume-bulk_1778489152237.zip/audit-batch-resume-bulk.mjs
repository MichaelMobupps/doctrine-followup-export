#!/usr/bin/env node
// audit-batch-resume-bulk.mjs
//
// Beautiful-Squidward audit: 3 rounds × 9 passes per round.
// Convergence: 2 consecutive fully-clean rounds → PASS overall.
// Otherwise → FAIL with the first failing pass per round.

import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const DOCTRINE_TS = join(API_BASE, "routes/doctrine.ts");
const PIPELINE_TSX = join(DASH_BASE, "pages/pipeline.tsx");

function load(path) {
  if (!existsSync(path)) return null;
  return readFileSync(path, "utf8");
}

function countOccurrences(haystack, needle) {
  if (!haystack) return 0;
  let count = 0;
  let from = 0;
  while (true) {
    const i = haystack.indexOf(needle, from);
    if (i === -1) break;
    count++;
    from = i + needle.length;
  }
  return count;
}

const passes = [
  // ----- Backend (doctrine.ts) -----
  {
    name: "B1: doctrine.ts contains POST /prospect/resume-bulk (exactly once)",
    run: () => {
      const s = load(DOCTRINE_TS);
      if (s === null) return { ok: false, why: `${DOCTRINE_TS} not found` };
      const n = countOccurrences(s, `router.post("/prospect/resume-bulk"`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "B2: doctrine.ts logs 'Bulk resume completed' (exactly once)",
    run: () => {
      const s = load(DOCTRINE_TS);
      const n = countOccurrences(s, `"Bulk resume completed"`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "B3: doctrine.ts brace balance unchanged sign (open == close)",
    run: () => {
      const s = load(DOCTRINE_TS);
      const opens = (s.match(/\{/g) || []).length;
      const closes = (s.match(/\}/g) || []).length;
      return opens === closes
        ? { ok: true }
        : { ok: false, why: `{=${opens} }=${closes}` };
    },
  },
  {
    name: "B4: doctrine.ts uses already-imported symbols only (no stray identifiers)",
    run: () => {
      const s = load(DOCTRINE_TS);
      // Spot-check that the new route uses only symbols already imported at top of file.
      const needed = ["inArray", "and", "prospectsTable", "usersTable", "followupsTable",
                      "logger", "requeueStalledDraftForProspect", "computeNextStageScheduledAt",
                      "getFollowupCap", "SCOPE_DOCTRINE", "UserTimingSettings"];
      const top = s.slice(0, 2000);
      const missing = needed.filter((n) => !top.includes(n));
      return missing.length === 0
        ? { ok: true }
        : { ok: false, why: `missing import refs in top of file: ${missing.join(", ")}` };
    },
  },

  // ----- Frontend (pipeline.tsx) -----
  {
    name: "F1: pipeline.tsx declares bulkResuming state (exactly once)",
    run: () => {
      const s = load(PIPELINE_TSX);
      if (s === null) return { ok: false, why: `${PIPELINE_TSX} not found` };
      const n = countOccurrences(s, `const [bulkResuming, setBulkResuming] = useState(false);`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "F2: pipeline.tsx defines handleBulkResume (exactly once)",
    run: () => {
      const s = load(PIPELINE_TSX);
      const n = countOccurrences(s, `async function handleBulkResume()`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "F3: pipeline.tsx fetches /api/prospect/resume-bulk (exactly once)",
    run: () => {
      const s = load(PIPELINE_TSX);
      const n = countOccurrences(s, `api/prospect/resume-bulk`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "F4: pipeline.tsx renders 'Resume all' button (exactly once)",
    run: () => {
      const s = load(PIPELINE_TSX);
      const n = countOccurrences(s, `Resume all`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "F5: pipeline.tsx — all 4 bulk-bar buttons gate on bulkResuming",
    run: () => {
      const s = load(PIPELINE_TSX);
      const n = countOccurrences(s, `disabled={bulkSending || bulkPausing || bulkResuming}`);
      // Send all, Pause all, Resume all, Close X = 4.
      return n === 4 ? { ok: true } : { ok: false, why: `found ${n}, want 4` };
    },
  },
];

// Harness invariant: 9 passes per round.
if (passes.length !== 9) {
  console.error(`AUDIT HARNESS BUG: expected 9 passes, got ${passes.length}`);
  process.exit(2);
}

function runRound(roundNum) {
  console.log(`--- Round ${roundNum} ---`);
  let allOk = true;
  for (const pass of passes) {
    const r = pass.run();
    if (r.ok) {
      console.log(`  PASS  ${pass.name}`);
    } else {
      console.log(`  FAIL  ${pass.name} :: ${r.why}`);
      allOk = false;
    }
  }
  return allOk;
}

let cleanStreak = 0;
let overallOk = false;
for (let i = 1; i <= 3; i++) {
  const ok = runRound(i);
  if (ok) cleanStreak++;
  else cleanStreak = 0;
  if (cleanStreak >= 2) {
    overallOk = true;
    break;
  }
}

console.log("");
if (overallOk) {
  console.log("CONVERGED: 2 consecutive clean rounds. AUDIT PASS.");
  process.exit(0);
} else {
  console.log("DID NOT CONVERGE within 3 rounds. AUDIT FAIL.");
  process.exit(1);
}
