# Batch 7f — Context Activity Log

Phase 7f. Replaces the placeholder at `/context/activity` with a real
ContextActivityLog page derived from the Doctrine Activity Log. Reshapes
`/api/context/campaign/status` from the simple `{ followups: [...] }`
shape to the rich per-user campaign aggregation that the Activity Log UI
expects.

Email Inspector clone is deferred to 7g — its backend variant
(`/context/gmail/sent-emails` with context-label flagging vs
doctrine-label flagging) is bigger and warrants its own batch.

## What's in this batch

**Backend changes (`routes/context.ts`):**

- **Inline `getFollowupCap` helper** at the top of the file. 3 lines,
  mirrors the doctrine.ts copy verbatim. No good place to extract to a
  shared lib yet — both copies will move together when there is.
- **Replace `/api/context/campaign/status` handler** with the rich
  per-user campaign aggregation cloned from doctrine. Returns the same
  shape as `/api/campaign/status`:
  - Top-level: `active: boolean`, `queued_count`, `sent_count`,
    `unreplied_prospects`, `users[]`.
  - Per-user: `id`, `email`, `name`, `max_followups`, `context_label`
    (vs doctrine's `doctrine_label`), `campaigns[]`.
  - Per-campaign: `label`, `total`, `unreplied`, `paused`, `queued`,
    `sent`, `actionable`.
  - Same aggregation logic: `campaignBreakdown` (count/filter), the
    `actionableProspects` → `prospectFollowupState` Map → `actionableByUser`
    chain that respects `getFollowupCap`, `followupBreakdown` by status,
    `perUserStats` Map collapsing all batch labels per user.
  - Scope is `SCOPE` (`app='context'`) instead of `SCOPE_DOCTRINE`.
  - `usersTable.contextLabel` instead of `usersTable.doctrineLabel`.
  - Response field renamed `doctrine_label` → `context_label`.

**Frontend changes (`dashboard/pages/context-activity.tsx`):**

The B7d placeholder is replaced with a transformed clone of
`activity-log.tsx`. The apply script copies activity-log.tsx in place
and runs 6 idempotent str_replace transformations:

1. Header comment — Phase 7f marker explaining the clone.
2. Rename component `ActivityLog` → `ContextActivityLog`.
3. URL retarget `/api/campaign/status` → `/api/context/campaign/status`.
4. Type field rename `doctrine_label: string` → `context_label: string`
   in `UserActivity`.
5. Render rename `{user.doctrine_label}` → `{user.context_label}`.
6. Title text "Activity Log" → "Context Activity Log".

Everything else — the StatPill / CampaignRow / UserRow components, the
30-second polling, the optimistic refresh button, the active vs idle
user partitioning, the Card animations — comes through unchanged.

## What changes for the user

- **`/context/activity`** is now a working Activity Log page. Same
  layout as the doctrine Activity Log: header counters
  (active/queued/sent/unreplied), per-user cards with their campaign
  breakdown, idle users shown separately. Amber theme.
- **What's the same vs doctrine**: per-user metrics, actionable counts,
  reply-rate display, polling cadence (5 seconds — inherited from
  activity-log.tsx, not 30 like Pipeline).
- **What's renamed**: the user's Gmail label is shown as
  `Label: <context_label>` where the doctrine version shows
  `Label: <doctrine_label>`. Same UI placement, different field
  source.

## Files

```
batch7f/
├── apply-batch7f.mjs       # Idempotent patch + clone-from-activity-log
├── audit-batch7f.mjs       # 9 passes × 3 rounds = 123 checks
└── README.md
```

## Apply

Standard pattern — single bash block in the ship instruction. Build
both api-server and dashboard. Mirror sync. Restart api-server +
republish dashboard.

## Verify

After applying:

- The apply script self-verifies 18 anchors (7 backend + 11 frontend).
- The audit runs 123 checks (41 per round × 3 rounds): getFollowupCap
  helper, /campaign/status reshape (Drizzle projection + response
  shape), SCOPE filter integrity (≥8 SCOPE refs, no SCOPE_DOCTRINE
  leakage), ContextActivityLog component identity + Phase 7f header +
  title, frontend retargets (URL + type field + render),
  doctrine_label functional code absent in context-activity.tsx,
  doctrine UI not regressed, B7e regression (ContextPipeline +
  /context/followups + /context/cancel-followup + asc import), B7c/B7a
  regression.

Backend smoke after restart:

```bash
curl -s "http://localhost:8080/api/context/campaign/status" -H "x-api-key: $ADDON_API_KEY" | head -c 600
```

Expected shape (with one connected user, no context prospects yet):

```json
{
  "active": false,
  "queued_count": 0,
  "sent_count": 0,
  "unreplied_prospects": 0,
  "users": [
    {
      "id": 1,
      "email": "michael@mobupps.com",
      "name": "Michael Goder",
      "max_followups": 3,
      "context_label": "Context Followuper",
      "campaigns": [
        { "label": "Context Followuper", "total": 0, "unreplied": 0,
          "paused": 0, "queued": 0, "sent": 0, "actionable": 0 }
      ]
    }
  ]
}
```

Browser smoke after dashboard rebuild + reload:

1. Navigate to `/context/activity`. Should render the connected user
   card with "IDLE" badge and campaign row with all zeros. Amber theme.
   Title reads "Context Activity Log".
2. Navigate to `/activity` (doctrine). Should render exactly as before
   — blue theme, title "Activity Log", same per-user metrics.
3. Both Activity Logs should poll their respective `/campaign/status`
   endpoints.

## Known residual

- ContextActivityLog inherits the doctrine activity-log polling cadence
  (5 seconds). Lower than the 30s Pipeline poll — was intentional in
  doctrine for live demo / monitoring. Refining is open.
- Email Inspector still renders the 7d placeholder at
  `/context/inspector`. Ships in 7g.
- `/api/context/campaign/status` no longer returns the simple
  `{ followups: [...] }` shape. If anything was consuming that older
  shape (no UI consumer existed), it would break. Internal-only API,
  acceptable.
