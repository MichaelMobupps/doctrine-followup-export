import { Router, type Request, type Response, type NextFunction } from "express";
import { google, gmail_v1 } from "googleapis";
import { db, prospectsTable, usersTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";
import { getGmailForUser } from "../services/gmailClient";
import { inferVertical } from "../lib/verticalClassifier";
import { logger } from "../lib/logger";

const router = Router();

function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const key = req.headers["x-api-key"];
  const expected = process.env.ADDON_API_KEY;
  if (!expected) { res.status(500).json({ error: "Server misconfigured: ADDON_API_KEY not set" }); return; }
  if (!key || key !== expected) { res.status(401).json({ error: "Invalid API key" }); return; }
  next();
}

router.use(authMiddleware);

function getLegacyGmail(): gmail_v1.Gmail {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
  );
  auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
  return google.gmail({ version: "v1", auth });
}

async function getGmailForRequest(req: Request): Promise<{ gmail: gmail_v1.Gmail; senderEmail: string }> {
  const userId = req.query.userId ? parseInt(req.query.userId as string) : null;

  if (userId) {
    const users = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    if (users.length > 0 && users[0].googleRefreshToken && users[0].isConnected) {
      return {
        gmail: getGmailForUser({ refreshToken: users[0].googleRefreshToken, email: users[0].email }),
        senderEmail: users[0].email.toLowerCase(),
      };
    }
  }

  return {
    gmail: getLegacyGmail(),
    senderEmail: (process.env.SENDER_EMAIL || "").toLowerCase(),
  };
}


function extractEmail(headerValue: string): string {
  const match = headerValue.match(/<([^>]+)>/) || headerValue.match(/([^\s,]+@[^\s,]+)/);
  return match ? match[1].trim() : headerValue.trim();
}

function extractName(headerValue: string): string {
  const match = headerValue.match(/^"?([^"<]+)"?\s*</);
  if (match) return match[1].trim();
  const email = extractEmail(headerValue);
  return email.split("@")[0].replace(/[._-]/g, " ");
}

function isWithinSyncWindow(timestamp: number): boolean {
  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  return timestamp >= sixtyDaysAgo.getTime();
}

router.get("/gmail/sent-emails", async (req: Request, res: Response) => {
  try {
    const { gmail, senderEmail } = await getGmailForRequest(req);
    const maxResults = Math.min(parseInt(req.query.limit as string) || 30, 50);
    const doctrineLabels = (process.env.DOCTRINE_LABELS || "doctrine").split(",").map(l => l.trim());

    const allLabelsRes = await gmail.users.labels.list({ userId: "me" });
    const allLabels = allLabelsRes.data.labels || [];
    const labelNameMap: Record<string, string> = {};
    const doctrineLabelIds: string[] = [];
    for (const label of allLabels) {
      if (label.id && label.name) {
        labelNameMap[label.id] = label.name;
        const nameLower = label.name.toLowerCase();
        if (doctrineLabels.some(dl => nameLower === dl.toLowerCase() || nameLower.startsWith(dl.toLowerCase() + "/"))) {
          doctrineLabelIds.push(label.id);
        }
      }
    }

    let q = "in:sent";
    if (req.query.search) {
      q += ` ${req.query.search}`;
    }

    const listRes = await gmail.users.messages.list({
      userId: "me",
      q,
      maxResults,
    });

    const items = listRes.data.messages || [];
    const emails: any[] = [];

    for (const item of items) {
      if (!item.id) continue;
      try {
        const msgRes = await gmail.users.messages.get({
          userId: "me",
          id: item.id,
          format: "full",
        });

        const msg = msgRes.data;
        if (!msg.id || !msg.threadId) continue;

        const headers = msg.payload?.headers || [];
        const getHeader = (name: string) =>
          headers.find(h => h.name?.toLowerCase() === name.toLowerCase())?.value || "";

        let body = "";
        const parts = msg.payload?.parts || [];
        if (msg.payload?.mimeType === "text/plain" && msg.payload?.body?.data) {
          body = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
        } else {
          for (const part of parts) {
            if (part.mimeType === "text/plain" && part.body?.data) {
              body = Buffer.from(part.body.data, "base64").toString("utf-8");
              break;
            }
          }
        }

        const labelIds = msg.labelIds || [];
        const labelNames = labelIds.map(id => labelNameMap[id] || id);
        const hasDoctrineLabel = labelIds.some(id => doctrineLabelIds.includes(id));
        const matchedDoctrineLabels = labelIds
          .filter(id => doctrineLabelIds.includes(id))
          .map(id => labelNameMap[id] || id);

        const to = getHeader("To");
        const subject = getHeader("Subject");
        const from = getHeader("From");
        const date = getHeader("Date");
        const recipientEmail = extractEmail(to);
        const recipientName = extractName(to);
        const { vertical, reason: verticalReason } = inferVertical(labelNames, subject, body);
        const timestamp = parseInt(msg.internalDate || "0");

        const isSentByMe = senderEmail ? from.toLowerCase().includes(senderEmail) : false;
        const withinSyncWindow = isWithinSyncWindow(timestamp);

        const wouldBePickedUp = hasDoctrineLabel && isSentByMe && withinSyncWindow;

        const reasons: string[] = [];
        if (!isSentByMe) reasons.push("Not sent by configured sender email");
        if (!hasDoctrineLabel) reasons.push("Missing doctrine label");
        if (!withinSyncWindow) reasons.push("Outside 60-day sync window");

        emails.push({
          id: msg.id,
          threadId: msg.threadId,
          from,
          to,
          recipientEmail,
          recipientName,
          subject,
          snippet: msg.snippet || "",
          bodyPreview: body.slice(0, 800).trim(),
          date,
          timestamp,
          labelIds,
          labelNames,
          hasDoctrineLabel,
          matchedDoctrineLabels,
          isSentByMe,
          detection: {
            wouldBePickedUp,
            whyNot: wouldBePickedUp ? [] : reasons,
            vertical,
            verticalReason,
            withinSyncWindow,
            company: recipientEmail ? (recipientEmail.split("@")[1]?.split(".")[0] || "") : "",
          },
        });
      } catch (err) {
        logger.error({ err, messageId: item.id }, "Failed to fetch message for inspector");
      }
    }

    const messageIds = emails.map(e => e.id);
    let dbProspects: Record<string, any> = {};
    if (messageIds.length > 0) {
      const rows = await db
        .select({
          gmailMessageId: prospectsTable.gmailMessageId,
          id: prospectsTable.id,
          replied: prospectsTable.replied,
          vertical: prospectsTable.vertical,
        })
        .from(prospectsTable)
        .where(inArray(prospectsTable.gmailMessageId, messageIds));

      for (const row of rows) {
        dbProspects[row.gmailMessageId] = row;
      }
    }

    const enrichedEmails = emails.map(e => ({
      ...e,
      inDatabase: !!dbProspects[e.id],
      ...(dbProspects[e.id] ? { dbRecord: dbProspects[e.id] } : {}),
    }));

    res.json({
      emails: enrichedEmails,
      meta: {
        total: enrichedEmails.length,
        withDoctrineLabel: enrichedEmails.filter(e => e.hasDoctrineLabel).length,
        inDatabase: enrichedEmails.filter(e => e.inDatabase).length,
        wouldBePickedUp: enrichedEmails.filter(e => e.detection.wouldBePickedUp).length,
        doctrineLabelIds,
        doctrineLabels,
      },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "Email inspector error");
    res.status(500).json({ error: msg });
  }
});

router.get("/gmail/thread/:threadId", async (req: Request, res: Response) => {
  try {
    const { gmail, senderEmail } = await getGmailForRequest(req);
    const threadId = req.params.threadId;

    const allLabelsRes = await gmail.users.labels.list({ userId: "me" });
    const allLabels = allLabelsRes.data.labels || [];
    const labelNameMap: Record<string, string> = {};
    for (const label of allLabels) {
      if (label.id && label.name) labelNameMap[label.id] = label.name;
    }

    const threadRes = await gmail.users.threads.get({
      userId: "me",
      id: threadId,
      format: "full",
    });

    const messages = threadRes.data.messages || [];

    const threadMessages = messages.map(msg => {
      const headers = msg.payload?.headers || [];
      const getHeader = (name: string) =>
        headers.find(h => h.name?.toLowerCase() === name.toLowerCase())?.value || "";

      let body = "";
      const parts = msg.payload?.parts || [];
      if (msg.payload?.mimeType === "text/plain" && msg.payload?.body?.data) {
        body = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
      } else {
        for (const part of parts) {
          if (part.mimeType === "text/plain" && part.body?.data) {
            body = Buffer.from(part.body.data, "base64").toString("utf-8");
            break;
          }
        }
      }

      const from = getHeader("From");
      const isFromMe = senderEmail ? from.toLowerCase().includes(senderEmail) : false;
      const labelNames = (msg.labelIds || []).map(id => labelNameMap[id] || id);

      return {
        id: msg.id,
        from,
        to: getHeader("To"),
        subject: getHeader("Subject"),
        date: getHeader("Date"),
        timestamp: parseInt(msg.internalDate || "0"),
        body: body.trim(),
        snippet: msg.snippet || "",
        isFromMe,
        labelNames,
      };
    });

    const hasExternalReply = threadMessages.some(m => !m.isFromMe);

    res.json({
      threadId,
      messageCount: threadMessages.length,
      hasExternalReply,
      messages: threadMessages,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "Thread fetch error");
    res.status(500).json({ error: msg });
  }
});

export default router;
