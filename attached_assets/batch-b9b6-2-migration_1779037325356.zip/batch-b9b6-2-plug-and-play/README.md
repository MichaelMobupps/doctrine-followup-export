# B9b.6 Migration — Plug-and-Play

Two paths. Pick whichever is easier.

## Path A — drop and run

1. Drag `run-b9b6.sh` into the Replit file tree, into your workspace ROOT (the `~/workspace/` directory — same level as `lib/`, `artifacts/`, `source-code/`).
2. In the Shell, run:

```
bash run-b9b6.sh
```

That's it. The script decodes the embedded migration to `lib/db/migrate-b9b6.mjs` and runs it. No `set -e`, no shell-exit surprises.

## Path B — pure shell paste (no file management)

Copy the one-line command from `one-line.sh` and paste it into the Replit shell. Single command, ~5KB of base64, writes the migration file and runs it in one go.

## What the migration does

1. Drops the global UNIQUE constraint on `prospects.gmail_message_id` (locates it by structure, so it works regardless of whether Postgres named it `_unique` or `_key`).
2. Creates a composite uniqueIndex `uq_prospects_user_message_app` on `(user_id, gmail_message_id, app)`.
3. Verifies the final state and lists all indexes on `prospects` for an eyeball check.

Transactional — rolls back on any error. Idempotent — re-running is a clean no-op.

## After it succeeds

Validate via the sync endpoint:

```
curl -sS -X POST -H "x-api-key: $ADDON_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"michael@mobupps.com"}' \
  https://doctrine-followupv-2.replit.app/api/context/sync
```

`synced` should be > 0 (Konami and Magnit threads auto-ingest). Mark button on /anti-ghosting works without Drizzle error. Then we're unblocked for B9b.7 (AntiGhosting Pipeline page).

## If something goes wrong

Paste the full terminal output back. The script and migration are both designed to leave clear error messages without exiting the shell.
