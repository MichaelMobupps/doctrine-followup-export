#!/usr/bin/env bash
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SNAPSHOT="${SCRIPT_DIR}/snapshot"
PAYLOAD="${SCRIPT_DIR}/payload"
WORK="${SCRIPT_DIR}/audit_work"
PATCHER="${PAYLOAD}/patches/apply_patches.py"
NODE_BIN="/tmp/node_modules/.bin"

PASS=0; FAIL=0; WARN=0
ok()   { echo "    [PASS]  $*"; PASS=$((PASS + 1)); }
fail() { echo "    [FAIL]  $*"; FAIL=$((FAIL + 1)); }
warn() { echo "    [WARN]  $*"; WARN=$((WARN + 1)); }

fresh_work() { rm -rf "$WORK"; cp -r "$SNAPSHOT" "$WORK"; }

echo
echo "=== ROUND 1 — Patch correctness ==="
fresh_work

OUTPUT=$(cd "$WORK" && python3 "$PATCHER" 2>&1)
COUNT_OK=$(echo "$OUTPUT" | grep -c "\[  OK  \]")
COUNT_FAIL=$(echo "$OUTPUT" | grep -c "\[ FAIL \]")
if [[ "$COUNT_OK" == "7" && "$COUNT_FAIL" == "0" ]]; then
    ok "Fresh apply: 7/7 OK, 0 FAIL"
else
    fail "Fresh apply mismatch: $COUNT_OK OK / $COUNT_FAIL FAIL"
fi

OUTPUT2=$(cd "$WORK" && python3 "$PATCHER" 2>&1)
COUNT_SKIP2=$(echo "$OUTPUT2" | grep -c "\[ SKIP \]")
COUNT_OK2=$(echo "$OUTPUT2" | grep -c "\[  OK  \]")
if [[ "$COUNT_OK2" == "0" && "$COUNT_SKIP2" == "7" ]]; then
    ok "Re-apply idempotent: 7/7 SKIP, 0 OK"
else
    fail "Re-apply not idempotent: $COUNT_OK2 OK / $COUNT_SKIP2 SKIP"
fi

for f in "api-server/lib/nativenessV4" "api-server/lib/doctrineLint" "api-server/services/followupPrompts" "api-server/tests/test-nativeness-v4"; do
    backup="$WORK/${f}.ts.v4r2_backup"
    base="$SNAPSHOT/${f}.ts"
    if [[ -f "$backup" ]] && cmp -s "$backup" "$base"; then
        ok "Backup ${f##*/}.ts.v4r2_backup is byte-identical to snapshot"
    else
        fail "Backup ${f##*/}.ts.v4r2_backup missing or differs"
    fi
done

if cmp -s "$WORK/api-server/tests/test-nativeness-v4-round2.ts" \
          "$PAYLOAD/api-server/tests/test-nativeness-v4-round2.ts"; then
    ok "Installed test-nativeness-v4-round2.ts is byte-identical to payload"
else
    fail "Installed test file differs from payload"
fi


echo
echo "=== ROUND 2 — Behavioral ==="
cd "$WORK/api-server"

SUITE_OUT=$(PATH="$PATH:$NODE_BIN" tsx --test \
    tests/test-nativeness-v3.ts \
    tests/test-nativeness-v4.ts \
    tests/test-nativeness-v4-round2.ts \
    tests/test-doctrine-hardening.ts 2>&1 | tail -10)
if echo "$SUITE_OUT" | grep -qE "# pass 18[0-9]"; then
    PASSED=$(echo "$SUITE_OUT" | grep -oE "# pass [0-9]+" | head -1 | awk '{print $3}')
    FAILED=$(echo "$SUITE_OUT" | grep -oE "# fail [0-9]+" | head -1 | awk '{print $3}')
    if [[ "$FAILED" == "0" && "$PASSED" -ge 180 ]]; then
        ok "Combined test sweep: $PASSED tests pass, $FAILED fail"
    else
        fail "Combined test sweep: $PASSED pass / $FAILED fail"
    fi
else
    fail "Combined test sweep: output unexpected"
    echo "$SUITE_OUT" | tail -8
fi


echo
echo "=== ROUND 3 — Runtime ==="

# Confirm tsx can load nativenessV4 (executes top-level code, surfaces syntax/import errors)
LOAD_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import * as m from './lib/nativenessV4';
const keys = ['findRepeatingDiscourseMarkers', 'findSemicolonWithoutConnector', 'findNonReflexiveRomanceVerbs', 'REPEATING_DISCOURSE_MARKERS', 'SEMICOLON_CONNECTORS', 'NON_REFLEXIVE_VERBS'];
for (const k of keys) {
  if (!(k in m)) { console.log('MISSING:' + k); process.exit(1); }
}
console.log('OK');
" 2>&1)
if [[ "$LOAD_OUT" == "OK" ]]; then
    ok "nativenessV4 loads + exports 3 functions + 3 vocabulary tables"
else
    fail "nativenessV4 load failed: $LOAD_OUT"
fi

LOAD_OUT2=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import './lib/doctrineLint';
import './services/followupPrompts';
console.log('OK');
" 2>&1)
if [[ "$LOAD_OUT2" == "OK" ]]; then
    ok "doctrineLint + followupPrompts load without runtime errors"
else
    fail "doctrineLint/followupPrompts load failed: $LOAD_OUT2"
fi


echo
echo "=== ROUND 4 — End-to-end wiring ==="

KEYS_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import { findAllNativenessViolationsV4 } from './lib/nativenessV4';
const r = findAllNativenessViolationsV4('test', 'pt');
const keys = ['repeating_discourse_markers', 'semicolon_no_connector', 'non_reflexive_romance_verbs'];
for (const k of keys) {
  console.log(k + '=' + (k in r ? 'present' : 'MISSING'));
}
" 2>&1)
for key in repeating_discourse_markers semicolon_no_connector non_reflexive_romance_verbs; do
    if echo "$KEYS_OUT" | grep -q "${key}=present"; then
        ok "Aggregator emits key: $key"
    else
        fail "Aggregator missing key: $key"
    fi
done

DENISE_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import { findAllNativenessViolationsV4 } from './lib/nativenessV4';
const email = 'No mercado brasileiro, Nubank e PicPay rodam mídia mobile otimizada; a oferta de 150% do CDI da XP encaixa nesse playbook.\n\nVale mencionar que temos resultados fortes. Operamos com inventário semi-exclusivo. Vale mencionar também C6 Bank.';
const r = findAllNativenessViolationsV4(email, 'pt-BR');
console.log('repeat=' + r.repeating_discourse_markers.length);
console.log('semi=' + r.semicolon_no_connector.length);
console.log('refl=' + r.non_reflexive_romance_verbs.length);
" 2>&1)
if echo "$DENISE_OUT" | grep -qE "repeat=[1-9]"; then ok "Denise email: REPEATING-DISCOURSE-MARKER fires"; else fail "Denise email: REPEATING-DISCOURSE-MARKER missed"; fi
if echo "$DENISE_OUT" | grep -qE "semi=[1-9]"; then ok "Denise email: SEMICOLON-NO-CONNECTOR fires"; else fail "Denise email: SEMICOLON-NO-CONNECTOR missed"; fi
if echo "$DENISE_OUT" | grep -qE "refl=[1-9]"; then ok "Denise email: NON-REFLEXIVE-ROMANCE-VERB fires"; else fail "Denise email: NON-REFLEXIVE-ROMANCE-VERB missed"; fi

for code in "REPEATING-DISCOURSE-MARKER" "SEMICOLON-NO-CONNECTOR" "NON-REFLEXIVE-ROMANCE-VERB"; do
    if grep -q "$code" "$WORK/api-server/lib/doctrineLint.ts"; then
        ok "doctrineLint references lint code: $code"
    else
        fail "doctrineLint missing lint code: $code"
    fi
done

for c in 13i 13j 13k; do
    if grep -q "${c}\\." "$WORK/api-server/services/followupPrompts.ts"; then
        ok "followupPrompts has criterion ${c}"
    else
        fail "followupPrompts missing criterion ${c}"
    fi
done


echo
echo "=== ROUND 5 — Regression ==="

for spec in \
    "api-server/lib/nativenessV4.ts|900" \
    "api-server/lib/doctrineLint.ts|90" \
    "api-server/services/followupPrompts.ts|10"; do
    path="${spec%|*}"
    max="${spec##*|}"
    base_lines=$(wc -l < "$SNAPSHOT/$path")
    new_lines=$(wc -l < "$WORK/$path")
    delta=$((new_lines - base_lines))
    if [[ "$delta" -le "$max" && "$delta" -ge 0 ]]; then
        ok "$path line delta: +$delta (budget +$max)"
    else
        warn "$path line delta: +$delta (budget +$max)"
    fi
done

# Untouched files byte-identical
for f in "api-server/lib/nativenessV3.ts" "api-server/lib/languageNativeness.ts" "api-server/lib/doctrineRules.ts"; do
    if cmp -s "$WORK/$f" "$SNAPSHOT/$f"; then
        ok "$f byte-identical to snapshot"
    else
        fail "$f was modified — Round-2 should leave this file untouched"
    fi
done

# Rollback restores byte-identical
ROLLBACK_DIR=$(mktemp -d)
cp -r "$WORK"/* "$ROLLBACK_DIR/"
( cd "$ROLLBACK_DIR"
  for f in api-server/lib/nativenessV4 api-server/lib/doctrineLint api-server/services/followupPrompts api-server/tests/test-nativeness-v4; do
      if [[ -f "${f}.ts.v4r2_backup" ]]; then
          cp "${f}.ts.v4r2_backup" "${f}.ts"
          rm "${f}.ts.v4r2_backup"
      fi
  done
  rm -f api-server/tests/test-nativeness-v4-round2.ts
)
DIFF_OUT=$(diff -r --exclude="node_modules" --exclude=".tmp*" "$ROLLBACK_DIR" "$SNAPSHOT" 2>&1)
if [[ -z "$DIFF_OUT" ]]; then
    ok "Rollback restores byte-identical to snapshot"
else
    fail "Rollback differs:"
    echo "$DIFF_OUT" | head -5
fi
rm -rf "$ROLLBACK_DIR"


echo
echo "================================================================"
echo "AUDIT SUMMARY"
echo "  PASS: $PASS"
echo "  FAIL: $FAIL"
echo "  WARN: $WARN"
echo "================================================================"
if [[ "$FAIL" == "0" ]]; then
    echo "Status: GO-FOR-SHIP"
    exit 0
else
    echo "Status: BLOCKED"
    exit 1
fi
