import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { gmail_v1 } from "googleapis";
import { db, prospectsTable, followupsTable, usersTable, threadMessagesTable } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { getGmailForUser } from "../services/gmailClient";
import { logger } from "../lib/logger";
import { validateThreadForMarking } from "../services/antiGhostingValidators";
import type { ThreadMessageBrief, ValidationOutcome } from "../services/antiGhostingValidators";
import { computeFirstFollowupAt } from "../services/antiGhostingScheduling";
import { syncThreadFromGmail } from "../services/threadReader";

/**
 * B9b: AntiGhosting Followuper routes.
 *
 * Mounted under /api/anti-ghosting/*. The third product alongside
 * Doctrine and Context. Scoped to prospects with app='anti_ghosting'.
 *
 * Endpoints in this batch:
 *
 *   POST /api/anti-ghosting/mark
 *     Body: { email, gmailThreadId, seedMessageId? }
 *     Runs the three marking validators (recent-outbound, has-inbound,
 *     not-in-followups). On pass, creates an anti_ghosting prospect,
 *     syncs the thread into thread_messages, schedules the F1 follow-up
 *     using max(sentAt + 7d, markedAt + 1d), and returns the new
 *     prospect's identity and scheduled time. On fail, returns 200 with
 *     the validator preview so the dashboard can show the operator
 *     exactly which check failed and why.
 *
 *   GET /api/anti-ghosting/candidates?email=...
 *     Lists Gmail threads tagged with the user's antiGhostingLabel that
 *     do not yet have an anti_ghosting prospect. Each candidate
 *     includes seed identification (date, subject, snippet,
 *     daysSinceSeed tier flag) and a per-thread validator preview so
 *     the dashboard can render the mark UI without a second round trip.
 *
 * LLM generation, scheduler dispatching for stages F2+, pause /
 * renewal flows, and the dashboard UI all land in later batches
 * (B9b.1 for UI, B9c for pipeline + scheduler, B9d for pause + renewal).
 */

const router: IRouter = Router();

function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const key = req.headers["x-api-key"];
  const expected = process.env.ADDON_API_KEY;

  if (!expected) {
    res.status(500).json({ error: "ADDON_API_KEY not set" });
    return;
  }

  if (!key || key !== expected) {
    res.status(401).json({ error: "Invalid API key" });
    return;
  }

  next();
}

router.use(authMiddleware);

// =====================================================================
// Helpers
// =====================================================================

interface ResolvedUser {
  id: number;
  email: string;
  antiGhostingLabel: string;
  gmail: gmail_v1.Gmail;
}

/**
 * Resolve the user from a request, build a Gmail client, and return both.
 * Throws a structured Error with `status` if the user is not found, not
 * connected, or missing credentials — the calling route handler catches
 * and translates to the matching HTTP status.
 */
async function resolveUserFromEmail(email: string): Promise<ResolvedUser> {
  if (!email) {
    const err = new Error("email is required") as Error & { status: number };
    err.status = 400;
    throw err;
  }

  const users = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email))
    .limit(1);

  if (users.length === 0) {
    const err = new Error(`User not found: ${email}`) as Error & { status: number };
    err.status = 404;
    throw err;
  }

  const user = users[0];
  if (!user.googleRefreshToken || !user.isConnected) {
    const err = new Error(`User ${email} is not connected to Gmail`) as Error & { status: number };
    err.status = 409;
    throw err;
  }

  const gmail = getGmailForUser({
    refreshToken: user.googleRefreshToken,
    email: user.email,
    name: user.name ?? undefined,
  });

  return {
    id: user.id,
    email: user.email,
    // Schema default ("AntiGhosting Followuper") covers existing rows that
    // were created before the column gained a value. New users get the
    // default at insert time. Treat null defensively.
    antiGhostingLabel: user.antiGhostingLabel ?? "AntiGhosting Followuper",
    gmail,
  };
}

/**
 * Classify a seed message's age into the three tone tiers used by the
 * downstream generator and by the dashboard's candidate cards.
 */
function daysSinceSeedTier(sentAt: Date, now: Date): "lt_30d" | "30d_to_6mo" | "gt_6mo" {
  const diffMs = now.getTime() - sentAt.getTime();
  const days = diffMs / (24 * 60 * 60 * 1000);
  if (days < 30) return "lt_30d";
  if (days < 180) return "30d_to_6mo";
  return "gt_6mo";
}

/**
 * Look up the set of Gmail thread IDs that already have an anti_ghosting
 * prospect for this user. Used by /candidates to filter out
 * already-marked threads from the label-tagged list.
 */
async function getAlreadyMarkedThreadIds(userId: number): Promise<Set<string>> {
  const rows = await db
    .selectDistinct({ gmailThreadId: threadMessagesTable.gmailThreadId })
    .from(threadMessagesTable)
    .innerJoin(prospectsTable, eq(prospectsTable.id, threadMessagesTable.prospectId))
    .where(
      and(
        eq(prospectsTable.userId, userId),
        eq(prospectsTable.app, "anti_ghosting"),
      ),
    );
  return new Set(rows.map((r: { gmailThreadId: string }) => r.gmailThreadId));
}

/**
 * Resolve the Gmail label IDs matching the user's antiGhostingLabel
 * setting. Supports the same comma-separated multi-label convention the
 * context route uses (e.g. "AntiGhosting Followuper,AntiGhost").
 *
 * Returns the empty array if none of the configured labels exist in the
 * user's mailbox; the caller should treat that as "no candidates" rather
 * than an error.
 */
async function resolveAntiGhostingLabelIds(
  gmail: gmail_v1.Gmail,
  labelSetting: string,
): Promise<string[]> {
  const wanted = labelSetting
    .split(",")
    .map((l) => l.trim().toLowerCase())
    .filter(Boolean);
  if (wanted.length === 0) return [];

  const allLabelsRes = await gmail.users.labels.list({ userId: "me" });
  const allLabels = allLabelsRes.data.labels || [];
  const matchedIds: string[] = [];
  for (const label of allLabels) {
    if (!label.id || !label.name) continue;
    const nameLower = label.name.toLowerCase();
    if (wanted.some((w) => nameLower === w || nameLower.startsWith(w + "/"))) {
      matchedIds.push(label.id);
    }
  }
  return matchedIds;
}

// =====================================================================
// POST /api/anti-ghosting/mark
// =====================================================================
router.post("/mark", async (req: Request, res: Response): Promise<void> => {
  try {
    const email = req.body?.email ? String(req.body.email) : "";
    const gmailThreadId = req.body?.gmailThreadId ? String(req.body.gmailThreadId) : "";
    const overrideSeedMessageId = req.body?.seedMessageId
      ? String(req.body.seedMessageId)
      : null;

    if (!gmailThreadId) {
      res.status(400).json({ error: "gmailThreadId is required" });
      return;
    }

    const user = await resolveUserFromEmail(email);

    // 1. Run the three validators.
    const outcome: ValidationOutcome = await validateThreadForMarking(
      gmailThreadId,
      user.gmail,
      user.email,
      user.id,
    );

    if (!outcome.ok) {
      // Validator failures are 200 OK with the structured preview so
      // the dashboard can render them inline. Only structural errors
      // (auth, missing thread, DB failure) bubble up as 4xx/5xx.
      res.json({
        ok: false,
        results: outcome.results,
        prospect: outcome.prospect,
        failureReason: outcome.failureReason,
      });
      return;
    }

    // 2. Pick the seed. Default = most recent outbound (what the validator
    // returned). Operator override = explicit seedMessageId in body, which
    // must be present in the thread AND be outbound.
    let seed: ThreadMessageBrief | null = outcome.seed;
    if (overrideSeedMessageId) {
      const override = outcome.threadMessages.find((m) => m.id === overrideSeedMessageId);
      if (!override) {
        res.status(400).json({ error: `seedMessageId ${overrideSeedMessageId} not found in thread` });
        return;
      }
      if (override.direction !== "outbound") {
        res.status(400).json({ error: "seedMessageId must reference an outbound (sent-by-user) message" });
        return;
      }
      seed = override;
    }
    if (!seed) {
      // Defensive — validator returned ok with no seed should be impossible,
      // but guard against future drift.
      res.status(500).json({ error: "Internal: validator returned ok with null seed" });
      return;
    }
    if (!outcome.prospect) {
      res.status(500).json({ error: "Internal: validator returned ok with null prospect" });
      return;
    }

    const markedAt = new Date();
    const scheduledAt = computeFirstFollowupAt({
      sentAt: seed.sentAt,
      markedAt,
    });

    // 3. Create the prospect row. originalLanguage is left null in B9b;
    //    B9c's generator will detect-and-fill at generation time if needed.
    //    vertical / subVertical are not meaningful for re-engagement —
    //    the prospect already had whatever vertical the original outreach
    //    used; we don't carry it forward.
    const inserted = await db
      .insert(prospectsTable)
      .values({
        userId: user.id,
        name: outcome.prospect.name || outcome.prospect.email,
        email: outcome.prospect.email,
        company: outcome.prospect.email.split("@")[1] ?? "",
        sentAt: seed.sentAt,
        originalSubject: seed.subject,
        originalBody: seed.body,
        gmailMessageId: seed.id,
        app: "anti_ghosting",
        // cycle defaults to 1 via schema (B9a). Explicit for clarity.
        cycle: 1,
      })
      .returning({ id: prospectsTable.id });

    if (inserted.length === 0) {
      res.status(500).json({ error: "Failed to insert prospect" });
      return;
    }
    const prospectId = inserted[0].id;

    // 4. Sync the thread into thread_messages. Re-fetches the thread
    //    (small overhead, ~200ms) but reuses the established persistence
    //    helper from B9a rather than re-implementing here.
    try {
      await syncThreadFromGmail(prospectId, user.gmail, gmailThreadId, user.email);
    } catch (err) {
      logger.warn(
        { err, prospectId, gmailThreadId },
        "syncThreadFromGmail failed during /mark; prospect is created but thread_messages may be incomplete",
      );
      // Don't fail the mark — the prospect is created and the F1
      // schedule will still fire. A future thread sync (B9c's
      // per-cycle re-read) will backfill.
    }

    // 5. Schedule F1.
    await db.insert(followupsTable).values({
      prospectId,
      stage: 1,
      cycle: 1,
      status: "scheduled",
      scheduledAt,
    });

    logger.info(
      { prospectId, userId: user.id, gmailThreadId, scheduledAt: scheduledAt.toISOString() },
      "AntiGhosting prospect marked",
    );

    res.json({
      ok: true,
      prospectId,
      scheduledAt: scheduledAt.toISOString(),
      seed: {
        gmailMessageId: seed.id,
        subject: seed.subject,
        sentAt: seed.sentAt.toISOString(),
      },
      prospect: outcome.prospect,
      results: outcome.results,
    });
  } catch (err: unknown) {
    const status = (err as { status?: number }).status ?? 500;
    const msg = err instanceof Error ? err.message : String(err);
    if (status >= 500) logger.error({ err }, "POST /anti-ghosting/mark failed");
    res.status(status).json({ error: msg });
  }
});

// =====================================================================
// GET /api/anti-ghosting/candidates?email=...
// =====================================================================
router.get("/candidates", async (req: Request, res: Response): Promise<void> => {
  try {
    const email = req.query.email ? String(req.query.email) : "";
    const maxResults = Math.min(
      parseInt((req.query.limit as string) ?? "20", 10) || 20,
      50,
    );

    const user = await resolveUserFromEmail(email);

    // 1. Resolve antiGhosting label IDs.
    const labelIds = await resolveAntiGhostingLabelIds(user.gmail, user.antiGhostingLabel);
    if (labelIds.length === 0) {
      res.json({
        ok: true,
        candidates: [],
        note: `No Gmail labels matching "${user.antiGhostingLabel}" found in user's mailbox. Apply that label in Gmail to mark threads for re-engagement.`,
      });
      return;
    }

    // 2. List label-tagged threads.
    const threadsRes = await user.gmail.users.threads.list({
      userId: "me",
      labelIds,
      maxResults,
    });
    const threads = threadsRes.data.threads || [];

    // 3. Filter out threads that already have an anti_ghosting prospect.
    const alreadyMarked = await getAlreadyMarkedThreadIds(user.id);

    // 4. For each remaining thread, run validators to populate the preview.
    //    Validators short-circuit on first failure so this is cheap for
    //    most threads (typically 1 Gmail call + 1 DB lookup).
    const now = new Date();
    const candidates: unknown[] = [];
    for (const t of threads) {
      if (!t.id) continue;
      if (alreadyMarked.has(t.id)) continue;

      try {
        const outcome = await validateThreadForMarking(t.id, user.gmail, user.email, user.id);
        candidates.push({
          gmailThreadId: t.id,
          ok: outcome.ok,
          results: outcome.results,
          failureReason: outcome.failureReason,
          prospect: outcome.prospect,
          seed: outcome.seed
            ? {
                gmailMessageId: outcome.seed.id,
                subject: outcome.seed.subject,
                snippet: outcome.seed.snippet,
                sentAt: outcome.seed.sentAt.toISOString(),
                daysSinceSeedTier: daysSinceSeedTier(outcome.seed.sentAt, now),
              }
            : null,
        });
      } catch (err) {
        logger.warn({ err, threadId: t.id }, "validator failed for candidate thread; skipping");
      }
    }

    res.json({ ok: true, candidates });
  } catch (err: unknown) {
    const status = (err as { status?: number }).status ?? 500;
    const msg = err instanceof Error ? err.message : String(err);
    if (status >= 500) logger.error({ err }, "GET /anti-ghosting/candidates failed");
    res.status(status).json({ error: msg });
  }
});

export default router;
