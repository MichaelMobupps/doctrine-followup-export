// B7p apply script.
// Surgical string-replace patches against the live src tree. Each edit
// includes an idempotency marker so re-running this script after a
// successful apply is a clean no-op rather than an error.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";

async function patchFile(relativePath, edits) {
  const absPath = path.join(WORKSPACE, relativePath);
  let content;
  try {
    content = await fs.readFile(absPath, "utf8");
  } catch (err) {
    throw new Error(`Cannot read ${absPath}: ${err.message}`);
  }

  let applied = 0;
  let alreadyApplied = 0;

  for (const edit of edits) {
    if (edit.marker && content.includes(edit.marker)) {
      console.log(`  [skip] ${edit.name} (already applied)`);
      alreadyApplied++;
      continue;
    }
    const occurrences = content.split(edit.search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Edit "${edit.name}" search string NOT FOUND in ${relativePath}. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Edit "${edit.name}" matched ${occurrences} times in ${relativePath}. Need a more specific search string.`);
    }
    content = content.replace(edit.search, edit.replace);
    applied++;
    console.log(`  [ok]   ${edit.name}`);
  }

  if (applied > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${relativePath} (applied ${applied}, skipped ${alreadyApplied})`);
  } else {
    console.log(`no-op: ${relativePath} (all ${alreadyApplied} edits already applied)`);
  }
}

// =============================================================
// Edit 1: api-server routes/doctrine.ts — lift 500-row cap on /followups
// =============================================================
const DOCTRINE_EDITS = [
  {
    name: "doctrine /followups limit 500 -> 50000",
    marker: "// B7p: limit raised; dashboard truncated for users with 150+ prospects",
    search:
      `      .orderBy(asc(followupsTable.scheduledAt))
      .limit(500);`,
    replace:
      `      .orderBy(asc(followupsTable.scheduledAt))
      // B7p: limit raised; dashboard truncated for users with 150+ prospects
      // and their queued tail rows fell off the end of the response, which
      // surfaced as "No stages queued" in the Pipeline page even when the
      // database had a queued row for the prospect.
      .limit(50000);`,
  },
];

// =============================================================
// Edit 2: api-server routes/context.ts — lift two 500-row caps
// =============================================================
const CONTEXT_EDITS = [
  {
    name: "context /prospects limit 500 -> 50000",
    marker: "// B7p: limit raised on /context/prospects",
    search:
      `      .orderBy(desc(prospectsTable.sentAt))
      .limit(500);`,
    replace:
      `      .orderBy(desc(prospectsTable.sentAt))
      // B7p: limit raised on /context/prospects for parity with doctrine.
      .limit(50000);`,
  },
  {
    name: "context /followups limit 500 -> 50000",
    marker: "// B7p: limit raised on /context/followups",
    search:
      `      .orderBy(asc(followupsTable.scheduledAt))
      .limit(500);`,
    replace:
      `      .orderBy(asc(followupsTable.scheduledAt))
      // B7p: limit raised on /context/followups for parity with doctrine.
      .limit(50000);`,
  },
];

// =============================================================
// Edit 3: dashboard pipeline.tsx
//   - activeStages filter: include "drafted"
//   - StageProgress switch: add drafted + stalled_awaiting_manual_send
//   - main render: route drafted to StatusSummary instead of countdown
//   - StatusSummary: render drafted as "Draft ready in Gmail — F{n}"
// =============================================================
const PIPELINE_EDITS = [
  {
    name: "pipeline activeStages: include drafted",
    marker: "B7p: include drafted",
    search:
      `    const activeStages = sorted.filter(r =>
      ["queued", "generating", "pending_approval"].includes(r.status)
    );`,
    replace:
      `    const activeStages = sorted.filter(r =>
      // B7p: include drafted so the dashboard surface matches the
      // scheduler's notion of "active" (status='drafted' blocks autoqueue).
      ["queued", "generating", "pending_approval", "drafted"].includes(r.status)
    );`,
  },
  {
    name: "pipeline StageProgress: add drafted + stalled cases",
    marker: "B7p: previously these two fell through to grey",
    search:
      `        case "failed":
          bg = "var(--danger)"; border = "var(--danger)";
          title = \`Stage \${i}: failed\`; break;
      }`,
    replace:
      `        case "failed":
          bg = "var(--danger)"; border = "var(--danger)";
          title = \`Stage \${i}: failed\`; break;
        // B7p: previously these two fell through to grey "not scheduled"
        // and the user could not see that a row existed at all.
        case "drafted":
          bg = "rgba(255,140,0,0.4)"; border = "rgb(255,140,0)";
          title = \`Stage \${i}: drafted in Gmail (send manually)\`; break;
        case "stalled_awaiting_manual_send":
          bg = "var(--danger-muted)"; border = "var(--danger)";
          title = \`Stage \${i}: stalled (draft unsent 30+ days)\`; break;
      }`,
  },
  {
    name: "pipeline main render: route drafted to StatusSummary",
    marker: "thread.next_followup.status !== \"drafted\"",
    search:
      `{thread.next_followup && !thread.followup_paused && !thread.replied && thread.next_followup.status !== "pending_approval" ? (`,
    replace:
      `{thread.next_followup && !thread.followup_paused && !thread.replied && thread.next_followup.status !== "pending_approval" && thread.next_followup.status !== "drafted" ? (`,
  },
  {
    name: "pipeline StatusSummary: render drafted explicitly",
    marker: "B7p: drafted rows surface here instead of as a countdown",
    search:
      `    if (thread.next_followup.status === "pending_approval") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--accent)" }}>
          <Eye className="h-3 w-3" /> Awaiting approval
        </span>
      );
    }
    return null; // handled by CountdownTimer in the main row`,
    replace:
      `    if (thread.next_followup.status === "pending_approval") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--accent)" }}>
          <Eye className="h-3 w-3" /> Awaiting approval
        </span>
      );
    }
    // B7p: drafted rows surface here instead of as a countdown. In
    // draft_in_gmail mode this is the normal "waiting for the user to
    // manually click Send in Gmail" state. The StallPill on the right
    // still escalates after 14/21/28 days.
    if (thread.next_followup.status === "drafted") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "rgb(255,140,0)" }}>
          <Mail className="h-3 w-3" /> Draft ready in Gmail — F{thread.next_followup.stage}
        </span>
      );
    }
    return null; // handled by CountdownTimer in the main row`,
  },
];

// =============================================================
// Edit 4: dashboard context-pipeline.tsx — same four fixes as pipeline.tsx
// =============================================================
const CONTEXT_PIPELINE_EDITS = [
  {
    name: "context-pipeline activeStages: include drafted",
    marker: "B7p: include drafted",
    search:
      `    const activeStages = sorted.filter(r =>
      ["queued", "generating", "pending_approval"].includes(r.status)
    );`,
    replace:
      `    const activeStages = sorted.filter(r =>
      // B7p: include drafted so the dashboard surface matches the
      // scheduler's notion of "active" (status='drafted' blocks autoqueue).
      ["queued", "generating", "pending_approval", "drafted"].includes(r.status)
    );`,
  },
  {
    name: "context-pipeline StageProgress: add drafted + stalled cases",
    marker: "B7p: previously these two fell through to grey",
    search:
      `        case "failed":
          bg = "var(--danger)"; border = "var(--danger)";
          title = \`Stage \${i}: failed\`; break;
      }`,
    replace:
      `        case "failed":
          bg = "var(--danger)"; border = "var(--danger)";
          title = \`Stage \${i}: failed\`; break;
        // B7p: previously these two fell through to grey "not scheduled"
        // and the user could not see that a row existed at all.
        case "drafted":
          bg = "rgba(255,140,0,0.4)"; border = "rgb(255,140,0)";
          title = \`Stage \${i}: drafted in Gmail (send manually)\`; break;
        case "stalled_awaiting_manual_send":
          bg = "var(--danger-muted)"; border = "var(--danger)";
          title = \`Stage \${i}: stalled (draft unsent 30+ days)\`; break;
      }`,
  },
  {
    name: "context-pipeline main render: route drafted to StatusSummary",
    marker: "thread.next_followup.status !== \"drafted\"",
    search:
      `{thread.next_followup && !thread.followup_paused && !thread.replied && thread.next_followup.status !== "pending_approval" ? (`,
    replace:
      `{thread.next_followup && !thread.followup_paused && !thread.replied && thread.next_followup.status !== "pending_approval" && thread.next_followup.status !== "drafted" ? (`,
  },
  {
    name: "context-pipeline StatusSummary: render drafted explicitly",
    marker: "B7p: drafted rows surface here instead of as a countdown",
    search:
      `    if (thread.next_followup.status === "pending_approval") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--accent)" }}>
          <Eye className="h-3 w-3" /> Awaiting approval
        </span>
      );
    }
    return null; // handled by CountdownTimer in the main row`,
    replace:
      `    if (thread.next_followup.status === "pending_approval") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "var(--accent)" }}>
          <Eye className="h-3 w-3" /> Awaiting approval
        </span>
      );
    }
    // B7p: drafted rows surface here instead of as a countdown. In
    // draft_in_gmail mode this is the normal "waiting for the user to
    // manually click Send in Gmail" state. The StallPill on the right
    // still escalates after 14/21/28 days.
    if (thread.next_followup.status === "drafted") {
      return (
        <span className="text-[12px] font-medium flex items-center gap-1" style={{ color: "rgb(255,140,0)" }}>
          <Mail className="h-3 w-3" /> Draft ready in Gmail — F{thread.next_followup.stage}
        </span>
      );
    }
    return null; // handled by CountdownTimer in the main row`,
  },
];

// =============================================================
// Edit 5: dashboard accounts.tsx — restore Max follow-ups UI
//   - add state below sendHourEnd
//   - render input + unlimited toggle before Send window section
//   - include maxFollowups in save body
// =============================================================
const ACCOUNTS_EDITS = [
  {
    name: "accounts: add maxFollowups state",
    marker: "B7p: maxFollowups UI restored",
    search:
      `  const [sendHourEnd, setSendHourEnd] = useState<number>(account.sendHourEnd ?? 18);`,
    replace:
      `  const [sendHourEnd, setSendHourEnd] = useState<number>(account.sendHourEnd ?? 18);
  // B7p: maxFollowups UI restored. The backend convention is that 0
  // (or any non-positive integer) means unlimited, anything > 0 is the cap.
  // We split that into two pieces of state so the input stays editable
  // even while the Unlimited checkbox is on (we just clamp on save).
  const initialMaxFollowups =
    typeof account.maxFollowups === "number" && account.maxFollowups > 0
      ? account.maxFollowups
      : 3;
  const initialUnlimited = account.maxFollowups === 0;
  const [maxFollowups, setMaxFollowups] = useState<number>(initialMaxFollowups);
  const [unlimitedFollowups, setUnlimitedFollowups] = useState<boolean>(initialUnlimited);`,
  },
  {
    name: "accounts: include maxFollowups in save body",
    marker: "// B7p: maxFollowups in save body",
    search:
      `        weeklyDigestEnabled,
      };`,
    replace:
      `        weeklyDigestEnabled,
        // B7p: maxFollowups in save body. 0 = unlimited per backend convention.
        maxFollowups: unlimitedFollowups ? 0 : maxFollowups,
      };`,
  },
  {
    name: "accounts: render Maximum follow-ups section before Send window",
    marker: "B7p: Maximum follow-ups per prospect section",
    search:
      `              {/* Send window — shared across modes */}`,
    replace:
      `              {/* B7p: Maximum follow-ups per prospect section */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Maximum follow-ups per prospect
                </label>
                <div className="flex items-center gap-3">
                  <Input
                    type="number"
                    min={1}
                    max={100}
                    value={maxFollowups}
                    onChange={(e) => setMaxFollowups(parseInt(e.target.value) || 1)}
                    disabled={unlimitedFollowups}
                    className="w-24"
                  />
                  <label className="flex items-center gap-2 text-[12px] cursor-pointer" style={{ color: "var(--text-secondary)" }}>
                    <input
                      type="checkbox"
                      checked={unlimitedFollowups}
                      onChange={(e) => setUnlimitedFollowups(e.target.checked)}
                    />
                    Unlimited
                  </label>
                </div>
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>
                  Cap on how many follow-up stages each prospect can receive. Unlimited keeps the cadence going until the prospect replies or you pause.
                </p>
              </div>

              {/* Send window — shared across modes */}`,
  },
];

async function main() {
  console.log("B7p: patching dashboard + api-server source files\n");

  console.log("[1/5] api-server/src/routes/doctrine.ts");
  await patchFile("artifacts/api-server/src/routes/doctrine.ts", DOCTRINE_EDITS);
  console.log();

  console.log("[2/5] api-server/src/routes/context.ts");
  await patchFile("artifacts/api-server/src/routes/context.ts", CONTEXT_EDITS);
  console.log();

  console.log("[3/5] dashboard/src/pages/pipeline.tsx");
  await patchFile("artifacts/dashboard/src/pages/pipeline.tsx", PIPELINE_EDITS);
  console.log();

  console.log("[4/5] dashboard/src/pages/context-pipeline.tsx");
  await patchFile("artifacts/dashboard/src/pages/context-pipeline.tsx", CONTEXT_PIPELINE_EDITS);
  console.log();

  console.log("[5/5] dashboard/src/pages/accounts.tsx");
  await patchFile("artifacts/dashboard/src/pages/accounts.tsx", ACCOUNTS_EDITS);
  console.log();

  console.log("B7p applied. Next: build api-server + dashboard, then deploy to production.");
}

main().catch((err) => {
  console.error("\nB7p apply failed:", err.message);
  console.error("\nNo partial writes happened for the failing file — the script aborts before any write when a search string is missing or ambiguous.");
  process.exit(1);
});
