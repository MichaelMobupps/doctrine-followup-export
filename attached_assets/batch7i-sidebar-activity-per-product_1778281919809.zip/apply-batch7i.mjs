#!/usr/bin/env node
/**
 * apply-batch7i.mjs — Phase 7i (sidebar activity per-product).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Two concerns:
 *
 *   1. Backend: add /api/context/my/activity to routes/context.ts.
 *      Mirrors the doctrine /my/activity handler (same response
 *      shape: last_sync, queued, next_due) but gated on app='context'.
 *
 *   2. Frontend: layout.tsx polls /api/my/activity for the sidebar's
 *      "AUTO-DETECTING / All caught up" indicator. On /context/*
 *      pages it should poll /api/context/my/activity instead. Switch
 *      the URL based on `onContext` (already computed in layout.tsx).
 *      Add `onContext` to the effect's deps so the poll re-fires
 *      immediately when the user switches products (instead of
 *      waiting up to 30 seconds for the next interval tick).
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src DASH_BASE=artifacts/dashboard/src \
 *     node apply-batch7i.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const log  = (msg) => console.log(`[apply-batch7i] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7i] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const contextRoutePath = join(API_BASE, "routes", "context.ts");
const layoutPath       = join(DASH_BASE, "components", "layout.tsx");

// ============================================================
// Step 1: Add /context/my/activity endpoint to context.ts
// ============================================================
log("Step 1: Add /context/my/activity endpoint...");

// Anchor: insert just before the /campaign/status block (the same
// anchor 7g used). This keeps endpoint ordering sensible.
strReplace(
  contextRoutePath,
  `// Phase 7g: Context Email Inspector backend. Returns sent emails from`,
  `// Phase 7i: per-product sidebar activity. Mirrors /api/my/activity
// (in routes/doctrine.ts) but gates on app='context'. Same response
// shape (last_sync, queued, next_due) so the dashboard sidebar
// indicator can switch URLs based on which product is active.
router.get("/my/activity", async (req: Request, res: Response) => {
  const userId = req.query.userId ? parseInt(req.query.userId as string) : null;
  if (!userId) { res.json({ last_sync: null, queued: 0, next_due: null }); return; }

  try {
    const latestProspect = await db
      .select({ createdAt: prospectsTable.createdAt })
      .from(prospectsTable)
      .where(and(SCOPE, eq(prospectsTable.userId, userId)))
      .orderBy(desc(prospectsTable.createdAt))
      .limit(1);

    const queuedCount = await db
      .select({ count: sql<number>\`count(*)\` })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        SCOPE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ));

    const nextDue = await db
      .select({ scheduledAt: followupsTable.scheduledAt })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        SCOPE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ))
      .orderBy(asc(followupsTable.scheduledAt))
      .limit(1);

    res.json({
      last_sync: latestProspect[0]?.createdAt?.toISOString() || null,
      queued: Number(queuedCount[0]?.count) || 0,
      next_due: nextDue[0]?.scheduledAt?.toISOString() || null,
    });
  } catch (err) {
    res.json({ last_sync: null, queued: 0, next_due: null });
  }
});

// Phase 7g: Context Email Inspector backend. Returns sent emails from`,
  "context.ts: add /my/activity endpoint",
  `// Phase 7i: per-product sidebar activity. Mirrors /api/my/activity`
);

// ============================================================
// Step 2: layout.tsx — switch URL on onContext + add to deps
// ============================================================
log("Step 2: layout.tsx — product-aware activity URL...");

strReplace(
  layoutPath,
  `  // Poll activity status every 30s
  useEffect(() => {
    if (!apiKey || !currentUser?.userId) return;
    const fetchActivity = async () => {
      try {
        const base = import.meta.env.BASE_URL || "/";
        const res = await fetch(\`\${base}api/my/activity?userId=\${currentUser.userId}\`, {
          headers: { "x-api-key": apiKey },
        });
        if (res.ok) setActivity(await res.json());
      } catch {}
    };
    fetchActivity();
    const interval = setInterval(fetchActivity, 30000);
    return () => clearInterval(interval);
  }, [apiKey, currentUser?.userId]);`,
  `  // Poll activity status every 30s.
  // Phase 7i: URL switches based on onContext so the sidebar indicator
  // shows the right product's queue numbers. \`onContext\` is in the
  // deps so the effect re-fires immediately on product switch (instead
  // of waiting up to 30s for the next interval tick).
  useEffect(() => {
    if (!apiKey || !currentUser?.userId) return;
    const activityPath = onContext ? "api/context/my/activity" : "api/my/activity";
    const fetchActivity = async () => {
      try {
        const base = import.meta.env.BASE_URL || "/";
        const res = await fetch(\`\${base}\${activityPath}?userId=\${currentUser.userId}\`, {
          headers: { "x-api-key": apiKey },
        });
        if (res.ok) setActivity(await res.json());
      } catch {}
    };
    fetchActivity();
    const interval = setInterval(fetchActivity, 30000);
    return () => clearInterval(interval);
  }, [apiKey, currentUser?.userId, onContext]);`,
  "layout.tsx: product-aware activity polling",
  `// Phase 7i: URL switches based on onContext so the sidebar indicator`
);

// ============================================================
// Step 3: Self-verify
// ============================================================
log("Step 3: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Backend
expectInFile(contextRoutePath, `// Phase 7i: per-product sidebar activity.`, "V1 context.ts /my/activity comment");
expectInFile(contextRoutePath, `router.get("/my/activity"`, "V2 /my/activity route declared");
expectInFile(contextRoutePath, `.where(and(SCOPE, eq(prospectsTable.userId, userId)))`, "V3 /my/activity gated on SCOPE");
expectInFile(contextRoutePath, `last_sync: latestProspect[0]?.createdAt?.toISOString() || null,`, "V4 /my/activity response shape");

// Frontend
expectInFile(layoutPath, `// Phase 7i: URL switches based on onContext`, "V5 layout.tsx Phase 7i comment");
expectInFile(layoutPath, `const activityPath = onContext ? "api/context/my/activity" : "api/my/activity";`, "V6 product-aware path");
expectInFile(layoutPath, `}, [apiKey, currentUser?.userId, onContext]);`, "V7 onContext in deps");

// Things that MUST be absent (regression)
expectNotInFile(layoutPath, `\${base}api/my/activity?userId=`, "V8 hardcoded doctrine URL gone");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7i patch applied. Sidebar activity indicator now polls the");
log("right product's endpoint based on the current route. /context/* ->");
log("/api/context/my/activity, anything else -> /api/my/activity.");
log("================================================================");
