# Followuper v4 Round-3 — Volume calibration (validation only)

TypeScript port of Prospector's v4r3 calibration logic. Followuper does NOT
generate fresh volume numbers (that's the Prospector's job) — its role is to
VALIDATE volume claims carried forward into follow-up emails.

## What this fixes

Same three brittleness gaps as Prospector, but validation-only:
1. No live scale lookup (Followuper doesn't do its own web_search)
2. No funnel-depth awareness in follow-up validation
3. No market scale awareness in follow-up validation

## How it works

Same formula as Prospector:

```
floor = vertical_base × funnel_multiplier × market_multiplier × 0.5
```

Followuper's role: when generating a follow-up that references volume numbers
from the prior thread, the critic + lint validate them against the floor.

- **Critic (followupPrompts.ts)** criterion 14: tells the LLM to flag volume claims
  outside the plausibility band, with worked examples (Cars24, XP, Singapore).
- **Lint (doctrineLint.ts)** deterministic check: extracts volume claims from the
  body via regex (English "per day", PT "por dia", ES "al día", DE "pro Tag",
  RU "по дням") and validates against the floor.

## File inventory

```
followuper-nativeness-v4r3/
  README.md
  audit_v4r3.sh
  patches/apply_patches.py
  api-server/lib/volumeCalibration.ts            # 9 functions + 4 tables + extractor
  api-server/tests/test-volume-calibration-v4r3.ts  # 42 tests
```

## The 4 operations

1. NewFile `volumeCalibration.ts` (calibration module + body extractor)
2. NewFile `test-volume-calibration-v4r3.ts` (42 tests)
3. Patch `doctrineLint.ts` — emit deterministic VOLUME-MARKET-FLOOR check
4. Patch `followupPrompts.ts` — add criterion 14 (FUNNEL COHERENCE + MARKET SCALE FLOOR)

## Deploy (Doctrine Follow-up monorepo)

```bash
python3 /path/to/followuper-nativeness-v4r3/patches/apply_patches.py artifacts/

pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/dashboard run build

cd artifacts/api-server
pnpm exec tsx --test \
    tests/test-nativeness-v3.ts \
    tests/test-nativeness-v4.ts \
    tests/test-nativeness-v4-round2.ts \
    tests/test-volume-calibration-v4r3.ts \
    tests/test-doctrine-hardening.ts
# Expected: 230 tests pass (24 v3 + 46 v4 + 40 v4r2 + 42 v4r3 + 72 doctrine hardening + 6 misc)
```

## Rollback

```bash
cd artifacts/api-server
for f in lib/doctrineLint services/followupPrompts; do
    cp ${f}.ts.v4r3_backup ${f}.ts && rm ${f}.ts.v4r3_backup
done
rm lib/volumeCalibration.ts tests/test-volume-calibration-v4r3.ts
```

## Godlike audit

```
PASS: 26 / FAIL: 0 / WARN: 0
Status: GO-FOR-SHIP
```

Empirical scenarios verified:
- Cars24 India ecommerce install 500/day → flagged below 2250 floor
- XP Brazil fintech first_deposit 500/day → plausible
- Singapore fintech first_deposit 500/day → flagged
- Cars24 body extractor catches "500+ qualified installs per day" → 500
- Multi-lingual extractors verified (EN/PT/ES/DE/RU/IT)
- nativenessV3 / nativenessV4 / languageNativeness byte-identical
- Rollback restores byte-identical
