#!/usr/bin/env node
/**
 * migrate-batch4.mjs — Phase 4 (weekly digest) DB migration.
 *
 * Idempotent. Transactional. Re-runs are no-ops.
 *
 * Adds two columns to `users`:
 *   - weekly_digest_enabled boolean NOT NULL DEFAULT false
 *   - last_weekly_digest_at timestamp with time zone (nullable)
 *
 * Seeds existing users:
 *   - review_in_app and draft_in_gmail users → weekly_digest_enabled = TRUE
 *     (they explicitly opted into a non-auto-send mode and will benefit
 *      from the recap)
 *   - auto_send users → keep DEFAULT FALSE (matches Phase 4 spec)
 *
 * The seed UPDATE only runs if the column was just added by this script.
 * If the column already exists from a prior run, the seed is skipped so
 * users who explicitly opted out never get re-flipped to TRUE.
 *
 * MUST be run from inside a Node ESM scope where `pg` is resolvable —
 * place the script under lib/db/ before invoking, OR set the script
 * path explicitly. (See README.md.)
 *
 * Usage:
 *   DATABASE_URL=postgres://... node migrate-batch4.mjs
 */

import pg from "pg";

const { Client } = pg;

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("ERROR: DATABASE_URL is not set.");
  process.exit(1);
}

async function columnExists(client, table, column) {
  const res = await client.query(
    `SELECT 1 FROM information_schema.columns
       WHERE table_name = $1 AND column_name = $2 LIMIT 1`,
    [table, column],
  );
  return res.rowCount > 0;
}

async function run() {
  const client = new Client({ connectionString: DATABASE_URL });
  await client.connect();

  let didAddEnabled = false;
  let didAddLastSent = false;

  try {
    await client.query("BEGIN");

    // ---- Step 1: weekly_digest_enabled column ---------------------------
    const hadEnabledBefore = await columnExists(client, "users", "weekly_digest_enabled");
    if (!hadEnabledBefore) {
      await client.query(`
        ALTER TABLE users
        ADD COLUMN weekly_digest_enabled boolean NOT NULL DEFAULT false
      `);
      didAddEnabled = true;
      console.log("[+] Added users.weekly_digest_enabled (default FALSE).");
    } else {
      console.log("[=] users.weekly_digest_enabled already exists; skipping ADD.");
    }

    // ---- Step 2: last_weekly_digest_at column ---------------------------
    const hadLastSentBefore = await columnExists(client, "users", "last_weekly_digest_at");
    if (!hadLastSentBefore) {
      await client.query(`
        ALTER TABLE users
        ADD COLUMN last_weekly_digest_at timestamp with time zone
      `);
      didAddLastSent = true;
      console.log("[+] Added users.last_weekly_digest_at (nullable).");
    } else {
      console.log("[=] users.last_weekly_digest_at already exists; skipping ADD.");
    }

    // ---- Step 3: Seed existing users (only if column was just added) -----
    if (didAddEnabled) {
      const seedResult = await client.query(`
        UPDATE users
        SET weekly_digest_enabled = TRUE
        WHERE followup_mode IN ('review_in_app', 'draft_in_gmail')
      `);
      console.log(`[+] Seeded ${seedResult.rowCount} review_in_app/draft_in_gmail users to weekly_digest_enabled=TRUE.`);
    } else {
      console.log("[=] Seed step skipped (column existed before this run).");
    }

    await client.query("COMMIT");
    console.log("[OK] Transaction committed.");

    // ---- Verification report --------------------------------------------
    const verify = await client.query(`
      SELECT
        followup_mode,
        weekly_digest_enabled,
        COUNT(*)::int AS cnt
      FROM users
      GROUP BY followup_mode, weekly_digest_enabled
      ORDER BY followup_mode, weekly_digest_enabled DESC
    `);

    console.log("\n--- Per-mode digest opt-in distribution ---");
    if (verify.rows.length === 0) {
      console.log("  (no users in table yet)");
    } else {
      for (const row of verify.rows) {
        console.log(`  ${row.followup_mode.padEnd(16)} digest=${String(row.weekly_digest_enabled).padEnd(5)} → ${row.cnt} users`);
      }
    }

    const colCheck = await client.query(`
      SELECT column_name, data_type, is_nullable, column_default
      FROM information_schema.columns
      WHERE table_name = 'users'
        AND column_name IN ('weekly_digest_enabled', 'last_weekly_digest_at')
      ORDER BY column_name
    `);
    console.log("\n--- Column verification ---");
    for (const row of colCheck.rows) {
      console.log(`  ${row.column_name.padEnd(28)} ${row.data_type.padEnd(28)} nullable=${row.is_nullable.padEnd(3)} default=${row.column_default || "(none)"}`);
    }

    console.log("\n[DONE] Batch 4 migration complete.");
  } catch (err) {
    await client.query("ROLLBACK").catch(() => {});
    console.error("[FAIL] Migration error; transaction rolled back.");
    console.error(err);
    process.exitCode = 1;
  } finally {
    await client.end();
  }
}

run();
