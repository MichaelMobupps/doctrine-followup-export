// ============================================================================
// v4 Round-2 (Universal native-style detectors)
// ============================================================================
// Three new detectors that catch failure modes Denise (BR PT native reviewer)
// flagged but that apply to every language the v4 layer covers:
//   - REPEATING-DISCOURSE-MARKER  (sentence-starter reuse, 26 languages)
//   - SEMICOLON-NO-CONNECTOR      (clause coherence, 17 languages)
//   - NON-REFLEXIVE-ROMANCE-VERB  (reflexive verb preference, 4 Romance langs)
// TypeScript port of prospector/stages/nativeness_v4.py v4 Round-2 work —
// behavior parity with the Python detectors verified by shared test fixtures.

export const REPEATING_DISCOURSE_MARKERS: Record<string, readonly string[]> = {
  en: ["worth mentioning", "worth noting", "i should add", "i'd note that",
       "notably", "importantly", "it's worth"],
  pt: ["vale mencionar", "vale destacar", "vale notar", "vale ressaltar",
       "é importante destacar", "é importante mencionar", "cabe destacar",
       "cabe mencionar", "convém destacar"],
  "pt-BR": ["vale mencionar", "vale destacar", "vale notar", "vale ressaltar",
            "é importante destacar", "é importante mencionar", "cabe destacar",
            "cabe mencionar", "convém destacar"],
  es: ["vale la pena mencionar", "vale la pena destacar", "cabe destacar",
       "cabe mencionar", "es importante notar", "es importante destacar",
       "conviene señalar", "conviene destacar"],
  fr: ["il convient de mentionner", "il convient de noter", "à noter",
       "à signaler", "notons que", "il est important de souligner",
       "il faut souligner", "il faut mentionner"],
  de: ["erwähnenswert ist", "bemerkenswert ist", "hervorzuheben ist",
       "es ist anzumerken", "es sei erwähnt", "anzumerken ist"],
  it: ["vale la pena menzionare", "vale la pena notare", "è importante notare",
       "è importante sottolineare", "da notare che", "merita menzionare",
       "occorre sottolineare"],
  nl: ["het is vermeldenswaard", "vermeldenswaard is", "opmerkelijk is",
       "noemenswaard is"],
  ja: ["なお", "ちなみに", "ご参考までに", "申し添えますと"],
  zh: ["值得一提的是", "顺便提一下", "另外值得注意的是", "值得注意的是"],
  ko: ["참고로", "덧붙여 말하면", "참고하시면", "한 가지 더 말씀드리면"],
  ar: ["تجدر الإشارة", "من الجدير بالذكر", "والجدير بالذكر", "تجدر الاشارة"],
  he: ["ראוי לציין", "כדאי להזכיר", "יש לציין", "חשוב לציין"],
  ru: ["стоит отметить", "важно упомянуть", "следует подчеркнуть",
       "стоит подчеркнуть", "необходимо отметить"],
  uk: ["варто зазначити", "слід підкреслити", "важливо зазначити",
       "необхідно відзначити"],
  tr: ["belirtmek gerekir ki", "şunu da belirtmek isterim",
       "şunu da eklemek isterim", "vurgulamak gerekir ki"],
  hi: ["बता दें कि", "ध्यान देने योग्य है", "गौरतलब है कि", "उल्लेखनीय है कि"],
  pl: ["warto wspomnieć", "warto zauważyć", "warto podkreślić", "należy zaznaczyć"],
  cs: ["stojí za zmínku", "je třeba poznamenat", "za zmínku stojí"],
  hu: ["érdemes megemlíteni", "fontos megjegyezni", "ki kell emelni"],
  ro: ["merită menționat", "trebuie subliniat", "este important de menționat"],
  sv: ["värt att nämna", "värt att notera", "det är värt att"],
  no: ["verdt å nevne", "verdt å merke seg", "det er verdt å"],
  nb: ["verdt å nevne", "verdt å merke seg", "det er verdt å"],
  da: ["værd at nævne", "værd at bemærke", "det er værd at"],
  fi: ["on syytä mainita", "on syytä huomata", "kannattaa mainita"],
};

export interface RepeatingMarkerHit {
  marker: string;
  count: number;
}

export function findRepeatingDiscourseMarkers(
  text: string,
  lang: string
): RepeatingMarkerHit[] {
  if (!text) return [];
  const langStr = (lang || "").trim().toLowerCase();
  let markers = REPEATING_DISCOURSE_MARKERS[langStr];
  if (!markers) {
    const base = langStr.includes("-") ? langStr.split("-")[0] : langStr;
    markers = REPEATING_DISCOURSE_MARKERS[base];
  }
  if (!markers || markers.length === 0) return [];

  const lower = text.toLowerCase();
  const hits: RepeatingMarkerHit[] = [];
  for (const marker of markers) {
    const m = marker.toLowerCase();
    // Count all occurrences
    let count = 0;
    let idx = lower.indexOf(m);
    while (idx !== -1) {
      count += 1;
      idx = lower.indexOf(m, idx + m.length);
    }
    if (count >= 2) {
      hits.push({ marker, count });
    }
  }
  return hits;
}


export const SEMICOLON_CONNECTORS: Record<string, readonly string[]> = {
  en: ["therefore", "thus", "hence", "consequently", "as", "accordingly",
       "moreover", "however", "still", "also", "indeed", "furthermore",
       "in addition", "in fact", "in contrast", "in particular", "nonetheless"],
  pt: ["logo", "portanto", "dessa forma", "assim", "por isso", "em vista disso",
       "ademais", "ou seja", "no entanto", "contudo", "além disso",
       "consequentemente", "diante disso"],
  "pt-BR": ["logo", "portanto", "dessa forma", "assim", "por isso", "em vista disso",
            "ademais", "ou seja", "no entanto", "contudo", "além disso",
            "consequentemente", "diante disso"],
  es: ["por lo tanto", "por consiguiente", "así pues", "en consecuencia",
       "de ahí que", "asimismo", "no obstante", "sin embargo", "además",
       "es decir", "por ende"],
  fr: ["ainsi", "par conséquent", "de ce fait", "aussi", "dès lors",
       "néanmoins", "toutefois", "en outre", "cependant", "c'est-à-dire",
       "à savoir"],
  de: ["daher", "folglich", "somit", "demnach", "infolgedessen", "dennoch",
       "jedoch", "außerdem", "zudem", "das heißt", "darüber hinaus"],
  it: ["pertanto", "quindi", "di conseguenza", "per cui", "ne consegue che",
       "tuttavia", "inoltre", "ovvero", "in altre parole", "cioè"],
  nl: ["daarom", "bijgevolg", "vandaar", "aldus", "echter", "bovendien",
       "dat wil zeggen", "namelijk"],
  ru: ["следовательно", "поэтому", "таким образом", "однако", "тем не менее",
       "то есть", "кроме того", "более того"],
  uk: ["отже", "тому", "таким чином", "однак", "проте", "крім того"],
  pl: ["zatem", "dlatego", "w związku z tym", "jednak", "ponadto", "czyli"],
  cs: ["proto", "tudíž", "tedy", "nicméně", "navíc", "totiž"],
  hu: ["ezért", "tehát", "így", "azonban", "továbbá", "vagyis"],
  ro: ["prin urmare", "așadar", "astfel", "totuși", "în plus", "adică"],
  sv: ["därför", "således", "alltså", "dock", "dessutom"],
  no: ["derfor", "således", "altså", "imidlertid", "dessuten"],
  nb: ["derfor", "således", "altså", "imidlertid", "dessuten"],
  da: ["derfor", "således", "altså", "imidlertid", "desuden"],
  fi: ["siksi", "näin ollen", "kuitenkin", "lisäksi", "toisin sanoen"],
};

// Languages where semicolons are uncommon in native business prose;
// detector skips them to avoid false positives.
export const SEMICOLON_DETECTOR_SKIP_LANGS: ReadonlySet<string> = new Set([
  "ja", "zh", "ko", "th", "ar", "he", "fa", "ur", "hi", "bn", "ta",
  "te", "mr", "vi", "id", "ms", "fil", "tl", "sw", "am", "ka", "el",
  "tr",
]);

export interface SemicolonHit {
  position: number;
  followedBy: string;
  suggestions: readonly string[];
}

function _escapeRegex(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function findSemicolonWithoutConnector(
  text: string,
  lang: string
): SemicolonHit[] {
  if (!text || !text.includes(";")) return [];
  const langStr = (lang || "").trim().toLowerCase();
  const base = langStr.includes("-") ? langStr.split("-")[0] : langStr;
  if (SEMICOLON_DETECTOR_SKIP_LANGS.has(langStr) ||
      SEMICOLON_DETECTOR_SKIP_LANGS.has(base)) {
    return [];
  }

  let connectors = SEMICOLON_CONNECTORS[langStr];
  if (!connectors) connectors = SEMICOLON_CONNECTORS[base];
  if (!connectors || connectors.length === 0) return [];

  // Sort longest-first so multi-word connectors match before single-word
  const connectorsSorted = [...connectors].sort((a, b) => b.length - a.length);
  const connectorRe = new RegExp(
    "^(?:" + connectorsSorted.map(_escapeRegex).join("|") + ")",
    "i"
  );

  const hits: SemicolonHit[] = [];
  // Match `;` then capture the immediately following word(s).
  // Uses /g flag for repeated matches.
  const semiRe = /;\s*([^\s;]+(?:\s+[^\s;]+)?)/g;
  let m: RegExpExecArray | null;
  while ((m = semiRe.exec(text)) !== null) {
    // Skip if newline appears between `;` and the next word — that's a list
    // terminator or sentence break, not a clause joiner. Common in PT/ES/IT
    // bullet-list business style.
    const semiEnd = m.index + 1;
    const wordStart = m.index + m[0].length - m[1].length;
    const between = text.slice(semiEnd, wordStart);
    if (between.includes("\n")) continue;

    const following = m[1].replace(/[,.;:!?]+$/, "");
    // Check if the post-semicolon text starts with any connector
    const postSemi = text.slice(semiEnd).replace(/^\s+/, "");
    if (!connectorRe.test(postSemi)) {
      hits.push({
        position: m.index,
        followedBy: following.slice(0, 30),
        suggestions: connectors.slice(0, 5),
      });
    }
  }
  return hits;
}


export interface NonReflexiveVerbPair {
  readonly bare: string;
  readonly reflexive: string;
}

export const NON_REFLEXIVE_VERBS: Record<string, readonly NonReflexiveVerbPair[]> = {
  pt: [
    { bare: "encaixa", reflexive: "se encaixa" },
    { bare: "aplica", reflexive: "se aplica" },
    { bare: "adequa", reflexive: "se adequa" },
    { bare: "ajusta", reflexive: "se ajusta" },
    { bare: "alinha", reflexive: "se alinha" },
    { bare: "integra", reflexive: "se integra" },
    { bare: "adapta", reflexive: "se adapta" },
    { bare: "aplicam", reflexive: "se aplicam" },
    { bare: "encaixam", reflexive: "se encaixam" },
    { bare: "ajustam", reflexive: "se ajustam" },
  ],
  "pt-BR": [
    { bare: "encaixa", reflexive: "se encaixa" },
    { bare: "aplica", reflexive: "se aplica" },
    { bare: "adequa", reflexive: "se adequa" },
    { bare: "ajusta", reflexive: "se ajusta" },
    { bare: "alinha", reflexive: "se alinha" },
    { bare: "integra", reflexive: "se integra" },
    { bare: "adapta", reflexive: "se adapta" },
    { bare: "aplicam", reflexive: "se aplicam" },
    { bare: "encaixam", reflexive: "se encaixam" },
    { bare: "ajustam", reflexive: "se ajustam" },
  ],
  es: [
    { bare: "encaja", reflexive: "se encaja" },
    { bare: "aplica", reflexive: "se aplica" },
    { bare: "ajusta", reflexive: "se ajusta" },
    { bare: "adapta", reflexive: "se adapta" },
    { bare: "alinea", reflexive: "se alinea" },
    { bare: "integra", reflexive: "se integra" },
    { bare: "encajan", reflexive: "se encajan" },
    { bare: "aplican", reflexive: "se aplican" },
  ],
  fr: [
    { bare: "applique", reflexive: "s'applique" },
    { bare: "ajuste", reflexive: "s'ajuste" },
    { bare: "adapte", reflexive: "s'adapte" },
    { bare: "intègre", reflexive: "s'intègre" },
    { bare: "aligne", reflexive: "s'aligne" },
    { bare: "appliquent", reflexive: "s'appliquent" },
  ],
  it: [
    { bare: "applica", reflexive: "si applica" },
    { bare: "adatta", reflexive: "si adatta" },
    { bare: "integra", reflexive: "si integra" },
    { bare: "allinea", reflexive: "si allinea" },
    { bare: "inserisce", reflexive: "si inserisce" },
    { bare: "applicano", reflexive: "si applicano" },
  ],
};

const REFLEXIVE_PRONOUNS: Record<string, readonly string[]> = {
  pt: ["se", "me", "te", "nos", "vos"],
  "pt-BR": ["se", "me", "te", "nos", "vos"],
  es: ["se", "me", "te", "nos", "os"],
  fr: ["s'", "se", "me", "te", "nous", "vous", "m'", "t'"],
  it: ["si", "mi", "ti", "ci", "vi"],
};

export interface NonReflexiveHit {
  verb: string;
  expected: string;
  context: string;
}

export function findNonReflexiveRomanceVerbs(
  text: string,
  lang: string
): NonReflexiveHit[] {
  if (!text) return [];
  const langStr = (lang || "").trim().toLowerCase();
  const base = langStr.includes("-") ? langStr.split("-")[0] : langStr;

  let verbs = NON_REFLEXIVE_VERBS[langStr];
  if (!verbs) verbs = NON_REFLEXIVE_VERBS[base];
  if (!verbs || verbs.length === 0) return [];

  const pronouns = REFLEXIVE_PRONOUNS[langStr] || REFLEXIVE_PRONOUNS[base] || [];
  const pronounsSet = new Set(pronouns.map(p => p.toLowerCase()));

  const hits: NonReflexiveHit[] = [];
  for (const { bare, reflexive } of verbs) {
    // Word-boundary match, case-insensitive
    const re = new RegExp("\\b" + _escapeRegex(bare) + "\\b", "gi");
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      const start = m.index;
      // Look at the 2 preceding tokens
      const prefix = text.slice(Math.max(0, start - 30), start);
      const tokenMatches = prefix.toLowerCase().match(/\b\w+'?\b|\bs'/g) || [];
      const recent = tokenMatches.slice(-2);
      // Skip if any reflexive pronoun is in the recent tokens
      if (recent.some(t => pronounsSet.has(t))) continue;
      // Skip if verb is at sentence start (after newline) or text start
      if (start === 0 || text[start - 1] === "\n") continue;
      const context = text.slice(
        Math.max(0, start - 25),
        Math.min(text.length, start + bare.length + 15)
      );
      hits.push({
        verb: bare,
        expected: reflexive,
        context: context.trim(),
      });
    }
  }
  return hits;
}
