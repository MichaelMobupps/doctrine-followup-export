#!/usr/bin/env python3
"""
B9b.8 patcher — applies the AntiGhosting Pipeline frontend.

Steps:
  1. Copies anti-ghosting-pipeline.tsx into artifacts/dashboard/src/pages/.
  2. Patches App.tsx:
     - Adds an import for AntiGhostingPipeline after the existing
       AntiGhosting import.
     - Adds a <Route path="/anti-ghosting/pipeline"> entry after the
       existing /anti-ghosting route.

Idempotent: re-running on a patched tree prints "skipped" for each step.
Aborts loudly on missing anchors rather than guessing.
"""

from __future__ import annotations

import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # b9b8_work/
WORKSPACE = Path.cwd()                          # ~/workspace when run there

SOURCE_TSX = ROOT / "frontend" / "anti-ghosting-pipeline.tsx"
DEST_TSX = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-pipeline.tsx"
APP_TSX = WORKSPACE / "artifacts/dashboard/src/App.tsx"

# Anchors and the lines we insert immediately after each one.
IMPORT_ANCHOR = 'import AntiGhosting from "@/pages/anti-ghosting";'
IMPORT_INSERT = (
    '// B9b.8: AntiGhosting Pipeline page (view-only listing of the\n'
    '// anti_ghosting prospects in flight; actions ship in later batches).\n'
    'import AntiGhostingPipeline from "@/pages/anti-ghosting-pipeline";'
)

ROUTE_ANCHOR = '<Route path="/anti-ghosting" component={AntiGhosting} />'
ROUTE_INSERT = (
    '      {/* B9b.8: AntiGhosting Pipeline route. */}\n'
    '      <Route path="/anti-ghosting/pipeline" component={AntiGhostingPipeline} />'
)


def fail(msg: str) -> "None":
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def info(msg: str) -> "None":
    print(f"[ok]   {msg}")


def skip(msg: str) -> "None":
    print(f"[skip] {msg}")


def insert_after_anchor(text: str, anchor: str, insert: str, label: str) -> tuple[str, bool]:
    """Insert `insert` on the line(s) right after the line containing `anchor`.

    Returns (new_text, changed). Idempotent: if `insert` already appears
    somewhere in the file, returns the file unchanged.
    """
    if insert.strip() in text:
        skip(f"{label} already present")
        return text, False

    lines = text.split("\n")
    found_at = None
    for i, line in enumerate(lines):
        if anchor in line:
            found_at = i
            break

    if found_at is None:
        fail(f"{label}: anchor not found in App.tsx: {anchor!r}")

    # Insert after the anchor line. Preserve original indentation pattern
    # by trusting the insert to carry its own.
    new_lines = lines[: found_at + 1] + insert.split("\n") + lines[found_at + 1 :]
    info(f"{label}: inserted after line {found_at + 1}")
    return "\n".join(new_lines), True


def main() -> "None":
    # --- 1. Copy the new tsx into place ---
    if not SOURCE_TSX.exists():
        fail(f"missing bundled source: {SOURCE_TSX}")

    if not DEST_TSX.parent.exists():
        fail(f"dashboard pages dir does not exist: {DEST_TSX.parent}")

    if DEST_TSX.exists():
        existing = DEST_TSX.read_text(encoding="utf-8")
        incoming = SOURCE_TSX.read_text(encoding="utf-8")
        if existing == incoming:
            skip(f"{DEST_TSX.relative_to(WORKSPACE)} already matches")
        else:
            shutil.copy2(SOURCE_TSX, DEST_TSX)
            info(f"overwrote {DEST_TSX.relative_to(WORKSPACE)}")
    else:
        shutil.copy2(SOURCE_TSX, DEST_TSX)
        info(f"created {DEST_TSX.relative_to(WORKSPACE)}")

    # --- 2. Patch App.tsx ---
    if not APP_TSX.exists():
        fail(f"App.tsx not found: {APP_TSX}")

    original = APP_TSX.read_text(encoding="utf-8")
    text = original

    text, _ = insert_after_anchor(text, IMPORT_ANCHOR, IMPORT_INSERT, "App.tsx import")
    text, _ = insert_after_anchor(text, ROUTE_ANCHOR, ROUTE_INSERT, "App.tsx route")

    if text != original:
        APP_TSX.write_text(text, encoding="utf-8")
        info("wrote App.tsx")
    else:
        skip("App.tsx already patched")

    print()
    print("B9b.8 frontend applied. Next steps:")
    print("  1. cd artifacts/dashboard && pnpm run build")
    print("  2. Restart the dashboard workflow")
    print("  3. Navigate to https://doctrine-followupv-2.replit.app/anti-ghosting/pipeline")
    print("  4. Expect 'Failed to load follow-ups' until the backend endpoint ships.")
    print("     The page rendering + URL routing is what this batch validates.")


if __name__ == "__main__":
    main()
