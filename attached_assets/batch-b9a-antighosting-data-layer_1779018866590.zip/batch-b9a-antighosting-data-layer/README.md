# Batch B9a — AntiGhosting Followuper, Data Layer

**Scope.** Foundation only. After this ship the AntiGhosting Followuper has its schema, runtime migrations, label-config column, and a thread-reader service capable of pulling Gmail thread history into a local mirror. No new behaviour is wired in — operators cannot yet mark threads, no follow-ups generate, no dashboard tab. Those land in B9b, B9c, B9d.

This is intentional. A data-layer-only ship can land safely without changing any user-visible flow.

## What changed

### Schema (`lib/db/src/schema/`)

- `prospects.ts`
  - `ProspectApp` union extends to `"doctrine" | "context" | "anti_ghosting"`
  - `PROSPECT_APPS` array includes the new value
  - New `PauseReason` type and `PAUSE_REASONS` array (`client_reply` | `manual_intervention` | `campaign_complete`)
  - Three new columns: `parentProspectId` (nullable self-ref), `cycle` (integer, default 1), `pauseReason` (nullable text)
  - Two new indexes: `idx_prospects_app_replied_paused` (dispatcher hot-path), `idx_prospects_parent` (renewal/analytics lookups)

- `followups.ts`
  - New `cycle` column (integer, default 1)
  - Unique constraint swapped from `(prospect_id, stage)` to `(prospect_id, cycle, stage)`

- `users.ts`
  - New `antiGhostingLabel` column with default `"AntiGhosting Followuper"`

- `thread-messages.ts` (new file)
  - Table holding normalised Gmail thread history
  - Columns: id, prospectId (FK), gmailMessageId (unique), gmailThreadId, direction (`inbound`/`outbound`), sentAt, fromEmail, subject, snippet, body, createdAt
  - Indexes on `(prospectId, sentAt)` and `gmailThreadId`

- `schema/index.ts` re-exports the new module

### Runtime migrations (`api-server/src/lib/startupMigrations.ts`)

Appended ~80 lines of idempotent SQL covering every schema delta above. All statements use `IF NOT EXISTS` on columns/tables/indexes and `DO $$ ... $$` blocks for constraints (Postgres does not accept `IF NOT EXISTS` on `ADD CONSTRAINT` directly). Re-running on every boot is a no-op after the first successful application.

### Services (`api-server/src/services/`)

- `gmailClient.ts` — at the end of file, six internal helpers are now re-exported as `*Helper` so other services can reuse them without duplication. No behaviour change: same function bodies, just newly-public.

- `threadReader.ts` (new file) — two public functions:
  - `getThreadMessages(prospectId)` returns every thread_messages row for a prospect, chronologically
  - `syncThreadFromGmail(prospectId, gmail, userEmail)` fetches the full Gmail thread and upserts each message
  - Two exported pure-function helpers (for testing): `classifyDirection(fromHeader, userEmail)` and `extractBodyText(payload)`

### Tests (`api-server/src/tests/`)

- `test-thread-reader-b9a.ts` — 15 unit tests covering direction classification (bare email, angle-brackets, case, empty header, empty user, substring edge case) and body extraction (text/plain, text/html, multipart alternative, nested multipart, missing data).
- Locally verified before bundling: **15 / 15 pass** (after stubbing `@workspace/db`, `googleapis`, `drizzle-orm`, and `../lib/logger` for standalone behavioural validation).

## Risk surface

1. **Schema additions are purely additive.** All new columns have defaults or are nullable. Existing rows are unaffected. Drizzle Kit push and the runtime migration agree.
2. **The unique-constraint swap on `followups` is the highest-risk operation.** The migration drops the old constraint and recreates the new one inside a single `DO $$ ... $$` block, both guarded by `pg_constraint` lookups so re-runs are no-ops. If the drop fails mid-block, Postgres rolls back the whole `DO` block. If the new constraint cannot be created (would only happen if real data already violates `(prospect_id, cycle, stage)` uniqueness — impossible since `cycle` defaults to 1 everywhere), the old constraint stays in place.
3. **`ProspectApp` widening exposes narrow-union sites downstream.** Files like `scheduler.ts:278`, `usageContext.ts:19`, `admin-activity.ts`, `admin-salvage.ts` currently type `app` as `"doctrine" | "context"`. With the widened union, anti_ghosting prospects would fall through to the doctrine branch. **This is harmless in B9a** because no anti_ghosting prospects exist yet. B9c will widen these unions when wiring the new generator.
4. **`threadReader.syncThreadFromGmail` is not yet called from anywhere.** It is dead code in B9a. B9b will call it from the marking-validation path; B9c will call it from the scheduler pre-flight.

## Layout

```
batch-b9a-antighosting-data-layer/
|-- README.md
|-- db/
|   `-- schema/
|       |-- prospects.ts        (replace)
|       |-- followups.ts        (replace)
|       |-- users.ts            (replace)
|       |-- thread-messages.ts  (new)
|       `-- index.ts            (replace)
`-- api-server/
    |-- lib/
    |   `-- startupMigrations.ts  (replace)
    |-- services/
    |   |-- gmailClient.ts        (replace; only the trailing re-export block changes)
    |   `-- threadReader.ts       (new)
    `-- tests/
        `-- test-thread-reader-b9a.ts  (new)
```

Apply to `lib/db/src/schema/` for the `db/` block and to `artifacts/api-server/src/...` for the `api-server/` block. After the patches apply, the live source-code mirror is refreshed via `source-code/sync.sh` (Drizzle has no separate build step, so `@workspace/db` is consumed directly via its `exports` map at runtime).

The runtime migrations apply on the next workflow restart, so the bash block ends before the restart and `restart_workflow` is delivered as a separate instruction.
