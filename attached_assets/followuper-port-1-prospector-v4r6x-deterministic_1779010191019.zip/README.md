# followuper-port-1 — Port prospector v4r6x deterministic fixes to followuper

First phase of porting prospector v4r6 fixes to the Chat Followuper. This bundle ports the **zero-LLM-cost deterministic fixes** only; LLM-backed ports (Korean Haiku transliteration) and refactor-heavy ports (Russian greeting brand-prefix strip, which needs context threading) are deferred to later phases.

## Why this port

The prospector and followuper both generate multilingual outbound emails via a draft → critic → rewriter pipeline. They share the same multi-language nativeness layer and the same class of failure modes — but until now, three deterministic fixes that landed in the prospector during v4r6x had no analog in followuper.

Most prospector-v4r6 fixes do NOT apply to followuper (Apollo enrichment, soft-salvage, thinking budget calibration, int.strip() defensive coercion). Three do:

| Prospector patch | What it fixes | Followuper status pre-port |
|---|---|---|
| v4r6x Patch B (`restore_universal_tech_brands`) | Russian Андроид → Android, АйОС → iOS | Missing — over-transliteration risk in Russian follow-ups |
| v4r6x Patch 4a (BRAND ADAPTATION + Latin-keep list) | Writer prompt directive: keep iOS/Android/AppsFlyer/Adjust/etc. Latin in non-Latin emails | Missing — followuper had GREETING NAME SCRIPT but no BRAND ADAPTATION |
| v4r6u + v4r6v (brand localization maps) | Latin → native script for local-market brands (Кинопоиск etc.) | Out of scope for Phase 1 — defer to later (LLM-prompt half is included via the same BRAND ADAPTATION directive; deterministic per-language maps are not) |

## What this bundle ships

| Patch | File | Change |
|---|---|---|
| **1** | `api-server/services/followupGenerator.ts` | Add `UNIVERSAL_TECH_RESTORE` map + `restoreUniversalTechBrands()` helper. Call from `humanizeText()` as the first transform before any other humanize pass. Russian Андроид/АйОС → Android/iOS. |
| **2a** | `api-server/services/followupPrompts.ts` | Add BRAND ADAPTATION directive + explicit Latin-keep list (iOS, Android, Google, Apple, AppsFlyer, Adjust, etc.) to SYSTEM prompt, immediately after GREETING NAME SCRIPT |
| **2b** | `api-server/services/followupPrompts.ts` | Same BRAND ADAPTATION directive in REWRITER prompt (so the rule applies during critic→rewriter healing iterations too) |
| **T** | `api-server/tests/test-followuper-port-1.ts` | 18 tests: source structure (6) + functional regex behavior (5) + prompt directive (5) + prospector parity (2) |

3 in-place patches + 1 new test file. Idempotent. Backups suffixed `.followuper-p1_backup`.

## Architectural notes

**Why `restoreUniversalTechBrands` is unconditional (no language param)**: the source patterns (Cyrillic Андроид, Korean 안드로이드 if added later, Chinese 安卓 if added later) only exist in non-Latin scripts. A Latin-script body never contains them, so the map is a no-op there. Saves us threading the target language through `humanizeText`.

**Why we patch humanizeText, not humanizeFollowup**: humanizeText runs on both subject AND body via `humanizeFollowup`. Subjects can also have over-transliterations (a Russian subject mentioning "АйОС integration" should restore to "iOS integration"). Single point of insertion → both fields covered.

**Why BRAND ADAPTATION is inserted in BOTH system and rewriter prompts**: the followuper has a draft → critic → rewriter loop. The system prompt drives the initial draft; the rewriter prompt drives healing iterations. If the directive is only in the system prompt, the rewriter can override or lose track of it during healing. Both = consistent enforcement.

## Phase 1 explicit out-of-scope

| Item | Why deferred |
|---|---|
| Russian greeting brand-prefix strip (v4r6s + v4r6w) | Requires threading the prospect's brand + contact name through humanizeText. The prospector's `_personalize_greeting` post-hook has no analog in followuper (followuper writes per-contact directly with the name already substituted). Refactor scope too big for Phase 1. |
| Korean Haiku transliteration (v4r6x Patch A) | LLM-backed (~$0.001 per Korean follow-up). Different architecture: the prospector uses a Haiku pre-pass at brief-build time; the followuper needs a different hook point. Phase 2. |
| Brand localization Latin → Native maps (v4r6u + v4r6v) | Deterministic map of 58 brands across 6 languages. Worth porting only if we observe Latin brand leakage in follow-up production. The BRAND ADAPTATION directive (Patch 2) covers the prompt-level half; the deterministic map is the defense-in-depth half. Skip until observed. |
| `contextFollowupPrompts.ts` BRAND ADAPTATION | The CONTEXT_GENERATOR_SYSTEM produces minimal-content follow-ups ("any update?" style) and rarely introduces new brand mentions. Skip unless we see issues there. |
| `contextFollowupGenerator.ts` humanize step | Currently has no humanize sanitization step at all (returns raw `{subject, body}`). This is a separate gap from the v4r6x port — log as its own concern. |

## Audited in this session

| step | result |
|---|---|
| Apply — 3 in-place patches + 1 new test file | ✓ |
| TypeScript syntax check (`tsc --noEmit --noResolve`, isolated) — no syntax errors in new code | ✓ (only expected `TS2307` module-resolution errors for missing node_modules in sandbox) |
| Run via `tsx --test` — 18 tests across 4 suites | ✓ 18/18 |
| Source verification: BRAND ADAPTATION present in exactly 2 locations (system + rewriter prompts) | ✓ |
| Functional verification: `restoreUniversalTechBrands` correctly maps Russian Cyrillic over-transliterations to Latin + idempotent + no-op on Latin bodies | ✓ |
| Idempotency re-run: all 3 in-place patches SKIP "already up-to-date" | ✓ |
| File-size sanity check: followupGenerator.ts +35 lines (helper), followupPrompts.ts +2 lines (2 prompt insertions) | ✓ |

## Replit Agent ship command

```bash
set -euo pipefail
cd "$HOME/$REPL_SLUG"

echo "=== 1. Stage bundle ==="
unzip -o ~/followuper-port-1-prospector-v4r6x-deterministic.zip -d /tmp/followuper-p1
ls -la /tmp/followuper-p1

echo ""
echo "=== 2. Apply patches ==="
python3 /tmp/followuper-p1/apply_patches.py

echo ""
echo "=== 3. TypeScript syntax check (skipLibCheck, noEmit) ==="
# Run against the live api-server with its own tsconfig (resolves modules)
cd artifacts/api-server && pnpm exec tsc --noEmit 2>&1 | grep -v "^$" | head -30 || echo "  (tsc clean or only pre-existing warnings)"
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 4. Run followuper port-1 tests ==="
cd artifacts/api-server && pnpm exec tsx --test tests/test-followuper-port-1.ts
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 5. Run existing followuper test suite (regression — must still pass) ==="
cd artifacts/api-server && pnpm exec tsx --test tests/test-doctrine-hardening.ts tests/test-nativeness-v4.ts tests/test-discourse-autofix-v4r4.ts tests/test-volume-calibration-v4r3.ts 2>&1 | tail -15
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 6. Idempotency re-run ==="
python3 /tmp/followuper-p1/apply_patches.py

echo ""
echo "=== 7. Build (workspace pattern) ==="
# @workspace/db has no build script — skip per Michael's standing pattern
cd artifacts/api-server && pnpm build 2>&1 | tail -10
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 8. Restart api-server workflow ==="
echo "(Use Replit UI: Workflows → api-server → Restart, or wait for next follow-up cron to pick up new code)"

echo ""
echo "=== followuper-port-1 ship complete. ==="
echo "    Russian Андроид → Android, АйОС → iOS now restored deterministically."
echo "    Writer + rewriter prompts now include BRAND ADAPTATION with iOS/Android/AppsFlyer/Adjust Latin-keep list."
echo "    Next observation point: any non-English follow-up generation — confirm iOS/Android stay Latin in Russian/Chinese/Japanese/Korean bodies."
```

Mirror omitted per your standing pattern.

## Followuper port TODO (later phases)

| Priority | Item | Source |
|---|---|---|
| MEDIUM | Korean Haiku transliteration → hook into followuper pipeline | prospector v4r6x Patch A |
| MEDIUM | Russian greeting brand-prefix strip (post-personalization variant) → context-threaded humanizeText | prospector v4r6s + v4r6w |
| LOW | Brand localization Latin → Native maps (6 languages, 58 brands) | prospector v4r6u + v4r6v |
| LOW | `contextFollowupGenerator.ts` add humanize step | new |
| LOW | `contextFollowupPrompts.ts` BRAND ADAPTATION directive | this port + observed need |
