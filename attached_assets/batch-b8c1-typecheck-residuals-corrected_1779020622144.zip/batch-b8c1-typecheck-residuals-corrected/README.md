# Batch B8c.1 — Typecheck Residuals, Corrected Line Targets

**Scope.** Complete the typecheck cleanup B8c started. B8c's Python regex targeted line numbers from a stale error report and ended up pointing at `req.params.id` lines (no `req.query` to match), so all 5 sites NOOP'd. Now we have the verbatim post-B8c typecheck output with the actual line numbers — 16 surgical edits across 5 files, all the same `req.query.X` cast-injection pattern that B8c's regex was designed for.

## Target inventory

15 Category-1 sites (cast to `string`):

```
admin-user-controls.ts:50,64       (2)
context.ts:336,459,500,532,561     (5)
doctrine.ts:572,775,855,1046,1210,1282  (6)
gmail-auth.ts:204,228              (2)
```

1 Category-2 site (cast to `string | undefined`):

```
email-inspector.ts:370             (1)
```

5 cascading implicit-any sites (`email-inspector.ts:376,378,381,398,414`) are not in the target set — they collapse to zero once line 370 picks the right googleapis overload. If any survive the fix they are real downstream issues requiring separate triage; the bash block surfaces them via the post-fix typecheck.

## What the script does

`scripts/fix-req-query-casts.py` is a standalone Python tool. It opens each target file, walks to each specified line, and applies the regex `(?<!String\()\b(req\.query\.[a-zA-Z_]\w*)\b(?!\s+as\s+\w)` with the appropriate cast suffix. Each line gets one of three outcomes:

- **FIX** — the pattern matched and the cast was applied. Prints OLD and NEW for review.
- **SKIP** — the line contains `req.query.X` but it is already cast (idempotent re-run). Logged as OK.
- **NOOP** — the line contains no `req.query.X` at all. The line number is stale. Script exits with code 2 so the bash block stops before typecheck, and the offending sites are printed for manual triage.

Behavioural test (on synthetic fixtures matching every target file at every target line, see audit notes): **16 / 16 FIX on first run, 16 / 16 SKIP on second run, 0 bad NOOPs**.

## Risk surface

1. **All edits are type-only.** No runtime change. Cast assertions don't affect runtime value handling.
2. **Idempotency.** Re-running the bash block is safe — already-cast sites are SKIPped, not double-wrapped.
3. **Cascading-any prediction.** Line 370's fix is expected to resolve `email-inspector.ts:376,378,381,398,414` automatically (TS narrows once the overload picks). If any survive, the post-fix typecheck output reveals them and they get a separate small follow-up.
4. **Line-number staleness guard.** The script exits non-zero on bad NOOPs so we cannot accidentally proceed to typecheck against a half-applied state. If any target line has shifted between Michael's typecheck output and the deploy, we see exactly which one and triage.

## Layout

```
batch-b8c1-typecheck-residuals-corrected/
|-- README.md
`-- scripts/
    `-- fix-req-query-casts.py   (the standalone fix script)
```

No source-file replacements in this batch. All edits applied by the script directly to the live `artifacts/api-server/src/routes/` files. Mirror sync IS needed since 5 route files change. No workflow restart — type-only.
