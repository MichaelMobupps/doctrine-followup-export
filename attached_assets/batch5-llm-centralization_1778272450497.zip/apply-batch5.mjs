#!/usr/bin/env node
/**
 * apply-batch5.mjs — Phase 5 (LLM call site audit + model centralization).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Touches:
 *   - artifacts/api-server/src/lib/anthropic.ts        (append MODEL_* exports)
 *   - artifacts/api-server/src/services/emailSummarizer.ts
 *                                                      (import + use MODEL_SUMMARIZER)
 *   - artifacts/api-server/src/services/followupGenerator.ts
 *                                                      (import + use 3 MODEL_* constants)
 *
 * After this script runs successfully, the agent must:
 *   1. pnpm --filter @workspace/api-server run build
 *   2. pnpm --filter @workspace/dashboard run build (no-op for this batch but kept for habit)
 *   3. restart_workflow on api-server
 *   4. Mirror sync via source-code/sync.sh
 *
 * No DB migration. No new packages. No new files.
 *
 * Usage:
 *   node apply-batch5.mjs
 *   API_BASE=artifacts/api-server/src node apply-batch5.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[apply-batch5] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch5] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

/**
 * Sentinel-based idempotent str_replace.
 * sentinel must be a substring of newStr but not of oldStr nor of the
 * original file. If sentinel is already present, the patch is a no-op.
 */
function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);

  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

// ============================================================
// Step 1: Append MODEL_* constants to lib/anthropic.ts
// ============================================================
log("Step 1: Patching lib/anthropic.ts...");
const anthropicLibPath = join(API_BASE, "lib", "anthropic.ts");

strReplace(
  anthropicLibPath,
  `export const anthropic = new Anthropic({
  apiKey,
  // Reasonable network timeouts. The SDK default is 10min, way too long for
  // a user-facing follow-up pipeline. If a request is still pending after 60s,
  // it's better to fail and let our retry layer try again.
  timeout: 60 * 1000,
  maxRetries: 0, // We implement our own retry logic with visibility and logging.
});`,
  `export const anthropic = new Anthropic({
  apiKey,
  // Reasonable network timeouts. The SDK default is 10min, way too long for
  // a user-facing follow-up pipeline. If a request is still pending after 60s,
  // it's better to fail and let our retry layer try again.
  timeout: 60 * 1000,
  maxRetries: 0, // We implement our own retry logic with visibility and logging.
});

/**
 * Centralized model identifiers. Single source of truth — every call site
 * imports the named constant for its role and never hardcodes a model
 * string. Swapping a model is a one-line change here.
 *
 * Phase 5 audit (May 2026): all four call sites verified to use the
 * standard messages.create API with no thinking.budget_tokens overrides.
 * Per Anthropic docs:
 *   - Opus 4.7 always uses adaptive reasoning; the fixed budget mode and
 *     CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING do not apply to it.
 *   - Sonnet 4.6 supports adaptive thinking by default and is in adaptive
 *     mode here because no override is set.
 * Adaptive thinking is therefore active across the entire pipeline.
 *
 * Roles:
 *   SUMMARIZER       — short JSON summary + language detect on inbound email
 *                      (low max_tokens, latency-sensitive)
 *   DRAFT_GENERATOR  — composes the follow-up subject + body
 *   CRITIC           — scores and flags issues; uses Opus for judgment quality
 *   REWRITER         — applies critic feedback and outputs a revised draft
 */
export const MODEL_SUMMARIZER:      "claude-sonnet-4-6" = "claude-sonnet-4-6";
export const MODEL_DRAFT_GENERATOR: "claude-sonnet-4-6" = "claude-sonnet-4-6";
export const MODEL_CRITIC:          "claude-opus-4-7"   = "claude-opus-4-7";
export const MODEL_REWRITER:        "claude-sonnet-4-6" = "claude-sonnet-4-6";`,
  "lib/anthropic.ts: append MODEL_* exports + audit doctrine block",
  `export const MODEL_SUMMARIZER:`
);

// ============================================================
// Step 2: Patch emailSummarizer.ts
// ============================================================
log("Step 2: Patching services/emailSummarizer.ts...");
const summarizerPath = join(API_BASE, "services", "emailSummarizer.ts");

strReplace(
  summarizerPath,
  `import { anthropic } from "../lib/anthropic";`,
  `import { anthropic, MODEL_SUMMARIZER } from "../lib/anthropic";`,
  "emailSummarizer.ts: import MODEL_SUMMARIZER",
  `import { anthropic, MODEL_SUMMARIZER }`
);

strReplace(
  summarizerPath,
  `      () => anthropic.messages.create({
        model: "claude-sonnet-4-6",
        max_tokens: 300,
        system: SUMMARIZE_SYSTEM,`,
  `      () => anthropic.messages.create({
        model: MODEL_SUMMARIZER,
        max_tokens: 300,
        system: SUMMARIZE_SYSTEM,`,
  "emailSummarizer.ts: use MODEL_SUMMARIZER constant",
  `model: MODEL_SUMMARIZER,`
);

// ============================================================
// Step 3: Patch followupGenerator.ts
// ============================================================
log("Step 3: Patching services/followupGenerator.ts...");
const generatorPath = join(API_BASE, "services", "followupGenerator.ts");

strReplace(
  generatorPath,
  `import { anthropic } from "../lib/anthropic";`,
  `import { anthropic, MODEL_DRAFT_GENERATOR, MODEL_CRITIC, MODEL_REWRITER } from "../lib/anthropic";`,
  "followupGenerator.ts: import 3 model constants",
  `MODEL_DRAFT_GENERATOR, MODEL_CRITIC, MODEL_REWRITER`
);

// 3a: Draft generator (line ~180, was claude-sonnet-4-6)
strReplace(
  generatorPath,
  `    () => anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: getFollowupSystemPrompt(),`,
  `    () => anthropic.messages.create({
      model: MODEL_DRAFT_GENERATOR,
      max_tokens: 8192,
      system: getFollowupSystemPrompt(),`,
  "followupGenerator.ts: draft generator uses MODEL_DRAFT_GENERATOR",
  `model: MODEL_DRAFT_GENERATOR,`
);

// 3b: Critic (line ~223, was claude-opus-4-7)
strReplace(
  generatorPath,
  `    () => anthropic.messages.create({
      model: "claude-opus-4-7",
      max_tokens: 8192,
      system: getCriticSystemPrompt(),`,
  `    () => anthropic.messages.create({
      model: MODEL_CRITIC,
      max_tokens: 8192,
      system: getCriticSystemPrompt(),`,
  "followupGenerator.ts: critic uses MODEL_CRITIC",
  `model: MODEL_CRITIC,`
);

// 3c: Rewriter (line ~253, was claude-sonnet-4-6)
strReplace(
  generatorPath,
  `    () => anthropic.messages.create({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: getRewriterSystemPrompt(),`,
  `    () => anthropic.messages.create({
      model: MODEL_REWRITER,
      max_tokens: 8192,
      system: getRewriterSystemPrompt(),`,
  "followupGenerator.ts: rewriter uses MODEL_REWRITER",
  `model: MODEL_REWRITER,`
);

// ============================================================
// Step 4: Self-verify
// ============================================================
log("Step 4: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found in ${path}: ${needle.slice(0, 80)}...`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle SHOULD NOT be in ${path}: ${needle.slice(0, 80)}...`);
  log(`  [OK] ${label}`);
}

// V1: lib/anthropic.ts has all 4 model exports
expectInFile(anthropicLibPath, `export const MODEL_SUMMARIZER:`, "V1a anthropic.ts MODEL_SUMMARIZER");
expectInFile(anthropicLibPath, `export const MODEL_DRAFT_GENERATOR:`, "V1b anthropic.ts MODEL_DRAFT_GENERATOR");
expectInFile(anthropicLibPath, `export const MODEL_CRITIC:`, "V1c anthropic.ts MODEL_CRITIC");
expectInFile(anthropicLibPath, `export const MODEL_REWRITER:`, "V1d anthropic.ts MODEL_REWRITER");

// V2: emailSummarizer imports + uses MODEL_SUMMARIZER
expectInFile(summarizerPath, `import { anthropic, MODEL_SUMMARIZER }`, "V2a emailSummarizer.ts import");
expectInFile(summarizerPath, `model: MODEL_SUMMARIZER,`, "V2b emailSummarizer.ts model usage");

// V3: followupGenerator imports + uses 3 constants
expectInFile(generatorPath, `MODEL_DRAFT_GENERATOR, MODEL_CRITIC, MODEL_REWRITER`, "V3a followupGenerator.ts import");
expectInFile(generatorPath, `model: MODEL_DRAFT_GENERATOR,`, "V3b followupGenerator.ts draft");
expectInFile(generatorPath, `model: MODEL_CRITIC,`, "V3c followupGenerator.ts critic");
expectInFile(generatorPath, `model: MODEL_REWRITER,`, "V3d followupGenerator.ts rewriter");

// V4: No hardcoded model strings remain in the patched files
expectNotInFile(summarizerPath, `model: "claude-sonnet-4-6"`, "V4a no hardcode in emailSummarizer");
expectNotInFile(generatorPath, `model: "claude-sonnet-4-6"`, "V4b no hardcode sonnet in followupGenerator");
expectNotInFile(generatorPath, `model: "claude-opus-4-7"`, "V4c no hardcode opus in followupGenerator");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 5 patch applied. Audit finding: zero thinking-budget");
log("overrides existed. Centralization complete; future model swaps");
log("are one-line changes in lib/anthropic.ts.");
log("================================================================");
