# CPS Sub-Vertical Classification — Full Change List

## Overview
Adds a second-pass CPS sub-vertical classifier (13 granular sub-verticals) that runs whenever vertical = "cps". Stores the result in a new `sub_vertical` column, feeds it into followup email generation for industry-specific context, and displays it in the dashboard.

## Files to change (9 files, 1 new DB migration)

---

### 1. `artifacts/api-server/src/lib/verticalClassifier.ts` — FULL REPLACE
Replace the entire file with the attached `verticalClassifier.ts`.

Key changes:
- `inferVertical()` now returns `{ vertical, subVertical, reason }` (was `{ vertical, reason }`)
- New `inferCpsSubVertical()` second-pass function with 13 sub-vertical signal sets
- New exports: `CPS_SUB_VERTICAL_LABELS`, `getCpsDisplayLabel()`

---

### 2. `lib/db/src/schema/prospects.ts` — ADD COLUMN
Add after the `vertical` line:

```typescript
  subVertical: text("sub_vertical"),
```

---

### 3. DB Migration — ADD COLUMN
Run in Replit shell:
```sql
ALTER TABLE prospects ADD COLUMN IF NOT EXISTS sub_vertical TEXT;
```

Or via drizzle: `npx drizzle-kit push`

---

### 4. `artifacts/api-server/src/services/gmailSync.ts` — 2 PATCHES

**Patch A** (syncForUser, ~line 71):
```
BEFORE: const vertical = inferVertical(msg.labels, msg.subject, msg.body).vertical;
AFTER:  const { vertical, subVertical } = inferVertical(msg.labels, msg.subject, msg.body);
```
AND in the insert values (~line 86):
```
BEFORE:
        vertical,
        product: inferProduct(vertical),
AFTER:
        vertical,
        subVertical,
        product: inferProduct(vertical),
```

**Patch B** (syncForLegacyUser, ~line 213): Same pattern as Patch A.

---

### 5. `artifacts/api-server/src/services/followupPrompts.ts` — 3 PATCHES

**Patch A**: Add `sub_vertical` to FollowupContext interface:
```typescript
export interface FollowupContext {
  prospect_name: string;
  company: string;
  vertical: string;
  sub_vertical: string | null;  // ← ADD THIS
  product: string;
  ...
```

**Patch B**: Update `getFollowupUserPrompt()` — replace the verticalLabels map:
```typescript
  const verticalLabels: Record<string, string> = {
    gaming_ua: "Gaming User Acquisition",
    non_gaming_ua: "Non-Gaming Mobile User Acquisition",
    cps: "CPS Web Performance",
    retargeting: "Mobile Retargeting",
  };

  const cpsSubLabels: Record<string, string> = {
    cps_ecommerce: "E-commerce & Retail (CPS web performance for online retail, confirmed purchases, product sales)",
    cps_classifieds: "Classifieds & Marketplaces (CPS web performance for listing submissions, seller leads)",
    cps_fintech: "Fintech & Financial Services (CPS performance for banking, trading, lending, payments)",
    cps_travel: "Travel & Hospitality (CPS performance for bookings, reservations, travel conversions)",
    cps_food_delivery: "Food & Delivery (CPS performance for order completions, restaurant/grocery delivery)",
    cps_subscription: "Subscription & SaaS (CPS performance for trial-to-paid, subscriber acquisition)",
    cps_education: "Education & EdTech (CPS performance for course enrollments, student acquisition)",
    cps_health_wellness: "Health & Wellness (CPS performance for telehealth, fitness, pharmacy conversions)",
    cps_utilities_telco: "Utilities & Telco (CPS performance for plan signups, SIM activations)",
    cps_automotive: "Automotive (CPS performance for car sales leads, test drive bookings, auto conversions)",
    cps_real_estate: "Real Estate & Property (CPS performance for property leads, listing engagement)",
    cps_dating_social: "Dating & Social (CPS performance for premium subscriptions, match conversions)",
    cps_gaming_iap: "Gaming In-App Purchase (CPS performance on purchase events, payer conversions)",
  };
```

**Patch C**: Update the VERTICAL line in the prompt:
```
BEFORE: VERTICAL: ${verticalLabels[ctx.vertical] || ctx.vertical}
AFTER:  VERTICAL: ${ctx.sub_vertical && cpsSubLabels[ctx.sub_vertical] ? cpsSubLabels[ctx.sub_vertical] : (verticalLabels[ctx.vertical] || ctx.vertical)}
```

---

### 6. `artifacts/api-server/src/services/scheduler.ts` — 2 PATCHES

**Patch A**: Add subVertical to the select query (~line 22):
```
BEFORE:
      vertical: prospectsTable.vertical,
      product: prospectsTable.product,
AFTER:
      vertical: prospectsTable.vertical,
      subVertical: prospectsTable.subVertical,
      product: prospectsTable.product,
```

**Patch B**: Add sub_vertical to the FollowupContext (~line 122):
```
BEFORE:
        vertical: item.vertical,
        product: item.product,
AFTER:
        vertical: item.vertical,
        sub_vertical: item.subVertical || null,
        product: item.product,
```

---

### 7. `artifacts/api-server/src/routes/email-inspector.ts` — 2 PATCHES

**Patch A** (~line 174): Capture subVertical from inferVertical:
```
BEFORE: const { vertical, reason: verticalReason } = inferVertical(labelNames, subject, body);
AFTER:  const { vertical, subVertical, reason: verticalReason } = inferVertical(labelNames, subject, body);
```

**Patch B**: Add subVertical to the detection object in the response (~line 207):
```
BEFORE:
            vertical,
            verticalReason,
AFTER:
            vertical,
            subVertical,
            verticalReason,
```

---

### 8. `artifacts/api-server/src/routes/doctrine.ts` — ADD sub_vertical to API responses

In the `/prospects` endpoint response mapping, add after `vertical: row.vertical,`:
```
      sub_vertical: row.subVertical || null,
```

In the `/followups` endpoint response mapping, add after `vertical: r.vertical,`:
```
      sub_vertical: r.subVertical || null,
```
(Note: need to also add subVertical to the followups select query from prospectsTable)

In the `/prospect/by-thread/:threadId` endpoint, add after `vertical: p.vertical,`:
```
      sub_vertical: p.subVertical || null,
```

---

### 9. Dashboard display updates — ALL vertical label maps

Update every `verticalLabels` / `VERTICAL_LABELS` map in these files:

- `artifacts/dashboard/src/pages/email-inspector.tsx` (~line 50)
- `artifacts/dashboard/src/pages/prospects.tsx` (Select dropdowns + any label maps)
- `artifacts/api-server/src/routes/doctrine.ts` (~line 185, the verticalLabels object)
- `addon/ContextualTrigger.gs` (~line 51)

For CPS entries, use the sub_vertical display label when available. The display logic:
```typescript
import { getCpsDisplayLabel } from "../lib/verticalClassifier";

// When displaying a prospect's vertical:
const displayVertical = prospect.vertical === "cps" && prospect.sub_vertical
  ? getCpsDisplayLabel(prospect.sub_vertical)
  : verticalLabels[prospect.vertical] || prospect.vertical;
```

---

## After all changes, run:
```bash
cd /home/runner/workspace
npx drizzle-kit push          # or ALTER TABLE directly
npx openapi-typescript lib/api-spec/openapi.yaml -o lib/api-client/src/generated.ts
bash source-code/sync.sh
```
