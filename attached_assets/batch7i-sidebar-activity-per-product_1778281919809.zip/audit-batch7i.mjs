#!/usr/bin/env node
/**
 * audit-batch7i.mjs — Beautiful-Squidward audit for Phase 7i.
 * 3 rounds × 9 passes per round. Small batch — fewer asserts per pass.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7i] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7i] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const ctxPipelineSrc    = read(join(DASH_BASE, "pages", "context-pipeline.tsx"));
const ctxActivitySrc    = read(join(DASH_BASE, "pages", "context-activity.tsx"));
const ctxInspectorSrc   = read(join(DASH_BASE, "pages", "context-inspector.tsx"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: backend endpoint declared
  log(`-- PASS 1: /context/my/activity declared --`);
  pass(`Phase 7i comment`, /Phase 7i: per-product sidebar activity\./.test(ctxRouteSrc));
  pass(`Route declared`, /router\.get\("\/my\/activity",/.test(ctxRouteSrc));
  pass(`Mirrors doctrine response shape doc`, /Same response\s*\n\/\/ shape \(last_sync, queued, next_due\)/.test(ctxRouteSrc));

  // PASS 2: backend logic mirrors doctrine
  log(`-- PASS 2: backend logic --`);
  pass(`userId guard short-circuits to nulls`, /if \(!userId\) \{ res\.json\(\{ last_sync: null, queued: 0, next_due: null \}\); return; \}/.test(ctxRouteSrc));
  pass(`latestProspect query`, /latestProspect = await db[\s\S]*?prospectsTable\.createdAt[\s\S]*?\.where\(and\(SCOPE, eq\(prospectsTable\.userId, userId\)\)\)/.test(ctxRouteSrc));
  pass(`queuedCount query`, /queuedCount = await db[\s\S]*?count\(\*\)[\s\S]*?eq\(followupsTable\.status, "queued"\)/.test(ctxRouteSrc));
  pass(`nextDue query`, /nextDue = await db[\s\S]*?\.orderBy\(asc\(followupsTable\.scheduledAt\)\)/.test(ctxRouteSrc));

  // PASS 3: backend gated on SCOPE (not SCOPE_DOCTRINE)
  log(`-- PASS 3: scope filter --`);
  // Inside the /my/activity handler block specifically, all three queries
  // should use SCOPE. Pull the block and check.
  const myActivityBlock = (() => {
    const m = ctxRouteSrc.match(/router\.get\("\/my\/activity"[\s\S]*?^\}\);$/m);
    return m ? m[0] : "";
  })();
  pass(`/my/activity block extracted`, myActivityBlock.length > 0);
  pass(`Block uses SCOPE 3 times`, (myActivityBlock.match(/\bSCOPE\b/g) || []).length === 3);
  pass(`Block has no SCOPE_DOCTRINE`, !/SCOPE_DOCTRINE/.test(myActivityBlock));

  // PASS 4: response shape
  log(`-- PASS 4: response shape --`);
  pass(`last_sync ISO string or null`, /last_sync: latestProspect\[0\]\?\.createdAt\?\.toISOString\(\) \|\| null,/.test(ctxRouteSrc));
  pass(`queued is Number`, /queued: Number\(queuedCount\[0\]\?\.count\) \|\| 0,/.test(ctxRouteSrc));
  pass(`next_due ISO string or null`, /next_due: nextDue\[0\]\?\.scheduledAt\?\.toISOString\(\) \|\| null,/.test(ctxRouteSrc));
  pass(`Catch returns null/zero defaults`, /catch \(err\) \{\s*\n\s*res\.json\(\{ last_sync: null, queued: 0, next_due: null \}\);/.test(ctxRouteSrc));

  // PASS 5: layout.tsx product-aware fetch
  log(`-- PASS 5: layout.tsx URL switch --`);
  pass(`Phase 7i comment in layout`, /Phase 7i: URL switches based on onContext/.test(layoutSrc));
  pass(`activityPath ternary`, /const activityPath = onContext \? "api\/context\/my\/activity" : "api\/my\/activity";/.test(layoutSrc));
  pass(`fetch uses activityPath`, /fetch\(`\$\{base\}\$\{activityPath\}\?userId=/.test(layoutSrc));
  pass(`Hardcoded doctrine URL absent`, !/`\$\{base\}api\/my\/activity\?userId=/.test(layoutSrc));

  // PASS 6: deps include onContext
  log(`-- PASS 6: effect deps --`);
  pass(`onContext in deps array`, /\}, \[apiKey, currentUser\?\.userId, onContext\]\);/.test(layoutSrc));
  pass(`Old deps array absent`, !/\}, \[apiKey, currentUser\?\.userId\]\);/.test(layoutSrc));

  // PASS 7: doctrine endpoint NOT regressed
  log(`-- PASS 7: doctrine /my/activity unchanged --`);
  pass(`Doctrine /my/activity still in doctrine.ts`, /router\.get\("\/my\/activity"/.test(doctrineRouteSrc));
  pass(`Doctrine /my/activity still uses SCOPE_DOCTRINE`, (() => {
    const m = doctrineRouteSrc.match(/router\.get\("\/my\/activity"[\s\S]*?^\}\);$/m);
    return m && (m[0].match(/SCOPE_DOCTRINE/g) || []).length === 3;
  })());

  // PASS 8: B7g/B7e/B7f regression
  log(`-- PASS 8: B7e-B7h regression --`);
  pass(`B7e: ContextPipeline default export`, /export default function ContextPipeline\(\)/.test(ctxPipelineSrc));
  pass(`B7e: /context/cancel-followup endpoint`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7f: ContextActivityLog default export`, /export default function ContextActivityLog\(\)/.test(ctxActivitySrc));
  pass(`B7f: /campaign/status returns context_label`, /context_label: u\.contextLabel,/.test(ctxRouteSrc));
  pass(`B7g: /context/gmail/sent-emails endpoint`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`B7h: ContextEmailInspector default export`, /export default function ContextEmailInspector\(\)/.test(ctxInspectorSrc));
  pass(`B7h: ctx-inspector hits /api/context/gmail/sent-emails`, /api\/context\/gmail\/sent-emails/.test(ctxInspectorSrc));

  // PASS 9: B7c/B7a/B7b regression
  log(`-- PASS 9: B7a-B7c regression --`);
  pass(`B7c: SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`B7c: SCOPE_DOCTRINE referenced ≥30 times`, (doctrineRouteSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`B7b: /context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7a: users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
  pass(`Layout still product-aware (data-product)`, /data-product=\{dataProduct\}/.test(layoutSrc));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
