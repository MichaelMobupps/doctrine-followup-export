# Batch B9b — AntiGhosting Marking Backend

**Scope.** Backend slice of the AntiGhosting marking flow. Two endpoints (`POST /mark`, `GET /candidates`), three validators, one pure scheduling formula, and a unit test suite. No dashboard UI in this batch (that lands as B9b.1). No LLM pipeline or scheduler dispatcher extension (B9c). No pause / renewal / notifications (B9d).

## Files

```
batch-b9b-antighosting-marking-backend/
|-- README.md
`-- api-server/
    |-- services/
    |   |-- antiGhostingScheduling.ts      (new)
    |   `-- antiGhostingValidators.ts      (new)
    |-- routes/
    |   |-- anti-ghosting.ts               (new)
    |   `-- index.ts                       (modified — 1 import + 1 mount)
    `-- tests/
        `-- test-anti-ghosting-b9b.ts      (new — 15 unit tests)
```

## services/antiGhostingScheduling.ts

Pure formula module. `computeFirstFollowupAt({ sentAt, markedAt, cadenceGapMs?, minBufferMs? })` returns `new Date(Math.max(sentAt + cadenceGap, markedAt + minBuffer))`. Defaults: `cadenceGap = 7 days` (matches the F1 max of the existing draft-mode timing), `minBuffer = 1 day` (prevents stale-seed marks from firing immediately and surprising the operator).

Exports the two default constants so callers and tests can reference them by name rather than magic numbers.

## services/antiGhostingValidators.ts

Two exports:

- `parseGmailThread(gmail, threadId, userEmail)` — fetches a thread, normalises every message into a `ThreadMessageBrief` (id, sentAt, fromHeader, fromEmail, fromName, subject, snippet, body, direction), sorts chronologically oldest-first. Used by the validator and (transitively, via the route's mark flow) by future renewal-cycle checks.

- `validateThreadForMarking(threadId, gmail, userEmail, userId)` — runs the three validators in design order:
  1. Most recent message is outbound
  2. Thread contains at least one inbound
  3. Most recent outbound is NOT in followups (i.e., not a system send)

  Short-circuits on first failure for response speed. Returns a `ValidationOutcome` with `ok` + `results` (the three booleans) + `seed` (the message to anchor on, populated only on pass) + `prospect` (the other party, populated on any path with an inbound) + `threadMessages` (full chronological list for downstream sync) + `failureReason` (operator-facing explanation, populated only on fail).

Validator 3 hits the DB with an indexed `(prospects.user_id, followups.gmail_message_id)` lookup. Scoped to the current user's prospects so cross-user message IDs cannot leak.

## routes/anti-ghosting.ts

X-API-Key gated (same `authMiddleware` pattern as `doctrine.ts` / `context.ts`). Two endpoints:

### `POST /api/anti-ghosting/mark`

Body: `{ email, gmailThreadId, seedMessageId? }`

Flow:
1. Resolve user from email (404 if not found, 409 if not Gmail-connected).
2. Run the three validators.
3. If any fail, return `200 OK` with `{ ok: false, results, prospect, failureReason }` so the dashboard can render the preview inline. Structural errors (auth, missing thread, DB failure) return 4xx/5xx as appropriate.
4. On pass, optionally override the seed to a user-specified `seedMessageId`. The override must be present in the thread AND outbound; otherwise 400.
5. Compute `scheduledAt = computeFirstFollowupAt({ sentAt: seed.sentAt, markedAt: now })`.
6. Insert the prospect row with `app='anti_ghosting'`, `cycle=1`, seed metadata in `originalSubject` / `originalBody` / `gmailMessageId`.
7. Call `syncThreadFromGmail` (the B9a helper) to populate `thread_messages` for this prospect. Failure here is logged as a warning but does NOT fail the mark — the prospect is created and F1 will still fire; the thread record can be backfilled by future reads.
8. Insert the F1 row into `followups` with `stage=1`, `cycle=1`, `status='scheduled'`, `scheduledAt`.
9. Return `{ ok: true, prospectId, scheduledAt, seed, prospect, results }`.

`originalLanguage`, `vertical`, `subVertical` are left null in B9b. Language detection wires in during B9c at generation time; vertical/subVertical are not meaningful for re-engagement (the prospect already existed under whatever original-flow vertical applied).

### `GET /api/anti-ghosting/candidates?email=&limit=`

Flow:
1. Resolve user from email.
2. Resolve `antiGhostingLabel` to Gmail label IDs (supports comma-separated multi-label, same as the context route's pattern).
3. List threads tagged with those labels (capped at `limit`, default 20, max 50).
4. Look up the set of thread IDs that already have an `app='anti_ghosting'` prospect for this user (one `selectDistinct` query, indexed by `(user_id, app)`).
5. For each candidate thread not yet marked, run `validateThreadForMarking` to populate the per-card preview.
6. Each candidate ships with `gmailThreadId`, validator pass/fail, the seed identification (`gmailMessageId`, `subject`, `snippet`, `sentAt`, `daysSinceSeedTier` ∈ `"lt_30d" | "30d_to_6mo" | "gt_6mo"`), the prospect identity, and the failure reason if any validator failed.

Reading every candidate's full thread is N+1 with respect to Gmail API calls. Acceptable at typical operator volumes (≤20 candidates per session) and matches the existing `/gmail/sent-emails` pattern in `context.ts`. If volumes grow past ~50, batching via `users.messages.list` with multi-thread aggregation is the optimisation, deferred until needed.

## tests/test-anti-ghosting-b9b.ts

15 unit tests across three sections:

- Section 1: `computeFirstFollowupAt` — fresh seed, stale seed, boundary, custom cadence, custom buffer, default-constant check (6 tests).
- Section 2: `parseGmailThread` — chronological sort, direction classification, From-header extraction, body decoding, missing-date skip, empty-thread case (6 tests).
- Section 3: `validateThreadForMarking` — structural failures that short-circuit before the DB check: empty thread, most-recent-inbound, no-inbound-exists (3 tests).

DB-backed paths (validator 3 pass/fail, /mark's prospect insertion, /candidates' selectDistinct) are deferred to an integration suite. The unit suite is fully self-contained and runs in ~5s.

Verified in a standalone sandbox: full `tsc --strict` clean across all 4 source files with real `googleapis@^144` and `drizzle-orm@^0.45` types installed. Sandbox-confirmed: 6/6 scheduling tests pass; parseGmailThread tests will pass against the real B9a helpers (sandbox stubs return defaults).

## Risk surface

1. **No schema migration in this batch.** B9a already laid every column and table needed (prospects.app supports `anti_ghosting`, thread_messages exists, users.antiGhostingLabel exists). Runtime startupMigrations are idempotent on boot but no new ALTERs run.

2. **Runtime path is new but contained.** `routes/index.ts` mounts one new sub-router. Existing routes are untouched. No middleware reorder, no auth changes.

3. **No background job changes.** F1 followups are scheduled to the existing `followups` table with `status='scheduled'`. The current scheduler/dispatcher will see these rows but doesn't yet know how to generate AntiGhosting content (the prompt module + dispatcher branch land in B9c). Until B9c ships, any AntiGhosting followup whose `scheduledAt` arrives will sit in 'scheduled' indefinitely. Acceptable for B9b because:
   - The default cadence is 7+1 days, so no scheduled row fires before B9c ships.
   - If B9c ships late and a scheduled row gets picked up by the existing scheduler, it would either fail (no doctrine/context prompt module matches anti_ghosting) or run a wrong generator. The scheduler's existing `app` branching defaults to "doctrine" on unknown apps — so an AntiGhosting prospect would erroneously generate Doctrine content. This is the only meaningful risk window.
   - Mitigation: ship B9c within 7 days of B9b. If that slips, a one-line scheduler guard (skip prospects with `app='anti_ghosting'`) can ship as a hotfix.

4. **No dashboard exposure.** The endpoints work but only via curl until B9b.1 ships. Acceptable — Michael's marking workflow today is manual anyway, and this lets us validate the API end-to-end before adding UI complexity.

5. **Gmail rate limits on /candidates.** Each candidate triggers a `threads.get` call. At default limit=20, that's 20 calls + 1 list call + 1 labels call per dashboard refresh. Within Gmail's per-user quota (250 quota units/second; threads.get is 10 units), worst case ~2 requests/second sustained. Fine.

## Layout (source mirror parity)

`source-code/sync.sh` will pick up:
- `lib/db/src/` — unchanged this batch
- `artifacts/api-server/src/services/antiGhostingScheduling.ts`, `antiGhostingValidators.ts` — new
- `artifacts/api-server/src/routes/anti-ghosting.ts` — new
- `artifacts/api-server/src/routes/index.ts` — modified
- `artifacts/api-server/src/tests/test-anti-ghosting-b9b.ts` — new

## Deferred

- **Dashboard marking UI** — B9b.1. Candidate list with validator preview cards, mark button, seed override picker.
- **LLM pipeline (writer / critic / rewriter) + prompt module for AntiGhosting** — B9c. `antiGhostingFollowupPrompts.ts`, generator, daysSinceSeed tone-tier wiring.
- **Scheduler dispatcher branch for `app='anti_ghosting'`** — B9c. Until then, the F1 row is scheduled but won't actually dispatch correctly (see risk #3).
- **Pause / renewal / notifications + dashboard polish** — B9d.
- **Add-on (Apps Script) Gmail-label ingress** — B9d or separate ship.
- **AntiGhosting parity Settings** — locked design in user memory, lands B9d or separate B9e.
