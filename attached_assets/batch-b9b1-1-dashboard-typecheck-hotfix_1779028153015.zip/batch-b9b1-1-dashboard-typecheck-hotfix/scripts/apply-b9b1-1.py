#!/usr/bin/env python3
r"""
B9b.1.1 — clear the 7 pre-existing dashboard typecheck residuals so the
typecheck gate becomes meaningful again.

These errors aren't caused by B9b.1 — they're latent drift from when
react-query v5 made queryKey mandatory on UseQueryOptions. Orval-generated
hooks in this dashboard forward the user's `query` options object straight
through to useQuery, and the v5 type for that object requires queryKey.
The 7 call sites all pass `query: { enabled: ... }` without queryKey, so
tsc fails on every dashboard typecheck.

The fix: add a queryKey to each call site's query options object.

Convention for queryKey values: ["/api/<path>"] in plain string-array form,
matching the existing `queryClient.invalidateQueries({ queryKey: [...] })`
calls in dashboard.tsx (lines 36-39) and pipeline.tsx (lines 626-628).
This ensures cache invalidation behaviour stays consistent — whatever
Orval's internal default is, the manually-provided queryKey takes
precedence, so the existing invalidate calls now correctly target the
cache entries.

Files touched (none are B9b.1's own):
  - src/pages/accounts.tsx          (1 site)
  - src/pages/dashboard.tsx         (2 sites)
  - src/pages/email-inspector.tsx   (3 sites)
  - src/pages/pipeline.tsx          (1 site)

Idempotent. Generalized NEW-substring-of-OLD check (from B9c.2.1 + B9b.1).
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    totals = [0, 0, 0]

    # ─────────────────────────────────────────────────────────────
    # 1. accounts.tsx — useGetGmailAccounts
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/dashboard/src/pages/accounts.tsx ---")
    a, b, w = patch_file(
        "artifacts/dashboard/src/pages/accounts.tsx",
        [
            (
                '  const { data, isLoading, refetch } = useGetGmailAccounts({\n'
                '    ...requestOpts,\n'
                '    query: { enabled: !!apiKey },\n'
                '  });\n',
                '  const { data, isLoading, refetch } = useGetGmailAccounts({\n'
                '    ...requestOpts,\n'
                '    query: { queryKey: ["/api/accounts"], enabled: !!apiKey },\n'
                '  });\n',
                "add queryKey to useGetGmailAccounts",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ─────────────────────────────────────────────────────────────
    # 2. dashboard.tsx — useGetStats + useGetCampaignStatus
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/dashboard/src/pages/dashboard.tsx ---")
    a, b, w = patch_file(
        "artifacts/dashboard/src/pages/dashboard.tsx",
        [
            (
                '  const { data: stats, isLoading, isError } = useGetStats({ ...requestOpts, query: { enabled: !!apiKey } });\n',
                '  const { data: stats, isLoading, isError } = useGetStats({ ...requestOpts, query: { queryKey: ["/api/stats"], enabled: !!apiKey } });\n',
                "add queryKey to useGetStats",
            ),
            (
                '  const { data: campaignStatus, isLoading: campaignLoading } = useGetCampaignStatus({\n'
                '    ...requestOpts,\n'
                '    query: { enabled: !!apiKey, refetchInterval: 10000 },\n'
                '  });\n',
                '  const { data: campaignStatus, isLoading: campaignLoading } = useGetCampaignStatus({\n'
                '    ...requestOpts,\n'
                '    query: { queryKey: ["/api/campaign/status"], enabled: !!apiKey, refetchInterval: 10000 },\n'
                '  });\n',
                "add queryKey to useGetCampaignStatus",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ─────────────────────────────────────────────────────────────
    # 3. email-inspector.tsx — useGetThread + useGetGmailAccounts + useGetSentEmails
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/dashboard/src/pages/email-inspector.tsx ---")
    a, b, w = patch_file(
        "artifacts/dashboard/src/pages/email-inspector.tsx",
        [
            (
                '  const { data, isLoading, isError } = useGetThread(threadId, {\n'
                '    request: { headers: { "x-api-key": apiKey } },\n'
                '    query: { enabled: !!threadId },\n'
                '  });\n',
                '  const { data, isLoading, isError } = useGetThread(threadId, {\n'
                '    request: { headers: { "x-api-key": apiKey } },\n'
                '    query: { queryKey: ["/api/thread", threadId], enabled: !!threadId },\n'
                '  });\n',
                "add queryKey to useGetThread",
            ),
            (
                '  const { data: accountsData } = useGetGmailAccounts({\n'
                '    ...requestOpts,\n'
                '    query: { enabled: !!apiKey },\n'
                '  });\n',
                '  const { data: accountsData } = useGetGmailAccounts({\n'
                '    ...requestOpts,\n'
                '    query: { queryKey: ["/api/accounts"], enabled: !!apiKey },\n'
                '  });\n',
                "add queryKey to useGetGmailAccounts in email-inspector",
            ),
            (
                '    { ...requestOpts, query: { enabled: !!apiKey && !!selectedUserId } },\n',
                '    { ...requestOpts, query: { queryKey: ["/api/sent-emails", selectedUserId], enabled: !!apiKey && !!selectedUserId } },\n',
                "add queryKey to useGetSentEmails",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ─────────────────────────────────────────────────────────────
    # 4. pipeline.tsx — useGetFollowups
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/dashboard/src/pages/pipeline.tsx ---")
    a, b, w = patch_file(
        "artifacts/dashboard/src/pages/pipeline.tsx",
        [
            (
                '    { ...requestOpts, query: { enabled: !!apiKey, refetchInterval: 30000 } }\n',
                '    { ...requestOpts, query: { queryKey: ["/api/followups", currentUser?.userId], enabled: !!apiKey, refetchInterval: 30000 } }\n',
                "add queryKey to useGetFollowups",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    expected = 7
    seen = totals[0] + totals[1]
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {totals[0]}")
    print(f"  Already-applied:   {totals[1]}")
    print(f"  Warnings:          {totals[2]}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if totals[2] > 0:
        print("  At least one edit could not be applied. Inspect WARN lines.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
