#!/usr/bin/env node
/**
 * audit-batch7h.mjs — Beautiful-Squidward audit for Phase 7h.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7h] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7h] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxInspectorSrc   = read(join(DASH_BASE, "pages", "context-inspector.tsx"));
const inspectorSrc      = read(join(DASH_BASE, "pages", "email-inspector.tsx"));
const ctxPipelineSrc    = read(join(DASH_BASE, "pages", "context-pipeline.tsx"));
const ctxActivitySrc    = read(join(DASH_BASE, "pages", "context-activity.tsx"));
const layoutSrc         = read(join(DASH_BASE, "components", "layout.tsx"));
const appSrc            = read(join(DASH_BASE, "App.tsx"));
const accountsSrc       = read(join(DASH_BASE, "pages", "accounts.tsx"));
const ctxRouteSrc       = read(join(API_BASE, "routes", "context.ts"));
const inspectorRouteSrc = read(join(API_BASE, "routes", "email-inspector.ts"));
const doctrineRouteSrc  = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc     = read(join(API_BASE, "routes", "index.ts"));
const usersSchema       = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: ContextEmailInspector component identity
  log(`-- PASS 1: ContextEmailInspector component --`);
  pass(`Default export ContextEmailInspector`, /export default function ContextEmailInspector\(\)/.test(ctxInspectorSrc));
  pass(`Phase 7h header comment`, /Phase 7h: ContextEmailInspector — clone of email-inspector\.tsx retargeted to/.test(ctxInspectorSrc));
  pass(`Title text`, />Context Email Inspector<\/h1>/.test(ctxInspectorSrc));
  pass(`Placeholder marker absent`, !/Phase 7d: placeholder\. Full Context Email Inspector ships in/.test(ctxInspectorSrc));

  // PASS 2: Raw fetch — ThreadView
  log(`-- PASS 2: ThreadView raw fetch --`);
  pass(`ThreadView Phase 7h comment`, /Phase 7h: useGetThread → raw fetch\. \/api\/gmail\/thread is shared/.test(ctxInspectorSrc));
  pass(`useState data inside ThreadView`, /const \[data, setData\] = useState<any>\(null\);/.test(ctxInspectorSrc));
  pass(`Effect fetches /api/gmail/thread/:id`, /fetch\(`\$\{base\}api\/gmail\/thread\/\$\{threadId\}`/.test(ctxInspectorSrc));
  pass(`Effect cleanup with cancelled flag`, /return \(\) => \{ cancelled = true; \};/.test(ctxInspectorSrc));

  // PASS 3: Raw fetch — accounts
  log(`-- PASS 3: Accounts raw fetch --`);
  pass(`Accounts Phase 7h comment`, /Phase 7h: useGetGmailAccounts → raw fetch\./.test(ctxInspectorSrc));
  pass(`Accounts state init`, /const \[accountsData, setAccountsData\] = useState<any>\(null\);/.test(ctxInspectorSrc));
  pass(`Accounts URL is shared`, /fetch\(`\$\{base\}api\/gmail\/accounts`/.test(ctxInspectorSrc));

  // PASS 4: Raw fetch — sent emails
  log(`-- PASS 4: Sent emails raw fetch --`);
  pass(`Sent-emails Phase 7h comment`, /Phase 7h: useGetSentEmails → raw fetch hitting \/api\/context\/gmail\/sent-emails\./.test(ctxInspectorSrc));
  pass(`refetchTrigger state`, /const \[refetchTrigger, setRefetchTrigger\] = useState\(0\);/.test(ctxInspectorSrc));
  pass(`refetch via useCallback`, /const refetch = useCallback\(\(\) => setRefetchTrigger\(\(t\) => t \+ 1\), \[\]\);/.test(ctxInspectorSrc));
  pass(`URLSearchParams used for query`, /const params = new URLSearchParams\(\);/.test(ctxInspectorSrc));
  pass(`URL targets /api/context/gmail/sent-emails`, /fetch\(`\$\{base\}api\/context\/gmail\/sent-emails\?\$\{params\.toString\(\)\}`/.test(ctxInspectorSrc));
  pass(`isFetching state managed`, /setIsFetching\(true\);/.test(ctxInspectorSrc) && /setIsFetching\(false\);/.test(ctxInspectorSrc));

  // PASS 5: Sync URL retargeted
  log(`-- PASS 5: Manual sync URL --`);
  pass(`/api/sync → /api/context/sync`, /fetch\(`\$\{base\}api\/context\/sync`/.test(ctxInspectorSrc));
  pass(`Doctrine /api/sync URL absent in ctx-inspector`, !/fetch\(`\$\{base\}api\/sync`/.test(ctxInspectorSrc));

  // PASS 6: Field renames — context vs doctrine
  log(`-- PASS 6: Context field renames --`);
  pass(`hasContextLabel present`, /hasContextLabel/.test(ctxInspectorSrc));
  pass(`matchedContextLabels present`, /matchedContextLabels/.test(ctxInspectorSrc));
  pass(`withContextLabel present`, /withContextLabel/.test(ctxInspectorSrc));
  pass(`Detection-panel "Context label" string`, /\["Context label", email\.hasContextLabel\]/.test(ctxInspectorSrc));
  pass(`Stat-pill "CONTEXT LABELED" string`, /\{ label: "CONTEXT LABELED", value: meta\.withContextLabel \}/.test(ctxInspectorSrc));
  pass(`hasDoctrineLabel absent`, !/hasDoctrineLabel/.test(ctxInspectorSrc));
  pass(`matchedDoctrineLabels absent`, !/matchedDoctrineLabels/.test(ctxInspectorSrc));
  pass(`withDoctrineLabel absent`, !/withDoctrineLabel/.test(ctxInspectorSrc));
  pass(`"Doctrine label" string absent`, !/"Doctrine label"/.test(ctxInspectorSrc));
  pass(`"DOCTRINE LABELED" string absent`, !/"DOCTRINE LABELED"/.test(ctxInspectorSrc));

  // PASS 7: Typed hooks fully removed
  log(`-- PASS 7: Typed hooks removed --`);
  pass(`useGetSentEmails() call removed`, !/useGetSentEmails\(/.test(ctxInspectorSrc));
  pass(`useGetThread() call removed`, !/useGetThread\(/.test(ctxInspectorSrc));
  pass(`useGetGmailAccounts() call removed`, !/useGetGmailAccounts\(/.test(ctxInspectorSrc));
  pass(`api-client-react import absent`, !/from "@workspace\/api-client-react"/.test(ctxInspectorSrc));
  pass(`function EmailInspector() default-export absent`, !/function EmailInspector\(\)/.test(ctxInspectorSrc));

  // PASS 8: Doctrine email-inspector.tsx + UI not regressed
  log(`-- PASS 8: Doctrine UI not regressed --`);
  pass(`email-inspector.tsx still default-exports EmailInspector`, /export default function EmailInspector\(\)/.test(inspectorSrc));
  pass(`email-inspector.tsx still imports typed hooks`, /import \{ useGetSentEmails, useGetThread, useGetGmailAccounts \} from "@workspace\/api-client-react"/.test(inspectorSrc));
  pass(`email-inspector.tsx still uses hasDoctrineLabel`, /hasDoctrineLabel/.test(inspectorSrc));
  pass(`email-inspector.tsx still hits /api/sync`, /fetch\(`\$\{base\}api\/sync`/.test(inspectorSrc));
  pass(`Doctrine /gmail/sent-emails handler still present`, /router\.get\("\/gmail\/sent-emails"/.test(inspectorRouteSrc));
  pass(`Doctrine still uses DOCTRINE_LABELS env var`, /process\.env\.DOCTRINE_LABELS/.test(inspectorRouteSrc));

  // PASS 9: B7c-B7g regression
  log(`-- PASS 9: B7c-B7g regression --`);
  pass(`B7c: SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`B7b: /context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`B7d: Layout product-aware`, /data-product=\{dataProduct\}/.test(layoutSrc));
  pass(`B7d: App.tsx mounts /context/inspector`, /<Route path="\/context\/inspector" component=\{ContextEmailInspector\} \/>/.test(appSrc));
  pass(`B7d: accounts.tsx has Context Gmail label`, /Context Gmail label/.test(accountsSrc));
  pass(`B7e: ContextPipeline default export`, /export default function ContextPipeline\(\)/.test(ctxPipelineSrc));
  pass(`B7e: /context/cancel-followup endpoint`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7f: ContextActivityLog default export`, /export default function ContextActivityLog\(\)/.test(ctxActivitySrc));
  pass(`B7f: /campaign/status returns context_label`, /context_label: u\.contextLabel,/.test(ctxRouteSrc));
  pass(`B7g: /context/gmail/sent-emails endpoint`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`B7g: per-user contextLabel resolution`, /let contextLabelStr = "Context Followuper";/.test(ctxRouteSrc));
  pass(`B7a: users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
