# Batch 7k — Sync→autoqueue gap fix (both products)

Phase 7k. Closes the bug where manually-synced prospects don't appear
in the Pipeline until the next 15-minute cron tick.

## The bug

When a user labels a Gmail thread (with the doctrine label or context
label) and clicks "Sync now", the flow is:

1. `routes/{doctrine,context}.ts /sync` calls `syncEmails` /
   `syncEmailsForUser` from `services/gmailSync.ts`.
2. `gmailSync` ingests labeled threads and inserts rows into
   `prospectsTable` (with `app='doctrine'` or `app='context'`).
3. **Gap**: nothing creates the F1 follow-up row.
4. The Pipeline page (`/pipeline` or `/context/pipeline`) calls
   `/api/{doctrine,context}/followups`, which does
   `from(followupsTable).innerJoin(prospectsTable, …)`.
5. Newly-synced prospects with no follow-up rows are invisible
   (inner join filters them out).
6. Up to 15 minutes later, the */15 cron tick runs sync again followed
   by `autoQueueAllCampaigns()`, which inserts F1 rows for all
   unreplied non-paused prospects across both products. Pipeline
   finally shows the new campaign.

The Inspector pages don't have this problem — they query
`prospectsTable` directly, so newly-synced prospects show as
"IN DATABASE" immediately after sync.

Bug confirmed by:

- `gmailSync.ts` contains zero `insert(followupsTable)` calls.
- `autoQueueAllCampaigns` is referenced only by `cron.ts` (line 22).
- Pipeline's `/followups` query is `innerJoin`, not `leftJoin`.

## What's in this batch

**`routes/doctrine.ts /sync` handler:**
- Restructured to capture `result` from either `syncEmailsForUser` or
  `syncEmails`, then call `autoQueueAllCampaigns()` once after the
  sync completes.
- Wrapped in try/catch — if auto-queue fails for any reason, the sync
  still returns a success response and `logger.warn` records the
  failure (cron will retry on the next tick).
- Existing behavior preserved: input validation for non-string
  `email`, per-user vs all-users branching, structured logging.
- Response shape extended with `auto_queued: N` field. Existing
  fields preserved — purely additive.

**`routes/context.ts /sync` handler:**
- Same fix, mirrored. Response shape extended the same way.

**Why one helper for two products:**
- `autoQueueAllCampaigns` walks all unreplied non-paused prospects
  across both products and queues F1 with each user's stage timing.
- Calling it from `/sync` or `/context/sync` produces identical
  correct behavior: it picks up whatever was just synced (regardless
  of product) and inserts F1 rows.
- Idempotent: `uq_followups_prospect_stage` + `onConflictDoNothing`
  prevent duplicate F1 inserts on subsequent calls.

## What changes for the user

- **Click "Sync now" on `/inspector` or `/context/inspector`**:
  the response includes `auto_queued: N` showing how many F1 stages
  were queued in the same request.
- **Switch to `/pipeline` or `/context/pipeline`**: newly-synced
  campaigns appear immediately on next refresh, no 15-minute wait.
- **Existing campaigns**: zero behavior change. autoQueueAllCampaigns
  is idempotent against existing F1 rows.

## Files

```
batch7k/
├── apply-batch7k.mjs       # Idempotent patch — 2 str_replaces
├── audit-batch7k.mjs       # 9 passes × 3 rounds = 99 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build api-server only (dashboard
unchanged). Mirror sync. Restart api-server.

## Verify

After applying:

- The apply script self-verifies 12 anchors (4 per handler × 2
  handlers + 4 regression).
- The audit runs 99 checks (33 per round × 3 rounds): both `/sync`
  handlers contain Phase 7k comment, dynamic import, call site, and
  spread response. Try/catch wraps the auto-queue call. Doctrine
  handler still has its input validation. The shared helper still
  exported. Cron still wires autoQueue. gmailSync still does not
  insert follow-ups. B7a-B7j regression.

Backend smoke after restart:

```bash
# 1. Sync a single user — response should now include auto_queued
curl -s -X POST "http://localhost:8080/api/sync" \
  -H "x-api-key: $ADDON_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"michael@mobupps.com"}'
# Expect: {synced, repliesDetected, ..., auto_queued: <number>}

# 2. Same but for context
curl -s -X POST "http://localhost:8080/api/context/sync" \
  -H "x-api-key: $ADDON_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"email":"michael@mobupps.com"}'
# Expect: {synced, ..., auto_queued: <number>}

# 3. Check that Pipeline now shows entries
curl -s "http://localhost:8080/api/context/followups" \
  -H "x-api-key: $ADDON_API_KEY" | head -c 500
# Expect: a non-empty array (with the previously-synced prospect's F1)
```

Browser verification:

1. Label a fresh Gmail thread with the Context label.
2. Open `/context/inspector`, click Refresh — see the email in the
   list with SYNCED pill (DB cross-ref worked).
3. Click "Sync now" or refresh — backend will run autoQueue.
4. Switch to `/context/pipeline` — the new prospect appears with an
   F1 stage scheduled. Active counter increments.

## Known residual

- `auto_queued` count returned by `/sync` reflects how many F1 rows
  were inserted across the entire user base in this run, not just for
  the syncer's user. This is by design: `autoQueueAllCampaigns` is
  process-wide, and the function is cheap (idempotent inserts). If a
  per-syncer-user count is wanted later, a scoped variant can be
  added.
- The cron path (every 15 min) still runs autoQueue. After this
  batch, the cron path becomes a fallback / catch-up rather than the
  primary trigger. This is desired.
- The 3-min fast-tick cron only runs `processDueFollowups` (not
  autoQueue). After B7k, that's still correct: fast-tick handles
  already-due rows, autoQueue creates new rows. Different jobs.
