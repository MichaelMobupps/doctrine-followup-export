#!/usr/bin/env node
/**
 * audit-batch7f.mjs — Beautiful-Squidward audit for Phase 7f.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DB_BASE   = process.env.DB_BASE   || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7f] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7f] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const ctxRouteSrc      = read(join(API_BASE, "routes", "context.ts"));
const doctrineRouteSrc = read(join(API_BASE, "routes", "doctrine.ts"));
const indexRouteSrc    = read(join(API_BASE, "routes", "index.ts"));
const ctxActivitySrc   = read(join(DASH_BASE, "pages", "context-activity.tsx"));
const ctxPipelineSrc   = read(join(DASH_BASE, "pages", "context-pipeline.tsx"));
const activityLogSrc   = read(join(DASH_BASE, "pages", "activity-log.tsx"));
const pipelineSrc      = read(join(DASH_BASE, "pages", "pipeline.tsx"));
const layoutSrc        = read(join(DASH_BASE, "components", "layout.tsx"));
const appSrc           = read(join(DASH_BASE, "App.tsx"));
const accountsSrc      = read(join(DASH_BASE, "pages", "accounts.tsx"));
const usersSchema      = read(join(DB_BASE, "schema", "users.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: getFollowupCap helper inlined in context.ts
  log(`-- PASS 1: getFollowupCap helper --`);
  pass(`Helper comment present`, /Phase 7f: shared helper inlined for the \/campaign\/status aggregation/.test(ctxRouteSrc));
  pass(`Helper signature matches doctrine`, /function getFollowupCap\(maxFollowups\?: number \| null\): number \| null \{/.test(ctxRouteSrc));
  pass(`Helper body matches doctrine`, /return typeof maxFollowups === "number" && maxFollowups > 0 \? maxFollowups : null;/.test(ctxRouteSrc));

  // PASS 2: /api/context/campaign/status reshape
  log(`-- PASS 2: /campaign/status reshape --`);
  pass(`Reshape comment present`, /Phase 7f: rich per-user campaign aggregation matching the doctrine/.test(ctxRouteSrc));
  pass(`Projects contextLabel`, /contextLabel: usersTable\.contextLabel,/.test(ctxRouteSrc));
  pass(`Returns context_label in response`, /context_label: u\.contextLabel,/.test(ctxRouteSrc));
  pass(`Returns active boolean`, /active: totalQueued > 0,/.test(ctxRouteSrc));
  pass(`Returns queued_count`, /queued_count: totalQueued,/.test(ctxRouteSrc));
  pass(`Returns sent_count`, /sent_count: totalSent,/.test(ctxRouteSrc));
  pass(`Returns unreplied_prospects`, /unreplied_prospects: totalUnreplied,/.test(ctxRouteSrc));
  pass(`Returns users array`, /users: userCampaigns,/.test(ctxRouteSrc));
  pass(`actionable per user computed`, /actionable: actionableByUser\.get\(u\.id\) \|\| 0,/.test(ctxRouteSrc));

  // PASS 3: /campaign/status uses SCOPE (not SCOPE_DOCTRINE)
  log(`-- PASS 3: scope filter integrity --`);
  pass(`SCOPE referenced in /campaign/status reshape`, (() => {
    // The reshape introduces 3 new uses of SCOPE inside campaignBreakdown,
    // actionableProspects, and followupBreakdown. Total SCOPE refs in
    // context.ts should be at least 8 (was ~5 before the reshape).
    return (ctxRouteSrc.split(/\bSCOPE\b/).length - 1) >= 8;
  })());
  pass(`SCOPE_DOCTRINE not present in context.ts`, !/SCOPE_DOCTRINE/.test(ctxRouteSrc));

  // PASS 4: ContextActivityLog component identity
  log(`-- PASS 4: ContextActivityLog component --`);
  pass(`Default export ContextActivityLog`, /export default function ContextActivityLog\(\)/.test(ctxActivitySrc));
  pass(`Phase 7f header comment`, /Phase 7f: ContextActivityLog — clone of activity-log\.tsx retargeted to/.test(ctxActivitySrc));
  pass(`Title text "Context Activity Log"`, /Context Activity Log\n\s*<\/h1>/.test(ctxActivitySrc));

  // PASS 5: Frontend retargets
  log(`-- PASS 5: Frontend retargets --`);
  pass(`URL retargeted to /api/context/campaign/status`, /api\/context\/campaign\/status/.test(ctxActivitySrc));
  pass(`Type uses context_label`, /context_label: string;/.test(ctxActivitySrc));
  pass(`Render uses {user.context_label}`, /\{user\.context_label\}/.test(ctxActivitySrc));

  // PASS 6: Old shape removed in context-activity.tsx
  log(`-- PASS 6: doctrine_label absent in functional code --`);
  // Comments may reference doctrine_label by name (e.g. "renamed from
  // doctrine_label"). Only the functional code matters: the type
  // declaration and the render binding.
  pass(`doctrine_label type declaration absent`, !/doctrine_label: string;/.test(ctxActivitySrc));
  pass(`{user.doctrine_label} render absent`, !/\{user\.doctrine_label\}/.test(ctxActivitySrc));
  pass(`api/campaign/status (non-context) URL absent`, !/api\/campaign\/status/.test(ctxActivitySrc));
  pass(`function ActivityLog() default-export absent`, !/function ActivityLog\(\)/.test(ctxActivitySrc));
  pass(`Activity Log UI ships in Phase 7f placeholder marker absent`, !/Activity Log UI ships in Phase 7f/.test(ctxActivitySrc));

  // PASS 7: Doctrine activity-log.tsx + UI not regressed
  log(`-- PASS 7: Doctrine UI not regressed --`);
  pass(`activity-log.tsx still default-exports ActivityLog`, /export default function ActivityLog\(\)/.test(activityLogSrc));
  pass(`activity-log.tsx still hits /api/campaign/status`, /api\/campaign\/status/.test(activityLogSrc));
  pass(`activity-log.tsx still uses doctrine_label`, /doctrine_label: string;/.test(activityLogSrc) && /\{user\.doctrine_label\}/.test(activityLogSrc));
  pass(`Doctrine /campaign/status still SCOPE_DOCTRINE-gated`, /SCOPE_DOCTRINE,\s*\n\s*eq\(prospectsTable\.replied, 0\),\s*\n\s*eq\(prospectsTable\.followupPaused, false\),\s*\n\s*inArray\(prospectsTable\.userId!, userIds\),/.test(doctrineRouteSrc));

  // PASS 8: B7e regression — Context Pipeline still working
  log(`-- PASS 8: B7e regression — ContextPipeline intact --`);
  pass(`ContextPipeline default export`, /export default function ContextPipeline\(\)/.test(ctxPipelineSrc));
  pass(`/api/context/followups URL in pipeline`, /api\/context\/followups/.test(ctxPipelineSrc));
  pass(`/api/context/cancel-followup URL in pipeline`, /api\/context\/cancel-followup/.test(ctxPipelineSrc));
  pass(`/api/context/followups response is snake_case`, /original_subject: r\.originalSubject,/.test(ctxRouteSrc));
  pass(`asc imported from drizzle-orm`, /import \{ and, asc, desc, eq, inArray, sql \} from "drizzle-orm"/.test(ctxRouteSrc));

  // PASS 9: B7c/B7a/B7d regression
  log(`-- PASS 9: B7c/B7a/B7d regression --`);
  pass(`SCOPE_DOCTRINE constant in doctrine.ts`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(doctrineRouteSrc));
  pass(`SCOPE_DOCTRINE referenced ≥30 times`, (doctrineRouteSrc.split("SCOPE_DOCTRINE").length - 1) >= 30);
  pass(`/context router mounted`, /router\.use\("\/context", contextRouter\)/.test(indexRouteSrc));
  pass(`Layout product-aware`, /data-product=\{dataProduct\}/.test(layoutSrc));
  pass(`App.tsx mounts /context/activity`, /<Route path="\/context\/activity" component=\{ContextActivityLog\} \/>/.test(appSrc));
  pass(`accounts.tsx has Context Gmail label`, /Context Gmail label/.test(accountsSrc));
  pass(`users.contextLabel schema column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
