#!/usr/bin/env node
/**
 * audit-batch6.mjs — Beautiful-Squidward audit for Phase 6.
 * 3 rounds × 9 passes per round.
 *
 * Verifies scheduler hardening:
 *   - lib/sendBudget.ts and lib/scheduleWindow.ts present and exporting
 *   - UTC pin + assertion in index.ts
 *   - timingEngine uses UTC variants exclusively
 *   - scheduler integrates window + budget gates before atomic claim
 *   - gmail-auth tightens input validation
 *   - bulk send cap lowered to 25
 *   - zero *.batch*.bak files anywhere in api-server tree
 *   - imports actually resolve (helper functions exported as imported)
 *
 * Run AFTER apply-batch6.mjs.
 *
 * Env vars:
 *   API_BASE = path to api-server source (default: artifacts/api-server/src)
 */

import { existsSync, readFileSync, readdirSync, statSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const sendBudgetPath     = join(API_BASE, "lib", "sendBudget.ts");
const scheduleWindowPath = join(API_BASE, "lib", "scheduleWindow.ts");
const indexPath          = join(API_BASE, "index.ts");
const timingEnginePath   = join(API_BASE, "services", "timingEngine.ts");
const schedulerPath      = join(API_BASE, "services", "scheduler.ts");
const gmailAuthPath      = join(API_BASE, "routes", "gmail-auth.ts");
const doctrinePath       = join(API_BASE, "routes", "doctrine.ts");

let totalPasses = 0;
let totalFails = 0;
const failureMessages = [];

function read(path) {
  if (!existsSync(path)) throw new Error(`File missing: ${path}`);
  return readFileSync(path, "utf-8");
}

function check(label, condition, detail = "") {
  totalPasses++;
  if (condition) {
    console.log(`    [PASS] ${label}`);
  } else {
    totalFails++;
    failureMessages.push(`${label}${detail ? " — " + detail : ""}`);
    console.log(`    [FAIL] ${label}${detail ? " — " + detail : ""}`);
  }
}

function countIn(path, needle) {
  return read(path).split(needle).length - 1;
}

function walkAll(dir) {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const n of readdirSync(dir)) {
    const full = join(dir, n);
    const st = statSync(full);
    if (st.isDirectory()) out.push(...walkAll(full));
    else if (st.isFile()) out.push(full);
  }
  return out;
}

function runOneRound(roundNum) {
  console.log(`\n--- Round ${roundNum} ---`);

  // PASS 1: Library files present and exporting expected symbols
  console.log(`  PASS 1: Helper libs present`);
  check("1a. sendBudget.ts present", existsSync(sendBudgetPath));
  check("1b. scheduleWindow.ts present", existsSync(scheduleWindowPath));
  if (existsSync(sendBudgetPath)) {
    const sb = read(sendBudgetPath);
    check("1c. sendBudget exports checkSendBudget", sb.includes(`export async function checkSendBudget`));
    check("1d. sendBudget reads DOCTRINE_HOURLY_SEND_CAP", sb.includes(`DOCTRINE_HOURLY_SEND_CAP`));
    check("1e. sendBudget reads DOCTRINE_DAILY_SEND_CAP", sb.includes(`DOCTRINE_DAILY_SEND_CAP`));
  }
  if (existsSync(scheduleWindowPath)) {
    const sw = read(scheduleWindowPath);
    check("1f. scheduleWindow exports isInSendWindow", sw.includes(`export function isInSendWindow`));
    check("1g. scheduleWindow uses getUTCDay/getUTCHours", sw.includes(`getUTCDay()`) && sw.includes(`getUTCHours()`));
  }

  // PASS 2: Boot-time UTC pin + assertion
  console.log(`  PASS 2: UTC boot pin`);
  const idx = read(indexPath);
  check("2a. index.ts pins process.env.TZ to UTC", idx.includes(`process.env.TZ = "UTC";`));
  check("2b. index.ts asserts Intl resolved tz is UTC",
    idx.includes(`Intl.DateTimeFormat()`) && /resolvedOptions\(\).timeZone\s*!==\s*"UTC"/.test(idx));
  check("2c. UTC pin precedes app/cron imports",
    /process\.env\.TZ\s*=\s*"UTC";\s*[\r\n]+\s*import app/.test(idx));

  // PASS 3: timingEngine uses UTC variants
  console.log(`  PASS 3: timingEngine UTC normalization`);
  const te = read(timingEnginePath);
  check("3a. timingEngine has getUTCDay (Phase 6)", te.includes(`getUTCDay()`));
  check("3b. timingEngine has setUTCDate (Phase 6)", te.includes(`setUTCDate(`));
  check("3c. timingEngine has setUTCHours", te.includes(`setUTCHours(`));
  check("3d. timingEngine has zero remaining setHours/getHours/getDay/setDate calls",
    !/(?<![Uu])\.setHours\(|(?<![Uu])\.getHours\(|(?<![Uu])\.getDay\(|(?<![Uu])\.setDate\(/.test(te));

  // PASS 4: Scheduler integrates window + budget gates
  console.log(`  PASS 4: Scheduler gates`);
  const sched = read(schedulerPath);
  check("4a. scheduler imports isInSendWindow", sched.includes(`import { isInSendWindow }`));
  check("4b. scheduler imports checkSendBudget", sched.includes(`import { checkSendBudget }`));
  check("4c. scheduler has Phase 6 gate A (send-window)", sched.includes(`Phase 6 gate A: send-window enforcement`));
  check("4d. scheduler has Phase 6 gate B (rate limiter)", sched.includes(`Phase 6 gate B: per-user send rate limiter`));
  check("4e. window gate calls isInSendWindow with userForWindow",
    /isInSendWindow\(userForWindow,\s*new Date\(\)\)/.test(sched));
  check("4f. budget gate calls checkSendBudget with userId",
    /checkSendBudget\(\{\s*userId:\s*item\.userId\s*\}\)/.test(sched));
  check("4g. both gates respect forceSend bypass",
    countIn(schedulerPath, `!options?.forceSend && item.userId`) >= 2);

  // PASS 5: gmail-auth input validation
  console.log(`  PASS 5: Input validation`);
  const ga = read(gmailAuthPath);
  check("5a. gmail-auth rejects empty sendDays", ga.includes(`Phase 6: require at least one valid day`));
  check("5b. gmail-auth returns 400 for empty sendDays",
    /sendDays must contain at least one valid day/.test(ga));
  check("5c. gmail-auth validates sendHour bounds", ga.includes(`Phase 6: send-hour bounds must form a non-empty`));
  check("5d. gmail-auth returns 400 for invalid sendHour bounds",
    /sendHourStart and sendHourEnd must satisfy/.test(ga));

  // PASS 6: Bulk send cap lowered
  console.log(`  PASS 6: Bulk send cap`);
  const dr = read(doctrinePath);
  check("6a. bulk endpoint uses cap=25", dr.includes(`Bulk send limited to 25 prospects per call`));
  check("6b. bulk endpoint enforces cap before processing",
    /if \(ids\.length > 25\)/.test(dr));
  check("6c. no remaining reference to old cap=100",
    !/Bulk send limited to 100 prospects per call/.test(dr));

  // PASS 7: Cron schedules unchanged from Batch 4 (no accidental cron drift)
  console.log(`  PASS 7: Cron stability`);
  const cron = read(join(API_BASE, "cron.ts"));
  check("7a. weekly-digest cron still present", cron.includes(`cron.schedule("0 0 * * 2"`));
  check("7b. draft-stall cron still present", cron.includes(`cron.schedule("30 0 * * *"`));
  check("7c. main process cron still present", cron.includes(`cron.schedule("5,20,35,50 * * * *"`));
  check("7d. fast-tick cron still present", cron.includes(`cron.schedule("*/3 * * * *"`));
  check("7e. sync+auto-queue cron still present", cron.includes(`cron.schedule("*/15 * * * *"`));

  // PASS 8: Zero *.bak files anywhere in api-server
  console.log(`  PASS 8: No backup files anywhere`);
  const allFiles = walkAll(API_BASE);
  const bakFiles = allFiles.filter((f) => f.endsWith(".bak"));
  check("8a. zero .bak files in api-server tree", bakFiles.length === 0, bakFiles.join(", "));
  const batchBaks = allFiles.filter((f) => /\.batch[^/]*\.bak$/.test(f));
  check("8b. zero .batch*.bak files specifically", batchBaks.length === 0, batchBaks.join(", "));

  // PASS 9: Import resolution — gates' imported helpers actually exist
  console.log(`  PASS 9: Import resolution`);
  if (existsSync(sendBudgetPath)) {
    const sb = read(sendBudgetPath);
    check("9a. checkSendBudget signature accepts {userId}",
      /export async function checkSendBudget\(args:\s*\{\s*userId:\s*number/.test(sb));
  }
  if (existsSync(scheduleWindowPath)) {
    const sw = read(scheduleWindowPath);
    check("9b. isInSendWindow signature takes (user, now)",
      /export function isInSendWindow\(user:\s*SendWindowUserView,\s*now:\s*Date\)/.test(sw));
    check("9c. SendWindowUserView matches userCache row shape (sendDays/sendHourStart/sendHourEnd)",
      sw.includes(`sendDays: number[]`) && sw.includes(`sendHourStart: number`) && sw.includes(`sendHourEnd: number`));
  }
  // Also: scheduler's userCache holds usersTable.$inferSelect rows, which include
  // those three fields. So the type compatibility should hold at compile time.
  check("9d. scheduler passes the cached user record into isInSendWindow",
    /const userForWindow = userCache\.get\(item\.userId\)/.test(sched));
}

console.log("================================================================");
console.log("Batch 6 audit — 3 rounds × 9 passes (Beautiful-Squidward)");
console.log("================================================================");

for (let round = 1; round <= 3; round++) {
  runOneRound(round);
}

console.log("");
console.log("================================================================");
console.log(`Total: ${totalPasses - totalFails}/${totalPasses} passed across 3 rounds.`);
if (totalFails > 0) {
  console.log(`FAILURES (${totalFails}):`);
  for (const m of failureMessages) console.log(`  - ${m}`);
  console.log("================================================================");
  process.exit(1);
} else {
  console.log("All passes succeeded across all 3 rounds.");
  console.log("================================================================");
}
