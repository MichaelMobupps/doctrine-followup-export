import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ApiKeyContextProvider } from "@/hooks/use-api-key";
import { CurrentUserProvider } from "@/hooks/use-current-user";
import { ApiKeyGate } from "@/components/api-key-provider";
import { Layout } from "@/components/layout";

import Prospects from "@/pages/prospects";
import Followups from "@/pages/followups";
import EmailInspector from "@/pages/email-inspector";
import Accounts from "@/pages/accounts";
import ActivityLog from "@/pages/activity-log";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Prospects} />
      <Route path="/prospects" component={Prospects} />
      <Route path="/followups" component={Followups} />
      <Route path="/inspector" component={EmailInspector} />
      <Route path="/accounts" component={Accounts} />
      <Route path="/activity" component={ActivityLog} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <CurrentUserProvider>
      <ApiKeyContextProvider>
        <ApiKeyGate>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
            <Layout>
              <Router />
            </Layout>
          </WouterRouter>
        </ApiKeyGate>
      </ApiKeyContextProvider>
      </CurrentUserProvider>
    </QueryClientProvider>
  );
}

export default App;
