#!/usr/bin/env python3
"""
B9c.1b - Frontend: AG inspector shows seed-annotated thread messages.

Switches the inspector's ThreadView component from the shared
/api/gmail/thread/:id endpoint to the new AG-specific
/api/anti-ghosting/thread/:gmailThreadId/messages?userId=N (from B9c.1a),
which returns parsed messages with direction tags + isSeed flag.

Field mapping (old shape -> new shape):
  msg.isFromMe       -> msg.direction === "outbound"
  msg.from           -> msg.fromName || msg.fromHeader
  msg.date           -> msg.sentAt (ISO string)
  msg.body, snippet  -> same names (ThreadMessageBrief has both)
  data.messageCount  -> data.messages?.length
  data.hasExternalReply -> data.messages?.some(m => m.direction === "inbound")
  + new: msg.isSeed -> renders a SEED badge in the message header

Three plumbing changes + four ThreadView body changes + one page-level
prop = eight surgical edits.

userId plumbing chain:
  Page (selectedUserId) -> EmailCard prop -> ThreadView prop -> fetch URL

One file (anti-ghosting-inspector.tsx). All anchors uniqueness-checked.
Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INSPECTOR = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-inspector.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# E1: EmailCard signature - add userId prop
# ====================================================================
E1_OLD = '''function EmailCard({ email, apiKey }: { email: SentEmail; apiKey: string }) {'''
E1_NEW = '''// B9c.1b: EmailCard now plumbs userId down to ThreadView for seed lookup.
function EmailCard({ email, apiKey, userId }: { email: SentEmail; apiKey: string; userId: string }) {'''


# ====================================================================
# E2: EmailCard's ThreadView call - add userId
# ====================================================================
E2_OLD = '''                  <ThreadView threadId={email.threadId} apiKey={apiKey} />'''
E2_NEW = '''                  <ThreadView threadId={email.threadId} apiKey={apiKey} userId={userId} />'''


# ====================================================================
# E3: ThreadView signature + leading comment
# ====================================================================
E3_OLD = '''function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {
  // /api/gmail/thread is shared between products (a Gmail thread is product-agnostic).'''
E3_NEW = '''function ThreadView({ threadId, apiKey, userId }: { threadId: string; apiKey: string; userId: string }) {
  // B9c.1b: AG inspector uses /api/anti-ghosting/thread/:id/messages to surface
  // seed annotations (which message is being used as AI context for F1/F2/F3).'''


# ====================================================================
# E4: ThreadView fetch URL
# ====================================================================
E4_OLD = '''    fetch(`${base}api/gmail/thread/${threadId}`, {
      headers: { "x-api-key": apiKey || "" },
    })'''
E4_NEW = '''    fetch(`${base}api/anti-ghosting/thread/${threadId}/messages?userId=${encodeURIComponent(userId)}`, {
      headers: { "x-api-key": apiKey || "" },
    })'''


# ====================================================================
# E5: useEffect deps - add userId
# ====================================================================
E5_OLD = '''  }, [threadId, apiKey]);'''
E5_NEW = '''  }, [threadId, apiKey, userId]);'''


# ====================================================================
# E6: messageCount + hasExternalReply derived from messages[]
# ====================================================================
E6_OLD = '''        <span>{data.messageCount} message{data.messageCount !== 1 ? "s" : ""}</span>
        {data.hasExternalReply ? (
          <Badge variant="success">REPLY</Badge>
        ) : (
          <Badge variant="outline">NO REPLY</Badge>
        )}'''
E6_NEW = '''        <span>{data.messages?.length ?? 0} message{(data.messages?.length ?? 0) !== 1 ? "s" : ""}</span>
        {data.messages?.some((m: any) => m.direction === "inbound") ? (
          <Badge variant="success">REPLY</Badge>
        ) : (
          <Badge variant="outline">NO REPLY</Badge>
        )}'''


# ====================================================================
# E7: Per-message rendering - swap isFromMe for direction-based check,
# from/date for fromName/sentAt, and inject SEED badge.
# ====================================================================
E7_OLD = '''      {data.messages?.map((msg: any) => (
        <div
          key={msg.id}
          className={cn("rounded-lg p-3 text-[13px]", msg.isFromMe ? "ml-6" : "mr-6")}
          style={{
            background: msg.isFromMe ? "var(--accent-muted)" : "var(--success-muted)",
            border: msg.isFromMe ? "1px solid var(--accent-border)" : "1px solid var(--success-border)",
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-[12px]" style={{ color: "var(--text-primary)" }}>
              {msg.isFromMe ? "Me" : msg.from}
            </span>
            <span className="text-[11px]" style={{ color: "var(--text-tertiary)" }}>
              {msg.date ? format(new Date(msg.date), "MMM d, HH:mm") : ""}
            </span>
          </div>
          <p className="whitespace-pre-wrap text-[12px] leading-relaxed max-h-32 overflow-hidden" style={{ color: "var(--text-secondary)" }}>
            {msg.body || msg.snippet}
          </p>
        </div>
      ))}'''

E7_NEW = '''      {/* B9c.1b: direction-based styling + SEED badge for the AI's context anchor. */}
      {data.messages?.map((msg: any) => (
        <div
          key={msg.id}
          className={cn("rounded-lg p-3 text-[13px]", msg.direction === "outbound" ? "ml-6" : "mr-6")}
          style={{
            background: msg.direction === "outbound" ? "var(--accent-muted)" : "var(--success-muted)",
            border: msg.direction === "outbound" ? "1px solid var(--accent-border)" : "1px solid var(--success-border)",
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="font-medium text-[12px] truncate" style={{ color: "var(--text-primary)" }}>
                {msg.direction === "outbound" ? "Me" : (msg.fromName || msg.fromHeader)}
              </span>
              {msg.isSeed && (
                <Badge variant="success" className="text-[10px] uppercase tracking-wide flex-shrink-0">SEED</Badge>
              )}
            </div>
            <span className="text-[11px] flex-shrink-0" style={{ color: "var(--text-tertiary)" }}>
              {msg.sentAt ? format(new Date(msg.sentAt), "MMM d, HH:mm") : ""}
            </span>
          </div>
          <p className="whitespace-pre-wrap text-[12px] leading-relaxed max-h-32 overflow-hidden" style={{ color: "var(--text-secondary)" }}>
            {msg.body || msg.snippet}
          </p>
        </div>
      ))}'''


# ====================================================================
# E8: Page-level EmailCard call - pass selectedUserId
# ====================================================================
E8_OLD = '''            <EmailCard key={email.id} email={email} apiKey={apiKey || ""} />'''
E8_NEW = '''            <EmailCard key={email.id} email={email} apiKey={apiKey || ""} userId={selectedUserId} />'''


def main():
    if not INSPECTOR.exists():
        fail(f"inspector not found: {INSPECTOR}")
    text = INSPECTOR.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(text, E1_OLD, E1_NEW,
        "E1: EmailCard signature add userId",
        marker="B9c.1b: EmailCard now plumbs userId")

    text, _ = replace_unique(text, E2_OLD, E2_NEW,
        "E2: ThreadView call add userId prop",
        marker='<ThreadView threadId={email.threadId} apiKey={apiKey} userId={userId} />')

    text, _ = replace_unique(text, E3_OLD, E3_NEW,
        "E3: ThreadView signature + comment",
        marker="B9c.1b: AG inspector uses /api/anti-ghosting/thread")

    text, _ = replace_unique(text, E4_OLD, E4_NEW,
        "E4: ThreadView fetch URL",
        marker="api/anti-ghosting/thread/${threadId}/messages")

    text, _ = replace_unique(text, E5_OLD, E5_NEW,
        "E5: useEffect deps add userId",
        marker="[threadId, apiKey, userId]")

    text, _ = replace_unique(text, E6_OLD, E6_NEW,
        "E6: messageCount/hasExternalReply derivation",
        marker='data.messages?.some((m: any) => m.direction === "inbound")')

    text, _ = replace_unique(text, E7_OLD, E7_NEW,
        "E7: per-message render direction + SEED badge",
        marker="B9c.1b: direction-based styling + SEED badge")

    text, _ = replace_unique(text, E8_OLD, E8_NEW,
        "E8: page-level EmailCard pass userId",
        marker='userId={selectedUserId}')

    if text != original:
        INSPECTOR.write_text(text, encoding="utf-8")
        ok(f"wrote {INSPECTOR.relative_to(WORKSPACE)}")
    else:
        skip("inspector already patched")

    print()
    print("B9c.1b seed-annotated thread view applied.")


if __name__ == "__main__":
    main()
