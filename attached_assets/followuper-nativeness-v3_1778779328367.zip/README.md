# Followuper Nativeness v3 — Reading-A++

TypeScript port of the Prospector v3 nativeness policy to the MobUpps
Followuper (Doctrine Follow-up monorepo). Companion to the Prospector
`nativeness_v3.py` shipped earlier; both products now share the same
Reading-A++ policy and the same detector behaviour.

---

## What this delivers

A strict localization standard for all 35 supported languages, plus two
universal style rules that apply to every language including English.

### Reading-A++ (for non-English emails)

The ONLY Latin tokens permitted inside the email body are:

1. **Pure acronyms** from a curated allowlist: CPI, CPA, CPM, CPC, CTR,
   CVR, ROAS, ROI, AOV, ARPU, ARPPU, ARPDAU, LTV, MAU, DAU, D1, D3, D7,
   D14, D30, D60, D90, MMP, SDK, IAP, OEM, API, KPI, KYC, AML, AI, ML,
   NLP, LLM, DSP, SSP, RTB, B2B, B2C, iOS, USD, EUR, and a long list of
   sector acronyms and currency codes (144 entries total).

2. **Proper nouns**: company brand names (Meta, Google, Apple, TikTok,
   Snapchat, Xiaomi, Huawei, OPPO, Vivo, AppsFlyer, Adjust, MobUpps,
   etc.), the prospect's own brand and product names, and any
   third-party brand or service named in the email.

EVERY OTHER English word — single tokens AND multi-word phrases — must
be translated. This includes capitalized loan-nouns like German
"Conversion" → "Umwandlung", "Performance" → "Leistung", "Retention" →
"Kundenbindung". The historical v2 ENGLISH-TOLERANT carve-out for
German / Dutch / Nordics and the ENGLISH-HEAVY carve-out for
Vietnamese / Thai / Indonesian / Malay / Filipino / Swahili are removed.

### Universal style rules (apply to every language)

- **X-not-Y comma-negation pattern is banned.** "performance partners,
  not raw installs" is forbidden in English; ", nicht" in German,
  ", не" in Russian, ", ไม่ใช่" in Thai, ", không phải" in Vietnamese,
  ", 不是" in Chinese, ", ではなく" in Japanese are also banned. Use
  "rather than" / "instead of" or rephrase.

- **Greeting-name transliteration** (non-Latin scripts only). The
  prospect's first name in the greeting must be in the target script:
  "เรียน Songsitt" must be "เรียน ทรงสิทธิ์"; "Hi Manish" inside a
  Hindi body must be "नमस्ते मनीश". The sender's signature at the
  bottom stays in Latin.

---

## Bundle contents

```
followuper-nativeness-v3.zip
├── README.md                          (this file)
├── followuper/
│   ├── lib/nativenessV3.ts            (~1100 lines, new module)
│   └── tests/
│       ├── test-nativeness-v3.ts      (67 tests, all pass)
│       └── test-doctrine-hardening.ts (29 tests, v3-updated assertions)
└── patches/
    └── apply_patches.py               (15 ops, idempotent)
```

The patch script installs the new module, the new test, the updated
existing test, and applies 12 anchor-based edits across three files:
`lib/languageNativeness.ts`, `lib/doctrineLint.ts`,
`services/followupPrompts.ts`.

---

## What gets patched

1. **`lib/nativenessV3.ts`** — new module. Exports data tables
   (LATIN_ALLOWLIST, FORBIDDEN_ENGLISH_PHRASES, FORBIDDEN_ENGLISH_SINGLETONS,
   BOILERPLATE_LATIN, X_NOT_Y_PATTERNS, NON_LATIN_SCRIPT_LANGS,
   VIETNAMESE_DIACRITIC_SET), 5 detectors, the aggregator
   `findAllNativenessViolations`, and the prompt builders
   `buildNativenessBlockV3` + `buildCriticNativenessBlockV3`.

2. **`lib/languageNativeness.ts`** — `buildNativenessBlock` and
   `buildCriticNativenessBlock` become thin forwarders to the v3
   builders. The v2 bodies are renamed to `_v2_LEGACY_REMOVED` and
   retained for the audit trail. Static ESM import added at the top.

3. **`lib/doctrineLint.ts`** — `detectNativenessViolations` becomes a
   v3 aggregator that runs all 5 v3 detectors and folds them into the
   same `ViolationReport` shape (`{found, issues, suggestions,
   matches}`) so callers keep working unchanged. The v1 body is
   renamed to `_v1_LEGACY_REMOVED`. Static ESM import added at the top.

4. **`services/followupPrompts.ts`** — six prompt-section edits:

   - **Critic criterion 4 (LANGUAGE NATURALNESS)** — rewritten for
     Reading-A++. The "Russian/Chinese/Spanish translate nearly
     everything; Vietnamese/Thai/Indonesian/Filipino keep nearly
     everything in English; German/Dutch/Nordic are mixed" text is
     removed.
   - **Critic criterion 9 sub-rule (d)** — was narrow
     "NO CPA-AS-DIFFERENTIATOR", now universal X-NOT-Y ban across all
     35 languages.
   - **Critic criterion 10 (new)** — UNTRANSLITERATED GREETING NAME
     for non-Latin-script targets.
   - **Rewriter LANGUAGE NATURALNESS bullet** — rewritten for
     Reading-A++ to match the critic; without this update, the rewriter
     would "fix" against v2 norms and ping-pong with the critic.
   - **Rewriter DOCTRINE bullet** — universal X-NOT-Y ban.
   - **Writer doctrine bullet 4** — universal X-NOT-Y ban.
   - **Writer LANGUAGE NATIVENESS bullet** — Reading-A++ baseline.

The writer's runtime prompt continues to inject the per-language
`buildNativenessBlock` block via `getFollowupUserPrompt`; the v3
forwarder ensures that block is now the Reading-A++ version with the
per-language translation reference table.

---

## What does NOT change

- The `ViolationReport` shape (`{found, issues, suggestions, matches}`)
  is preserved exactly. Existing callers in `followupGenerator.ts` and
  `contextFollowupGenerator.ts` keep working unchanged.
- The 9 existing critic criteria (1-9) are preserved. Only the wording
  of criteria 4 and 9d changes; new criterion 10 is added.
- The 6 exported prompt-builder functions (writer system + user,
  critic system + user, rewriter system + user) are all still exported.
- The context-follow-up flow (`contextFollowupPrompts.ts`,
  `contextFollowupGenerator.ts`) is intentionally unchanged. Its critic
  is simpler (5 dimensions, faithfulness + tone + brevity) and does not
  reference the nativeness blocks. The v3 deterministic lint still
  fires via `detectAllDeterministicViolations` for both flows.
- The legacy v1/v2 function bodies are retained (renamed to
  `_LEGACY_REMOVED`) for audit and rollback reference.

---

## Audit results

**5-round godlike audit, 37 of 37 checks PASS, 0 FAIL, 0 WARN.**

- **Round 1 — Patch correctness (5/5):** 15/15 OK on fresh apply;
  15/15 SKIP on idempotent second run; 3 backups byte-identical to
  snapshot; FAIL on missing anchor; installed nativenessV3.ts is
  byte-identical to payload.
- **Round 2 — Behavioral coverage (5/5):** 67/67 tests pass; v3 strips
  ENGLISH-TOLERANT/ENGLISH-HEAVY carve-outs for de/vi/th; X-not-Y
  across 8 langs; greeting-name across 8 scripts; 6 production fixtures
  all behave correctly.
- **Round 3 — Runtime correctness (7/7):** strict tsc clean on
  nativenessV3.ts in isolation; on patched languageNativeness.ts; on
  patched doctrineLint.ts; no runtime require() calls (ESM safe);
  static imports present; template-literal backticks balanced (32).
- **Round 4 — End-to-end wiring (12/12):** writer forwarder body,
  critic forwarder body, lint aggregator wired, criterion 10 present,
  v3 markers on critic + rewriter + writer prompts (6 markers), legacy
  v2 carve-out text removed everywhere, legacy "NO CPA-AS-DIFFERENTIATOR"
  removed everywhere.
- **Round 5 — Regression risk (8/8):** line deltas reasonable
  (lang +29, lint +100, prompts +2); ViolationReport contract
  preserved; all 10 critic criteria present; rollback restores snapshot
  byte-identical; legacy v1/v2 bodies retained for audit; all 6
  prompt-builder exports intact; existing `test-doctrine-hardening.ts`
  passes 29/29 (with v3-updated assertions for the 5 v1-era tests that
  v3 explicitly supersedes).

---

## Deploy

The live Followuper code lives at `artifacts/api-server/src/` on the
Replit workspace, not at `source-code/api-server/` (which is the
read-only mirror updated by `source-code/sync.sh`).

To deploy:

1. Unzip the bundle on the Replit workspace.
2. Run `python3 patches/apply_patches.py artifacts/api-server/src`.
3. Run `pnpm --filter @workspace/api-server run typecheck`.
4. Run the two test files: `node --import ... --test tests/test-nativeness-v3.ts` and `node --import ... --test tests/test-doctrine-hardening.ts`.
5. Run `pnpm --filter @workspace/api-server run build`.
6. Run the mirror sync (`source-code/sync.sh` or `scripts/sync-source-code.sh`).
7. Restart the api-server workflow.

The bash deploy block in the chat message ships all of the above as a
single copyable command sequence.

---

## Behavioural changes after deploy

- German emails: capitalized loan-nouns like "Conversion", "Performance",
  "Retention" will start firing as violations and be translated to
  "Umwandlung", "Leistung", "Kundenbindung".
- Vietnamese / Thai / Indonesian / Malay / Filipino / Swahili emails:
  the "single tokens MAY stay in English" carve-out is gone. Words like
  "retention", "install", "cohort" will be flagged and translated.
- All non-English emails: every English content word and every
  multi-word English phrase that previously slipped through under a
  language-specific carve-out will now be caught.
- Non-Latin-script emails: the prospect's first name in the greeting
  will be transliterated into the target script. Sender signature
  remains in Latin.
- All languages including English: the X-not-Y comma-negation pattern
  (", not Y" / ", не Y" / ", nicht Y" / ", ไม่ใช่ Y" / etc.) will be
  flagged and rewritten as "rather than" / "instead of" / or rephrased.

Expect a transient bump in critic-flagged drafts in the first few hours
after deploy as the writer adjusts. The rewriter is patched in lockstep
so the rewrite cycle converges within 1-2 rounds.
