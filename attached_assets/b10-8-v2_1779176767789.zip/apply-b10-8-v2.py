#!/usr/bin/env python3
"""
B10.8 v2 - Recovery for B10.8 partial application.

The v1 patcher's A2 marker matched a different component's closing
pattern (likely SummaryCard, which returns <Card>...</Card> without
a motion wrapper). False-positive on the "already applied" check
caused A2 to skip while A1 had already swapped the opening tag.
Result: <Card initial={false}>...</motion.div> mismatch, TS errors.

v2 applies only A2 (the missed close-tag rewrite). Other anchors
(A1, A3, A4, A5) already applied successfully and don't need retouching.

A2 transforms in UserCard:
      </Card>
    </motion.div>
  );
}
to:
    </Card>
  );
}

Single anchor. Pure OLD-presence check, no marker.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ACT = WORKSPACE / "artifacts/dashboard/src/pages/activity-log.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


# A2 close-tag rewrite. The OLD pattern is unique - 6-space </Card>
# followed by 4-space </motion.div>. Only the UserCard's closing pair
# has this shape (idle-user's closing was 14-space + 12-space, already
# handled by A4 in v1).
OLD = '''      </Card>
    </motion.div>'''

NEW = '''    </Card>'''


def main():
    if not ACT.exists():
        fail(f"activity-log.tsx not found: {ACT}")
    text = ACT.read_text(encoding="utf-8")

    count = text.count(OLD)
    if count == 0:
        print("[skip] OLD anchor not found - assuming already fixed")
        return
    if count != 1:
        fail(f"OLD anchor matched {count} times; expected 1")

    text = text.replace(OLD, NEW)
    ACT.write_text(text, encoding="utf-8")
    print("[ok]   A2 (close-tag rewrite): updated")
    print(f"[ok]   wrote {ACT.relative_to(WORKSPACE)}")
    print()
    print("B10.8 v2 recovery applied.")


if __name__ == "__main__":
    main()
