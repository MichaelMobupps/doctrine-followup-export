#!/usr/bin/env python3
r"""
B9c.2 — wire the AntiGhosting generator into the scheduler dispatcher.

Three files modified, total of 9 edits. Each edit uses anchor-based
text replacement; idempotency via NEW-first check (skips when the
post-edit state is already present).

Files and edits:

1. lib/anthropic.ts
   - Add MODEL_ANTI_GHOSTING_GENERATOR / CRITIC / REWRITER constants.

2. lib/usageContext.ts
   - Widen UsageAttribution.app union to include "anti_ghosting".

3. artifacts/api-server/src/services/scheduler.ts
   - Add imports for parseGmailThread, computeDaysSinceSeedTier,
     generateAntiGhostingFollowup, AntiGhostingFollowupContext.
   - Add `cycle: followupsTable.cycle` to the dispatcher SELECT.
   - Remove the B9c.1 exclusion filter line.
   - Add `eq(followupsTable.cycle, item.cycle)` to the
     previousFollowups WHERE (cycle scoping).
   - Insert the AntiGhostingFollowupContext build block before the
     existing FollowupContext assembly.
   - Widen the runWithUsageContext app discriminator to handle
     "anti_ghosting".
   - Widen the dispatch ternary to a three-branch conditional.

Run from the workspace root:
    python3 apply-b9c2.py
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    """
    Apply a list of (old, new, label) edits to a file.
    NEW-first check: if NEW already in content, SKIP. Otherwise replace
    OLD with NEW. Returns (applied, already_applied, warns).
    """
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        if new == "":
            # Deletion edit. Empty NEW would trivially match every string,
            # so we cannot use the NEW-first check for these. Idempotency
            # is provided by checking OLD: if OLD is absent, the deletion
            # has already happened.
            if old in content:
                content = content.replace(old, "", 1)
                print(f"  FIX  {path}: {label} (deletion)")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — deletion already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    totals = [0, 0, 0]  # applied, already, warns

    # ────────────────────────────────────────────────────────────────
    # File 1: lib/anthropic.ts — add 3 model aliases
    # ────────────────────────────────────────────────────────────────
    print("\n--- artifacts/api-server/src/lib/anthropic.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/lib/anthropic.ts",
        [
            (
                'export const MODEL_CONTEXT_REWRITER:  "claude-sonnet-4-6" = "claude-sonnet-4-6";\n',
                'export const MODEL_CONTEXT_REWRITER:  "claude-sonnet-4-6" = "claude-sonnet-4-6";\n'
                '// B9c.2: AntiGhosting flow uses the same models as Context for now.\n'
                '// Aliases let us swap independently later without touching call sites.\n'
                'export const MODEL_ANTI_GHOSTING_GENERATOR: "claude-sonnet-4-6" = "claude-sonnet-4-6";\n'
                'export const MODEL_ANTI_GHOSTING_CRITIC:    "claude-opus-4-7"   = "claude-opus-4-7";\n'
                'export const MODEL_ANTI_GHOSTING_REWRITER:  "claude-sonnet-4-6" = "claude-sonnet-4-6";\n',
                "add MODEL_ANTI_GHOSTING_* constants",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ────────────────────────────────────────────────────────────────
    # File 2: lib/usageContext.ts — widen app union
    # ────────────────────────────────────────────────────────────────
    print("\n--- artifacts/api-server/src/lib/usageContext.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/lib/usageContext.ts",
        [
            (
                '  app: "doctrine" | "context";\n',
                '  app: "doctrine" | "context" | "anti_ghosting";\n',
                'widen UsageAttribution.app union',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ────────────────────────────────────────────────────────────────
    # File 3: services/scheduler.ts — 7 edits
    # ────────────────────────────────────────────────────────────────
    sched_path = "artifacts/api-server/src/services/scheduler.ts"
    print(f"\n--- {sched_path} ---")

    # Edit 3a: imports — append AntiGhosting-related imports after the
    # existing followupGenerator import block.
    a, b, w = patch_file(
        sched_path,
        [
            (
                'import { generateFollowupEmail } from "./followupGenerator";\n',
                'import { generateFollowupEmail } from "./followupGenerator";\n'
                '// B9c.2: AntiGhosting generator wiring + thread re-read helper.\n'
                'import { generateAntiGhostingFollowup } from "./antiGhostingFollowupGenerator";\n'
                'import { computeDaysSinceSeedTier } from "./antiGhostingFollowupPrompts";\n'
                'import type { AntiGhostingFollowupContext } from "./antiGhostingFollowupPrompts";\n'
                'import { parseGmailThread } from "./antiGhostingValidators";\n'
                'import { getGmailForUser } from "./gmailClient";\n',
                'add AntiGhosting + Gmail imports',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # Edit 3b: add cycle to the SELECT
    a, b, w = patch_file(
        sched_path,
        [
            (
                '      // Phase 7b: discriminator for which generator to use per row.\n'
                '      app: prospectsTable.app,\n'
                '    })\n',
                '      // Phase 7b: discriminator for which generator to use per row.\n'
                '      app: prospectsTable.app,\n'
                '      // B9c.2: cycle is needed both for AntiGhosting context build\n'
                '      // and for cycle-scoped previousFollowups query.\n'
                '      cycle: followupsTable.cycle,\n'
                '    })\n',
                'add cycle to dispatcher SELECT',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # Edit 3c: remove the B9c.1 exclusion filter
    a, b, w = patch_file(
        sched_path,
        [
            (
                '    // B9c.1: gate the dispatcher off anti_ghosting until B9c.2\n'
                '    // ships the real generator + proper dispatch branch.\n'
                '    // Without this line, any anti_ghosting row that became "queued"\n'
                '    // would fall through to the doctrine generator and produce\n'
                '    // wrong-voice content. Remove this line as part of B9c.2.\n'
                '    ne(prospectsTable.app, "anti_ghosting"),\n',
                '',
                'remove B9c.1 anti_ghosting exclusion filter',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # Edit 3d: cycle-scope the previousFollowups query
    a, b, w = patch_file(
        sched_path,
        [
            (
                '              eq(followupsTable.prospectId, item.prospectId),\n'
                '              eq(followupsTable.status, "sent"),\n'
                '              lt(followupsTable.stage, item.stage),\n',
                '              eq(followupsTable.prospectId, item.prospectId),\n'
                '              eq(followupsTable.status, "sent"),\n'
                '              lt(followupsTable.stage, item.stage),\n'
                '              // B9c.2: cycle scoping — AntiGhosting renewals re-use\n'
                '              // stage numbers across cycles, so prior-stage queries\n'
                '              // MUST filter by the same cycle. Doctrine/context have\n'
                '              // cycle=1 default so this is a no-op for them.\n'
                '              eq(followupsTable.cycle, item.cycle),\n',
                'cycle-scope the previousFollowups query',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # Edit 3e: insert the anti-ghosting context build BEFORE the
    # existing ctx assembly. Anchor: the existing `const ctx:
    # FollowupContext` opening line.
    a, b, w = patch_file(
        sched_path,
        [
            (
                '      const ctx: FollowupContext = {\n'
                '        prospect_name: item.prospectName,\n',
                '      // B9c.2: when the row is for an anti_ghosting prospect, build\n'
                '      // a separate AntiGhostingFollowupContext via a LIVE re-read of\n'
                '      // the Gmail thread. We do this BEFORE building the existing ctx\n'
                '      // so both are ready at dispatch time. Failures here (user not\n'
                '      // connected, Gmail API error) throw and let the outer per-row\n'
                '      // catch log + move on; the row stays "queued" and will retry on\n'
                '      // the next scheduler tick.\n'
                '      let antiGhostingCtx: AntiGhostingFollowupContext | null = null;\n'
                '      if (item.app === "anti_ghosting") {\n'
                '        if (!item.userId) {\n'
                '          throw new Error(`anti_ghosting prospect ${item.prospectId} has no userId`);\n'
                '        }\n'
                '        if (!userCache.has(item.userId)) {\n'
                '          const us = await db.select().from(usersTable).where(eq(usersTable.id, item.userId)).limit(1);\n'
                '          if (us.length > 0) userCache.set(item.userId, us[0]);\n'
                '        }\n'
                '        const agUser = userCache.get(item.userId);\n'
                '        if (!agUser || !agUser.googleRefreshToken || !agUser.isConnected) {\n'
                '          throw new Error(`anti_ghosting prospect ${item.prospectId}: user ${item.userId} not Gmail-connected`);\n'
                '        }\n'
                '        const agGmail = getGmailForUser({\n'
                '          refreshToken: agUser.googleRefreshToken,\n'
                '          email: agUser.email,\n'
                '          name: agUser.name ?? undefined,\n'
                '        });\n'
                '        const parsedThread = await parseGmailThread(agGmail, item.gmailThreadId, agUser.email);\n'
                '        antiGhostingCtx = {\n'
                '          prospect_name: item.prospectName,\n'
                '          prospect_email: item.email,\n'
                '          company: item.company,\n'
                '          sender_name: senderName,\n'
                '          seed_subject: item.originalSubject,\n'
                '          seed_body: item.originalBody,\n'
                '          thread_messages: parsedThread.map((m) => ({\n'
                '            direction: m.direction,\n'
                '            sentAt: m.sentAt,\n'
                '            fromName: m.fromName,\n'
                '            fromEmail: m.fromEmail,\n'
                '            subject: m.subject,\n'
                '            body: m.body,\n'
                '          })),\n'
                '          stage: item.stage,\n'
                '          cycle: item.cycle,\n'
                '          days_since_seed: daysSince,\n'
                '          days_since_seed_tier: computeDaysSinceSeedTier(item.sentAt, new Date()),\n'
                '          original_language: item.originalLanguage || "en",\n'
                '          previous_followups: previousFollowups.length > 0\n'
                '            ? previousFollowups.map((p) => ({ stage: p.stage, subject: p.subject, body: p.body }))\n'
                '            : undefined,\n'
                '        };\n'
                '      }\n'
                '\n'
                '      const ctx: FollowupContext = {\n'
                '        prospect_name: item.prospectName,\n',
                'insert anti-ghosting ctx build before existing ctx assembly',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # Edit 3f: widen runWithUsageContext app discriminator
    a, b, w = patch_file(
        sched_path,
        [
            (
                '          app: item.app === "context" ? "context" : "doctrine",\n',
                '          app: item.app === "anti_ghosting" ? "anti_ghosting"\n'
                '            : item.app === "context" ? "context" : "doctrine",\n',
                'widen runWithUsageContext app discriminator',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # Edit 3g: widen the dispatch ternary to three branches
    a, b, w = patch_file(
        sched_path,
        [
            (
                '        () => item.app === "context"\n'
                '          ? generateContextFollowup(ctx)\n'
                '          : generateFollowupEmail(ctx),\n',
                '        () => {\n'
                '          // B9c.2: three-way dispatch. anti_ghosting uses the\n'
                '          // AntiGhostingFollowupContext built above; doctrine and\n'
                '          // context share the FollowupContext.\n'
                '          if (item.app === "anti_ghosting" && antiGhostingCtx) {\n'
                '            return generateAntiGhostingFollowup(antiGhostingCtx);\n'
                '          }\n'
                '          return item.app === "context"\n'
                '            ? generateContextFollowup(ctx)\n'
                '            : generateFollowupEmail(ctx);\n'
                '        },\n',
                'widen dispatch ternary to three-branch conditional',
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ────────────────────────────────────────────────────────────────
    # Summary
    # ────────────────────────────────────────────────────────────────
    expected = 9
    seen = totals[0] + totals[1]
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {totals[0]}")
    print(f"  Already-applied:   {totals[1]}")
    print(f"  Warnings:          {totals[2]}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if totals[2] > 0:
        print(f"  At least one edit could not be applied. Inspect WARN lines above.")
        return 2
    if seen < expected:
        print(f"  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
