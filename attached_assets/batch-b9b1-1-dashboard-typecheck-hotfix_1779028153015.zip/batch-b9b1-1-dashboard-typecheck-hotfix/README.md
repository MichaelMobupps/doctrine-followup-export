# Batch B9b.1.1 — Dashboard Typecheck Hotfix

**Scope.** Add `queryKey` to the 7 pre-existing Orval call sites that fail tsc under react-query v5's stricter `UseQueryOptions` type. Clears the dashboard typecheck gate that was failing on B9b.1 deploy. No new files, no behaviour change at runtime.

## Why these errors exist

react-query v5 made `queryKey` mandatory on `UseQueryOptions<...>`. The Orval-generated hooks in this dashboard forward the user's `query` options object straight through to `useQuery`, so callers must now provide `queryKey` — Orval's internal default isn't enough to satisfy the type system at the call site.

The errors are latent from whenever the dashboard upgraded to react-query v5; they only surfaced now because B9b.1 was the first batch this session to run `pnpm --filter @workspace/dashboard run typecheck`. The runtime path is unaffected (vite + esbuild don't run tsc), which is why nobody noticed until the typecheck gate fired.

None of B9b.1's new files (`anti-ghosting.tsx`, `picker.tsx`) trip this — they use `useQuery` directly with explicit `queryKey` parameters, satisfying v5 from the start.

## Why fix now rather than defer

Going forward, every dashboard batch will hit the same red gate. Two paths:
1. Lower the gate (skip typecheck on dashboard) — loses signal forever.
2. Fix the 7 sites — restore the gate's value.

Path 2 is small, surgical, and clears the noise once.

## Convention for the queryKey values

Plain string-array form matching the existing `queryClient.invalidateQueries({ queryKey: [...] })` calls in `dashboard.tsx` (lines 36-39) and `pipeline.tsx` (lines 626-628):

```typescript
queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
queryClient.invalidateQueries({ queryKey: ["/api/followups"] });
```

So the fix uses the same `["/api/<path>"]` form. Two side benefits:
1. Cache invalidation calls now correctly target the cache entries those queries populate (previously they may have been no-ops, depending on what Orval's internal default key was).
2. The convention is consistent across read and invalidate, so future call sites have a clear pattern to follow.

For queries with parameters (`useGetThread(threadId, ...)`, `useGetSentEmails({ userId, ... }, ...)`, `useGetFollowups({ userId }, ...)`), the parameter is appended to the queryKey array so different parameter values get different cache entries — standard react-query convention.

## What ships

Single Python patch script with 7 surgical edits across 4 files:

| File | Hook | queryKey added |
|---|---|---|
| `accounts.tsx` | `useGetGmailAccounts` | `["/api/accounts"]` |
| `dashboard.tsx` | `useGetStats` | `["/api/stats"]` |
| `dashboard.tsx` | `useGetCampaignStatus` | `["/api/campaign/status"]` |
| `email-inspector.tsx` | `useGetThread` | `["/api/thread", threadId]` |
| `email-inspector.tsx` | `useGetGmailAccounts` | `["/api/accounts"]` |
| `email-inspector.tsx` | `useGetSentEmails` | `["/api/sent-emails", selectedUserId]` |
| `pipeline.tsx` | `useGetFollowups` | `["/api/followups", currentUser?.userId]` |

Each edit is one line inside an existing `query: { enabled: ..., ... }` options object. Idempotency via the generalized NEW-substring-of-OLD check.

## Risk surface

1. **Behavioural impact at runtime: minimal**. The hooks were already running at runtime (vite skipped typecheck); they just now have explicit cache keys instead of relying on Orval's internal default. If Orval's default matched `["/api/<path>"]` then nothing changes. If it didn't, then the existing invalidate calls have been silently no-op'ing, and this fix makes invalidation start working correctly. Either way, no regression.
2. **No new types, no schema, no scheduler, no generator changes**.
3. **B9b.1's own files are not touched** — the new AntiGhosting page already uses `useQuery` directly with `queryKey` provided.
4. **Sandbox-tested across all 4 files**: 7 FIX on first run, 7 SKIP on second run, every `query: {}` object ends with a corresponding queryKey.

## Validation

```bash
python3 scripts/apply-b9b1-1.py
pnpm --filter @workspace/dashboard run typecheck
```

Expect: 7 edits applied, 0 typecheck errors.

## Layout

```
batch-b9b1-1-dashboard-typecheck-hotfix/
|-- README.md
`-- scripts/
    `-- apply-b9b1-1.py
```

No source-file replacements. All edits applied directly to live files via the script.
