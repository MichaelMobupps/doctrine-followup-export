// B7q apply script.
// Weekly digest hardening:
//   1. Replace .length-based counts with proper count(*) queries so the
//      "Follow-ups sent (50)" undercount goes away.
//   2. Raise per-section row limit from 50 to 200.
//   3. Drop the broken "stalled in last 7d" filter on Section 5.
//   4. Neutral branding in subject + footer ("Doctrine" -> "Followuper").
//   5. Add a Tuesday 06:00 UTC retry tick for failed digests.
//   6. Add admin endpoints to preview HTML and to send a test digest now.
//
// Same surgical string-replace pattern as B7p, with idempotency markers.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";

async function patchFile(relativePath, edits) {
  const absPath = path.join(WORKSPACE, relativePath);
  let content;
  try {
    content = await fs.readFile(absPath, "utf8");
  } catch (err) {
    throw new Error(`Cannot read ${absPath}: ${err.message}`);
  }
  let applied = 0;
  let alreadyApplied = 0;
  for (const edit of edits) {
    if (edit.marker && content.includes(edit.marker)) {
      console.log(`  [skip] ${edit.name} (already applied)`);
      alreadyApplied++;
      continue;
    }
    const occurrences = content.split(edit.search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Edit "${edit.name}" search NOT FOUND in ${relativePath}. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Edit "${edit.name}" matched ${occurrences} times in ${relativePath}. Need more specific anchor.`);
    }
    content = content.replace(edit.search, edit.replace);
    applied++;
    console.log(`  [ok]   ${edit.name}`);
  }
  if (applied > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${relativePath} (applied ${applied}, skipped ${alreadyApplied})`);
  } else {
    console.log(`no-op: ${relativePath} (all ${alreadyApplied} edits already applied)`);
  }
}

// =============================================================
// Edit set A: services/weeklyDigest.ts
//   - count(*) queries for each of the 6 sections
//   - .limit(50) -> .limit(200)
//   - drop the broken 7-day filter on stalled section
//   - replace .length-based counts in the return object
//   - neutralize brand strings in subject + footer
// =============================================================
const DIGEST_EDITS = [
  // (A1) Section 1 — sent: add count query, raise row limit
  {
    name: "digest A1: sent count + limit",
    marker: "B7q: sent count",
    search:
`  // Section 1: Sent in the last 7 days.
  const sentRows = await db
    .select({
      stage: followupsTable.stage,
      sentAt: followupsTable.sentAt,
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
    })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(followupsTable.status, "sent"),
      isNotNull(followupsTable.sentAt),
      gte(followupsTable.sentAt, weekStart),
      lte(followupsTable.sentAt, now),
    ))
    .orderBy(sql\`\${followupsTable.sentAt} desc\`)
    .limit(50);`,
    replace:
`  // Section 1: Sent in the last 7 days.
  // B7q: sent count is a separate count(*) so the email shows the real
  // total even when there are more than the displayed row cap.
  const sentCountRows = await db
    .select({ c: sql\`count(*)\`.mapWith(Number) })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(followupsTable.status, "sent"),
      isNotNull(followupsTable.sentAt),
      gte(followupsTable.sentAt, weekStart),
      lte(followupsTable.sentAt, now),
    ));
  const sentCount = sentCountRows[0]?.c ?? 0;
  const sentRows = await db
    .select({
      stage: followupsTable.stage,
      sentAt: followupsTable.sentAt,
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
    })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(followupsTable.status, "sent"),
      isNotNull(followupsTable.sentAt),
      gte(followupsTable.sentAt, weekStart),
      lte(followupsTable.sentAt, now),
    ))
    .orderBy(sql\`\${followupsTable.sentAt} desc\`)
    .limit(200);`,
  },
  // (A2) Section 2 — replies
  {
    name: "digest A2: replies count + limit",
    marker: "B7q: replies count",
    search:
`  // Section 2: Replies received in the last 7 days.
  const repliesRows = await db
    .select({
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
      repliedAt: prospectsTable.repliedAt,
    })
    .from(prospectsTable)
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(prospectsTable.replied, 1),
      isNotNull(prospectsTable.repliedAt),
      gte(prospectsTable.repliedAt, weekStart),
      lte(prospectsTable.repliedAt, now),
    ))
    .orderBy(sql\`\${prospectsTable.repliedAt} desc\`)
    .limit(50);`,
    replace:
`  // Section 2: Replies received in the last 7 days.
  // B7q: replies count via count(*).
  const repliesCountRows = await db
    .select({ c: sql\`count(*)\`.mapWith(Number) })
    .from(prospectsTable)
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(prospectsTable.replied, 1),
      isNotNull(prospectsTable.repliedAt),
      gte(prospectsTable.repliedAt, weekStart),
      lte(prospectsTable.repliedAt, now),
    ));
  const repliesCount = repliesCountRows[0]?.c ?? 0;
  const repliesRows = await db
    .select({
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
      repliedAt: prospectsTable.repliedAt,
    })
    .from(prospectsTable)
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(prospectsTable.replied, 1),
      isNotNull(prospectsTable.repliedAt),
      gte(prospectsTable.repliedAt, weekStart),
      lte(prospectsTable.repliedAt, now),
    ))
    .orderBy(sql\`\${prospectsTable.repliedAt} desc\`)
    .limit(200);`,
  },
  // (A3) Section 3 — pending approvals
  {
    name: "digest A3: pendingApproval count + limit",
    marker: "B7q: pendingApproval count",
    search:
`  // Section 3: Pending approvals (review_in_app mode users see this; others get count=0).
  const pendingApprovalRows = args.followupMode === "review_in_app"
    ? await db
        .select({
          stage: followupsTable.stage,
          scheduledAt: followupsTable.scheduledAt,
          prospectName: prospectsTable.prospectName,
          company: prospectsTable.company,
          email: prospectsTable.email,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(
          eq(prospectsTable.userId, args.userId),
          eq(followupsTable.status, "pending_approval"),
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
        ))
        .orderBy(followupsTable.scheduledAt)
        .limit(50)
    : [];`,
    replace:
`  // Section 3: Pending approvals (review_in_app mode users see this; others get count=0).
  // B7q: pendingApproval count via count(*).
  let pendingApprovalCount = 0;
  if (args.followupMode === "review_in_app") {
    const r = await db
      .select({ c: sql\`count(*)\`.mapWith(Number) })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        eq(prospectsTable.userId, args.userId),
        eq(followupsTable.status, "pending_approval"),
        eq(prospectsTable.replied, 0),
        eq(prospectsTable.followupPaused, false),
      ));
    pendingApprovalCount = r[0]?.c ?? 0;
  }
  const pendingApprovalRows = args.followupMode === "review_in_app"
    ? await db
        .select({
          stage: followupsTable.stage,
          scheduledAt: followupsTable.scheduledAt,
          prospectName: prospectsTable.prospectName,
          company: prospectsTable.company,
          email: prospectsTable.email,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(
          eq(prospectsTable.userId, args.userId),
          eq(followupsTable.status, "pending_approval"),
          eq(prospectsTable.replied, 0),
          eq(prospectsTable.followupPaused, false),
        ))
        .orderBy(followupsTable.scheduledAt)
        .limit(200)
    : [];`,
  },
  // (A4) Section 4 — drafts approaching timeout
  {
    name: "digest A4: approachingTimeout count + limit",
    marker: "B7q: approachingTimeout count",
    search:
`  // Section 4: Drafts approaching timeout (draft_in_gmail mode only).
  // A draft is "approaching" if its scheduledAt is between 14 and 30 days old.
  const approachingTimeoutRows = args.followupMode === "draft_in_gmail"
    ? await db
        .select({
          stage: followupsTable.stage,
          scheduledAt: followupsTable.scheduledAt,
          prospectName: prospectsTable.prospectName,
          company: prospectsTable.company,
          email: prospectsTable.email,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(
          eq(prospectsTable.userId, args.userId),
          eq(followupsTable.status, "drafted"),
          lte(followupsTable.scheduledAt, new Date(now.getTime() - STALL_WARNING_DAYS * DAY_MS)),
          gte(followupsTable.scheduledAt, new Date(now.getTime() - STALL_HARD_DAYS * DAY_MS)),
        ))
        .orderBy(followupsTable.scheduledAt)
        .limit(50)
    : [];`,
    replace:
`  // Section 4: Drafts approaching timeout (draft_in_gmail mode only).
  // A draft is "approaching" if its scheduledAt is between 14 and 30 days old.
  // B7q: approachingTimeout count via count(*).
  let approachingTimeoutCount = 0;
  if (args.followupMode === "draft_in_gmail") {
    const r = await db
      .select({ c: sql\`count(*)\`.mapWith(Number) })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        eq(prospectsTable.userId, args.userId),
        eq(followupsTable.status, "drafted"),
        lte(followupsTable.scheduledAt, new Date(now.getTime() - STALL_WARNING_DAYS * DAY_MS)),
        gte(followupsTable.scheduledAt, new Date(now.getTime() - STALL_HARD_DAYS * DAY_MS)),
      ));
    approachingTimeoutCount = r[0]?.c ?? 0;
  }
  const approachingTimeoutRows = args.followupMode === "draft_in_gmail"
    ? await db
        .select({
          stage: followupsTable.stage,
          scheduledAt: followupsTable.scheduledAt,
          prospectName: prospectsTable.prospectName,
          company: prospectsTable.company,
          email: prospectsTable.email,
        })
        .from(followupsTable)
        .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
        .where(and(
          eq(prospectsTable.userId, args.userId),
          eq(followupsTable.status, "drafted"),
          lte(followupsTable.scheduledAt, new Date(now.getTime() - STALL_WARNING_DAYS * DAY_MS)),
          gte(followupsTable.scheduledAt, new Date(now.getTime() - STALL_HARD_DAYS * DAY_MS)),
        ))
        .orderBy(followupsTable.scheduledAt)
        .limit(200)
    : [];`,
  },
  // (A5) Section 5 — stalled drafts: drop the broken 7-day filter, add count
  {
    name: "digest A5: stalled drop bad filter + count + limit",
    marker: "B7q: stalled section drops the broken",
    search:
`  // Section 5: Drafts stalled in the last 7 days.
  // Stalls move the row to status=stalled_awaiting_manual_send. Use the
  // scheduled_at as an approximation for when it was created.
  const stalledRows = await db
    .select({
      stage: followupsTable.stage,
      scheduledAt: followupsTable.scheduledAt,
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
    })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(followupsTable.status, "stalled_awaiting_manual_send"),
      gte(followupsTable.scheduledAt, new Date(now.getTime() - (STALL_HARD_DAYS + 7) * DAY_MS)),
    ))
    .orderBy(sql\`\${followupsTable.scheduledAt} desc\`)
    .limit(50);`,
    replace:
`  // Section 5: Currently stalled drafts (all of them, regardless of age).
  // B7q: stalled section drops the broken "in last 7 days" filter. The
  // followups table has no stalledAt column so the previous proxy on
  // scheduledAt mis-included old drafts and excluded recently-stalled
  // older ones. Showing all current stalls is correct and simple.
  const stalledCountRows = await db
    .select({ c: sql\`count(*)\`.mapWith(Number) })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(followupsTable.status, "stalled_awaiting_manual_send"),
    ));
  const stalledCount = stalledCountRows[0]?.c ?? 0;
  const stalledRows = await db
    .select({
      stage: followupsTable.stage,
      scheduledAt: followupsTable.scheduledAt,
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
    })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
    .where(and(
      eq(prospectsTable.userId, args.userId),
      eq(followupsTable.status, "stalled_awaiting_manual_send"),
    ))
    .orderBy(sql\`\${followupsTable.scheduledAt} desc\`)
    .limit(200);`,
  },
  // (A6) Section 6 — new prospects
  {
    name: "digest A6: newProspects count + limit",
    marker: "B7q: newProspects count",
    search:
`  // Section 6: New prospects added in the last 7 days.
  const newProspectsRows = await db
    .select({
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
      createdAt: prospectsTable.createdAt,
    })
    .from(prospectsTable)
    .where(and(
      eq(prospectsTable.userId, args.userId),
      gte(prospectsTable.createdAt, weekStart),
      lte(prospectsTable.createdAt, now),
    ))
    .orderBy(sql\`\${prospectsTable.createdAt} desc\`)
    .limit(50);`,
    replace:
`  // Section 6: New prospects added in the last 7 days.
  // B7q: newProspects count via count(*).
  const newProspectsCountRows = await db
    .select({ c: sql\`count(*)\`.mapWith(Number) })
    .from(prospectsTable)
    .where(and(
      eq(prospectsTable.userId, args.userId),
      gte(prospectsTable.createdAt, weekStart),
      lte(prospectsTable.createdAt, now),
    ));
  const newProspectsCount = newProspectsCountRows[0]?.c ?? 0;
  const newProspectsRows = await db
    .select({
      prospectName: prospectsTable.prospectName,
      company: prospectsTable.company,
      email: prospectsTable.email,
      createdAt: prospectsTable.createdAt,
    })
    .from(prospectsTable)
    .where(and(
      eq(prospectsTable.userId, args.userId),
      gte(prospectsTable.createdAt, weekStart),
      lte(prospectsTable.createdAt, now),
    ))
    .orderBy(sql\`\${prospectsTable.createdAt} desc\`)
    .limit(200);`,
  },
  // (A7) Return object: swap .length-based counts for the new variables
  {
    name: "digest A7: return object uses count(*) results",
    marker: "B7q: return uses real counts",
    search:
`    sentCount: sentRows.length,
    sentRows: sentRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage}\`,
    })),
    repliesCount: repliesRows.length,
    repliesRows: repliesRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: r.repliedAt ? fmtDate(new Date(r.repliedAt)) : undefined,
    })),
    pendingApprovalCount: pendingApprovalRows.length,
    pendingApprovalRows: pendingApprovalRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage}\`,
    })),
    approachingTimeoutCount: approachingTimeoutRows.length,
    approachingTimeoutRows: approachingTimeoutRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage} · \${daysSince(r.scheduledAt, now)}d unsent\`,
    })),
    stalledCount: stalledRows.length,
    stalledRows: stalledRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage}\`,
    })),
    newProspectsCount: newProspectsRows.length,`,
    replace:
`    // B7q: return uses real counts from count(*), not the length of the
    // truncated row arrays.
    sentCount,
    sentRows: sentRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage}\`,
    })),
    repliesCount,
    repliesRows: repliesRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: r.repliedAt ? fmtDate(new Date(r.repliedAt)) : undefined,
    })),
    pendingApprovalCount,
    pendingApprovalRows: pendingApprovalRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage}\`,
    })),
    approachingTimeoutCount,
    approachingTimeoutRows: approachingTimeoutRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage} · \${daysSince(r.scheduledAt, now)}d unsent\`,
    })),
    stalledCount,
    stalledRows: stalledRows.map((r) => ({
      label: \`\${r.prospectName || r.email} · \${r.company || "(no company)"}\`,
      meta: \`Stage \${r.stage}\`,
    })),
    newProspectsCount,`,
  },
  // (A8) Stalled section title — drop "(last 7d)"
  {
    name: "digest A8: stalled section title",
    marker: "Drafts currently stalled",
    search: `sections.push(renderSection("Drafts stalled (last 7d)", data.stalledCount, data.stalledRows));`,
    replace: `sections.push(renderSection("Drafts currently stalled", data.stalledCount, data.stalledRows));`,
  },
  // (A9) Neutral subject line
  {
    name: "digest A9: neutral subject line",
    marker: "B7q: neutral subject",
    search: `    const subject = \`Doctrine weekly recap — week of \${fmtDate(data.weekStart)}\`;`,
    replace: `    // B7q: neutral subject (covers Doctrine + Context apps under one digest).
    const subject = \`Weekly recap — week of \${fmtDate(data.weekStart)}\`;`,
  },
  // (A10) Neutral HTML title + footer
  {
    name: "digest A10: neutral HTML title + footer",
    marker: "B7q: neutral HTML branding",
    search:
`    <h2 style="margin:0 0 4px 0;font-size:18px;font-weight:600;color:#111;">Doctrine weekly recap</h2>
    <p style="margin:0;font-size:12px;color:#888;">Week of \${fmtDate(data.weekStart)} — \${fmtDate(data.weekEnd)} · \${escapeHtml(userName)}</p>
    \${emptyMsg}
    \${sections.filter(Boolean).join("")}
    <p style="margin:32px 0 0 0;padding-top:16px;border-top:1px solid #e5e5e5;font-size:11px;color:#aaa;">
      You are receiving this because weekly digest is enabled in your Doctrine settings.
      To opt out, open Settings in the app and disable Weekly digest.
    </p>`,
    replace:
`    <!-- B7q: neutral HTML branding -->
    <h2 style="margin:0 0 4px 0;font-size:18px;font-weight:600;color:#111;">Weekly recap</h2>
    <p style="margin:0;font-size:12px;color:#888;">Week of \${fmtDate(data.weekStart)} — \${fmtDate(data.weekEnd)} · \${escapeHtml(userName)}</p>
    \${emptyMsg}
    \${sections.filter(Boolean).join("")}
    <p style="margin:32px 0 0 0;padding-top:16px;border-top:1px solid #e5e5e5;font-size:11px;color:#aaa;">
      You are receiving this because weekly digest is enabled in your account settings.
      To opt out, open Settings in the app and disable Weekly digest.
    </p>`,
  },
];

// =============================================================
// Edit set B: cron.ts — add Tuesday 06:00 UTC retry tick
// =============================================================
const CRON_EDITS = [
  {
    name: "cron: add Tuesday 06:00 UTC retry tick",
    marker: "B7q: retry tick for failed weekly digests",
    search:
`  logger.info("Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50, draft-stall @00:30, weekly-digest @Tue 00:00 UTC, fast-tick @*/3");
}`,
    replace:
`  // B7q: retry tick for failed weekly digests. The runWeeklyDigest()
  // function's 6-day dedupe window means any user whose digest already
  // sent at 00:00 UTC will be skipped here. Only users whose digest
  // FAILED earlier today (lastWeeklyDigestAt is older than 6 days, or
  // unset) actually get a fresh send.
  cron.schedule("0 6 * * 2", async () => {
    const startedAt = Date.now();
    let outcome: "ok" | "partial" | "error" = "ok";
    const details: Record<string, unknown> = {};
    try {
      logger.info("Running weekly digest retry tick...");
      const result = await runWeeklyDigest();
      details.considered = result.considered;
      details.sent = result.sent;
      details.skipped = result.skipped;
      details.failed = result.failed;
      logger.info(
        { considered: result.considered, sent: result.sent, skipped: result.skipped, failed: result.failed },
        "Weekly digest retry done",
      );
    } catch (err) {
      outcome = "error";
      details.error = err instanceof Error ? err.message : String(err);
      logger.error({ err }, "Weekly digest retry error");
    } finally {
      await recordHeartbeat({
        tickName: "weekly_digest_retry",
        durationMs: Date.now() - startedAt,
        outcome,
        details,
      });
    }
  }, { timezone: "UTC" });

  logger.info("Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50, draft-stall @00:30, weekly-digest @Tue 00:00 UTC + retry @Tue 06:00 UTC, fast-tick @*/3");
}`,
  },
];

// =============================================================
// Edit set C: routes/admin-salvage.ts — append digest preview + send-test
// =============================================================
const ADMIN_SALVAGE_EDITS = [
  {
    name: "admin-salvage: import digest functions",
    marker: "B7q: digest preview + send-test endpoints",
    search: `import { queueStageForProspect } from "../services/scheduler";`,
    replace:
`import { queueStageForProspect } from "../services/scheduler";
// B7q: digest preview + send-test endpoints. The cron only runs Tuesday
// 00:00 UTC, so without these we cannot test or preview the digest at all.
import { gatherDigestData, formatDigestHtml, sendWeeklyDigestForUser } from "../services/weeklyDigest";`,
  },
  {
    name: "admin-salvage: append digest endpoints",
    marker: "POST /admin/digest/preview",
    search: `export default router;`,
    replace:
`// B7q: POST /admin/digest/preview — render the digest HTML for a user
// without sending. Returns text/html so the caller can pipe it to a file
// and open it in a browser:
//   curl ... > preview.html && xdg-open preview.html
router.post("/admin/digest/preview", async (req: Request, res: Response) => {
  try {
    const email = String(req.body?.email || "").trim();
    if (!email) { res.status(400).json({ error: "email is required" }); return; }
    const user = (await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1))[0];
    if (!user) { res.status(404).json({ error: \`User not found: \${email}\` }); return; }
    const data = await gatherDigestData({ userId: user.id, followupMode: user.followupMode });
    const html = formatDigestHtml(data, user.name || user.email);
    res.set("Content-Type", "text/html; charset=utf-8");
    res.send(html);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "B7q digest preview error");
    res.status(500).json({ error: msg });
  }
});

// B7q: POST /admin/digest/send-test — send the digest to a user right
// now, bypassing the Tuesday cron + dedupe window. Body: { email }.
// Useful for verifying the digest end-to-end without waiting a week.
router.post("/admin/digest/send-test", async (req: Request, res: Response) => {
  try {
    const email = String(req.body?.email || "").trim();
    if (!email) { res.status(400).json({ error: "email is required" }); return; }
    const user = (await db.select().from(usersTable).where(eq(usersTable.email, email)).limit(1))[0];
    if (!user) { res.status(404).json({ error: \`User not found: \${email}\` }); return; }
    if (!user.isConnected || !user.googleRefreshToken) {
      res.status(409).json({ error: "User is not connected (Gmail OAuth missing). Reconnect first." });
      return;
    }
    const result = await sendWeeklyDigestForUser({
      id: user.id,
      email: user.email,
      name: user.name,
      googleRefreshToken: user.googleRefreshToken,
      followupMode: user.followupMode,
    });
    res.json({ email: user.email, ...result });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "B7q digest send-test error");
    res.status(500).json({ error: msg });
  }
});

export default router;`,
  },
];

async function main() {
  console.log("B7q: weekly digest hardening\n");

  console.log("[1/3] api-server/src/services/weeklyDigest.ts");
  await patchFile("artifacts/api-server/src/services/weeklyDigest.ts", DIGEST_EDITS);
  console.log();

  console.log("[2/3] api-server/src/cron.ts");
  await patchFile("artifacts/api-server/src/cron.ts", CRON_EDITS);
  console.log();

  console.log("[3/3] api-server/src/routes/admin-salvage.ts");
  await patchFile("artifacts/api-server/src/routes/admin-salvage.ts", ADMIN_SALVAGE_EDITS);
  console.log();

  console.log("B7q applied. Next: build api-server, restart workflow, deploy to production.");
}

main().catch((err) => {
  console.error("\nB7q apply failed:", err.message);
  console.error("\nNo partial writes happened for the failing file.");
  process.exit(1);
});
