# followuper-port-1.1 — Hotfix for followuper-port-1 ship defects

## What went wrong with v1

Michael's ship report flagged two defects in the original followuper-port-1 ship:

**Defect 1 — ESM test file failure**:
```
/home/runner/workspace/artifacts/api-server/src/tests/test-followuper-port-1.ts:20
const SERVICES_DIR = path.join(__dirname, "..", "services");
                               ^
ReferenceError: __dirname is not defined in ES module scope
```

The shipped test used CommonJS `__dirname` which is undefined in ES module scope. My sandbox testing ran via `tsx --test` which silently shims `__dirname` for ESM modules, hiding the bug. The live api-server runs under a stricter ESM toolchain where the global is genuinely undefined.

**Defect 2 — apply script auto-selected mirror not live tree**:
```
First apply_patches.py run from repo root: ⚠️ Script auto-selected
source-code/api-server (mirror) because the script probes for
services/followupGenerator.ts at the api-server root, which only matches
the flat mirror layout — artifacts/api-server has src/services/….
Patches landed in the mirror, not the live tree.
```

My target-detection probe `services/followupGenerator.ts` only matched the flat layout used by `source-code/` (the read-only review mirror). The live api-server uses `artifacts/api-server/src/services/...` — with a `src/` segment my probe never tried. Michael worked around it via a symlink for the second run.

Both defects are clear ship-quality misses on my part.

## What this hotfix ships

| File | Action | Why |
|---|---|---|
| `api-server/.../tests/test-followuper-port-1.ts` | Replace v1 file | Use `fileURLToPath(import.meta.url)` ESM idiom instead of `__dirname` — runs cleanly in ESM scope |
| `apply_patches.py` | Replaced | Probes `artifacts/api-server/src/...` FIRST, then `artifacts/api-server/...`, then `source-code/api-server/...`, then sandbox paths. Live tree always wins when both are present. |

The 3 prompt + generator patches from v1 are unchanged. If they're already correctly applied to the live tree (as they are in Michael's case, per his symlink re-apply showing 3 OK), the hotfix's apply step SKIPs all 3 as idempotent.

## What this hotfix does NOT do

- Does NOT re-apply patches that are already in place (idempotent — confirmed by 3 SKIPs in the test trace below).
- Does NOT touch the mirror tree at `source-code/api-server`. Running `source-code/sync.sh` from `artifacts/` → `source-code/` after this hotfix will overwrite the mis-applied v1 mirror patches with the correct content from `artifacts/api-server/src/`, converging both trees.
- Does NOT change any patch logic — only the test file and the target-detection probe.

## Audited in this session

| Test case | Result |
|---|---|
| Apply from `artifacts/api-server/src` (already-patched live tree from v1+symlink) | ✓ 3 SKIP + test file installed v1.1 ESM-compatible |
| Apply from `source-code/api-server` (already-patched mirror from v1 first run) | ✓ 3 SKIP + test file installed v1.1 ESM-compatible |
| Apply from **repo root** with BOTH `artifacts/` AND `source-code/` present (the v1 first-run case) | ✓ correctly selects `artifacts/api-server/src` — patches land in LIVE tree, mirror untouched |
| ESM test run via `tsx --test` on the live tree (replicates Michael's `tsx` ESM toolchain) | ✓ 18/18 pass (Defect 1 fixed) |
| Idempotency: re-run 2× and 3× from repo root after first apply | ✓ all 4 steps SKIP every time |
| Marker count stability: BRAND ADAPTATION × 2, UNIVERSAL_TECH_RESTORE × 1 — no duplicates from repeated applies | ✓ |
| Full regression on live tree (296 tests across 8 files = 7 existing + 1 new) | ✓ 296/296 in sandbox (Michael's live tree should match) |

## Replit Agent ship command

```bash
set -euo pipefail
cd "$HOME/$REPL_SLUG"

echo "=== 1. Stage hotfix bundle ==="
unzip -o ~/followuper-port-1-1-hotfix.zip -d /tmp/followuper-p1-1
ls -la /tmp/followuper-p1-1

echo ""
echo "=== 2. Apply hotfix (from repo root) ==="
# This will correctly auto-detect artifacts/api-server/src now.
# Expected: 3 SKIPs (patches already correctly applied via symlink in v1 ship)
# Expected: 1 OK for test file replacement (v1's broken file → v1.1 ESM-compatible)
python3 /tmp/followuper-p1-1/apply_patches.py

echo ""
echo "=== 3. Run the now-working test file ==="
cd artifacts/api-server && pnpm exec tsx --test src/tests/test-followuper-port-1.ts
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 4. Full followuper regression (must still pass) ==="
cd artifacts/api-server && pnpm exec tsx --test \
    src/tests/test-doctrine-hardening.ts \
    src/tests/test-nativeness-v4.ts \
    src/tests/test-nativeness-v4-round2.ts \
    src/tests/test-nativeness-v4-round4.ts \
    src/tests/test-discourse-autofix-v4r4.ts \
    src/tests/test-volume-calibration-v4r3.ts \
    src/tests/test-nativeness-v3.ts \
    2>&1 | tail -15
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 5. Build api-server ==="
cd artifacts/api-server && pnpm build 2>&1 | tail -5
cd "$HOME/$REPL_SLUG"

echo ""
echo "=== 6. Sync mirror from live (converges the v1 mis-applied mirror) ==="
bash source-code/sync.sh

echo ""
echo "=== 7. Idempotency re-run ==="
python3 /tmp/followuper-p1-1/apply_patches.py

echo ""
echo "=== 8. Restart api-server workflow ==="
echo "(Use Replit UI: Workflows → api-server → Restart, or wait for next follow-up cron)"

echo ""
echo "=== followuper-port-1.1 hotfix complete. ==="
echo "    Defect 1 fixed: test-followuper-port-1.ts uses fileURLToPath ESM idiom."
echo "    Defect 2 fixed: apply_patches.py auto-detects artifacts/api-server/src first."
echo "    Live tree patches were already correct from v1; this only replaces the broken test file."
```

## Process lesson

The reason my sandbox tests missed Defect 1 is `tsx --test` vs the live api-server's ESM toolchain behavior diverge on `__dirname`. `tsx` provides CommonJS-compat shims when running test files, masking ESM-strictness bugs. The live api-server's build pipeline produces strict ESM modules where `__dirname` is genuinely undefined.

For future TypeScript test ports: use `fileURLToPath(import.meta.url)` from the start, never rely on `__dirname` in test files. This matches the convention used by the existing followuper tests (which import modules directly rather than reading files by path).

For future apply_patches.py target detection: probe multiple layouts (`src/services/`, `services/`) when the target is a TypeScript monorepo. Don't assume the artifact and mirror have the same internal structure.
