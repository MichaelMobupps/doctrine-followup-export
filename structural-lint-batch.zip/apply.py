#!/usr/bin/env python3
"""
Idempotent wiring patch for the structural linter.

Two surgical edits to services/followupGenerator.ts:
  1. Import detectStructuralViolations + mergeViolationReports.
  2. Merge the structural report into the existing `deterministicCheck` so the
     existing gate and merge-into-critique block pick it up with no further
     changes.

Anchors are lines the Gemini-critic batches did not touch. If an anchor is not
found, the script HALTS without writing, so a drifted tree never gets a
mangled patch.
"""
import sys

TARGET = sys.argv[1] if len(sys.argv) > 1 else None
if not TARGET:
    print("usage: apply.py <path-to-followupGenerator.ts>")
    sys.exit(2)

with open(TARGET, "r", encoding="utf-8") as f:
    src = f.read()
orig = src

IMPORT_ANCHOR = 'import { detectAllDeterministicViolations } from "../lib/doctrineLint";'
IMPORT_ADD = 'import { detectStructuralViolations, mergeViolationReports } from "../lib/structuralLint";'

MERGE_ANCHOR = (
    "    const deterministicCheck = detectAllDeterministicViolations("
    "current.body, ctx.original_language);"
)
MERGE_NEW = (
    "    const deterministicCheck = mergeViolationReports(\n"
    "      detectAllDeterministicViolations(current.body, ctx.original_language),\n"
    "      detectStructuralViolations(current.body, {\n"
    "        languageTag: ctx.original_language,\n"
    "        originalText: groundingSource,\n"
    "      }),\n"
    "    );"
)

# ---- edit 1: import ----
if 'from "../lib/structuralLint"' in src:
    print("[apply] import already present, skipping")
else:
    if IMPORT_ANCHOR not in src:
        print("[apply] HALT: import anchor not found. Tree may have drifted.")
        print("        expected line: " + IMPORT_ANCHOR)
        sys.exit(3)
    src = src.replace(IMPORT_ANCHOR, IMPORT_ANCHOR + "\n" + IMPORT_ADD, 1)
    print("[apply] added structuralLint import")

# ---- edit 2: merge into deterministicCheck ----
if "detectStructuralViolations(current.body" in src:
    print("[apply] merge already present, skipping")
else:
    if MERGE_ANCHOR not in src:
        print("[apply] HALT: merge anchor not found. Tree may have drifted.")
        print("        expected line: " + MERGE_ANCHOR)
        sys.exit(4)
    src = src.replace(MERGE_ANCHOR, MERGE_NEW, 1)
    print("[apply] merged structural report into deterministicCheck")

if src == orig:
    print("[apply] no changes (already fully applied)")
else:
    with open(TARGET, "w", encoding="utf-8") as f:
        f.write(src)
    print("[apply] wrote " + TARGET)
