# Batch B9b.2 — AntiGhosting Label Field in Settings

**Scope.** Surface `users.antiGhostingLabel` as an editable input on the Accounts settings page, mirroring the existing Doctrine and Context label inputs. Schema column has existed since B9a; this batch closes the UI gap.

## What was missing

Three layers were already wired but the Settings round-trip wasn't:

| Layer | Status before B9b.2 |
|---|---|
| Schema column `users.antiGhostingLabel` | ✓ existed (B9a, default `"AntiGhosting Followuper"`) |
| Marking flow reads the column | ✓ `resolveUserFromEmail` returns it, `resolveAntiGhostingLabelIds` consumes it |
| GET `/api/gmail/accounts` returns the column | ✗ not in SELECT projection |
| PUT `/api/gmail/accounts/:id/settings` accepts the field | ✗ not in body destructure, not in updates handler |
| Dashboard form input | ✗ no markup, no state |

Without these, the operator can only customize the label by direct SQL. The flow runs fine with the default `"AntiGhosting Followuper"` but offers no UI override.

## Six surgical edits

### API: `artifacts/api-server/src/routes/gmail-auth.ts`

1. Add `antiGhostingLabel: usersTable.antiGhostingLabel` to the GET response SELECT projection (next to `contextLabel`).
2. Add `antiGhostingLabel` to the PUT body destructure (between `contextLabel` and `followupMode`).
3. Add `if (antiGhostingLabel !== undefined) updates.antiGhostingLabel = String(antiGhostingLabel);` to the updates handler (after the `contextLabel` line, mirroring its shape exactly).

### Dashboard: `artifacts/dashboard/src/pages/accounts.tsx`

4. Add `antiGhostingLabel` state variable with `useState<string>(...)` after the existing `doctrineLabel` and `contextLabel` states. Uses `(account as Record<string, any>).antiGhostingLabel` cast because the Orval-generated `GmailAccount` type may not yet include the new field; the cast is noted in a comment so a future Orval regen can swap it for direct property access.
5. Add `antiGhostingLabel,` to the save-request body (between `contextLabel` and `weeklyDigestEnabled`).
6. Add a new `<div>` block in the form between the Context label block and the Weekly Digest toggle, with the same shape as Doctrine/Context: uppercase tracking label, `<Input>` bound to `antiGhostingLabel`/`setAntiGhostingLabel`, placeholder `"AntiGhosting Followuper"`, helper text `Comma-separated label names to sync into the Anti-Ghosting flow`.

## Risk surface

1. **Type cast on the dashboard read** — `(account as Record<string, any>).antiGhostingLabel` bypasses the Orval-generated `GmailAccount` type, which may not include the new field. If your Orval pipeline auto-regenerates from the API response shape, the next regen will let us drop the cast (the comment at the call site flags this).
2. **No schema change** — column already exists.
3. **No marking-flow change** — the route already reads the column. This batch only adds an edit path for it.
4. **Default behavior preserved** — schema default `"AntiGhosting Followuper"` means existing users see no change unless they explicitly edit the new input.
5. **Idempotency** — patch script uses the generalized NEW-substring-of-OLD check. 6 FIX on first run, 6 SKIP on second. Verified in sandbox against fixtures matching the live source verbatim.

## Layout

```
batch-b9b2-anti-ghosting-label-settings/
|-- README.md
`-- scripts/
    `-- apply-b9b2.py
```

No source-file replacements. All edits applied directly to live files via the script.

## Validation

```bash
python3 scripts/apply-b9b2.py
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/dashboard run typecheck
pnpm --filter @workspace/api-server run build
pnpm --filter @workspace/dashboard run build
```

Expect: 6 edits applied, 0 typecheck errors on both packages, both builds succeed.

After deploy:
- Settings page renders the new `Anti-Ghosting Gmail label` input between Context and Weekly Digest.
- Default value shows `"AntiGhosting Followuper"` for existing users.
- Editing + Save persists. Refresh the page → the new value comes back from GET.
- `/anti-ghosting` candidate list now reads from the operator's customized label (was already wired to read from this column).
