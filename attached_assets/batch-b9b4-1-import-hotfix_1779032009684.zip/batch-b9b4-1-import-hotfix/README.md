# Batch B9b.4.1 — gmailSync.ts Import Hotfix

**Scope.** Add the `ingestAntiGhostingLabeledThreads` import that B9b.4 missed. One surgical edit.

## Why

B9b.4's import patch anchored on `import { syncThreadFromGmail } from "./threadReader";` which I wrongly assumed lived in `gmailSync.ts`. It doesn't — that symbol is imported by `routes/anti-ghosting.ts` directly, not via gmailSync. The anchor missed, so the import line never got added, while the call site (second edit) applied correctly. Result: `TS2304: Cannot find name 'ingestAntiGhostingLabeledThreads'`.

## Fix

Single edit, anchored on `import { logger } from "../lib/logger";` — a single-line import reliably present in the file. Inserts the new import on the next line.

## Risk

- Pure type-system fix. No behaviour change.
- The B9b.4 file installs and the call-site edit are already in place from the partial apply. This batch only adds the import.
- Sandbox-tested against a fixture mimicking the partial-apply state: 1 FIX on first run, 1 SKIP on second run.

## Validation

```bash
python3 scripts/apply-b9b4-1.py
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server run build
```

Expect: 1 edit applied, 0 typecheck errors (the TS2304 clears), build succeeds. Then continue the standard sync + workflow restart.

## Layout

```
batch-b9b4-1-import-hotfix/
|-- README.md
`-- scripts/
    `-- apply-b9b4-1.py
```
