# Batch 7m — Pipeline stage indicator visual fix (both products)

Phase 7m. Closes the UI bug where stage-indicator squares cap at
`max_followups` even when the prospect actually has more sent stages.

## The bug

The `StageProgress` component (in both `pipeline.tsx` and
`context-pipeline.tsx`, the latter cloned from the former in B7e)
renders one small square per stage. The loop bound `maxStages` was:

```tsx
const maxStages = isUnlimitedFollowups(thread.max_followups)
  ? Math.max(3, highestStage)        // unlimited: extends past 3
  : thread.max_followups;            // capped: ignores highestStage
```

The capped branch is the bug. When `max_followups = 3` but
`highestStage = 5` (because manual "Send Now" forced stages past the
cap, or because the user reduced max_followups after some stages were
already sent), the loop only renders 3 squares — even though
`thread.stages` has 5 real stages worth of data.

Visible symptom: rows showing "5/3" or "4/3" in the stage counter
but only 3 small squares lit. Misleading: looks like only 3 stages
exist when in fact 5 do.

## The fix

The capped branch now also extends to `highestStage`:

```tsx
const maxStages = isUnlimitedFollowups(thread.max_followups)
  ? Math.max(3, highestStage)
  : Math.max(thread.max_followups, highestStage);
```

Both branches now follow the same rule: render exactly enough squares
to cover both the configured cap AND every real stage that exists.

Net effect:

- Cap=3, sent=2: 3 squares (2 green + 1 dark) — same as before.
- Cap=3, sent=3: 3 squares (3 green) — same as before.
- Cap=3, sent=5: 5 squares (5 green) — was 3, now reality.
- Cap=3, sent=4 with one queued at stage 4: 4 squares (3 green +
  1 yellow) — was 3.
- Unlimited: behavior unchanged (already grew with highestStage).

Same fix applied to both files.

## Files

```
batch7m/
├── apply-batch7m.mjs       # Idempotent patch — 2 str_replaces
├── audit-batch7m.mjs       # 9 passes × 3 rounds = 96 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build dashboard only (api-server
unchanged). Mirror sync. Republish dashboard.

## Verify

After applying:

- The apply script self-verifies 10 anchors (4 fix-confirmed + 2
  old-pattern-absent + 2 unlimited-branch-unchanged + 2
  highestStage-compute-preserved).
- The audit runs 96 checks (32 per round × 3 rounds): both
  `StageProgress` blocks have the Phase 7m comment, both capped
  branches use `Math.max(thread.max_followups, highestStage)`, both
  unlimited branches still extend to highestStage, render loop
  unchanged, stage-status switch (sent/queued/pending_approval/
  cancelled/failed) preserved, both branches reference highestStage
  (so highestStage appears ≥3 times per block). Plus B7a-B7l
  regression.

Browser smoke after dashboard republish + hard-reload:

1. Open `/pipeline` (doctrine).
2. Find any thread showing "4/3" or "5/3" in the stage counter
   (right side of the stage row).
3. The stage indicator squares now extend to match the counter:
   "5/3" → 5 squares, "4/3" → 4 squares. All sent stages render
   green, regardless of cap.
4. Threads showing "X/3" where X ≤ 3 render exactly as before.
5. Open `/context/pipeline`. Same behavior once a context campaign
   has any sent stages.

## Known residual

- Visual width grows with stage count. A prospect with many manual
  Send-Now sends will render a long row of squares. The 1px gap
  + 10px squares scale linearly — at 10 stages the strip is ~109px
  wide. Acceptable; matches the data faithfully.
- The fix does not change any backend behavior, send semantics, or
  stage scheduling. Only the visualization.
- Doesn't address the inverse case where `thread.stages` includes
  cancelled or failed rows at high stages — those will render as the
  appropriate color (transparent + outline for cancelled, red for
  failed) per the existing switch statement. Same as before.
