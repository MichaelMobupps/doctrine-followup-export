#!/usr/bin/env python3
"""
B9d.9.1 - Fix AG logo wordmark visibility on light bg.

The inline SVG logo at anti-ghosting.tsx has two text elements
designed for the original dark theme:

  "Anti-Ghosting" text fill="#e8e9ed" (near-white)
  "FollowUper" text uses agWordGrad: #3b82f6 -> #6db4ff
      (lighter stop fails WCAG on light bg)

Now that AG uses a light theme (B9d.1 + B9d.5 + B9d.9), both
need dark colors with strong contrast.

Two anchors in anti-ghosting.tsx:
  A1: agWordGrad gradient stops - darken to navy-to-blue-600
      for strong contrast on light bg.
  A2: "Anti-Ghosting" text fill - swap to slate-900 dark.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
PAGE = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: agWordGrad - darken gradient stops for light-bg contrast
# Anchor on the full agWordGrad block (unique - agLoopGrad has different stops).
# ====================================================================
A1_OLD = '''        <linearGradient id="agWordGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#6db4ff" />
        </linearGradient>'''

A1_NEW = '''        {/* B9d.9.1: wordmark gradient darkened for light-bg contrast. */}
        <linearGradient id="agWordGrad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#1e3a8a" />
          <stop offset="100%" stopColor="#2563eb" />
        </linearGradient>'''


# ====================================================================
# A2: "Anti-Ghosting" text fill - swap from near-white to slate-900
# Anchor on the full text element line (unique because of x/y/content).
# ====================================================================
A2_OLD = '''      <text x="140" y="240" textAnchor="middle" fill="#e8e9ed" fontFamily="Geist, system-ui, sans-serif" fontSize="32" fontWeight="500" letterSpacing="-0.5">Anti-Ghosting</text>'''

A2_NEW = '''      {/* B9d.9.1: Anti-Ghosting fill swapped from near-white #e8e9ed to slate-900 for light-bg. */}
      <text x="140" y="240" textAnchor="middle" fill="#0f172a" fontFamily="Geist, system-ui, sans-serif" fontSize="32" fontWeight="500" letterSpacing="-0.5">Anti-Ghosting</text>'''


def main():
    if not PAGE.exists():
        fail(f"anti-ghosting.tsx not found: {PAGE}")
    text = PAGE.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: agWordGrad darkened",
        marker="B9d.9.1: wordmark gradient darkened",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: Anti-Ghosting text fill darkened",
        marker="B9d.9.1: Anti-Ghosting fill swapped",
    )

    if text != original:
        PAGE.write_text(text, encoding="utf-8")
        ok(f"wrote {PAGE.relative_to(WORKSPACE)}")
    else:
        skip("anti-ghosting.tsx already patched")

    print()
    print("B9d.9.1 AG logo wordmark visibility applied.")


if __name__ == "__main__":
    main()
