#!/usr/bin/env node
/**
 * Batch 3a — Code patches
 *
 * What this does (after migrate-batch3a.mjs has updated the database):
 *   1. db/schema/users.ts:
 *        - Add FollowupMode type, FOLLOWUP_MODES const, DEFAULT_DRAFT_STAGE_TIMING.
 *        - Replace `requireApproval: boolean` column with `followupMode: text("followup_mode")`
 *          and add `draftStageTiming: jsonb("draft_stage_timing")`.
 *   2. db/schema/followups.ts:
 *        - Add `draftMessageId: text("draft_message_id")` (nullable).
 *   3. api-server/services/scheduler.ts:
 *        - Read `user?.followupMode === "review_in_app"` instead of `user?.requireApproval`.
 *   4. api-server/routes/gmail-auth.ts:
 *        - ACCOUNT_SELECT projection: replace requireApproval with followupMode + draftStageTiming.
 *        - Add enrichAccount() helper that derives requireApproval from followupMode for
 *          backward compatibility with the existing UI (Pipeline Pre-approval toggle, the
 *          Settings page). Both res.json calls wrap responses through enrichAccount.
 *        - PUT settings: requireApproval boolean continues to be accepted from clients;
 *          translates to the new followup_mode enum on the way to the DB.
 *
 * Net user-facing impact: zero. Same UI, same API surface, same behavior.
 * 3c will replace the requireApproval boolean with a 3-option mode picker.
 *
 * Idempotent: every step checks for an "already applied" anchor before writing.
 */
import fs from "node:fs";
import path from "node:path";

const DB_BASE  = process.env.DB_BASE  || "artifacts/db/src";
const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const USERS_SCHEMA     = path.join(DB_BASE,  "schema/users.ts");
const FOLLOWUPS_SCHEMA = path.join(DB_BASE,  "schema/followups.ts");
const SCHEDULER        = path.join(API_BASE, "services/scheduler.ts");
const GMAIL_AUTH       = path.join(API_BASE, "routes/gmail-auth.ts");

let changed = 0;
let skipped = 0;

function read(p) {
  if (!fs.existsSync(p)) {
    console.error(`[fail] file not found: ${p}`);
    process.exit(1);
  }
  return fs.readFileSync(p, "utf8");
}
function write(p, s) {
  fs.writeFileSync(p, s, "utf8");
}

function replaceOnce(filePath, label, oldStr, newStr) {
  const src = read(filePath);
  if (src.includes(newStr)) {
    console.log(`  [skip] ${label} (already applied)`);
    skipped++;
    return;
  }
  const occurrences = src.split(oldStr).length - 1;
  if (occurrences === 0) {
    console.error(`  [fail] ${label}: anchor not found`);
    console.error(`         expected:\n${oldStr.split("\n").slice(0, 3).join("\n")}...`);
    process.exit(1);
  }
  if (occurrences > 1) {
    console.error(`  [fail] ${label}: anchor matched ${occurrences} times — must be unique`);
    process.exit(1);
  }
  write(filePath, src.replace(oldStr, newStr));
  console.log(`  [ok] ${label}`);
  changed++;
}

// ---------- 1. db/schema/users.ts ----------

console.log(`\n[1/4] ${USERS_SCHEMA}`);

// 1a. Add FollowupMode type, constants, and DEFAULT_DRAFT_STAGE_TIMING
replaceOnce(
  USERS_SCHEMA,
  "users schema: add FollowupMode types and draft default",
  `export const DEFAULT_SEND_DAYS: number[] = [1, 2, 3, 4, 5];`,
  `export const DEFAULT_SEND_DAYS: number[] = [1, 2, 3, 4, 5];

export type FollowupMode = "auto_send" | "review_in_app" | "draft_in_gmail";
export const FOLLOWUP_MODES: FollowupMode[] = ["auto_send", "review_in_app", "draft_in_gmail"];

// Default windows for the draft-mode timing block. Stage 1 matches the auto-send
// stage 1 default (3-7 days after initial outreach). Stages 2+ are inter-stage
// gaps measured from the *previous* stage's manual send time, so the numbers
// here are smaller than the auto-send absolute windows.
export const DEFAULT_DRAFT_STAGE_TIMING: StageTiming[] = [
  { minDays: 3, maxDays: 7 },   // F1 draft: 3-7 days after initial outreach
  { minDays: 5, maxDays: 10 },  // F2 draft: 5-10 days after user manually sends F1
  { minDays: 7, maxDays: 14 },  // F3 draft: 7-14 days after user manually sends F2
];`,
);

// 1b. Replace requireApproval column with followupMode + draftStageTiming
replaceOnce(
  USERS_SCHEMA,
  "users schema: replace requireApproval column with followupMode + draftStageTiming",
  `  testMode: boolean("test_mode").notNull().default(false),
  requireApproval: boolean("require_approval").notNull().default(false),`,
  `  testMode: boolean("test_mode").notNull().default(false),
  followupMode: text("followup_mode").$type<FollowupMode>().notNull().default("auto_send"),
  draftStageTiming: jsonb("draft_stage_timing").$type<StageTiming[]>().notNull().default(DEFAULT_DRAFT_STAGE_TIMING),`,
);

// ---------- 2. db/schema/followups.ts ----------

console.log(`\n[2/4] ${FOLLOWUPS_SCHEMA}`);

replaceOnce(
  FOLLOWUPS_SCHEMA,
  "followups schema: add draftMessageId column",
  `  sentAt: timestamp("sent_at", { withTimezone: true }),
  gmailMessageId: text("gmail_message_id"),
  errorMessage: text("error_message"),`,
  `  sentAt: timestamp("sent_at", { withTimezone: true }),
  gmailMessageId: text("gmail_message_id"),
  draftMessageId: text("draft_message_id"),
  errorMessage: text("error_message"),`,
);

// ---------- 3. services/scheduler.ts ----------

console.log(`\n[3/4] ${SCHEDULER}`);

replaceOnce(
  SCHEDULER,
  "scheduler: read followupMode instead of requireApproval",
  `      const needsApproval = options?.forceSend ? false : (user?.requireApproval ?? false);`,
  `      const needsApproval = options?.forceSend ? false : (user?.followupMode === "review_in_app");`,
);

// ---------- 4. routes/gmail-auth.ts ----------

console.log(`\n[4/4] ${GMAIL_AUTH}`);

// 4a. ACCOUNT_SELECT projection: replace requireApproval with followupMode + draftStageTiming.
//     Add enrichAccount() helper for backward-compat (derives requireApproval boolean).
replaceOnce(
  GMAIL_AUTH,
  "gmail-auth: ACCOUNT_SELECT + enrichAccount",
  `  requireApproval: usersTable.requireApproval,
  createdAt: usersTable.createdAt,
} as const;`,
  `  followupMode: usersTable.followupMode,
  draftStageTiming: usersTable.draftStageTiming,
  createdAt: usersTable.createdAt,
} as const;

// Batch 3a back-compat: derive \`requireApproval\` boolean from \`followupMode\` so
// existing UI (Pre-approval toggle on the Pipeline page, account form on the
// Settings page) keeps working with no client-side changes. The boolean leaves
// the API in 3c when the UI moves to the 3-option mode picker.
function enrichAccount<T extends { followupMode?: string | null }>(a: T): T & { requireApproval: boolean } {
  return { ...a, requireApproval: a.followupMode === "review_in_app" };
}`,
);

// 4b. GET /gmail/accounts: wrap response with enrichAccount
replaceOnce(
  GMAIL_AUTH,
  "gmail-auth: enrich list response",
  `    const users = await db.select(ACCOUNT_SELECT).from(usersTable).orderBy(usersTable.createdAt);
    res.json({ accounts: users });`,
  `    const users = await db.select(ACCOUNT_SELECT).from(usersTable).orderBy(usersTable.createdAt);
    res.json({ accounts: users.map(enrichAccount) });`,
);

// 4c. PUT settings: enrich response + translate requireApproval to followupMode
replaceOnce(
  GMAIL_AUTH,
  "gmail-auth: translate requireApproval write to followupMode",
  `    if (requireApproval !== undefined) updates.requireApproval = Boolean(requireApproval);

    await db.update(usersTable).set(updates).where(eq(usersTable.id, userId));

    const updated = await db.select(ACCOUNT_SELECT).from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    res.json({ success: true, account: updated[0] || null });`,
  `    if (requireApproval !== undefined) {
      // Batch 3a: requireApproval boolean now maps to followupMode enum.
      // true -> 'review_in_app', false -> 'auto_send'. UI is unchanged.
      updates.followupMode = requireApproval ? "review_in_app" : "auto_send";
    }

    await db.update(usersTable).set(updates).where(eq(usersTable.id, userId));

    const updated = await db.select(ACCOUNT_SELECT).from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    res.json({ success: true, account: updated[0] ? enrichAccount(updated[0]) : null });`,
);

// ---------- Verify ----------

console.log(`\n[verify]`);

const finalUsers     = read(USERS_SCHEMA);
const finalFollowups = read(FOLLOWUPS_SCHEMA);
const finalScheduler = read(SCHEDULER);
const finalGmail     = read(GMAIL_AUTH);

const checks = [
  [finalUsers.includes(`export type FollowupMode`),                                                    "users.ts: FollowupMode type exported"],
  [finalUsers.includes(`DEFAULT_DRAFT_STAGE_TIMING`),                                                  "users.ts: DEFAULT_DRAFT_STAGE_TIMING exported"],
  [finalUsers.includes(`followupMode: text("followup_mode")`),                                         "users.ts: followupMode column declared"],
  [finalUsers.includes(`draftStageTiming: jsonb("draft_stage_timing")`),                               "users.ts: draftStageTiming column declared"],
  [!finalUsers.includes(`requireApproval: boolean("require_approval")`),                               "users.ts: requireApproval column removed"],
  [finalFollowups.includes(`draftMessageId: text("draft_message_id")`),                                "followups.ts: draftMessageId column declared"],
  [finalScheduler.includes(`user?.followupMode === "review_in_app"`),                                  "scheduler.ts: reads followupMode"],
  [!finalScheduler.includes(`user?.requireApproval`),                                                  "scheduler.ts: no longer reads requireApproval"],
  [finalGmail.includes(`followupMode: usersTable.followupMode`),                                       "gmail-auth.ts: projection includes followupMode"],
  [finalGmail.includes(`function enrichAccount`),                                                      "gmail-auth.ts: enrichAccount helper present"],
  [(finalGmail.match(/enrichAccount/g) || []).length >= 3,                                             "gmail-auth.ts: enrichAccount used at all 2 response sites (1 definition + 2 usages)"],
  [!finalGmail.includes(`updates.requireApproval = Boolean(requireApproval)`),                         "gmail-auth.ts: PUT no longer writes requireApproval column"],
  [finalGmail.includes(`updates.followupMode = requireApproval ? "review_in_app" : "auto_send"`),      "gmail-auth.ts: PUT translates requireApproval -> followupMode"],
];

let failed = 0;
for (const [ok, label] of checks) {
  console.log(`  ${ok ? "[ok]" : "[fail]"} ${label}`);
  if (!ok) failed++;
}

console.log(`\nsummary: ${changed} change(s) applied, ${skipped} skipped (already applied)`);
if (failed > 0) {
  console.error(`verify: ${failed} check(s) failed`);
  process.exit(1);
}
console.log("verify: all checks passed");
