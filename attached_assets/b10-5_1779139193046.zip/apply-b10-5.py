#!/usr/bin/env python3
"""
B10.5 - Pass userId to /api/gmail/thread/:threadId so per-user OAuth
        token is used (fixes invalid_grant from B10.3 result).

Backend's getGmailForRequest already reads req.query.userId and
switches to getGmailForUser(refreshToken, email) when present. Without
userId, falls through to getLegacyGmail() which uses
process.env.GOOGLE_REFRESH_TOKEN — that token is invalid/expired,
producing HTTP 500: invalid_grant.

Frontend wires selectedUserId through:
  main component -> EmailCard -> ThreadView -> fetch URL

Five anchors:
  A1: ThreadView signature - add userId prop
  A2: useQuery config - embed userId in URL, queryKey, enabled gate
  A3: EmailCard signature - add userId prop
  A4: ThreadView invocation inside EmailCard - pass userId
  A5: EmailCard invocation in main component - pass selectedUserId

Idempotent. Markers checked per anchor.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INSP = WORKSPACE / "artifacts/dashboard/src/pages/email-inspector.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def patch(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already applied")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor matched {count} times; expected 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: ThreadView signature
# ====================================================================
A1_OLD = '''function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {'''
A1_NEW = '''function ThreadView({ threadId, apiKey, userId }: { threadId: string; apiKey: string; userId: string }) {'''


# ====================================================================
# A2: useQuery config - URL, queryKey, enabled gate
# ====================================================================
A2_OLD = '''    queryKey: ["/api/thread", threadId],
    queryFn: async () => {
      const res = await fetch(`/api/gmail/thread/${threadId}`, {
        headers: { "x-api-key": apiKey },
      });
      if (!res.ok) {
        let detail = "";
        try {
          const body = await res.json();
          detail = body?.error || JSON.stringify(body);
        } catch {
          detail = await res.text().catch(() => "");
        }
        throw new Error(`HTTP ${res.status}${detail ? `: ${detail}` : ""}`);
      }
      return res.json();
    },
    enabled: !!threadId && !!apiKey,
  });'''

A2_NEW = '''    queryKey: ["/api/thread", threadId, userId],
    queryFn: async () => {
      // B10.5: include userId so backend getGmailForRequest uses the per-user
      // OAuth token. Without it, the legacy env-var token is tried — which is
      // invalid/expired, producing 500 invalid_grant.
      const url = `/api/gmail/thread/${threadId}?userId=${encodeURIComponent(userId)}`;
      const res = await fetch(url, {
        headers: { "x-api-key": apiKey },
      });
      if (!res.ok) {
        let detail = "";
        try {
          const body = await res.json();
          detail = body?.error || JSON.stringify(body);
        } catch {
          detail = await res.text().catch(() => "");
        }
        throw new Error(`HTTP ${res.status}${detail ? `: ${detail}` : ""}`);
      }
      return res.json();
    },
    enabled: !!threadId && !!apiKey && !!userId,
  });'''


# ====================================================================
# A3: EmailCard signature
# ====================================================================
A3_OLD = '''function EmailCard({ email, apiKey }: { email: SentEmail; apiKey: string }) {'''
A3_NEW = '''function EmailCard({ email, apiKey, userId }: { email: SentEmail; apiKey: string; userId: string }) {'''


# ====================================================================
# A4: ThreadView invocation inside EmailCard
# ====================================================================
A4_OLD = '''<ThreadView threadId={email.threadId} apiKey={apiKey} />'''
A4_NEW = '''<ThreadView threadId={email.threadId} apiKey={apiKey} userId={userId} />'''


# ====================================================================
# A5: EmailCard invocation in main component
# ====================================================================
A5_OLD = '''<EmailCard key={email.id} email={email} apiKey={apiKey || ""} />'''
A5_NEW = '''<EmailCard key={email.id} email={email} apiKey={apiKey || ""} userId={selectedUserId} />'''


def main():
    if not INSP.exists():
        fail(f"email-inspector.tsx not found: {INSP}")
    text = INSP.read_text(encoding="utf-8")
    original = text

    text, _ = patch(text, A1_OLD, A1_NEW,
                    "A1: ThreadView signature",
                    marker="function ThreadView({ threadId, apiKey, userId }")
    text, _ = patch(text, A2_OLD, A2_NEW,
                    "A2: useQuery URL/queryKey/enabled",
                    marker="B10.5: include userId so backend")
    text, _ = patch(text, A3_OLD, A3_NEW,
                    "A3: EmailCard signature",
                    marker="function EmailCard({ email, apiKey, userId }")
    text, _ = patch(text, A4_OLD, A4_NEW,
                    "A4: ThreadView invocation",
                    marker="<ThreadView threadId={email.threadId} apiKey={apiKey} userId={userId}")
    text, _ = patch(text, A5_OLD, A5_NEW,
                    "A5: EmailCard invocation",
                    marker='<EmailCard key={email.id} email={email} apiKey={apiKey || ""} userId={selectedUserId}')

    if text != original:
        INSP.write_text(text, encoding="utf-8")
        ok(f"wrote {INSP.relative_to(WORKSPACE)}")
    else:
        skip("email-inspector.tsx already patched")

    print()
    print("B10.5 userId threading applied.")


if __name__ == "__main__":
    main()
