# Batch 4 — Self-mailed weekly digest

## What this batch does

Adds a weekly digest email that fires every Tuesday at 00:00 UTC and is sent
through each user's own Gmail OAuth credentials. No external mail provider.

Six sections in the digest body, covering the last 7 days:

1. Follow-ups sent
2. Replies received
3. Pending approval (review_in_app users only)
4. Drafts approaching 30-day timeout (draft_in_gmail users only)
5. Drafts stalled in last 7 days
6. New prospects added

Sections with zero rows are not rendered. If everything is zero, the body
shows a one-line "no activity" message instead.

Users opt in/out via a Settings toggle. Existing review_in_app and
draft_in_gmail users are flipped ON by the migration; auto_send users
default OFF and stay OFF unless they explicitly enable.

## Files in this bundle

| File | Purpose |
|---|---|
| `migrate-batch4.mjs`            | DB migration (idempotent, transactional). Adds `users.weekly_digest_enabled` and `users.last_weekly_digest_at`, seeds opt-in flag for existing review/draft users. |
| `apply-batch4.mjs`              | Code patch. Applies 10 idempotent str_replace operations across 4 files, copies the new service file in, removes 5 leftover .batch3b.bak files. |
| `audit-batch4.mjs`              | Beautiful-Squidward audit harness. 3 rounds × 9 passes = 27 checks per round, 120 total assertions. |
| `payload/services/weeklyDigest.ts` | New service file. Copied into `artifacts/api-server/src/services/` by apply-batch4.mjs. |

No new npm packages. Uses existing `node-cron`, `googleapis`, `drizzle-orm`,
and `pg` deps.

## Operating defaults baked in (from prior batches)

- `DB_BASE = lib/db/src`
- `API_BASE = artifacts/api-server/src`
- `DASH_BASE = artifacts/dashboard/src`
- Migration script needs `pg` in scope. Place under `lib/db/` before running.
- Restart via `restart_workflow`. Never `kill 1`.
- Build before restart is mandatory.
- Mirror sync `artifacts/` and `lib/db/` → `source-code/` after deploy.

## How to deploy (paste-ready agent command)

See the agent command block in the response that shipped this zip.

## Manual verification after deploy

```bash
# 1. Confirm columns landed
psql "$DATABASE_URL" -c "
  SELECT column_name, data_type, column_default
  FROM information_schema.columns
  WHERE table_name='users' AND column_name IN ('weekly_digest_enabled','last_weekly_digest_at')
  ORDER BY column_name;"
# expect 2 rows

# 2. Confirm seed distribution
psql "$DATABASE_URL" -c "
  SELECT followup_mode, weekly_digest_enabled, COUNT(*)
  FROM users GROUP BY 1,2 ORDER BY 1,2;"
# expect: review_in_app + draft_in_gmail users = TRUE; auto_send users = FALSE

# 3. Confirm cron registered (check api-server logs at startup)
# expect log line: "Cron jobs active: ... weekly-digest @Tue 00:00 UTC ..."

# 4. Force-send to yourself for end-to-end check
# (run inside api-server with env vars):
#   node -e "import('./services/weeklyDigest.js').then(m => m.runWeeklyDigest({force:true}))"
# Then check your own Gmail inbox.
```

## Roll-forward note

This batch is forward-only. There is no rollback script. To undo:

```sql
-- Disable the cron by setting all users to OFF
UPDATE users SET weekly_digest_enabled = FALSE;

-- (Optional) drop the columns. Only do this if you really need to revert.
ALTER TABLE users DROP COLUMN IF EXISTS weekly_digest_enabled;
ALTER TABLE users DROP COLUMN IF EXISTS last_weekly_digest_at;
```

The code patches must be reverted via git. The agent command does not
keep a separate rollback bundle.
