import { pgTable, serial, text, integer, timestamp, boolean, index, uniqueIndex, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export interface StageTiming {
  minDays: number;
  maxDays: number;
}

export const DEFAULT_STAGE_TIMING: StageTiming[] = [
  { minDays: 3, maxDays: 7 },
  { minDays: 10, maxDays: 14 },
  { minDays: 21, maxDays: 28 },
];

export const DEFAULT_SEND_DAYS: number[] = [1, 2, 3, 4, 5];

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull().default(""),
  googleRefreshToken: text("google_refresh_token"),
  isConnected: boolean("is_connected").notNull().default(false),

  stageTiming: jsonb("stage_timing").$type<StageTiming[]>().notNull().default(DEFAULT_STAGE_TIMING),
  sendDays: jsonb("send_days").$type<number[]>().notNull().default(DEFAULT_SEND_DAYS),
  sendHourStart: integer("send_hour_start").notNull().default(8),
  sendHourEnd: integer("send_hour_end").notNull().default(18),
  maxFollowups: integer("max_followups").notNull().default(3),
  doctrineLabel: text("doctrine_label").notNull().default("Doctrine SDR"),
  testMode: boolean("test_mode").notNull().default(false),
  requireApproval: boolean("require_approval").notNull().default(false),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  uniqueIndex("idx_users_email").on(table.email),
  index("idx_users_connected").on(table.isConnected),
]);

export const insertUserSchema = createInsertSchema(usersTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof usersTable.$inferSelect;
