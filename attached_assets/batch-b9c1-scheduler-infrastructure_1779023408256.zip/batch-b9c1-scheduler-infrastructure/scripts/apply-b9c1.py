#!/usr/bin/env python3
r"""
B9c.1 — infrastructure batch. Three surgical edits across two files.

Edit 1 (routes/anti-ghosting.ts): change the F1 followup insert status
from "scheduled" to "queued" so the scheduler dispatcher actually picks
the row up. B9b shipped with the wrong status (scheduled never matches
the dispatcher's WHERE clause); this is the corrective.

Edit 2 (services/scheduler.ts): add `ne` to the drizzle-orm import.

Edit 3 (services/scheduler.ts): add an exclusion filter
`ne(prospectsTable.app, "anti_ghosting")` to the dispatcher's conditions
array, so anti_ghosting rows are NOT picked for dispatch yet. Without
this gate, once edit 1 lands the dispatcher would happily pick an
anti_ghosting row, fall through the existing `app === "context" ?
generateContextFollowup : generateFollowupEmail` ternary, and run the
DOCTRINE generator on it — wrong voice, wrong structure, possible
client-facing output. The exclusion stays in place until B9c.2 lands
the real anti_ghosting generator + a proper third branch.

All three edits are idempotent — running this script twice produces
the same final state. Self-reporting: prints diffs and SKIP labels.

Usage: python3 apply-b9c1.py  (from the workspace root)
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int]:
    """
    Apply a list of (old, new, label) edits to a file.
    Returns (applied_count, already_count).
    """
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0)

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    for old, new, label in edits:
        # Check NEW first. If the file is already in the post-edit state,
        # SKIP — otherwise, when NEW is a superset of OLD (e.g., we're
        # APPENDING content next to OLD rather than REPLACING it), the
        # naive "OLD-in-content" check would re-apply on every run and
        # double-insert the append. Checking NEW first short-circuits.
        if new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither old nor new pattern found")

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already)


def main() -> int:
    total_applied = 0
    total_already = 0
    total_files_with_issues = 0

    # --- Edit 1: B9b status fix ---
    print("\n--- artifacts/api-server/src/routes/anti-ghosting.ts ---")
    a, b = patch_file(
        "artifacts/api-server/src/routes/anti-ghosting.ts",
        [
            (
                '      status: "scheduled",',
                '      status: "queued",',
                "F1 followup status scheduled -> queued",
            )
        ],
    )
    total_applied += a
    total_already += b

    # --- Edits 2 + 3: scheduler exclusion gate for anti_ghosting ---
    print("\n--- artifacts/api-server/src/services/scheduler.ts ---")
    a, b = patch_file(
        "artifacts/api-server/src/services/scheduler.ts",
        [
            (
                'import { eq, and, lte, lt, inArray } from "drizzle-orm";',
                'import { eq, ne, and, lte, lt, inArray } from "drizzle-orm";',
                "add `ne` to drizzle-orm imports",
            ),
            (
                '    eq(followupsTable.status, "queued"),\n'
                '    lte(followupsTable.scheduledAt, new Date()),\n',
                '    eq(followupsTable.status, "queued"),\n'
                '    lte(followupsTable.scheduledAt, new Date()),\n'
                '    // B9c.1: gate the dispatcher off anti_ghosting until B9c.2\n'
                '    // ships the real generator + proper dispatch branch.\n'
                '    // Without this line, any anti_ghosting row that became "queued"\n'
                '    // would fall through to the doctrine generator and produce\n'
                '    // wrong-voice content. Remove this line as part of B9c.2.\n'
                '    ne(prospectsTable.app, "anti_ghosting"),\n',
                "add anti_ghosting exclusion filter to dispatcher conditions",
            ),
        ],
    )
    total_applied += a
    total_already += b

    print(f"\n=== Summary ===")
    print(f"  Edits applied:      {total_applied}")
    print(f"  Already-applied:    {total_already}")
    expected = 3
    if total_applied + total_already < expected:
        print(f"  WARNING: expected {expected} edits, only saw {total_applied + total_already}")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
