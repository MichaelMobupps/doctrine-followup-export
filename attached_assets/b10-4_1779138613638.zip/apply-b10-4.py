#!/usr/bin/env python3
"""
B10.4 - Activity Log: drop per-card explicit stagger delay.

The file's UserCard and idle-user motion.divs each compute their own
delay = index * 0.05 (50ms per card). With ~13 cards this builds a
650ms cascade *before* duration. Compounds with B9d.8's App-level
staggerChildren: 0.03 (additional 30ms per card via inheritance).
User-perceived cascade: ~1+ seconds. Previously perceived as instant.

Fix: drop the explicit delay in both motion wrappers. Cards now animate
together at duration: 0.2. Inherited B9d.8 stagger still gives a subtle
30ms cascade - feels snappy, not laggy.

Two anchors:
  A1: UserCard wrapper transition (line ~203)
  A2: Idle-user wrapper transition (line ~449)

Both lines are unique. Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ACT = WORKSPACE / "artifacts/dashboard/src/pages/activity-log.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def patch(text, old, new, label):
    if new in text and old not in text:
        skip(f"{label}: already applied")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor matched {count} times; expected 1")
    ok(f"{label}: delay removed")
    return text.replace(old, new, 1), True


# A1: UserCard motion.div wrapper.
A1_OLD = '''      transition={{ delay: index * 0.05, duration: 0.2 }}'''
A1_NEW = '''      // B10.4: explicit per-card delay removed. Cards animate together at duration: 0.2.
      // Inherited B9d.8 staggerChildren (30ms) still provides a subtle entrance cascade.
      transition={{ duration: 0.2 }}'''


# A2: Idle-user motion.div wrapper.
A2_OLD = '''              transition={{ delay: (activeUsers.length + i) * 0.05, duration: 0.2 }}'''
A2_NEW = '''              // B10.4: explicit per-card delay removed.
              transition={{ duration: 0.2 }}'''


def main():
    if not ACT.exists():
        fail(f"activity-log.tsx not found: {ACT}")
    text = ACT.read_text(encoding="utf-8")
    original = text

    text, _ = patch(text, A1_OLD, A1_NEW, "A1: UserCard wrapper delay")
    text, _ = patch(text, A2_OLD, A2_NEW, "A2: Idle-user wrapper delay")

    if text != original:
        ACT.write_text(text, encoding="utf-8")
        ok(f"wrote {ACT.relative_to(WORKSPACE)}")
    else:
        skip("activity-log.tsx already at fixed state")

    print()
    print("B10.4 activity-log stagger removal applied.")


if __name__ == "__main__":
    main()
