#!/usr/bin/env node
/**
 * apply-batch4.mjs — Phase 4 (weekly digest) code patch.
 *
 * Idempotent. Anchored str_replace operations — re-runs are no-ops.
 *
 * Touches:
 *   - lib/db/src/schema/users.ts          (add 2 columns)
 *   - artifacts/api-server/src/cron.ts    (add Tuesday 00:00 UTC cron)
 *   - artifacts/api-server/src/routes/gmail-auth.ts
 *                                         (project new fields, accept in PUT)
 *   - artifacts/api-server/src/services/weeklyDigest.ts
 *                                         (NEW FILE — copied from payload/)
 *   - artifacts/dashboard/src/pages/accounts.tsx
 *                                         (add settings toggle)
 *
 * Cleanup:
 *   - Removes Batch 3b backup files (*.batch3b.bak) left in api-server/.
 *
 * After this script runs successfully, the agent must run:
 *   1. pnpm --filter @workspace/db run build
 *   2. pnpm --filter @workspace/api-server run build
 *   3. pnpm --filter @workspace/dashboard run build
 *   4. restart_workflow
 *   5. Mirror sync artifacts/ + lib/db/ → source-code/
 *
 * Usage:
 *   node apply-batch4.mjs
 *   DB_BASE=lib/db/src API_BASE=artifacts/api-server/src DASH_BASE=artifacts/dashboard/src node apply-batch4.mjs
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync, copyFileSync, unlinkSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));

const DB_BASE   = process.env.DB_BASE   || "lib/db/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const PAYLOAD_DIR = join(SCRIPT_DIR, "payload");

const log  = (msg) => console.log(`[apply-batch4] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch4] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

/**
 * Idempotent str_replace, sentinel-based.
 *
 * `sentinel` MUST be a substring of `newStr` that is NOT a substring of
 * `oldStr` and NOT present anywhere in the original file. If sentinel is
 * already in the file, the patch is treated as already applied (no-op).
 * Otherwise the anchor `oldStr` must match exactly once and is replaced.
 *
 * This is the only way to safely make str_replace idempotent when the new
 * content preserves the old content as a substring (which is the case for
 * "insert after / prepend to" patches).
 */
function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);

  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

// ============================================================
// Step 1: Patch lib/db/src/schema/users.ts
// ============================================================
log("Step 1: Patching schema (users)...");
const usersSchemaPath = join(DB_BASE, "schema", "users.ts");

strReplace(
  usersSchemaPath,
  `  hasSeenDraftModeWarning: boolean("has_seen_draft_mode_warning").notNull().default(false),`,
  `  hasSeenDraftModeWarning: boolean("has_seen_draft_mode_warning").notNull().default(false),

  // Phase 4: weekly digest opt-in. Defaults to FALSE so new users (created
  // in auto_send mode) do not auto-receive the digest. The migration in
  // migrate-batch4.mjs flips this to TRUE for existing review_in_app and
  // draft_in_gmail users on first run.
  weeklyDigestEnabled: boolean("weekly_digest_enabled").notNull().default(false),
  // Tracks when the cron last sent a digest to this user. Used as a 6-day
  // dedupe window to make accidental cron reruns a no-op.
  lastWeeklyDigestAt: timestamp("last_weekly_digest_at", { withTimezone: true }),`,
  "users.ts: add weeklyDigestEnabled + lastWeeklyDigestAt",
  `weeklyDigestEnabled: boolean("weekly_digest_enabled")`
);

// ============================================================
// Step 2: Copy weeklyDigest.ts service into api-server
// ============================================================
log("Step 2: Installing weeklyDigest.ts service...");
const targetServicesDir = join(API_BASE, "services");
const digestSrc  = join(PAYLOAD_DIR, "services", "weeklyDigest.ts");
const digestDst  = join(targetServicesDir, "weeklyDigest.ts");

if (!existsSync(PAYLOAD_DIR)) fail(`PAYLOAD_DIR not found: ${PAYLOAD_DIR}`);
if (!existsSync(digestSrc))   fail(`payload weeklyDigest.ts missing at ${digestSrc}`);
if (!existsSync(targetServicesDir)) fail(`api-server services dir missing: ${targetServicesDir}`);

copyFileSync(digestSrc, digestDst);
log(`  [+] services/weeklyDigest.ts installed`);

// ============================================================
// Step 3: Patch cron.ts to add Tuesday 00:00 UTC digest cron
// ============================================================
log("Step 3: Patching cron.ts...");
const cronPath = join(API_BASE, "cron.ts");

strReplace(
  cronPath,
  `import { processDueFollowups, autoQueueAllCampaigns, stallDraftedFollowups } from "./services/scheduler";`,
  `import { processDueFollowups, autoQueueAllCampaigns, stallDraftedFollowups } from "./services/scheduler";
import { runWeeklyDigest } from "./services/weeklyDigest";`,
  "cron.ts: import runWeeklyDigest",
  `import { runWeeklyDigest } from "./services/weeklyDigest";`
);

strReplace(
  cronPath,
  `  logger.info("Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50, draft-stall @00:30, fast-tick @*/3");`,
  `  // Weekly digest: Tuesday 00:00 UTC. The runWeeklyDigest() function
  // self-dedupes via users.last_weekly_digest_at (6-day window) so any
  // accidental rerun within the same Tuesday is a no-op.
  cron.schedule("0 0 * * 2", async () => {
    logger.info("Running weekly digest...");
    try {
      const result = await runWeeklyDigest();
      logger.info(
        { considered: result.considered, sent: result.sent, skipped: result.skipped, failed: result.failed },
        "Weekly digest done",
      );
    } catch (err) {
      logger.error({ err }, "Weekly digest error");
    }
  }, { timezone: "UTC" });

  logger.info("Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50, draft-stall @00:30, weekly-digest @Tue 00:00 UTC, fast-tick @*/3");`,
  "cron.ts: add weekly digest cron + update startup log",
  `cron.schedule("0 0 * * 2"`
);

// ============================================================
// Step 4: Patch gmail-auth.ts to project + accept new fields
// ============================================================
log("Step 4: Patching gmail-auth.ts...");
const gmailAuthPath = join(API_BASE, "routes", "gmail-auth.ts");

strReplace(
  gmailAuthPath,
  `  hasSeenDraftModeWarning: usersTable.hasSeenDraftModeWarning,
  createdAt: usersTable.createdAt,
} as const;`,
  `  hasSeenDraftModeWarning: usersTable.hasSeenDraftModeWarning,
  weeklyDigestEnabled: usersTable.weeklyDigestEnabled,
  lastWeeklyDigestAt: usersTable.lastWeeklyDigestAt,
  createdAt: usersTable.createdAt,
} as const;`,
  "gmail-auth.ts: project weeklyDigestEnabled + lastWeeklyDigestAt",
  `weeklyDigestEnabled: usersTable.weeklyDigestEnabled,`
);

strReplace(
  gmailAuthPath,
  `    const {
      stageTiming,
      sendDays,
      sendHourStart,
      sendHourEnd,
      maxFollowups,
      doctrineLabel,
      followupMode,
      draftStageTiming,
      hasSeenDraftModeWarning,
    } = req.body;`,
  `    const {
      stageTiming,
      sendDays,
      sendHourStart,
      sendHourEnd,
      maxFollowups,
      doctrineLabel,
      followupMode,
      draftStageTiming,
      hasSeenDraftModeWarning,
      weeklyDigestEnabled,
    } = req.body;`,
  "gmail-auth.ts: destructure weeklyDigestEnabled from PUT body",
  `weeklyDigestEnabled,
    } = req.body;`
);

strReplace(
  gmailAuthPath,
  `    if (hasSeenDraftModeWarning !== undefined) {
      // Boolean coercion: only set TRUE if explicitly truthy. Once TRUE we
      // never want to flip back to FALSE via this endpoint, so ignore false
      // payloads. (Schema-level constraint is NOT NULL DEFAULT FALSE; the
      // operator can manually reset via SQL if ever needed.)
      if (hasSeenDraftModeWarning === true) {
        updates.hasSeenDraftModeWarning = true;
      }
    }`,
  `    if (hasSeenDraftModeWarning !== undefined) {
      // Boolean coercion: only set TRUE if explicitly truthy. Once TRUE we
      // never want to flip back to FALSE via this endpoint, so ignore false
      // payloads. (Schema-level constraint is NOT NULL DEFAULT FALSE; the
      // operator can manually reset via SQL if ever needed.)
      if (hasSeenDraftModeWarning === true) {
        updates.hasSeenDraftModeWarning = true;
      }
    }
    if (weeklyDigestEnabled !== undefined) {
      // Phase 4: weekly digest opt-in is a true two-way toggle. Users can
      // turn it off (and back on) freely from the Settings UI.
      updates.weeklyDigestEnabled = weeklyDigestEnabled === true;
    }`,
  "gmail-auth.ts: accept weeklyDigestEnabled writes",
  `updates.weeklyDigestEnabled = weeklyDigestEnabled === true;`
);

// ============================================================
// Step 5: Patch dashboard accounts.tsx — add Settings toggle
// ============================================================
log("Step 5: Patching dashboard accounts.tsx...");
const accountsPath = join(DASH_BASE, "pages", "accounts.tsx");

strReplace(
  accountsPath,
  `  const [doctrineLabel, setDoctrineLabel] = useState<string>(account.doctrineLabel || "Doctrine SDR");`,
  `  const [doctrineLabel, setDoctrineLabel] = useState<string>(account.doctrineLabel || "Doctrine SDR");
  const [weeklyDigestEnabled, setWeeklyDigestEnabled] = useState<boolean>(account.weeklyDigestEnabled === true);`,
  "accounts.tsx: add weeklyDigestEnabled state",
  `const [weeklyDigestEnabled, setWeeklyDigestEnabled] = useState<boolean>`
);

strReplace(
  accountsPath,
  `        followupMode,
        stageTiming: autoStages,
        draftStageTiming: draftStages,
        sendDays,
        sendHourStart,
        sendHourEnd,
        doctrineLabel,
      };`,
  `        followupMode,
        stageTiming: autoStages,
        draftStageTiming: draftStages,
        sendDays,
        sendHourStart,
        sendHourEnd,
        doctrineLabel,
        weeklyDigestEnabled,
      };`,
  "accounts.tsx: include weeklyDigestEnabled in PUT body",
  `doctrineLabel,
        weeklyDigestEnabled,
      };`
);

strReplace(
  accountsPath,
  `              {/* Gmail label */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Gmail label
                </label>
                <Input
                  value={doctrineLabel}
                  onChange={(e) => setDoctrineLabel(e.target.value)}
                  placeholder="Doctrine SDR"
                  className="max-w-xs"
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync</p>
              </div>`,
  `              {/* Gmail label */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Gmail label
                </label>
                <Input
                  value={doctrineLabel}
                  onChange={(e) => setDoctrineLabel(e.target.value)}
                  placeholder="Doctrine SDR"
                  className="max-w-xs"
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync</p>
              </div>

              {/* Phase 4: Weekly digest toggle */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Weekly digest
                </label>
                <button
                  type="button"
                  role="switch"
                  aria-checked={weeklyDigestEnabled}
                  onClick={() => setWeeklyDigestEnabled(!weeklyDigestEnabled)}
                  className="inline-flex items-center gap-3 px-3 py-2 rounded-md transition-all"
                  style={{
                    background: weeklyDigestEnabled ? "var(--accent-muted)" : "var(--bg-tertiary)",
                    border: \`1px solid \${weeklyDigestEnabled ? "var(--accent-border)" : "var(--border-default)"}\`,
                    cursor: "pointer",
                  }}
                >
                  <span
                    className="inline-block rounded-full transition-transform"
                    style={{
                      width: "32px",
                      height: "18px",
                      background: weeklyDigestEnabled ? "var(--accent)" : "var(--border-hover)",
                      position: "relative",
                    }}
                  >
                    <span
                      className="inline-block rounded-full bg-white shadow"
                      style={{
                        width: "14px",
                        height: "14px",
                        position: "absolute",
                        top: "2px",
                        left: weeklyDigestEnabled ? "16px" : "2px",
                        transition: "left 0.15s ease",
                      }}
                    />
                  </span>
                  <span className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>
                    {weeklyDigestEnabled ? "Enabled" : "Disabled"}
                  </span>
                </button>
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>
                  Sends a recap of the last 7 days every Tuesday at 00:00 UTC, delivered to your own Gmail inbox.
                </p>
              </div>`,
  "accounts.tsx: insert weekly digest settings block",
  `Phase 4: Weekly digest toggle`
);

// ============================================================
// Step 6: Cleanup .batch3b.bak files
// ============================================================
log("Step 6: Cleaning up Batch 3b backup files...");
const bakFiles = [
  join(API_BASE, "cron.ts.batch3b.bak"),
  join(API_BASE, "services", "gmailClient.ts.batch3b.bak"),
  join(API_BASE, "services", "gmailSync.ts.batch3b.bak"),
  join(API_BASE, "services", "scheduler.ts.batch3b.bak"),
  join(API_BASE, "services", "timingEngine.ts.batch3b.bak"),
];
let removed = 0;
for (const bak of bakFiles) {
  if (existsSync(bak)) {
    unlinkSync(bak);
    log(`  [-] Removed ${bak}`);
    removed++;
  }
}
log(`  Removed ${removed} backup file(s).`);

// ============================================================
// Step 7: Self-verify (9 grep checks — Beautiful Squidward style)
// ============================================================
log("Step 7: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found in ${path}: ${needle.slice(0, 80)}...`);
  log(`  [OK] ${label}`);
}

function expectCountInFile(path, needle, expected, label) {
  const content = readFileOrFail(path);
  const count = content.split(needle).length - 1;
  if (count !== expected) fail(`Verify "${label}": expected ${expected} occurrences of "${needle.slice(0, 50)}", found ${count}.`);
  log(`  [OK] ${label} (count=${count})`);
}

// V1: Schema column added
expectInFile(usersSchemaPath, `weeklyDigestEnabled: boolean("weekly_digest_enabled")`, "V1 schema weeklyDigestEnabled column");
// V2: Schema timestamp column added
expectInFile(usersSchemaPath, `lastWeeklyDigestAt: timestamp("last_weekly_digest_at"`, "V2 schema lastWeeklyDigestAt column");
// V3: Service file installed and contains the public exports
expectInFile(digestDst, `export async function runWeeklyDigest`, "V3 weeklyDigest.ts runWeeklyDigest export");
expectInFile(digestDst, `export async function sendWeeklyDigestForUser`, "V3b weeklyDigest.ts sendWeeklyDigestForUser export");
// V4: Cron import wired
expectInFile(cronPath, `import { runWeeklyDigest } from "./services/weeklyDigest"`, "V4 cron.ts runWeeklyDigest import");
// V5: Cron schedule set with Tuesday 00:00 UTC
expectInFile(cronPath, `cron.schedule("0 0 * * 2"`, "V5 cron.ts Tuesday 00:00 cron");
// V6: Cron uses UTC timezone explicitly
expectInFile(cronPath, `timezone: "UTC"`, "V6 cron.ts UTC timezone");
// V7: gmail-auth projects new fields
expectInFile(gmailAuthPath, `weeklyDigestEnabled: usersTable.weeklyDigestEnabled,`, "V7 gmail-auth.ts projection");
// V8: gmail-auth accepts the field in PUT body
expectInFile(gmailAuthPath, `updates.weeklyDigestEnabled = weeklyDigestEnabled === true;`, "V8 gmail-auth.ts PUT write");
// V9: Dashboard has the toggle state and PUT body field
expectInFile(accountsPath, `const [weeklyDigestEnabled, setWeeklyDigestEnabled] = useState<boolean>`, "V9 accounts.tsx state hook");
expectInFile(accountsPath, `weeklyDigestEnabled,\n      };`, "V9b accounts.tsx in PUT body");
expectInFile(accountsPath, `Weekly digest`, "V9c accounts.tsx label rendered");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 4 patch applied. Next: build + restart + mirror sync.");
log("================================================================");
