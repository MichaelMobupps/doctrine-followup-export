#!/usr/bin/env python3
"""
B9d.9 - AG bg darkening for clearer sidebar/card separation.

Single anchor in index.css: the AG bg block from B9d.5 darkens from
slate-100 (#f1f5f9) to slate-200 (#e2e8f0) for the page bg. Hover bg
also bumps to slate-300 (#cbd5e1) to maintain differentiation from
the new page bg.

Sidebar (--bg-secondary #ffffff) and cards (--bg-secondary #ffffff)
stay pure white - they now visibly float above the darker slate bg.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INDEX_CSS = WORKSPACE / "artifacts/dashboard/src/index.css"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


OLD = '''  /* B9d.5: page bg darkened to slate-100 so white cards visibly float. */
  --bg-primary: #f1f5f9;
  --bg-secondary: #ffffff;
  --bg-tertiary: #e2e8f0;
  --bg-elevated: #ffffff;'''

NEW = '''  /* B9d.5: page bg darkened so white cards visibly float. */
  /* B9d.9: bumped page bg to slate-200 and hover to slate-300 for clearer separation. */
  --bg-primary: #e2e8f0;
  --bg-secondary: #ffffff;
  --bg-tertiary: #cbd5e1;
  --bg-elevated: #ffffff;'''

MARKER = "B9d.9: bumped page bg to slate-200"


def main():
    if not INDEX_CSS.exists():
        fail(f"index.css not found: {INDEX_CSS}")
    text = INDEX_CSS.read_text(encoding="utf-8")

    if MARKER in text:
        print("[skip] AG bg darkening already applied")
        return

    count = text.count(OLD)
    if count == 0:
        fail("anchor not found - expected the B9d.5 AG bg block")
    if count != 1:
        fail(f"anchor matched {count} times; expected exactly 1")

    text = text.replace(OLD, NEW)
    INDEX_CSS.write_text(text, encoding="utf-8")
    print("[ok]   AG bg darkened to slate-200/slate-300")
    print(f"[ok]   wrote {INDEX_CSS.relative_to(WORKSPACE)}")
    print()
    print("B9d.9 AG bg darkening applied.")


if __name__ == "__main__":
    main()
