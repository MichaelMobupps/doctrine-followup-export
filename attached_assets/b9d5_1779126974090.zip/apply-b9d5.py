#!/usr/bin/env python3
"""
B9d.5 - Modern feel: accent glow on primary CTAs + AG bg refinement.

Six anchors:
  C1: AG bg refinement \u2014 bg-primary darker so cards visibly float.
      #f8fafc \u2192 #f1f5f9 (slate-100), bg-tertiary \u2192 #e2e8f0.
  C2: :root          add --accent-glow rgba(59,130,246,0.25)
  C3: AG block       add --accent-glow rgba(37,99,235,0.22)  (lighter, subtler on white)
  C4: Doctrine block add --accent-glow rgba(37,99,235,0.35)  (saturated on dark)
  C5: Context block  add --accent-glow rgba(245,158,11,0.40) (warm halo on dark)
  U1: Button default - hover:shadow-[0_4px_24px_var(--accent-glow)]
      Adds soft accent halo on hover; resting still uses shadow-sm.

Pure CSS transitions (200ms from B9d.2). No animation framework
added. No new dependencies. Reversible by deleting tokens + Button
shadow class.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INDEX_CSS = WORKSPACE / "artifacts/dashboard/src/index.css"
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# C1: AG bg refinement \u2014 page bg slightly darker, cards now pop.
# Anchor on the three AG bg tokens in order (unique to AG block).
# ====================================================================
C1_OLD = '''  --bg-primary: #f8fafc;
  --bg-secondary: #ffffff;
  --bg-tertiary: #f1f5f9;
  --bg-elevated: #ffffff;'''

C1_NEW = '''  /* B9d.5: page bg darkened to slate-100 so white cards visibly float. */
  --bg-primary: #f1f5f9;
  --bg-secondary: #ffffff;
  --bg-tertiary: #e2e8f0;
  --bg-elevated: #ffffff;'''


# ====================================================================
# C2: :root - add --accent-glow
# Anchor on the unique :root accent-foreground comment.
# ====================================================================
C2_OLD = '''  --accent-foreground: #ffffff; /* B9d.4: text color for elements with accent bg */'''

C2_NEW = '''  --accent-foreground: #ffffff; /* B9d.4: text color for elements with accent bg */
  --accent-glow: rgba(59,130,246,0.25); /* B9d.5: accent halo for hover/focus on primary CTAs */'''


# ====================================================================
# C3: AG block - add --accent-glow
# Anchor on the AG-specific accent-foreground line.
# ====================================================================
C3_OLD = '''  --accent-border: rgba(37,99,235,0.25);
  --accent-foreground: #ffffff; /* B9d.4 */'''

C3_NEW = '''  --accent-border: rgba(37,99,235,0.25);
  --accent-foreground: #ffffff; /* B9d.4 */
  --accent-glow: rgba(37,99,235,0.22); /* B9d.5: subtler on white bg */'''


# ====================================================================
# C4: Doctrine block - add --accent-glow
# Anchor on Doctrine-specific lines (accent-border value + Tailwind comment).
# ====================================================================
C4_OLD = '''  --accent-border: rgba(37,99,235,0.28);
  --accent-foreground: #ffffff;

  /* Tailwind v4 mirrors so utility classes pick up the new blue. */'''

C4_NEW = '''  --accent-border: rgba(37,99,235,0.28);
  --accent-foreground: #ffffff;
  --accent-glow: rgba(37,99,235,0.35); /* B9d.5: saturated blue halo on dark bg */

  /* Tailwind v4 mirrors so utility classes pick up the new blue. */'''


# ====================================================================
# C5: Context block - add --accent-glow
# Anchor on Context-specific lines (amber accent-border + dark accent-fg).
# ====================================================================
C5_OLD = '''  --accent-border: rgba(245,158,11,0.30);
  --accent-foreground: #1a1208;'''

C5_NEW = '''  --accent-border: rgba(245,158,11,0.30);
  --accent-foreground: #1a1208;
  --accent-glow: rgba(245,158,11,0.40); /* B9d.5: warm amber halo */'''


# ====================================================================
# U1: Button default variant - add hover glow shadow
# Anchor on B9d.4's default variant line.
# ====================================================================
U1_OLD = '''      // B9d.4: text-[var(--accent-foreground)] enables per-product text-color on accent bg (white on blue, dark on amber).
      default: "bg-[var(--accent)] text-[var(--accent-foreground)] border border-[var(--accent)] shadow-sm hover:bg-[var(--accent-hover)] hover:border-[var(--accent-hover)] focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]",'''

U1_NEW = '''      // B9d.4: text-[var(--accent-foreground)] enables per-product text-color on accent bg (white on blue, dark on amber).
      // B9d.5: hover lifts a soft accent-tinted halo (--accent-glow) for premium CTA feel.
      default: "bg-[var(--accent)] text-[var(--accent-foreground)] border border-[var(--accent)] shadow-sm hover:bg-[var(--accent-hover)] hover:border-[var(--accent-hover)] hover:shadow-[0_4px_24px_var(--accent-glow)] focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]",'''


def patch_css():
    if not INDEX_CSS.exists():
        fail(f"index.css not found: {INDEX_CSS}")
    text = INDEX_CSS.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, C1_OLD, C1_NEW,
        "C1: AG bg refinement",
        marker="B9d.5: page bg darkened to slate-100",
    )

    text, _ = replace_unique(
        text, C2_OLD, C2_NEW,
        "C2: :root add --accent-glow",
        marker="--accent-glow: rgba(59,130,246,0.25)",
    )

    text, _ = replace_unique(
        text, C3_OLD, C3_NEW,
        "C3: AG block add --accent-glow",
        marker="--accent-glow: rgba(37,99,235,0.22)",
    )

    text, _ = replace_unique(
        text, C4_OLD, C4_NEW,
        "C4: Doctrine block add --accent-glow",
        marker="--accent-glow: rgba(37,99,235,0.35)",
    )

    text, _ = replace_unique(
        text, C5_OLD, C5_NEW,
        "C5: Context block add --accent-glow",
        marker="--accent-glow: rgba(245,158,11,0.40)",
    )

    if text != original:
        INDEX_CSS.write_text(text, encoding="utf-8")
        ok(f"wrote {INDEX_CSS.relative_to(WORKSPACE)}")
    else:
        skip("index.css already patched")


def patch_ui():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, U1_OLD, U1_NEW,
        "U1: Button default hover glow",
        marker="B9d.5: hover lifts a soft accent-tinted halo",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")


def main():
    patch_css()
    patch_ui()
    print()
    print("B9d.5 glow + AG bg refinement applied.")


if __name__ == "__main__":
    main()
