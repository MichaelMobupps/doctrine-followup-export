# Followuper Nativeness v4 — Email Followuper Native-Style + Translationese Layer

TypeScript port of the Prospector v4 nativeness layer for the Followuper
monorepo (`michael2502/Email-Folllowuper`). Adds three layers of native-style
quality enforcement on top of the existing v3 Reading-A++ policy. **Purely
additive**: `nativenessV3.ts` is unchanged byte-for-byte; v4 stacks on top
via forwarder updates.

## What this fixes

The v3 Reading-A++ layer caught individual English content tokens in
non-English emails, X-not-Y comma-negation, and non-Latin greeting-name
transliteration failures. Three failure modes remained that v3 could not
detect:

1. **Translationese patterns** — literal English-idiom translations whose
   individual words are correct local-language tokens but whose combination
   reads as translated-from-English. v3 can't catch these because each word
   in isolation is fine. Examples in pt-BR: `evento norte` (north star),
   `gancho de` (hook), `mistura de editores` (publisher mix),
   `em sobreposição direta` (in direct overlap), `contra o CPA` (vs the CPA),
   `O ponto específico aqui é que`, `A forma como X é Y` (colloquial spoken
   register in formal B2B).

2. **Missing native structure** — non-English emails that lack the structural
   elements that distinguish a native B2B sales email from an English-
   translated one: social opener after greeting, native cohesion markers,
   softener phrases for differentiator claims, collaborative permission-
   asking CTA. v3 has no model of native B2B email structure.

3. **Universal name adaptation** — v3 only transliterated names for non-Latin
   scripts (`th`, `zh`, `ja`, `ko`, `ar`, `he`, `hi`, etc.). It missed the
   Latin-script-with-diacritic case: `Vinicius` should be `Vinícius` in pt;
   `Jose` should be `José` in es; `Tuan` should be `Tuấn` in vi.

## v4.1 — Loanword calibration

Some target languages have native English loanwords that v3's aggressive
singleton-flagging caught as false positives. v4.1 adds a per-language
`NATIVE_ENGLISH_LOANWORDS` exemption set:

- **KEEP in English** (pt-BR, es-LatAm, it, nl, id, ms, fil, tl): `performance`,
  `fee`, `players`, `mix`, `mobile`, `app/apps`, `blog/blogs`, `ROAS`, `LTV`,
  `KPI/KPIs`, `CTV`, `RTG`, `AB`. pt-BR additionally keeps BR finance
  acronyms: `PIX`, `FGC`, `CDI`, `AUM`, `CDB`.
- **TRANSLATE** (de, fr, ru, ja, zh, ko, ar, he, hi, th, vi): no loanword
  exemption — these languages translate the same concepts.

This means `mix de editores` is acceptable in pt-BR but `mistura de
editores` is a violation (the English loanword `mix` is native; the
translated noun is not). Same logic in es: `mix de editores` OK, `mezcla de
editores` violation. In German, `Publisher-Mix` is a violation —
`Publisher-Auswahl` or `Publisher-Mischung` (translated equivalent) is
required.

## v4.2 — Universal production-failure pattern checklist (criterion 13)

Added to the critic prompt as a 13th criterion. Eight sub-criteria that are
language-AGNOSTIC failure principles applied to every non-English email,
with per-language examples spanning 14 target languages (pt, es, it, fr, de,
ru, ja, zh, ko, ar, he, hi, th, vi):

- **13a. Greeting without social opener** — including the apologetic openers
  REQUIRED in Japanese (`突然のご連絡失礼いたします`), Chinese (`冒昧打扰`),
  and Korean (`갑작스러운 연락 드려 죄송합니다`).
- **13b. Stacked facts without cohesion markers** — per-language marker
  lists spanning Romance, Germanic, Slavic, CJK, Semitic, Indic, and
  Southeast Asian language families.
- **13c. Differentiator claim without softener** — per-language softener
  phrases for hedging value claims and CTAs.
- **13d. CTA verb-form check** — universal failure: declarative-infinitive
  CTAs read as translated from English. Per-language collaborative-grammar
  references (PT/ES subjunctive plural, FR conditional, DE Konjunktiv II,
  RU subjunctive plural, JA keigo, KO 존댓말, ZH 您是否方便, AR formal
  permission, HE/HI/TH/VI permission-asking patterns).
- **13e. Technical terminology inconsistency** — same concept rendered with
  two LOCAL terms (PT `coorte` vs `safra`, RU `когорта` vs `группа`, JA
  `コホート` vs `グループ`, ZH `群组` vs `队列`).
- **13f. Specific banned phrases per language** — explicit translationese
  lists for 14 languages.
- **13g. Regional variant leakage** — 4 major splits: pt → BR (reject EU
  PT `estamos a fazer`), es → LatAm (reject `vosotros`/`os escribo`),
  zh → CN Simplified (reject `伺服器`/`網路`/`資料`), ar → MSA (reject
  Egyptian `عايز`).
- **13h. Loanword inconsistency** — explicit distinction between
  loanword-KEEPING and loanword-TRANSLATING languages.

## v4.3 — Hotfix: writer + rewriter GREETING script-aware rule

Production failure observed: Followuper emitted `เรียน Thasawan,` in a Thai
outreach email — Thai greeting word + Latin-script first name. v3 criterion
10 and v4 UNIVERSAL NAME ADAPTATION both have the transliteration rule, but
the LLM kept emitting the Latin name because the **writer prompt itself**
had a competing GREETING instruction:

```
- GREETING: ALWAYS start the email with a greeting. If a first name is
  provided, use it (e.g., "Hi Sarah,"). ...
```

The `e.g., "Hi Sarah,"` example gave the LLM explicit permission to use the
Latin name as-provided. The v4 nativeness block transliteration rule lives
later in the prompt and competes with — and loses to — this earlier
explicit example. The critic + linter caught the failure after the fact,
but the writer kept regenerating it.

v4.3 replaces the weak GREETING instruction in BOTH the writer
(`getFollowupSystemPrompt`) and the rewriter (`getRewriterSystemPrompt`)
prompts with a non-bypassable script-aware rule that:

- Declares **CASE 1 (non-Latin-script target)** mandatory transliteration
  for 19 languages: Thai, Chinese, Japanese, Korean, Arabic, Hebrew, Persian,
  Urdu, Hindi, Bengali, Tamil, Telugu, Marathi, Russian, Ukrainian, Greek,
  Amharic, Georgian, Armenian.
- Shows **8 FORBIDDEN → REQUIRED examples** spanning Thai, Hindi, Japanese,
  Korean, Chinese, Russian, Arabic, Hebrew, Greek — including the canonical
  `Thasawan → ทศวรรณ` Thai example that triggered v4.3.
- Declares **CASE 2 (Latin-with-diacritic target)** orthography adaptation
  for 15 languages with examples (`Vinicius → Vinícius`, `Jose → José`,
  `Tuan → Tuấn`, `Lukasz → Łukasz`, etc.).
- Declares **CASE 3 (ASCII-Latin target)** name-as-provided for English,
  Dutch, Indonesian, Malay, Swahili, Filipino/Tagalog.

The rule is framed as `CRITICAL — non-bypassable rule that overrides any
default to "use the name as provided"`. Both prompts patched so that
neither the writer NOR the rewriter can emit a Latin-script name in a
non-Latin-script email.



## File inventory

```
followuper-nativeness-v4/
  README.md                                      # this file
  audit_v4.sh                                    # 5-round godlike audit (47 checks)
  api-server/
    lib/
      nativenessV4.ts                            # v4 module (~56 KB, 35 langs, 169 patterns)
    tests/
      test-nativeness-v4.ts                      # v4 test suite (46 tests inc. 5 v4.3 hotfix)
  patches/
    apply_patches.py                             # 13 operations, idempotent, anchor-based
```

## Deploy procedure

```bash
# From the Followuper repo root (Replit: artifacts/api-server/src/... is the live
# tree; this patch script targets the api-server root).

# 1. Apply the 13 ops
python3 /path/to/followuper-nativeness-v4/patches/apply_patches.py

# 2. Run both test suites
cd api-server
npx tsx tests/test-nativeness-v3.ts  # must show: 67/67 pass
npx tsx tests/test-nativeness-v4.ts  # must show: 46/46 pass

# 3. Typecheck the 4 touched files
npx tsc --noEmit lib/nativenessV4.ts lib/languageNativeness.ts \
    lib/doctrineLint.ts services/followupPrompts.ts

# 4. Mirror artifacts/ → source-code/ (Followuper sync direction per Replit
# monorepo specs: scripts/sync-source-code.sh)
bash scripts/sync-source-code.sh
```

The 13 operations:

1. **NewFile**: `api-server/lib/nativenessV4.ts` (55,959 bytes)
2. **NewFile**: `api-server/tests/test-nativeness-v4.ts`
3. **Patch**: `languageNativeness.ts` — add v4 import
4. **Patch**: `languageNativeness.ts` — switch `buildNativenessBlock`
   forwarder to call `buildNativenessBlockV4`
5. **Patch**: `languageNativeness.ts` — extend `buildCriticNativenessBlock`
   to concatenate v3 critic block + v4 critic block
6. **Patch**: `doctrineLint.ts` — add v4 aggregator import
7. **Patch**: `doctrineLint.ts` — switch `detectNativenessViolations`
   to call `findAllNativenessViolationsV4`
8. **Patch**: `doctrineLint.ts` — emit `TRANSLATIONESE-PATTERN` issues
9. **Patch**: `followupPrompts.ts` — add critic criteria 11 (translationese),
   12 (native structure), 13 (production-failure patterns, all 8 sub-criteria,
   14 languages)
10. **Patch**: `test-nativeness-v3.ts` — relax 1 writer-wrapper strict-
    equality assertion (the wrapper contract changes under v4)
11. **Patch**: `test-nativeness-v3.ts` — relax 1 critic-wrapper strict-
    equality assertion (same reason)
12. **Patch**: `followupPrompts.ts` — **v4.3 hotfix**: replace writer
    GREETING instruction with non-bypassable script-aware rule
13. **Patch**: `followupPrompts.ts` — **v4.3 hotfix**: same replacement
    in rewriter GREETING instruction

Idempotent: re-running the patch script on an already-patched tree results
in `0 OK, 13 SKIP, 0 FAIL`. Count-based marker idempotency handles ops 12
and 13 (both place the same GREETING rule sentinel — the rewriter op
declares `expected_marker_count=2` so it applies after the writer set the
count to 1).

## Rollback procedure

```bash
cd api-server
# Restore each .v3_backup
find . -name "*.v3_backup" -type f | while read backup; do
    orig="${backup%.v3_backup}"
    cp "$backup" "$orig"
    rm "$backup"
done
# Remove the v4 module + tests
rm -f lib/nativenessV4.ts tests/test-nativeness-v4.ts
# Verify
npx tsx tests/test-nativeness-v3.ts  # should show 67/67 pass
```

## Audit result

```
PASS: 47
FAIL: 0
WARN: 0
Status: GO-FOR-SHIP
```

- **Round 1 (Patch correctness)**: 13/13 PASS — 13 fresh ops, 13 idempotent
  re-applies, all 4 backups byte-identical, both newly-installed files
  byte-identical to payload, all v4 markers present, translationese emission
  present, missing-anchor scenario fails loudly.
- **Round 2 (Behavioral)**: 8/8 PASS — v3 67/67, v4 46/46 (inc. 5 v4.3
  hotfix tests), Image-2 BAD PT fires 7 translationese hits, Denise's GOOD
  PT clean, Image-1 BAD Thai fires greeting-name, coverage counts (22
  langs / 169 patterns / 35 style guides / 8 loanword exemption sets).
- **Round 3 (Runtime)**: 5/5 PASS — TypeScript typecheck clean on all 4
  touched files, v4 module imports all 10 public exports.
- **Round 4 (End-to-end wiring)**: 12/12 PASS — forwarders updated,
  doctrineLint uses v4 aggregator + emits translationese, followupPrompts
  has all 3 new critic criteria, criterion 13 has all 8 sub-criteria and
  references 14 languages, writer block stacks v3 + v4 correctly. **v4.3:
  GREETING NAME SCRIPT rule present in BOTH writer + rewriter (2x),
  Thasawan → ทศวรรณ canonical example present, weak 'Hi Sarah,' pattern
  removed, 11 non-Latin-script languages listed explicitly.**
- **Round 5 (Regression)**: 9/9 PASS — all 4 file line deltas under budget,
  `nativenessV3.ts` byte-identical to snapshot (v4 is purely additive),
  ViolationReport contract preserved (v3 keys + 2 new keys), rollback
  restores byte-identical, 10 + 3 = 13 critic criteria total, v3 test count
  stable at 67.

## Notes specific to Followuper architecture

- The Followuper uses ESM with bundler module resolution. Imports omit `.js`
  extension (matches existing project style for `./nativenessV3`, etc.).
- Tests use the built-in `node:test` runner via `npx tsx`. No jest/vitest
  dependency.
- The Followuper writer prompt at `services/followupPrompts.ts` already
  references `buildNativenessBlock` and `buildCriticNativenessBlock` through
  the `lib/languageNativeness.ts` forwarder layer — the v4 wiring is a
  one-line change in each forwarder, and the writer/critic prompts pick up
  v4 automatically on next request.
- Unlike the Prospector, the Followuper writer prompt does not have hard
  "Do NOT transliterate the name" override rules. Name adaptation lands
  through the v4 NATIVE STYLE GUIDE block in the writer prompt.
