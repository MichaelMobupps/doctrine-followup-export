#!/usr/bin/env python3
"""
Idempotent patcher for the Gemini critic model switch.

Three files, each edit anchored on verbatim current text. Any missing anchor
HALTS without writing that file, so a drifted tree never gets a mangled patch.

  gemini.ts        : GEMINI_CRITIC_MODEL becomes env-configurable, default
                     gemini-3-flash-preview.
  pricing.ts       : add rows for gemini-3.1-pro and gemini-3-flash-preview.
  criticProvider.ts: define + export GEMINI_CRITIC_FOCUS and append it to the
                     Gemini critic system prompt only. Anthropic prompt untouched.
"""
import sys, os

API_SRC = sys.argv[1] if len(sys.argv) > 1 else None
if not API_SRC or not os.path.isdir(API_SRC):
    print("usage: apply.py <api-server/src dir>")
    sys.exit(2)

def read(p):
    with open(p, "r", encoding="utf-8") as f:
        return f.read()

def write(p, s):
    with open(p, "w", encoding="utf-8") as f:
        f.write(s)

def halt(msg):
    print("[apply] HALT: " + msg)
    sys.exit(3)

# ---------------------------------------------------------------- gemini.ts
gem_path = os.path.join(API_SRC, "lib/gemini.ts")
gem = read(gem_path)
GEM_ANCHOR = 'export const GEMINI_CRITIC_MODEL = "gemini-3.5-flash";'
GEM_NEW = 'export const GEMINI_CRITIC_MODEL = process.env.GEMINI_CRITIC_MODEL || "gemini-3-flash-preview";'
if "process.env.GEMINI_CRITIC_MODEL" in gem:
    print("[apply] gemini.ts: model line already env-configurable, skipping")
elif GEM_ANCHOR in gem:
    write(gem_path, gem.replace(GEM_ANCHOR, GEM_NEW, 1))
    print("[apply] gemini.ts: GEMINI_CRITIC_MODEL is now env-configurable (default gemini-3-flash-preview)")
else:
    halt("gemini.ts model anchor not found")

# ---------------------------------------------------------------- pricing.ts
pr_path = os.path.join(API_SRC, "lib/pricing.ts")
pr = read(pr_path)
PR_ANCHOR = '  "gemini-3.5-flash":          { input: 1.50,  output: 9.00 },'
PR_NEW = (
    PR_ANCHOR + "\n"
    '  "gemini-3.1-pro":            { input: 2.00,  output: 12.00 },\n'
    '  "gemini-3-flash-preview":    { input: 0.50,  output: 3.00 },'
)
if '"gemini-3-flash-preview"' in pr:
    print("[apply] pricing.ts: new rows already present, skipping")
elif PR_ANCHOR in pr:
    write(pr_path, pr.replace(PR_ANCHOR, PR_NEW, 1))
    print("[apply] pricing.ts: added gemini-3.1-pro and gemini-3-flash-preview rows")
else:
    halt("pricing.ts gemini-3.5-flash row anchor not found")

# ---------------------------------------------------------- criticProvider.ts
cp_path = os.path.join(API_SRC, "services/criticProvider.ts")
cp = read(cp_path)

FOCUS_CONST = (
    "// Gemini critic focus directive. In production the deterministic linter runs\n"
    "// upstream of the critic and rewrites any draft that trips a mechanical rule,\n"
    "// so by the time the LLM critic sees a draft those rules are already clean.\n"
    "// This tells the cheaper Gemini model to trust that and spend its scrutiny on\n"
    "// the judgment a regex cannot make. It is appended only to the Gemini system\n"
    "// prompt; the Anthropic critic prompt is unchanged.\n"
    "export const GEMINI_CRITIC_FOCUS = [\n"
    '  "ENFORCEMENT CONTEXT: A deterministic linter runs before you and rewrites any",\n'
    '  "draft that violates a mechanical rule, so the draft you are grading is already",\n'
    '  "clean on: sentence-count, em and en dashes, hedged numbers, hype adjectives,",\n'
    '  "the X-not-Y comma negation, multi-event claims, invented statistics,",\n'
    '  "meta-language, closing or sign-off lines, the language-nativeness rules, and",\n'
    '  "the presence of a follow-up acknowledgment. Do not spend your budget",\n'
    '  "re-policing those. Concentrate your judgment on what the linter cannot see:",\n'
    '  "whether the follow-up is relevant to this specific prospect and their original",\n'
    '  "email, whether it advances a genuinely new angle instead of restating the prior",\n'
    '  "message, whether the tone reads as a real human sales rep, and whether the",\n'
    '  "language is natural beyond the mechanical checks. Still return every score in",\n'
    '  "the required JSON, but weight your overall score and your needs_rewrite",\n'
    '  "decision toward those judgment dimensions.",\n'
    "].join(\" \");\n\n"
)
CP_FN_ANCHOR = "async function geminiCritique("
CP_SYS_ANCHOR = "    systemParts: [UNTRUSTED_DATA_SYSTEM_CLAUSE, getCriticSystemPrompt()],"
CP_SYS_NEW = "    systemParts: [UNTRUSTED_DATA_SYSTEM_CLAUSE, getCriticSystemPrompt(), GEMINI_CRITIC_FOCUS],"

changed = False
if "GEMINI_CRITIC_FOCUS" in cp:
    print("[apply] criticProvider.ts: focus directive already present, skipping const + wiring")
else:
    if CP_FN_ANCHOR not in cp:
        halt("criticProvider.ts geminiCritique anchor not found")
    if CP_SYS_ANCHOR not in cp:
        halt("criticProvider.ts systemParts anchor not found")
    cp = cp.replace(CP_FN_ANCHOR, FOCUS_CONST + CP_FN_ANCHOR, 1)
    cp = cp.replace(CP_SYS_ANCHOR, CP_SYS_NEW, 1)
    write(cp_path, cp)
    changed = True
    print("[apply] criticProvider.ts: added GEMINI_CRITIC_FOCUS and appended it to the Gemini prompt")

print("[apply] done")
