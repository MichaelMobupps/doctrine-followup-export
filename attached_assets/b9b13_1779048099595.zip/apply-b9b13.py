#!/usr/bin/env python3
"""
B9b.13 — /api/anti-ghosting/my/activity endpoint + un-skip the layout
polling for AntiGhosting pages.

Three anchored edits across two files:

Backend (artifacts/api-server/src/routes/anti-ghosting.ts):
  1. Extend the drizzle-orm import to include `desc` and `sql`.
  2. Insert a new GET /my/activity handler before `export default router;`.
     Mirrors /api/context/my/activity exactly with one delta: scope is
     prospectsTable.app = "anti_ghosting" instead of "context".

Frontend (artifacts/dashboard/src/components/layout.tsx):
  3. Replace the B9b.8.2 skip pattern with a three-way activityPath
     ternary that routes AG to the new endpoint.

Idempotent. Anchor-uniqueness checked. Aborts loudly on drift.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
BACKEND = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"
FRONTEND = WORKSPACE / "artifacts/dashboard/src/components/layout.tsx"

# --------------------------------------------------------------------
# Anchor 1: drizzle-orm import extension
# --------------------------------------------------------------------
IMPORT_OLD = 'import { and, asc, eq } from "drizzle-orm";'
IMPORT_NEW = 'import { and, asc, desc, eq, sql } from "drizzle-orm";'

# --------------------------------------------------------------------
# Anchor 2: insert handler before export
# --------------------------------------------------------------------
EXPORT_ANCHOR = "export default router;"
HANDLER_MARKER = "B9b.13: GET /api/anti-ghosting/my/activity"

NEW_HANDLER = '''
// ====================================================================
// B9b.13: GET /api/anti-ghosting/my/activity
// ====================================================================
// Per-product sidebar activity for AntiGhosting. Mirrors
// /api/context/my/activity with scope = prospectsTable.app = "anti_ghosting".
// Same response shape (last_sync, queued, next_due) so the dashboard
// sidebar indicator just switches URLs based on which product is active.
router.get("/my/activity", async (req: Request, res: Response) => {
  const userId = req.query.userId ? parseInt(String(req.query.userId), 10) : null;
  if (!userId) { res.json({ last_sync: null, queued: 0, next_due: null }); return; }
  try {
    const SCOPE = eq(prospectsTable.app, "anti_ghosting");

    const latestProspect = await db
      .select({ createdAt: prospectsTable.createdAt })
      .from(prospectsTable)
      .where(and(SCOPE, eq(prospectsTable.userId, userId)))
      .orderBy(desc(prospectsTable.createdAt))
      .limit(1);

    const queuedCount = await db
      .select({ count: sql<number>`count(*)` })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        SCOPE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ));

    const nextDue = await db
      .select({ scheduledAt: followupsTable.scheduledAt })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(
        SCOPE,
        eq(prospectsTable.userId, userId),
        eq(followupsTable.status, "queued"),
      ))
      .orderBy(asc(followupsTable.scheduledAt))
      .limit(1);

    res.json({
      last_sync: latestProspect[0]?.createdAt?.toISOString() || null,
      queued: Number(queuedCount[0]?.count) || 0,
      next_due: nextDue[0]?.scheduledAt?.toISOString() || null,
    });
  } catch (err) {
    res.json({ last_sync: null, queued: 0, next_due: null });
  }
});

'''

# --------------------------------------------------------------------
# Anchor 3: layout.tsx skip replacement
# --------------------------------------------------------------------
LAYOUT_SKIP_OLD = '''    if (!apiKey || !currentUser?.userId) return;
    // B9b.8.2: no /api/anti-ghosting/my/activity endpoint yet — skip polling there.
    if (onAntiGhosting) { setActivity(null); return; }
    const activityPath = onContext ? "api/context/my/activity" : "api/my/activity";'''

LAYOUT_SKIP_NEW = '''    if (!apiKey || !currentUser?.userId) return;
    // B9b.13: AG activity endpoint now exists; include it in the routing.
    const activityPath = onAntiGhosting
      ? "api/anti-ghosting/my/activity"
      : onContext
      ? "api/context/my/activity"
      : "api/my/activity";'''

LAYOUT_MARKER = "B9b.13: AG activity endpoint now exists"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def info(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker=None):
    """Replace `old` with `new`, verifying old appears exactly once.
    Idempotency via `marker` (or `new` if not given)."""
    check = marker if marker is not None else new
    if check in text:
        skip(f"{label} already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found: {old[:80]!r}")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1.")
    info(f"{label}: updated")
    return text.replace(old, new, 1), True


def insert_before_unique(text, anchor, insert, label, marker):
    """Insert `insert` before `anchor`, verifying anchor appears exactly once."""
    if marker in text:
        skip(f"{label} already present")
        return text, False
    count = text.count(anchor)
    if count == 0:
        fail(f"{label}: anchor not found: {anchor!r}")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1.")
    info(f"{label}: inserted")
    return text.replace(anchor, insert.lstrip("\n") + "\n" + anchor, 1), True


def patch_backend():
    if not BACKEND.exists():
        fail(f"backend not found: {BACKEND}")
    text = BACKEND.read_text(encoding="utf-8")
    original = text

    # 1. Extend drizzle-orm import.
    text, _ = replace_unique(text, IMPORT_OLD, IMPORT_NEW, "drizzle-orm import")

    # 2. Insert handler.
    text, _ = insert_before_unique(
        text, EXPORT_ANCHOR, NEW_HANDLER, "/my/activity handler",
        marker=HANDLER_MARKER,
    )

    if text != original:
        BACKEND.write_text(text, encoding="utf-8")
        info(f"wrote {BACKEND.relative_to(WORKSPACE)}")
    else:
        skip("backend already patched")


def patch_frontend():
    if not FRONTEND.exists():
        fail(f"layout not found: {FRONTEND}")
    text = FRONTEND.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, LAYOUT_SKIP_OLD, LAYOUT_SKIP_NEW, "layout AG-skip replacement",
        marker=LAYOUT_MARKER,
    )

    if text != original:
        FRONTEND.write_text(text, encoding="utf-8")
        info(f"wrote {FRONTEND.relative_to(WORKSPACE)}")
    else:
        skip("layout already patched")


def main():
    patch_backend()
    patch_frontend()
    print()
    print("B9b.13 sidebar activity for AntiGhosting applied.")


if __name__ == "__main__":
    main()
