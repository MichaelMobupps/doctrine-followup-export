#!/usr/bin/env node
/**
 * apply-batch6.mjs — Phase 6 (scheduler hardening).
 *
 * Closes the spam-reputation gaps identified in the May 8 audit:
 *   A. Per-user send rate limiter (DOCTRINE_HOURLY_SEND_CAP / DOCTRINE_DAILY_SEND_CAP)
 *   B. Send-window enforcement at SEND time
 *   C. Bulk Send-Now cap 100 → 25
 *   D. Input validation: sendDays must be non-empty; sendHourEnd > sendHourStart
 *   E. UTC pin at boot + setUTCHours/getUTCDay normalization
 *
 * Plus glob cleanup: any *.batch*.bak file in the api-server tree is
 * removed (catches the doctrine.ts.batch3b.bak that Batch 4 missed and
 * any future stragglers).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Touches:
 *   - artifacts/api-server/src/lib/sendBudget.ts        (NEW from payload)
 *   - artifacts/api-server/src/lib/scheduleWindow.ts    (NEW from payload)
 *   - artifacts/api-server/src/index.ts                 (UTC pin)
 *   - artifacts/api-server/src/services/scheduler.ts    (window+budget gates)
 *   - artifacts/api-server/src/services/timingEngine.ts (setUTCHours/getUTCDay)
 *   - artifacts/api-server/src/routes/gmail-auth.ts     (input validation)
 *   - artifacts/api-server/src/routes/doctrine.ts       (bulk cap 100 → 25)
 *
 * Cleanup: glob *.batch*.bak under api-server.
 *
 * No DB migration. No new packages. No new schema.
 *
 * Usage:
 *   node apply-batch6.mjs
 *   API_BASE=artifacts/api-server/src node apply-batch6.mjs
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync, unlinkSync, readdirSync, statSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const PAYLOAD_DIR = join(SCRIPT_DIR, "payload");

const log  = (msg) => console.log(`[apply-batch6] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch6] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

function copyPayload(srcRel, dstAbs, label) {
  const src = join(PAYLOAD_DIR, srcRel);
  if (!existsSync(src)) fail(`payload missing: ${src}`);
  copyFileSync(src, dstAbs);
  log(`  [+] ${label}`);
}

function walkAllFiles(dir) {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const n of readdirSync(dir)) {
    const full = join(dir, n);
    const st = statSync(full);
    if (st.isDirectory()) out.push(...walkAllFiles(full));
    else if (st.isFile()) out.push(full);
  }
  return out;
}

// ============================================================
// Step 1: Install payload library files
// ============================================================
log("Step 1: Installing payload libraries...");
const libDir = join(API_BASE, "lib");
if (!existsSync(libDir)) fail(`api-server lib dir missing: ${libDir}`);

copyPayload("lib/sendBudget.ts",     join(libDir, "sendBudget.ts"),     "lib/sendBudget.ts installed");
copyPayload("lib/scheduleWindow.ts", join(libDir, "scheduleWindow.ts"), "lib/scheduleWindow.ts installed");

// ============================================================
// Step 2: UTC pin at boot — index.ts
// ============================================================
log("Step 2: Patching index.ts (UTC pin)...");
const indexPath = join(API_BASE, "index.ts");

strReplace(
  indexPath,
  `import app from "./app";
import { logger } from "./lib/logger";
import { startCronJobs } from "./cron";`,
  `// Phase 6: pin the process timezone to UTC before ANY Date arithmetic
// runs. The schedule math in timingEngine.ts uses setUTCHours/getUTCDay
// explicitly, but this guarantees that any code path which still uses
// the local-tz variants (third-party libs, future code) also operates
// on UTC. Set it as early as possible — before importing modules that
// may read/cache the tz.
process.env.TZ = "UTC";

import app from "./app";
import { logger } from "./lib/logger";
import { startCronJobs } from "./cron";

if (Intl.DateTimeFormat().resolvedOptions().timeZone !== "UTC") {
  // The TZ env var should pin Node's date math, but if Intl reports
  // something else, the host has overridden it in a way Node respects.
  // Fail loudly rather than silently miscompute send-windows.
  throw new Error(
    \`Process timezone is \${Intl.DateTimeFormat().resolvedOptions().timeZone}, not UTC. \` +
    \`Doctrine schedule math assumes UTC. Refusing to start.\`,
  );
}`,
  "index.ts: UTC pin + assertion at boot",
  `process.env.TZ = "UTC";`
);

// ============================================================
// Step 3: timingEngine.ts — switch to UTC variants
// ============================================================
log("Step 3: Patching timingEngine.ts (UTC normalization)...");
const timingEnginePath = join(API_BASE, "services", "timingEngine.ts");

// 3a: findNextAllowedDay uses getUTCDay
strReplace(
  timingEnginePath,
  `function findNextAllowedDay(date: Date, sendDays: number[]): Date {
  if (sendDays.length === 0) return date;
  const result = new Date(date);
  let attempts = 0;
  while (!sendDays.includes(result.getDay()) && attempts < 7) {
    result.setDate(result.getDate() + 1);
    attempts++;
  }
  return result;
}`,
  `function findNextAllowedDay(date: Date, sendDays: number[]): Date {
  if (sendDays.length === 0) return date;
  const result = new Date(date);
  let attempts = 0;
  // Phase 6: use getUTCDay/setUTCDate so day-of-week math is timezone-free.
  while (!sendDays.includes(result.getUTCDay()) && attempts < 7) {
    result.setUTCDate(result.getUTCDate() + 1);
    attempts++;
  }
  return result;
}`,
  "timingEngine.ts: findNextAllowedDay uses getUTCDay/setUTCDate",
  `// Phase 6: use getUTCDay/setUTCDate so day-of-week math is timezone-free.`
);

// 3b: generateScheduledTime uses setUTCHours
strReplace(
  timingEnginePath,
  `  const scheduled = new Date(now);
  scheduled.setDate(scheduled.getDate() + dayOffset);
  scheduled.setHours(hour, minute, 0, 0);

  const adjusted = findNextAllowedDay(scheduled, window.sendDays);
  adjusted.setHours(hour, minute, 0, 0);

  return adjusted.toISOString();`,
  `  // Phase 6: all clock math uses UTC variants. The TZ pin in index.ts
  // already guarantees Node operates on UTC, but explicit calls here
  // make the intent unambiguous and survive future TZ regressions.
  const scheduled = new Date(now);
  scheduled.setUTCDate(scheduled.getUTCDate() + dayOffset);
  scheduled.setUTCHours(hour, minute, 0, 0);

  const adjusted = findNextAllowedDay(scheduled, window.sendDays);
  adjusted.setUTCHours(hour, minute, 0, 0);

  return adjusted.toISOString();`,
  "timingEngine.ts: generateScheduledTime uses setUTCHours/setUTCDate",
  `// Phase 6: all clock math uses UTC variants. The TZ pin`
);

// ============================================================
// Step 4: scheduler.ts — integrate window + budget gates
// ============================================================
log("Step 4: Patching scheduler.ts (window + budget gates)...");
const schedulerPath = join(API_BASE, "services", "scheduler.ts");

// 4a: Add imports
strReplace(
  schedulerPath,
  `const ACTIVE_FOLLOWUP_STATUSES = ["queued", "generating", "pending_approval", "drafted"];`,
  `import { isInSendWindow } from "../lib/scheduleWindow";
import { checkSendBudget } from "../lib/sendBudget";

const ACTIVE_FOLLOWUP_STATUSES = ["queued", "generating", "pending_approval", "drafted"];`,
  "scheduler.ts: import isInSendWindow + checkSendBudget",
  `import { isInSendWindow } from "../lib/scheduleWindow";`
);

// 4b: Insert gate checks BEFORE the atomic claim. Anchor is the comment
// "User Gmail credentials unavailable" + the no-sender block. We add the
// new checks immediately after the no-sender check.
strReplace(
  schedulerPath,
  `      if (!senderEmail) {
        logger.warn({ followupId: item.followupId, prospectId: item.prospectId }, "No sender credentials available — skipping");
        continue;
      }

      const claimResult = await db
        .update(followupsTable)
        .set({ status: "generating" })
        .where(and(eq(followupsTable.id, item.followupId), eq(followupsTable.status, "queued")));`,
  `      if (!senderEmail) {
        logger.warn({ followupId: item.followupId, prospectId: item.prospectId }, "No sender credentials available — skipping");
        continue;
      }

      // Phase 6 gate A: send-window enforcement at SEND time.
      // forceSend bypasses the window — explicit user actions are trusted.
      // Cron-driven sends defer the row (status stays 'queued') if outside.
      if (!options?.forceSend && item.userId) {
        const userForWindow = userCache.get(item.userId);
        if (userForWindow) {
          const win = isInSendWindow(userForWindow, new Date());
          if (!win.ok) {
            logger.info(
              { followupId: item.followupId, prospectId: item.prospectId, reason: win.reason, utcDay: win.utcDay, utcHour: win.utcHour },
              "Outside send window — deferring follow-up to next tick",
            );
            continue;
          }
        }
      }

      // Phase 6 gate B: per-user send rate limiter.
      // forceSend bypasses the cap (Send Now is an explicit user choice).
      // Bulk Send-Now is separately capped to 25 at the route level.
      if (!options?.forceSend && item.userId) {
        const budget = await checkSendBudget({ userId: item.userId });
        if (!budget.allowed) {
          logger.warn(
            {
              followupId: item.followupId,
              prospectId: item.prospectId,
              userId: item.userId,
              reason: budget.reason,
              sentLastHour: budget.sentLastHour,
              hourlyCap: budget.hourlyCap,
              sentToday: budget.sentToday,
              dailyCap: budget.dailyCap,
            },
            "Send budget exceeded — deferring follow-up to next tick",
          );
          continue;
        }
      }

      const claimResult = await db
        .update(followupsTable)
        .set({ status: "generating" })
        .where(and(eq(followupsTable.id, item.followupId), eq(followupsTable.status, "queued")));`,
  "scheduler.ts: insert window + budget gates before atomic claim",
  `Phase 6 gate A: send-window enforcement at SEND time.`
);

// ============================================================
// Step 5: gmail-auth.ts — tighten input validation
// ============================================================
log("Step 5: Patching gmail-auth.ts (input validation)...");
const gmailAuthPath = join(API_BASE, "routes", "gmail-auth.ts");

// 5a: sendDays — reject empty arrays
strReplace(
  gmailAuthPath,
  `    if (sendDays !== undefined && Array.isArray(sendDays)) {
      updates.sendDays = sendDays.filter((d: any) => typeof d === "number" && d >= 0 && d <= 6);
    }`,
  `    if (sendDays !== undefined && Array.isArray(sendDays)) {
      // Phase 6: require at least one valid day. An empty array silently
      // disabled the day filter via the early-return in findNextAllowedDay,
      // which surprised users who expected a tighter window.
      const validDays = sendDays.filter((d: any) => typeof d === "number" && d >= 0 && d <= 6);
      if (validDays.length === 0) {
        res.status(400).json({ error: "sendDays must contain at least one valid day (0=Sunday..6=Saturday)" });
        return;
      }
      updates.sendDays = validDays;
    }`,
  "gmail-auth.ts: reject empty sendDays array",
  `Phase 6: require at least one valid day.`
);

// 5b: sendHourStart / sendHourEnd — require end > start
// We need to validate AFTER both are parsed but BEFORE the DB update.
// Anchor is the existing parsing block.
strReplace(
  gmailAuthPath,
  `    if (sendHourStart !== undefined) updates.sendHourStart = parseInt(sendHourStart);
    if (sendHourEnd !== undefined) updates.sendHourEnd = parseInt(sendHourEnd);`,
  `    if (sendHourStart !== undefined) updates.sendHourStart = parseInt(sendHourStart);
    if (sendHourEnd !== undefined) updates.sendHourEnd = parseInt(sendHourEnd);
    // Phase 6: send-hour bounds must form a non-empty interval. The schedule
    // math uses Math.random() * (end - start), which produces NaN/negative
    // hours when end <= start. Resolve effective values from the incoming
    // payload OR the current row defaults to validate the COMBINED state.
    {
      const effStart = updates.sendHourStart !== undefined
        ? updates.sendHourStart
        : (await db.select({ v: usersTable.sendHourStart }).from(usersTable).where(eq(usersTable.id, userId)).limit(1))[0]?.v ?? 8;
      const effEnd = updates.sendHourEnd !== undefined
        ? updates.sendHourEnd
        : (await db.select({ v: usersTable.sendHourEnd }).from(usersTable).where(eq(usersTable.id, userId)).limit(1))[0]?.v ?? 18;
      if (!Number.isFinite(effStart) || !Number.isFinite(effEnd) || effStart < 0 || effStart > 23 || effEnd < 1 || effEnd > 24 || effEnd <= effStart) {
        res.status(400).json({
          error: \`sendHourStart and sendHourEnd must satisfy 0 <= start < end <= 24 (got start=\${effStart}, end=\${effEnd})\`,
        });
        return;
      }
    }`,
  "gmail-auth.ts: enforce sendHourEnd > sendHourStart with bounds",
  `Phase 6: send-hour bounds must form a non-empty interval.`
);

// ============================================================
// Step 6: doctrine.ts — bulk cap 100 → 25
// ============================================================
log("Step 6: Patching doctrine.ts (bulk cap)...");
const doctrinePath = join(API_BASE, "routes", "doctrine.ts");

strReplace(
  doctrinePath,
  `  if (ids.length > 100) {
    res.status(400).json({ error: "Bulk send limited to 100 prospects per call" });
    return;
  }`,
  `  // Phase 6: lowered from 100 → 25. Bulk Send-Now uses forceSend per row,
  // which bypasses the rate limiter, so the cap here is the only ceiling
  // on burst volume through one mailbox in a single call.
  if (ids.length > 25) {
    res.status(400).json({ error: "Bulk send limited to 25 prospects per call" });
    return;
  }`,
  "doctrine.ts: bulk send cap 100 → 25",
  `Phase 6: lowered from 100 → 25.`
);

// ============================================================
// Step 7: Glob cleanup — any *.batch*.bak under api-server
// ============================================================
log("Step 7: Glob-cleaning any *.batch*.bak files...");
const allFiles = walkAllFiles(API_BASE);
const bakFiles = allFiles.filter((f) => /\.batch[^/]*\.bak$/.test(f));
let removedCount = 0;
for (const f of bakFiles) {
  unlinkSync(f);
  log(`  [-] Removed ${f}`);
  removedCount++;
}
log(`  Removed ${removedCount} backup file(s).`);

// ============================================================
// Step 8: Self-verify
// ============================================================
log("Step 8: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found: ${needle.slice(0, 70)}...`);
  log(`  [OK] ${label}`);
}

expectInFile(join(libDir, "sendBudget.ts"),     `export async function checkSendBudget`, "V1a sendBudget exported");
expectInFile(join(libDir, "scheduleWindow.ts"), `export function isInSendWindow`,        "V1b isInSendWindow exported");
expectInFile(indexPath,                         `process.env.TZ = "UTC";`,               "V2  index.ts UTC pin");
expectInFile(timingEnginePath,                  `setUTCHours(hour, minute, 0, 0)`,       "V3a timingEngine setUTCHours");
expectInFile(timingEnginePath,                  `getUTCDay()`,                            "V3b timingEngine getUTCDay");
expectInFile(schedulerPath,                     `import { isInSendWindow }`,             "V4a scheduler imports window helper");
expectInFile(schedulerPath,                     `import { checkSendBudget }`,            "V4b scheduler imports budget helper");
expectInFile(schedulerPath,                     `Phase 6 gate A: send-window enforcement`, "V4c scheduler window gate present");
expectInFile(schedulerPath,                     `Phase 6 gate B: per-user send rate limiter`, "V4d scheduler budget gate present");
expectInFile(gmailAuthPath,                     `Phase 6: require at least one valid day`, "V5a sendDays validation");
expectInFile(gmailAuthPath,                     `Phase 6: send-hour bounds must form a non-empty`, "V5b sendHour validation");
expectInFile(doctrinePath,                      `Bulk send limited to 25 prospects per call`, "V6  bulk cap 25");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 6 patch applied. Set per-user caps via Replit Secrets if");
log("you want to tune for Workspace accounts:");
log("  DOCTRINE_HOURLY_SEND_CAP   default 30");
log("  DOCTRINE_DAILY_SEND_CAP    default 200");
log("================================================================");
