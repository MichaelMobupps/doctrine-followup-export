# Batch 7d — Picker, Theme, Switcher, Context Settings

Phase 7d. Scaffolds the Context Based Followuper UI without touching the
Doctrine UI. Picker landing, sidebar product switcher, amber theme via
`data-product` attribute, and the per-account `contextLabel` Settings field.

The full Context Pipeline page ships in 7e. The Context Email Inspector
and Activity Log ship in 7f.

## What's in this batch

**New files (4):**

- `dashboard/pages/picker.tsx` — product picker landing page. Two cards
  (Sales Doctrine / Context Based). Remembers the last choice in
  localStorage under key `doctrine.lastProduct`.
- `dashboard/pages/context-pipeline.tsx` — placeholder. "Pipeline UI
  ships in Phase 7e."
- `dashboard/pages/context-inspector.tsx` — placeholder. "Inspector UI
  ships in Phase 7f."
- `dashboard/pages/context-activity.tsx` — placeholder. "Activity Log UI
  ships in Phase 7f."

**Modified files (4):**

- `dashboard/App.tsx` — registers 4 new wouter routes (`/picker`,
  `/context/pipeline`, `/context/inspector`, `/context/activity`).
  Existing doctrine routes (`/`, `/pipeline`, `/prospects`, `/followups`,
  `/inspector`, `/accounts`, `/activity`) are preserved exactly as-is.
- `dashboard/components/layout.tsx` — derives `onContext` from
  `location.startsWith("/context")`. Sets `data-product={dataProduct}` on
  the root div. Brand label flips between "Doctrine AI" and "Context Based".
  Nav items target the active product's URL family. New "Switch product"
  link in the sidebar (between Settings and Sign out) routes to `/picker`.
- `dashboard/index.css` — appends `[data-product="context"]` block that
  overrides only the accent palette: `--accent`, `--accent-hover`,
  `--accent-muted`, `--accent-border`. All other tokens (bg, text, border,
  success, danger) stay shared.
- `dashboard/pages/accounts.tsx` — adds `contextLabel` state, includes
  it in the save body, renders a Context Gmail label input below the
  existing Doctrine label input. Default value `"Context Followuper"`.

## What changes for the user

- **Doctrine users**: zero behavior change. Existing bookmarks and the
  default landing (`/` → Pipeline) work exactly as today. The sidebar
  now has a "Switch product" entry above Sign out — clicking it goes to
  the picker.
- **Picker** (`/picker`): two cards. Choose either product, the choice
  is remembered in localStorage. Doctrine card → `/`. Context card →
  `/context/pipeline`.
- **Context navigation** (`/context/*`): sidebar reskins amber, brand
  shows "Context Based", nav items point to the context URL family.
  Pipeline / Inspector / Activity render placeholder content until 7e–7f.
- **Settings** (`/accounts`): users can now set their Context Gmail
  label per-account, separate from the Doctrine label. Default is
  "Context Followuper".

## Files

```
batch7d/
├── apply-batch7d.mjs          # Idempotent patch script
├── audit-batch7d.mjs          # 9 passes × 3 rounds = 144 checks
├── files/
│   └── dashboard/
│       └── pages/
│           ├── picker.tsx
│           ├── context-pipeline.tsx
│           ├── context-inspector.tsx
│           └── context-activity.tsx
└── README.md
```

## Apply

Standard pattern — single bash block in the ship instruction. Build
both api-server and dashboard. Mirror sync. Restart workflow.

## Verify

After applying:

- The apply script self-verifies 20 checks across all touched files.
- The audit script runs 144 checks (9 passes × 3 rounds × roughly 5
  assertions each), covering: new page exports, picker UX, App.tsx
  routing, CSS amber theme, Layout product awareness, accounts.tsx
  contextLabel field, Doctrine UI non-regression, B7c regression,
  B7a/B7b regression.

Smoke tests after Replit Agent restart:

- Open `/picker` — two cards visible, click each.
- From doctrine pages: sidebar reads "Doctrine AI", blue accent.
- From `/context/pipeline`: sidebar reads "Context Based", amber accent,
  page shows the placeholder.
- Settings page: scroll to Gmail labels — both Doctrine and Context
  inputs are present.

## Known residual

- `/context/pipeline`, `/context/inspector`, `/context/activity` are
  placeholders. Full UI ships in 7e (Pipeline) and 7f (Inspector +
  Activity Log).
- The sidebar's Auto-detecting / queued-followups indicator at the
  bottom continues to poll `/api/my/activity` regardless of which
  product is active. This means context users see doctrine queue
  numbers in the sidebar. Refining to per-product activity status is
  deferred to 7e or later.

## Communication

After 7d ships, the "Context Followuper" Gmail label name CAN be
communicated to users. They can configure it in Settings (Context Gmail
label field) and the next 15-minute sync will pick up labelled threads
into the context flow. The full Context UI to manage those follow-ups
arrives in 7e.
