/**
 * Vertical classifier — infers vertical from email content.
 *
 * Priority order:
 *   1. Explicit label/subject keywords (gaming, cps, fintech, retarget)
 *   2. Email body content analysis (gaming signals, fintech signals, retargeting signals)
 *   3. Default: non_gaming_ua
 *
 * Body analysis uses weighted signal scoring so a single stray word
 * doesn't flip classification — the content needs a real cluster of
 * gaming/fintech/retargeting language to override the default.
 */

// ── Signal definitions ──────────────────────────────────────────────

interface Signal {
  pattern: RegExp;
  weight: number;
}

/**
 * Gaming signals — terms that appear in gaming UA emails but almost
 * never in non-gaming mobile UA, CPS, or retargeting emails.
 *
 * Three tiers:
 *   strong (3): unambiguously gaming — game genres, stores, game-specific metrics
 *   medium (2): strongly associated but can appear elsewhere (e.g. "installs" in non-gaming UA)
 *   weak   (1): contextual nudges — meaningful in clusters, not alone
 */
const GAMING_SIGNALS: Signal[] = [
  // Strong — game genres & formats
  { pattern: /\b(match-?\d|puzzle|casual|hyper-?casual|mid-?core|hard-?core|idle|rpg|mmorpg|moba|strategy game|simulation game|card game|word game|trivia)\b/i, weight: 3 },
  // Strong — game-industry-specific terms
  { pattern: /\b(playable\s+ad|rewarded\s+video|offerwall|in-?app\s+purchas|iap|gacha|loot\s*box|game\s+economy|soft\s+launch|global\s+launch|live-?ops|liveops)\b/i, weight: 3 },
  // Strong — game studios / publisher context
  { pattern: /\b(game\s+studio|game\s+publisher|game\s+developer|mobile\s+game|gaming\s+app|gaming\s+compan|top\s+grossing\s+game)\b/i, weight: 3 },
  // Strong — well-known game titles as contextual anchors (extend as needed)
  { pattern: /\b(clash\s+of\s+clans|candy\s+crush|coin\s+master|royal\s+match|fishdom|gardenscapes|homescapes|township|merge\s+mansion|monopoly\s+go|squad\s+busters|brawl\s+stars|pubg\s+mobile|genshin\s+impact|roblox|among\s+us)\b/i, weight: 3 },
  // Medium — UA metrics with gaming flavor
  { pattern: /\b(d[137]\s+retention|roas\s+day|day-?\d+\s+roas|ltv\s+model|cohort\s+ltv|paying\s+user|arpdau|arppu|arpu)\b/i, weight: 2 },
  // Medium — ad network / platform terms heavy in gaming
  { pattern: /\b(applovin|unity\s+ads|ironsouce|ironsource|is\s+levelplay|mintegral|liftoff|vungle|chartboost|moloco|adjoe)\b/i, weight: 2 },
  // Medium — gaming market context
  { pattern: /\b(app\s*annie|sensor\s*tower|data\.ai|appmagic|apptica|mobile\s+gaming\s+market|gaming\s+vertical)\b/i, weight: 2 },
  // Weak — terms that nudge toward gaming in context
  { pattern: /\b(installs|cpi|ipm|ctr|creative\s+testing|ad\s+monetiz|mediation|waterfall|bidding)\b/i, weight: 1 },
  // Weak — game-adjacent terms
  { pattern: /\b(title|titles|portfolio|top\s+charts|charts)\b/i, weight: 1 },
];

const GAMING_THRESHOLD = 5; // need at least this combined weight to classify as gaming

const CPS_SIGNALS: Signal[] = [
  { pattern: /\b(fintech|finance\s+app|banking\s+app|neobank|crypto|trading\s+app|lending|insurance\s+app|payments?\s+app)\b/i, weight: 3 },
  { pattern: /\b(cps|cost\s+per\s+sale|cost\s+per\s+action|cpa\s+model|rev-?share|revenue\s+share)\b/i, weight: 3 },
  { pattern: /\b(subscription|trial\s+to\s+paid|first\s+deposit|ftd|first\s+time\s+deposit|fico|credit\s+score|loan\s+app)\b/i, weight: 2 },
  { pattern: /\b(affiliate|performance\s+network|offer\s+wall|conversion\s+flow)\b/i, weight: 1 },
];

const CPS_THRESHOLD = 4;

const RETARGETING_SIGNALS: Signal[] = [
  { pattern: /\b(retarget|re-?target|re-?engage|reengag|remarketing|re-?marketing)\b/i, weight: 3 },
  { pattern: /\b(lapsed\s+user|dormant\s+user|churned\s+user|inactive\s+user|win-?back)\b/i, weight: 3 },
  { pattern: /\b(deep\s*link|deferred\s+deep\s*link|push\s+notification\s+campaign|crm\s+campaign)\b/i, weight: 2 },
  { pattern: /\b(reattribution|re-?attribution)\b/i, weight: 2 },
];

const RETARGETING_THRESHOLD = 4;

// ── Scoring ─────────────────────────────────────────────────────────

function scoreSignals(text: string, signals: Signal[]): number {
  let score = 0;
  for (const { pattern, weight } of signals) {
    if (pattern.test(text)) {
      score += weight;
    }
  }
  return score;
}

interface MatchDetail {
  vertical: string;
  score: number;
}

// ── Public API ──────────────────────────────────────────────────────

export interface VerticalResult {
  vertical: string;
  reason: string;
}

/**
 * Infer vertical from all available context.
 *
 * @param labels   - Gmail label names on the message
 * @param subject  - Email subject line
 * @param body     - Email body text (first 500 chars is fine)
 */
export function inferVertical(
  labels: string[],
  subject: string,
  body: string = "",
): VerticalResult {
  // ── Pass 1: explicit keyword in labels or subject (existing behavior) ──
  const labelSubject = labels.join(" ").toLowerCase() + " " + subject.toLowerCase();
  if (labelSubject.includes("gaming")) {
    return { vertical: "gaming_ua", reason: "Keyword 'gaming' in labels or subject" };
  }
  if (labelSubject.includes("cps") || labelSubject.includes("fintech")) {
    return { vertical: "cps", reason: "Keyword 'cps'/'fintech' in labels or subject" };
  }
  if (labelSubject.includes("retarget")) {
    return { vertical: "retargeting", reason: "Keyword 'retarget' in labels or subject" };
  }

  // ── Pass 2: body content scoring ──
  const fullText = (subject + " " + body).toLowerCase();

  const gamingScore = scoreSignals(fullText, GAMING_SIGNALS);
  const cpsScore = scoreSignals(fullText, CPS_SIGNALS);
  const retargetingScore = scoreSignals(fullText, RETARGETING_SIGNALS);

  // Collect candidates that cross their threshold
  const candidates: MatchDetail[] = [];
  if (gamingScore >= GAMING_THRESHOLD) {
    candidates.push({ vertical: "gaming_ua", score: gamingScore });
  }
  if (cpsScore >= CPS_THRESHOLD) {
    candidates.push({ vertical: "cps", score: cpsScore });
  }
  if (retargetingScore >= RETARGETING_THRESHOLD) {
    candidates.push({ vertical: "retargeting", score: retargetingScore });
  }

  if (candidates.length > 0) {
    // Highest score wins; ties go to first match (gaming > cps > retargeting)
    candidates.sort((a, b) => b.score - a.score);
    const winner = candidates[0];
    return {
      vertical: winner.vertical,
      reason: `Body content analysis (score: ${winner.score})`,
    };
  }

  // ── Pass 3: default ──
  return { vertical: "non_gaming_ua", reason: "Default (no keyword or content match)" };
}
