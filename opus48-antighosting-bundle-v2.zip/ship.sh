#!/usr/bin/env bash
# ship.sh — Opus 4.8 critic upgrade + Anti-Ghosting Activity Log & Admin Cost.
#
# Idempotent. Full-file replacements (no in-place patching), so re-running is
# safe. Order: backup -> copy to artifacts/src -> typecheck gate -> tests gate
# -> build -> mirror (source-code/sync.sh).
#
# Run from the extracted bundle directory:  bash ship.sh
set -euo pipefail

# --- paths (match source-code/sync.sh) -------------------------------------
WORKSPACE="${WORKSPACE:-/home/runner/workspace}"
BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$BUNDLE_DIR/payload"
AG_SRC="$WORKSPACE/artifacts/api-server/src"
DASH_SRC="$WORKSPACE/artifacts/dashboard/src"
STAMP="$(date '+%Y%m%d-%H%M%S')"
BACKUP="$WORKSPACE/.ship-backups/opus48-ag-$STAMP"

echo "WORKSPACE = $WORKSPACE"
[ -d "$AG_SRC" ] || { echo "FATAL: $AG_SRC not found. Set WORKSPACE correctly."; exit 1; }
[ -d "$DASH_SRC" ] || { echo "FATAL: $DASH_SRC not found. Set WORKSPACE correctly."; exit 1; }

# --- 1) backup -------------------------------------------------------------
echo "== backup -> $BACKUP =="
mkdir -p "$BACKUP"
( cd "$PAYLOAD/api-server" && find . -type f -print0 ) | while IFS= read -r -d '' f; do
  if [ -f "$AG_SRC/$f" ]; then mkdir -p "$BACKUP/api-server/$(dirname "$f")"; cp "$AG_SRC/$f" "$BACKUP/api-server/$f"; fi
done
( cd "$PAYLOAD/dashboard" && find . -type f -print0 ) | while IFS= read -r -d '' f; do
  if [ -f "$DASH_SRC/$f" ]; then mkdir -p "$BACKUP/dashboard/$(dirname "$f")"; cp "$DASH_SRC/$f" "$BACKUP/dashboard/$f"; fi
done

# --- 2) copy payload -> artifacts/src --------------------------------------
echo "== copy payload -> artifacts/src =="
( cd "$PAYLOAD/api-server" && find . -type f -print0 ) | while IFS= read -r -d '' f; do
  mkdir -p "$AG_SRC/$(dirname "$f")"; cp "$PAYLOAD/api-server/$f" "$AG_SRC/$f"; echo "  api-server/src/$f"
done
( cd "$PAYLOAD/dashboard" && find . -type f -print0 ) | while IFS= read -r -d '' f; do
  mkdir -p "$DASH_SRC/$(dirname "$f")"; cp "$PAYLOAD/dashboard/$f" "$DASH_SRC/$f"; echo "  dashboard/src/$f"
done

# --- 3) typecheck gate (hard) ----------------------------------------------
echo "== typecheck: api-server =="
pnpm -C "$WORKSPACE/artifacts/api-server" run typecheck
echo "== typecheck: dashboard =="
pnpm -C "$WORKSPACE/artifacts/dashboard" run typecheck

# --- 4) tests gate (best effort; non-fatal if no runner wired) -------------
echo "== tests: api-server (best effort) =="
if pnpm -C "$WORKSPACE/artifacts/api-server" exec vitest --version >/dev/null 2>&1; then
  set +e
  pnpm -C "$WORKSPACE/artifacts/api-server" exec vitest run src/tests 2>&1 | tail -20
  TEST_RC=${PIPESTATUS[0]}
  set -e
  [ "$TEST_RC" -eq 0 ] || { echo "FATAL: tests failed (rc=$TEST_RC)."; exit 1; }
else
  echo "  vitest not available in api-server; skipping. Run your suite manually if wired at the root."
fi

# --- 5) build (api-server, then dashboard) ---------------------------------
# @workspace/db has no build script and is intentionally not built here.
echo "== build: api-server =="
pnpm -C "$WORKSPACE/artifacts/api-server" run build
echo "== build: dashboard =="
pnpm -C "$WORKSPACE/artifacts/dashboard" run build

# --- 6) mirror artifacts -> source-code ------------------------------------
echo "== mirror via source-code/sync.sh =="
bash "$WORKSPACE/source-code/sync.sh"

echo ""
echo "SUCCESS. Backup at: $BACKUP"
echo "Next: click Republish in Replit to deploy the new build."
