# Batch 7l — Context safety parity with doctrine

Phase 7l. Closes the two real gaps surfaced by the May 9 scheduler-
hardening audit (the audit also confirmed B6 + nine other safety
guards apply identically to both products through shared code paths).

## What's in this batch

**Gap A — defense-in-depth on UPDATE WHERE clauses**

Three UPDATE sites in `routes/context.ts` previously did not gate on
`SCOPE` in their WHERE clause. The doctrine equivalents do (e.g.
`.where(and(SCOPE_DOCTRINE, eq(id, prospectId)))`). Functionally safe
today because prospect IDs are globally unique on `prospects`, but
the doctrine pattern is more defensive:

- `/prospect/:id/pause` — `update().set({followupPaused:true}).where(and(SCOPE, eq(id, prospectId)))`
- `/prospect/:id/resume` — `update().set({followupPaused:false}).where(and(SCOPE, eq(id, prospectId)))`
- `/prospect/pause-bulk` — `update().set({followupPaused:true}).where(and(SCOPE, inArray(id, contextIds)))`

For `/pause-bulk`, `contextIds` was already SCOPE-filtered by a prior
SELECT, so the SCOPE in the UPDATE is genuinely redundant — but it
future-proofs against a refactor that swaps `contextIds` for `ids`
by accident.

**Gap B — `/prospect/:id/resume` immediately queues next stage**

The doctrine `/prospect/:id/resume` does three things:

1. Set `followup_paused = false`
2. Re-queue any stalled draft (`STALLED_AWAITING_MANUAL_SEND` → `queued`)
3. **If no active follow-up exists**, compute the next stage timing
   from the user's `stageTiming` / `sendDays` / `sendHourStart..End`
   and insert a queued follow-up row inline.

Before B7l, the context resume only did (1) and (2). Step (3) was
left to the 15-minute `autoQueueAllCampaigns` cron. Cron does catch
up — no data corruption — but the user sees "nothing happens" for
up to 15 minutes after resuming a context campaign. This batch ports
step (3) to the context resume handler line-for-line:

- Reads `users.maxFollowups` via the existing `getFollowupCap` helper.
- Queries `existingFollowups` for the prospect, splits into `sentRows`
  and `activeStages`.
- Branch: if stalled was re-queued, that's the queued stage.
- Branch: if no active follow-ups and `nextStage <= maxFollowups`,
  computes `scheduledAt` via `computeNextStageScheduledAt`, inserts
  a queued row.
- Insert wrapped in try/catch — race against the autoQueue cron tick
  is handled by `uq_followups_prospect_stage`. The catch is silent
  because cron's row stands.

Response shape extended with `queued_stage` (number | null) and
`max_followups` (number, 0 if user has none). Existing fields preserved.

## What changes for the user

- **Pause/resume actions on `/context/pipeline`**: every UPDATE is
  atomic and SCOPE-gated. No user-visible difference today, but the
  context handlers no longer have a defensive-programming gap relative
  to doctrine.
- **Resume a paused context campaign**: F1 (or the next stage) appears
  in the Pipeline immediately on next refresh, instead of after up to
  15 minutes. This matches doctrine resume.

## Files

```
batch7l/
├── apply-batch7l.mjs       # Idempotent patch — 5 str_replaces
├── audit-batch7l.mjs       # 9 passes × 3 rounds = 126 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build api-server only (dashboard
unchanged). Mirror sync. Restart api-server.

## Verify

After applying:

- The apply script self-verifies 18 anchors (3 imports + 6 Gap A + 5
  Gap B + 3 unconditional-pattern absence + 2 stalled-path preserve).
- The audit runs 126 checks (42 per round × 3 rounds): timingEngine
  imports, all three Gap A sites SCOPE-gated, Gap B branches present
  (stalled path + active-zero path with cap check + try/catch around
  insert), response shape extension, doctrine handlers NOT regressed
  (still SCOPE_DOCTRINE-gated). B7a-B7k regression.

Backend smoke after restart (no Gmail OAuth needed for these):

```bash
# 1. Pause is idempotent and atomic — call twice, both succeed
curl -s -X POST "http://localhost:8080/api/context/prospect/999999/pause" \
  -H "x-api-key: $ADDON_API_KEY"
echo
# Expect: {"error":"Context prospect not found"} (assuming 999999 doesn't exist)

# 2. Resume on a non-existent prospect — same error path
curl -s -X POST "http://localhost:8080/api/context/prospect/999999/resume" \
  -H "x-api-key: $ADDON_API_KEY"
echo
# Expect: {"error":"Context prospect not found"}

# 3. Pause-bulk with empty array
curl -s -X POST "http://localhost:8080/api/context/prospect/pause-bulk" \
  -H "x-api-key: $ADDON_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"prospectIds":[]}'
echo
# Expect: {"error":"prospectIds must be a non-empty array of positive integers"}

# 4. Doctrine pause — regression check, should still work the same way
curl -s -X POST "http://localhost:8080/api/prospect/451/pause" \
  -H "x-api-key: $ADDON_API_KEY"
echo
# Expect: {"success":true,"paused":true,"cancelled_queued":N}
```

Functional E2E for Gap B (requires a paused context prospect):

1. With a non-replied context prospect that has been paused.
2. Call `POST /api/context/prospect/:id/resume`.
3. Response now includes `queued_stage: 1` (or whichever stage is
   next) and `max_followups: 3` (or the user's setting).
4. `GET /api/context/followups` returns the new queued row immediately.

## Known residual

- The race between `/resume` queueing and the cron's autoQueue tick
  is benign: the unique constraint `uq_followups_prospect_stage`
  guarantees only one of them lands. The resume handler's silent
  catch is correct — cron's row stands.
- The other low-impact differences from the audit (`/sync` body
  validation, `/approve` race window) remain unchanged. The `/approve`
  race ends up safe via the scheduler's downstream atomic claim;
  `/sync` body validation is theoretical only. Not addressing in
  this batch.
