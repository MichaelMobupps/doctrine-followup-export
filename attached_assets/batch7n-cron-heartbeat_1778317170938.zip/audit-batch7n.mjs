#!/usr/bin/env node
/**
 * audit-batch7n.mjs — Beautiful-Squidward audit for Phase 7n.
 * 3 rounds × 9 passes per round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DB_BASE  = process.env.DB_BASE  || "lib/db/src";

const log  = (msg) => console.log(`[audit-batch7n] ${msg}`);
const fail = (msg) => { console.error(`[audit-batch7n] FAIL: ${msg}`); process.exit(1); };

function read(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

const schemaSrc      = read(join(DB_BASE, "schema", "cron-heartbeats.ts"));
const schemaIndexSrc = read(join(DB_BASE, "schema", "index.ts"));
const helperSrc      = read(join(API_BASE, "lib", "cronHeartbeat.ts"));
const cronSrc        = read(join(API_BASE, "cron.ts"));

let totalPassed = 0, totalRequired = 0;

function pass(label, condition) {
  totalRequired++;
  if (condition) {
    totalPassed++;
    log(`  PASS: ${label}`);
  } else {
    fail(`Audit pass failed: ${label}`);
  }
}

function runRound(roundNum) {
  log(`\n===== Round ${roundNum} =====`);

  // PASS 1: Drizzle schema file shape
  log(`-- PASS 1: schema/cron-heartbeats.ts --`);
  pass(`Phase 7n header in schema file`, /Phase 7n: cron heartbeat schema\./.test(schemaSrc));
  pass(`cronHeartbeatsTable export`, /export const cronHeartbeatsTable = pgTable\("cron_heartbeats", \{/.test(schemaSrc));
  pass(`tick_name column NOT NULL`, /tickName: text\("tick_name"\)\.notNull\(\),/.test(schemaSrc));
  pass(`fired_at column with default`, /firedAt: timestamp\("fired_at", \{ withTimezone: true \}\)\.notNull\(\)\.defaultNow\(\),/.test(schemaSrc));
  pass(`outcome NOT NULL`, /outcome: text\("outcome"\)\.notNull\(\),/.test(schemaSrc));
  pass(`duration_ms with default 0`, /durationMs: integer\("duration_ms"\)\.notNull\(\)\.default\(0\),/.test(schemaSrc));
  pass(`details jsonb`, /details: jsonb\("details"\),/.test(schemaSrc));

  // PASS 2: schema barrel exports
  log(`-- PASS 2: schema barrel --`);
  pass(`Barrel exports cron-heartbeats`, /export \* from "\.\/cron-heartbeats";/.test(schemaIndexSrc));
  pass(`Existing exports preserved (users, prospects, followups, oauth-nonces)`,
       /export \* from "\.\/users";/.test(schemaIndexSrc) &&
       /export \* from "\.\/prospects";/.test(schemaIndexSrc) &&
       /export \* from "\.\/followups";/.test(schemaIndexSrc) &&
       /export \* from "\.\/oauth-nonces";/.test(schemaIndexSrc));

  // PASS 3: helper shape
  log(`-- PASS 3: lib/cronHeartbeat.ts --`);
  pass(`Phase 7n header in helper`, /Phase 7n: recordHeartbeat helper\./.test(helperSrc));
  pass(`Imports from @workspace/db`, /import \{ db, cronHeartbeatsTable \} from "@workspace\/db";/.test(helperSrc));
  pass(`Imports logger`, /import \{ logger \} from "\.\/logger";/.test(helperSrc));
  pass(`CronOutcome type exported`, /export type CronOutcome = "ok" \| "partial" \| "error";/.test(helperSrc));
  pass(`recordHeartbeat exported`, /export async function recordHeartbeat\(args: \{/.test(helperSrc));
  pass(`Helper INSERTs into cronHeartbeatsTable`, /await db\.insert\(cronHeartbeatsTable\)\.values\(\{/.test(helperSrc));
  pass(`Helper try/catch wraps insert (errors don't propagate)`,
       /try \{[\s\S]*?await db\.insert\(cronHeartbeatsTable\)[\s\S]*?\} catch \(err\) \{/.test(helperSrc));

  // PASS 4: cron.ts import
  log(`-- PASS 4: cron.ts import --`);
  pass(`cron.ts imports recordHeartbeat`, /import \{ recordHeartbeat \} from "\.\/lib\/cronHeartbeat";/.test(cronSrc));
  pass(`Phase 7n import comment`, /Phase 7n: per-tick heartbeat recording for cron-firing observability\./.test(cronSrc));

  // PASS 5: each tick is wrapped
  log(`-- PASS 5: each tick wrapped (5 ticks total) --`);
  pass(`startedAt captured in all 5 ticks`, (cronSrc.match(/const startedAt = Date\.now\(\);/g) || []).length === 5);
  pass(`outcome variable in all 5 ticks`, (cronSrc.match(/let outcome: "ok" \| "partial" \| "error" = "ok";/g) || []).length === 5);
  pass(`details object in all 5 ticks`, (cronSrc.match(/const details: Record<string, unknown> = \{\};/g) || []).length === 5);
  pass(`finally block in all 5 ticks`, (cronSrc.match(/\} finally \{/g) || []).length === 5);
  pass(`recordHeartbeat called 5 times`, (cronSrc.match(/await recordHeartbeat\(\{/g) || []).length === 5);

  // PASS 6: each tickName is correct
  log(`-- PASS 6: tickName values --`);
  pass(`tickName "sync_and_autoqueue"`, /tickName: "sync_and_autoqueue",/.test(cronSrc));
  pass(`tickName "process_due"`, /tickName: "process_due",/.test(cronSrc));
  pass(`tickName "draft_stall_watcher"`, /tickName: "draft_stall_watcher",/.test(cronSrc));
  pass(`tickName "fast_tick"`, /tickName: "fast_tick",/.test(cronSrc));
  pass(`tickName "weekly_digest"`, /tickName: "weekly_digest",/.test(cronSrc));

  // PASS 7: existing logic preserved (regression)
  log(`-- PASS 7: existing logic preserved --`);
  pass(`syncEmails call preserved`, /const result = await syncEmails\(\);/.test(cronSrc));
  pass(`autoQueueAllCampaigns call preserved`, /const autoQueued = await autoQueueAllCampaigns\(\);/.test(cronSrc));
  pass(`processDueFollowups call preserved (in process_due)`, (cronSrc.match(/const result = await processDueFollowups\(\);/g) || []).length >= 2);
  pass(`stallDraftedFollowups call preserved`, /const stalled = await stallDraftedFollowups\(\);/.test(cronSrc));
  pass(`runWeeklyDigest call preserved`, /const result = await runWeeklyDigest\(\);/.test(cronSrc));
  pass(`Boot log preserved`, /Cron jobs active:/.test(cronSrc));
  pass(`5 cron.schedule calls intact`, (cronSrc.match(/cron\.schedule\(/g) || []).length === 5);

  // PASS 8: details captured per tick
  log(`-- PASS 8: per-tick details capture --`);
  pass(`sync_and_autoqueue captures synced + autoQueued`,
       /details\.synced = result\.synced;[\s\S]*?details\.autoQueued = autoQueued;/.test(cronSrc));
  pass(`process_due / fast_tick capture sent + drafted + failed`,
       (cronSrc.match(/details\.sent = result\.sent;/g) || []).length >= 2 &&
       (cronSrc.match(/details\.drafted = result\.drafted;/g) || []).length === 2 &&
       (cronSrc.match(/details\.failed = result\.failed;/g) || []).length >= 2);
  pass(`draft_stall_watcher captures stalled`, /details\.stalled = stalled;/.test(cronSrc));
  pass(`weekly_digest captures considered/sent/skipped/failed`,
       /details\.considered = result\.considered;[\s\S]*?details\.skipped = result\.skipped;/.test(cronSrc));

  // PASS 9: B7a-B7m regression
  log(`-- PASS 9: B7a-B7m regression --`);
  const ctxRouteSrc = read(join(API_BASE, "routes", "context.ts"));
  const docRouteSrc = read(join(API_BASE, "routes", "doctrine.ts"));
  const usersSchema = read(join(DB_BASE, "schema", "users.ts"));
  pass(`B7a: users.contextLabel column`, /contextLabel:\s*text\("context_label"\)/.test(usersSchema));
  pass(`B7c: SCOPE_DOCTRINE present`, /const SCOPE_DOCTRINE = eq\(prospectsTable\.app, "doctrine"\)/.test(docRouteSrc));
  pass(`B7e: /context/cancel-followup endpoint`, /router\.post\("\/cancel-followup"/.test(ctxRouteSrc));
  pass(`B7g: /context/gmail/sent-emails endpoint`, /router\.get\("\/gmail\/sent-emails"/.test(ctxRouteSrc));
  pass(`B7i: /context/my/activity endpoint`, /router\.get\("\/my\/activity"/.test(ctxRouteSrc));
  pass(`B7k: doctrine /sync auto_queued field`, /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(docRouteSrc));
  pass(`B7k: context /sync auto_queued field`, /res\.json\(\{ \.\.\.result, auto_queued: autoQueued \}\);/.test(ctxRouteSrc));
  pass(`B7l: context resume Gap A SCOPE-gated UPDATE`,
       /set\(\{ followupPaused: false \}\)\.where\(and\(SCOPE, eq\(prospectsTable\.id, prospectId\)\)\)/.test(ctxRouteSrc));
  pass(`B7l: context resume Gap B response shape`,
       /queued_stage,[\s\S]*?max_followups: maxFollowups \?\? 0,/.test(ctxRouteSrc));
}

runRound(1);
runRound(2);
runRound(3);

console.log("");
console.log(`Total: ${totalPassed}/${totalRequired} passed across 3 rounds.`);
if (totalPassed === totalRequired) {
  console.log("All passes succeeded across all 3 rounds.");
  process.exit(0);
} else {
  process.exit(1);
}
