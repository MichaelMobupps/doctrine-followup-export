#!/usr/bin/env python3
r"""
B9b.6.1 — hotfix for the missed second edit in B9b.6.

The OLD anchor in B9b.6 used `idx_prospects_app` as the last index
before `]);`. B9a actually added two more indexes after that one
(`idx_prospects_app_replied_paused` and `idx_prospects_parent`), so
the right "last index" anchor is `idx_prospects_parent`.

This patch only adds the missing composite uniqueIndex. B9b.6's first
edit (removing global `.unique()` from the column) already applied,
so the schema is currently in a partial state — UQ dropped, no
replacement index. Until this hotfix runs, do NOT run drizzle-kit
generate or the generated migration will only DROP CONSTRAINT with
nothing to replace it.

One edit. Idempotent.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path, edits):
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main():
    print("\n--- lib/db/src/schema/prospects.ts ---")
    a, b, w = patch_file(
        "lib/db/src/schema/prospects.ts",
        [
            (
                '  // B9a: parent lookups (analytics view "all reengagements derived from\n'
                '  // prospect X").\n'
                '  index("idx_prospects_parent").on(table.parentProspectId),\n'
                ']);\n',
                '  // B9a: parent lookups (analytics view "all reengagements derived from\n'
                '  // prospect X").\n'
                '  index("idx_prospects_parent").on(table.parentProspectId),\n'
                '  // B9b.6: scope gmail_message_id uniqueness to (user, app) so a\n'
                '  // thread can carry both a doctrine prospect and an anti_ghosting\n'
                '  // prospect that share the same outbound seed message. The previous\n'
                '  // global UQ on the column blocked the canonical re-engagement-\n'
                '  // after-doctrine pattern.\n'
                '  uniqueIndex("uq_prospects_user_message_app").on(\n'
                '    table.userId,\n'
                '    table.gmailMessageId,\n'
                '    table.app,\n'
                '  ),\n'
                ']);\n',
                "add (user_id, gmail_message_id, app) uniqueIndex after idx_prospects_parent",
            ),
        ],
    )

    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {a}")
    print(f"  Already-applied:   {b}")
    print(f"  Warnings:          {w}")
    if w > 0:
        print("  Warning fired — see WARN line above.")
        return 2
    if a + b < 1:
        print("  No edit took effect.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
