#!/usr/bin/env node
/**
 * audit-batch4.mjs — Beautiful-Squidward audit harness for Batch 4.
 *
 * 3 rounds × 9 passes per round = 27 passes total.
 *
 * Run AFTER apply-batch4.mjs has been applied. Operates on the staging
 * tree by default. Override with env vars:
 *   DB_BASE   = path to the db schema directory   (default: lib/db/src)
 *   API_BASE  = path to api-server source         (default: artifacts/api-server/src)
 *   DASH_BASE = path to dashboard source          (default: artifacts/dashboard/src)
 *
 * Exits non-zero if any pass fails on any round.
 */

import { existsSync, readFileSync } from "fs";
import { join } from "path";

const DB_BASE   = process.env.DB_BASE   || "lib/db/src";
const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const usersSchemaPath = join(DB_BASE, "schema", "users.ts");
const cronPath        = join(API_BASE, "cron.ts");
const gmailAuthPath   = join(API_BASE, "routes", "gmail-auth.ts");
const digestPath      = join(API_BASE, "services", "weeklyDigest.ts");
const accountsPath    = join(DASH_BASE, "pages", "accounts.tsx");

let totalPasses = 0;
let totalFails = 0;
const failureMessages = [];

function read(path) {
  if (!existsSync(path)) throw new Error(`File missing: ${path}`);
  return readFileSync(path, "utf-8");
}

function check(label, condition, detail = "") {
  totalPasses++;
  if (condition) {
    console.log(`    [PASS] ${label}`);
  } else {
    totalFails++;
    failureMessages.push(`${label}${detail ? " — " + detail : ""}`);
    console.log(`    [FAIL] ${label}${detail ? " — " + detail : ""}`);
  }
}

function countIn(path, needle) {
  return read(path).split(needle).length - 1;
}

function runOneRound(roundNum) {
  console.log(`\n--- Round ${roundNum} ---`);

  // PASS 1: Schema columns declared
  console.log(`  PASS 1: Schema columns`);
  const schema = read(usersSchemaPath);
  check("1a. weeklyDigestEnabled column declared",
    schema.includes(`weeklyDigestEnabled: boolean("weekly_digest_enabled")`));
  check("1b. weeklyDigestEnabled is notNull and default false",
    schema.includes(`weeklyDigestEnabled: boolean("weekly_digest_enabled").notNull().default(false)`));
  check("1c. lastWeeklyDigestAt column declared",
    schema.includes(`lastWeeklyDigestAt: timestamp("last_weekly_digest_at"`));
  check("1d. lastWeeklyDigestAt has withTimezone:true",
    schema.includes(`lastWeeklyDigestAt: timestamp("last_weekly_digest_at", { withTimezone: true })`));

  // PASS 2: Service file installed and exports correct
  console.log(`  PASS 2: Service file`);
  check("2a. weeklyDigest.ts file present", existsSync(digestPath));
  if (existsSync(digestPath)) {
    const digest = read(digestPath);
    check("2b. exports runWeeklyDigest", digest.includes(`export async function runWeeklyDigest`));
    check("2c. exports sendWeeklyDigestForUser", digest.includes(`export async function sendWeeklyDigestForUser`));
    check("2d. exports gatherDigestData", digest.includes(`export async function gatherDigestData`));
    check("2e. exports formatDigestHtml", digest.includes(`export function formatDigestHtml`));
  }

  // PASS 3: Cron wired
  console.log(`  PASS 3: Cron`);
  const cron = read(cronPath);
  check("3a. runWeeklyDigest imported from ./services/weeklyDigest",
    cron.includes(`import { runWeeklyDigest } from "./services/weeklyDigest"`));
  check("3b. Tuesday 00:00 schedule string present",
    cron.includes(`cron.schedule("0 0 * * 2"`));
  check("3c. UTC timezone explicitly set on the digest cron",
    cron.includes(`timezone: "UTC"`));
  check("3d. startup log mentions weekly-digest",
    cron.includes(`weekly-digest @Tue 00:00 UTC`));

  // PASS 4: gmail-auth route projects + accepts new fields
  console.log(`  PASS 4: gmail-auth route`);
  const gauth = read(gmailAuthPath);
  check("4a. ACCOUNT_SELECT projects weeklyDigestEnabled",
    gauth.includes(`weeklyDigestEnabled: usersTable.weeklyDigestEnabled,`));
  check("4b. ACCOUNT_SELECT projects lastWeeklyDigestAt",
    gauth.includes(`lastWeeklyDigestAt: usersTable.lastWeeklyDigestAt,`));
  check("4c. PUT body destructures weeklyDigestEnabled",
    /weeklyDigestEnabled,\s*\}\s*=\s*req\.body;/.test(gauth));
  check("4d. PUT writes weeklyDigestEnabled",
    gauth.includes(`updates.weeklyDigestEnabled = weeklyDigestEnabled === true;`));

  // PASS 5: Dashboard state + PUT body
  console.log(`  PASS 5: Dashboard state`);
  const accts = read(accountsPath);
  check("5a. weeklyDigestEnabled state hook present",
    accts.includes(`const [weeklyDigestEnabled, setWeeklyDigestEnabled] = useState<boolean>`));
  check("5b. state initialized from account.weeklyDigestEnabled === true",
    accts.includes(`useState<boolean>(account.weeklyDigestEnabled === true)`));
  check("5c. weeklyDigestEnabled in PUT body object",
    /doctrineLabel,\s+weeklyDigestEnabled,\s+\};/.test(accts));

  // PASS 6: Dashboard UI section
  console.log(`  PASS 6: Dashboard UI section`);
  check("6a. Phase 4 marker comment present",
    accts.includes(`Phase 4: Weekly digest toggle`));
  check("6b. Settings label says 'Weekly digest'",
    /Weekly digest/.test(accts));
  check("6c. role='switch' on the toggle button",
    accts.includes(`role="switch"`));
  check("6d. setWeeklyDigestEnabled wired to onClick",
    accts.includes(`setWeeklyDigestEnabled(!weeklyDigestEnabled)`));

  // PASS 7: No leftover .batch3b.bak files
  console.log(`  PASS 7: Backup cleanup`);
  const bakFiles = [
    join(API_BASE, "cron.ts.batch3b.bak"),
    join(API_BASE, "services", "gmailClient.ts.batch3b.bak"),
    join(API_BASE, "services", "gmailSync.ts.batch3b.bak"),
    join(API_BASE, "services", "scheduler.ts.batch3b.bak"),
    join(API_BASE, "services", "timingEngine.ts.batch3b.bak"),
  ];
  for (const bak of bakFiles) {
    check(`7. ${bak} removed`, !existsSync(bak));
  }

  // PASS 8: Imports resolve at source — every import in weeklyDigest.ts
  // can be found in the file it claims to come from.
  console.log(`  PASS 8: Import resolution`);
  if (existsSync(digestPath)) {
    const digest = read(digestPath);
    // 8a: getGmailForUser is imported from ./gmailClient and exists there
    const gmailClientPath = join(API_BASE, "services", "gmailClient.ts");
    if (existsSync(gmailClientPath)) {
      const gmailClient = read(gmailClientPath);
      check("8a. getGmailForUser imported and exported in gmailClient.ts",
        digest.includes(`import { getGmailForUser } from "./gmailClient"`) &&
        gmailClient.includes(`export function getGmailForUser`));
    } else {
      check("8a. gmailClient.ts exists", false, `path: ${gmailClientPath}`);
    }
    // 8b: usersTable, prospectsTable, followupsTable imported from @workspace/db
    check("8b. workspace/db tables imported in weeklyDigest.ts",
      digest.includes(`from "@workspace/db"`) &&
      digest.includes(`usersTable`) &&
      digest.includes(`prospectsTable`) &&
      digest.includes(`followupsTable`));
    // 8c: schema declares all imported tables/columns
    check("8c. schema/users.ts has weeklyDigestEnabled (referenced by digest service)",
      schema.includes(`weeklyDigestEnabled`));
    check("8d. schema/users.ts has lastWeeklyDigestAt (referenced by digest service)",
      schema.includes(`lastWeeklyDigestAt`));
  }

  // PASS 9: No accidental duplicate insertions — counts match expectations
  console.log(`  PASS 9: Duplicate check`);
  check("9a. weeklyDigestEnabled column declared exactly once in schema",
    countIn(usersSchemaPath, `weeklyDigestEnabled: boolean("weekly_digest_enabled")`) === 1);
  check("9b. runWeeklyDigest imported exactly once in cron.ts",
    countIn(cronPath, `import { runWeeklyDigest }`) === 1);
  check("9c. Tuesday cron scheduled exactly once",
    countIn(cronPath, `cron.schedule("0 0 * * 2"`) === 1);
  check("9d. ACCOUNT_SELECT projection added exactly once",
    countIn(gmailAuthPath, `weeklyDigestEnabled: usersTable.weeklyDigestEnabled,`) === 1);
  check("9e. PUT updates.weeklyDigestEnabled appears exactly once",
    countIn(gmailAuthPath, `updates.weeklyDigestEnabled = weeklyDigestEnabled === true;`) === 1);
  check("9f. accounts state hook declared exactly once",
    countIn(accountsPath, `const [weeklyDigestEnabled, setWeeklyDigestEnabled]`) === 1);
  check("9g. accounts UI block inserted exactly once",
    countIn(accountsPath, `Phase 4: Weekly digest toggle`) === 1);
}

console.log("================================================================");
console.log("Batch 4 audit — 3 rounds × 9 passes (Beautiful-Squidward)");
console.log("================================================================");

for (let round = 1; round <= 3; round++) {
  runOneRound(round);
}

console.log("");
console.log("================================================================");
console.log(`Total: ${totalPasses - totalFails}/${totalPasses} passed across 3 rounds.`);
if (totalFails > 0) {
  console.log(`FAILURES (${totalFails}):`);
  for (const m of failureMessages) console.log(`  - ${m}`);
  console.log("================================================================");
  process.exit(1);
} else {
  console.log("All passes succeeded across all 3 rounds.");
  console.log("================================================================");
}
