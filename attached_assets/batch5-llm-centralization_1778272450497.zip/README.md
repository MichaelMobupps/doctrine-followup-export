# Batch 5 — LLM call site audit + model centralization

## What this batch does

**Audit finding (no code change required):** all four `anthropic.messages.create`
call sites already use the standard API with no `thinking.budget_tokens`
overrides anywhere. Adaptive thinking is therefore active across the entire
pipeline — Opus 4.7 is always adaptive; Sonnet 4.6 is adaptive by default
because no override is set. The audit portion of Phase 5 was a no-op finding;
no model behavior changes shipped.

**Code change:** centralize the four model identifiers in `lib/anthropic.ts`
as named exports. Every call site now imports its role-specific constant
(`MODEL_SUMMARIZER`, `MODEL_DRAFT_GENERATOR`, `MODEL_CRITIC`, `MODEL_REWRITER`)
instead of hardcoding `"claude-sonnet-4-6"` / `"claude-opus-4-7"`. Future
model swaps are one-line changes in `lib/anthropic.ts`.

## Files in this bundle

| File | Purpose |
|---|---|
| `apply-batch5.mjs` | Code patch. 7 idempotent str_replace operations + 13 self-verifies. |
| `audit-batch5.mjs` | Beautiful-Squidward harness: 3 rounds × 9 passes = 75 assertions. |

No new files. No DB migration. No new packages. No payload directory.

## Call site inventory (all 4 confirmed clean of thinking-budget overrides)

| File | Line | Role | Model |
|---|---|---|---|
| `services/emailSummarizer.ts` | 198 | SUMMARIZER | `claude-sonnet-4-6` |
| `services/followupGenerator.ts` | 180 | DRAFT_GENERATOR | `claude-sonnet-4-6` |
| `services/followupGenerator.ts` | 223 | CRITIC | `claude-opus-4-7` |
| `services/followupGenerator.ts` | 253 | REWRITER | `claude-sonnet-4-6` |

## Operating defaults baked in

- `API_BASE = artifacts/api-server/src`
- No DB build step (db package has no build script).
- No dashboard build needed (this batch doesn't touch the UI), but agents
  may build it anyway out of habit — that's harmless.

## Optional follow-up: Sonnet → Opus promotion for generator + rewriter

Independent of this batch. If you decide later that the draft and rewriter
sections benefit from stronger reasoning at higher cost, the change is two
edits in `lib/anthropic.ts`:

```ts
// Promote both to Opus 4.7
export const MODEL_DRAFT_GENERATOR: "claude-opus-4-7" = "claude-opus-4-7";
export const MODEL_REWRITER:        "claude-opus-4-7" = "claude-opus-4-7";
```

Cost note: Opus is roughly 5× the per-token cost of Sonnet. With the
generator + rewriter together running ~2 calls per outbound follow-up, this
is a unit-economics decision, not a code-quality one. Defer until you have
enough A/B reads to know whether the lift is worth it.

## Manual verification after deploy

```bash
# 1. Confirm centralized constants are present
grep -nE "^export const MODEL_" artifacts/api-server/src/lib/anthropic.ts

# 2. Confirm zero hardcoded "claude-..." strings outside lib/
grep -rn 'model: "claude-' artifacts/api-server/src/services/ || echo "(no hardcoded model strings)"

# 3. Confirm zero thinking-budget overrides
grep -rn 'budget_tokens\|thinking:\s*{' artifacts/api-server/src/ || echo "(no overrides)"
```

Expected: 4 lines from #1, "(no hardcoded model strings)" from #2,
"(no overrides)" from #3.

## Roll-forward note

Forward-only batch. To revert (if ever needed), the original literal strings
were:
- `"claude-sonnet-4-6"` for SUMMARIZER, DRAFT_GENERATOR, REWRITER
- `"claude-opus-4-7"` for CRITIC

Just replace each `MODEL_*` reference with the original literal in the three
files and remove the `MODEL_*` export block from `lib/anthropic.ts`. Or use
git revert.
