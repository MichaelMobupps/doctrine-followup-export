#!/usr/bin/env python3
"""
B9d.4 - Doctrine deep-blue refresh + Context warm/amber theme.

Three product themes now coexist via [data-product] CSS overrides:

  Doctrine (data-product="doctrine"):
    Deep authoritative blue. Accent shifts from blue-500 (#3b82f6,
    the previous default) to blue-600 (#2563eb). Subtle deepening
    that strengthens the brand without breaking continuity.

  Context (data-product="context"):
    Warm amber identity. Accent shifts to amber-500 (#f59e0b).
    Because white-on-amber fails WCAG (~2.2:1), Context's
    --accent-foreground is dark (#1a1208) instead of white. This
    requires introducing a --accent-foreground token used by the
    Button default variant.

  AntiGhosting (data-product="anti_ghosting"):
    Unchanged from B9d.1 - whitish theme. Gains explicit
    --accent-foreground: #ffffff for consistency.

Four anchors:
  C1: index.css :root      - add --accent-foreground: #ffffff
  C2: index.css AG block   - add --accent-foreground: #ffffff (explicit)
  C3: index.css insertion  - new Doctrine + Context blocks before @layer base
  U1: ui.tsx Button        - default variant text-white \u2192 text-[var(--accent-foreground)]

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INDEX_CSS = WORKSPACE / "artifacts/dashboard/src/index.css"
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# C1: :root - add --accent-foreground
# Anchor on the unique :root accent block (different hex from AG/Doctrine).
# ====================================================================
C1_OLD = '''  --accent: #3b82f6;
  --accent-hover: #2563eb;
  --accent-muted: rgba(59,130,246,0.10);
  --accent-border: rgba(59,130,246,0.25);'''

C1_NEW = '''  --accent: #3b82f6;
  --accent-hover: #2563eb;
  --accent-muted: rgba(59,130,246,0.10);
  --accent-border: rgba(59,130,246,0.25);
  --accent-foreground: #ffffff; /* B9d.4: text color for elements with accent bg */'''


# ====================================================================
# C2: AG block - explicit --accent-foreground
# Anchor on the AG-specific accent values (unique hex).
# ====================================================================
C2_OLD = '''  --accent: #2563eb;
  --accent-hover: #1d4ed8;
  --accent-muted: rgba(37,99,235,0.08);
  --accent-border: rgba(37,99,235,0.25);'''

C2_NEW = '''  --accent: #2563eb;
  --accent-hover: #1d4ed8;
  --accent-muted: rgba(37,99,235,0.08);
  --accent-border: rgba(37,99,235,0.25);
  --accent-foreground: #ffffff; /* B9d.4 */'''


# ====================================================================
# C3: insert Doctrine + Context blocks before @layer base
# Anchor on the AG block's closing line followed by @layer base.
# (B9d.1 inserted AG before @layer base; B9d.4 inserts these AFTER AG.)
# ====================================================================
C3_OLD = '''  --color-tertiary: #94a3b8;
}
@layer base {'''

C3_NEW = '''  --color-tertiary: #94a3b8;
}

/* ============================================================== */
/* B9d.4: Doctrine deep-blue refresh.                              */
/* ============================================================== */
/* Activated by layout setting data-product="doctrine" (the        */
/* default product). Accent shifts from blue-500 to blue-600 for   */
/* deeper authority. Surfaces stay neutral dark from :root.        */
[data-product="doctrine"] {
  --accent: #2563eb;
  --accent-hover: #1d4ed8;
  --accent-muted: rgba(37,99,235,0.12);
  --accent-border: rgba(37,99,235,0.28);
  --accent-foreground: #ffffff;

  /* Tailwind v4 mirrors so utility classes pick up the new blue. */
  --color-primary: #2563eb;
  --color-primary-foreground: #ffffff;
  --color-ring: #2563eb;
}

/* ============================================================== */
/* B9d.4: Context warm/amber theme.                                */
/* ============================================================== */
/* Activated by data-product="context". Amber accent signals       */
/* warmth + relationship orientation. White text fails WCAG on     */
/* amber (~2.2:1), so --accent-foreground is dark (~7.5:1).        */
/* --info also shifts to amber for visual consistency.             */
[data-product="context"] {
  --accent: #f59e0b;
  --accent-hover: #d97706;
  --accent-muted: rgba(245,158,11,0.12);
  --accent-border: rgba(245,158,11,0.30);
  --accent-foreground: #1a1208;

  --info: #f59e0b;
  --info-muted: rgba(245,158,11,0.12);
  --info-border: rgba(245,158,11,0.28);

  /* Tailwind v4 mirrors so utility classes pick up amber. */
  --color-primary: #f59e0b;
  --color-primary-foreground: #1a1208;
  --color-ring: #f59e0b;
  --color-info: #f59e0b;
  --color-info-foreground: #1a1208;
}

@layer base {'''


# ====================================================================
# U1: Button default variant - text-white \u2192 text-[var(--accent-foreground)]
# Anchor on the B9d.2 default variant line.
# ====================================================================
U1_OLD = '''      default: "bg-[var(--accent)] text-white border border-[var(--accent)] shadow-sm hover:bg-[var(--accent-hover)] hover:border-[var(--accent-hover)] focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]",'''

U1_NEW = '''      // B9d.4: text-[var(--accent-foreground)] enables per-product text-color on accent bg (white on blue, dark on amber).
      default: "bg-[var(--accent)] text-[var(--accent-foreground)] border border-[var(--accent)] shadow-sm hover:bg-[var(--accent-hover)] hover:border-[var(--accent-hover)] focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]",'''


def patch_css():
    if not INDEX_CSS.exists():
        fail(f"index.css not found: {INDEX_CSS}")
    text = INDEX_CSS.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, C1_OLD, C1_NEW,
        "C1: :root add --accent-foreground",
        marker="--accent-foreground: #ffffff; /* B9d.4: text color for elements with accent bg */",
    )

    text, _ = replace_unique(
        text, C2_OLD, C2_NEW,
        "C2: AG block add --accent-foreground",
        marker="--accent-foreground: #ffffff; /* B9d.4 */",
    )

    text, _ = replace_unique(
        text, C3_OLD, C3_NEW,
        "C3: insert Doctrine + Context blocks",
        marker="B9d.4: Doctrine deep-blue refresh",
    )

    if text != original:
        INDEX_CSS.write_text(text, encoding="utf-8")
        ok(f"wrote {INDEX_CSS.relative_to(WORKSPACE)}")
    else:
        skip("index.css already patched")


def patch_ui():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, U1_OLD, U1_NEW,
        "U1: Button default variant accent-foreground token",
        marker="B9d.4: text-[var(--accent-foreground)]",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")


def main():
    patch_css()
    patch_ui()
    print()
    print("B9d.4 Doctrine + Context theme refresh applied.")


if __name__ == "__main__":
    main()
