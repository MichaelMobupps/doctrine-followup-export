import os

WORKSPACE = "/home/runner/workspace"
DASHBOARD = f"{WORKSPACE}/artifacts/dashboard/src"

# ─── Fix 1: Remove Dashboard page, make Prospects the landing page ───
print("Fix 1: Removing Dashboard, Prospects becomes home page...")

app_path = f"{DASHBOARD}/App.tsx"
with open(app_path, "r") as f:
    c = f.read()

# Remove Dashboard import and route, make Prospects the "/" route
c = c.replace('import Dashboard from "@/pages/dashboard";\n', '')
c = c.replace('      <Route path="/" component={Dashboard} />\n', '      <Route path="/" component={Prospects} />\n')

with open(app_path, "w") as f:
    f.write(c)
print("  App.tsx: Dashboard removed, Prospects is now /")

# Update layout nav — remove Dashboard link
layout_path = f"{DASHBOARD}/components/layout.tsx"
with open(layout_path, "r") as f:
    c = f.read()

c = c.replace(
    '    { name: "Dashboard", href: "/", icon: LayoutDashboard },\n    { name: "Prospects", href: "/prospects", icon: Users },',
    '    { name: "Prospects", href: "/", icon: Users },'
)
# Remove LayoutDashboard from imports if unused
c = c.replace('import { LayoutDashboard, Users,', 'import { Users,')

with open(layout_path, "w") as f:
    f.write(c)
print("  layout.tsx: Dashboard nav removed, Prospects is first item")

# ─── Fix 2: Email inspector — only show current user's account, no dropdown ───
print("\nFix 2: Email inspector locked to current user only...")

insp_path = f"{DASHBOARD}/pages/email-inspector.tsx"
with open(insp_path, "r") as f:
    c = f.read()

# Replace the account selector dropdown with a fixed display of current user
# Find the select element and replace with a static label
old_select = '''            <select
              value={selectedUserId}
              onChange={e => setSelectedUserId(e.target.value)}
              className="h-9 rounded-md px-3 text-[13px]"
              style={{
                background: "var(--bg-tertiary)",
                border: "1px solid var(--border-default)",
                color: "var(--text-primary)",
                minWidth: "180px",
              }}
            >
              {accounts.map((acct: any) => (
                <option key={acct.id} value={String(acct.id)}>
                  {acct.name || acct.email}
                </option>
              ))}
            </select>'''

new_display = '''            <div
              className="h-9 rounded-md px-3 text-[13px] flex items-center"
              style={{
                background: "var(--bg-tertiary)",
                border: "1px solid var(--border-default)",
                color: "var(--text-primary)",
                minWidth: "180px",
              }}
            >
              {currentUser?.email || "Loading..."}
            </div>'''

if old_select in c:
    c = c.replace(old_select, new_display)
    print("  Replaced dropdown with static user display")

# Also force selectedUserId from currentUser only (no accounts loop)
old_effect = '''  useEffect(() => {
    if (!selectedUserId && accounts.length > 0 && currentUser?.userId) {
      setSelectedUserId(String(currentUser.userId));
    } else if (!selectedUserId && accounts.length > 0) {
      setSelectedUserId(String(accounts[0].id));
    }
  }, [accounts, currentUser]);'''

new_effect = '''  useEffect(() => {
    if (currentUser?.userId) {
      setSelectedUserId(String(currentUser.userId));
    }
  }, [currentUser?.userId]);'''

c = c.replace(old_effect, new_effect)

with open(insp_path, "w") as f:
    f.write(c)
print("  email-inspector.tsx: locked to current user")

# ─── Fix 3: Accounts page — only show current user's account ───
print("\nFix 3: Accounts page locked to current user...")

acct_path = f"{DASHBOARD}/pages/accounts.tsx"
with open(acct_path, "r") as f:
    c = f.read()

# Check if filtering already exists
if "allAccounts" in c:
    print("  Already has filtering, skipping")
else:
    # Add useCurrentUser import if missing
    if "useCurrentUser" not in c:
        c = c.replace(
            'import { useApiKey } from "@/hooks/use-api-key";',
            'import { useApiKey } from "@/hooks/use-api-key";\nimport { useCurrentUser } from "@/hooks/use-current-user";'
        )
    
    # Add currentUser hook if missing
    if 'const { user: currentUser }' not in c:
        c = c.replace(
            '  const { apiKey } = useApiKey();',
            '  const { apiKey } = useApiKey();\n  const { user: currentUser } = useCurrentUser();'
        )
    
    # Filter accounts to current user only
    old_accounts = '  const accounts = (data as any)?.accounts || [];'
    new_accounts = '''  const allAccounts = (data as any)?.accounts || [];
  const accounts = currentUser?.userId
    ? allAccounts.filter((a: any) => a.id === currentUser.userId)
    : allAccounts;'''
    c = c.replace(old_accounts, new_accounts)

with open(acct_path, "w") as f:
    f.write(c)
print("  accounts.tsx: filtered to current user only")

# ─── Fix 4: autoQueueAllCampaigns on 3-min tick ───
print("\nFix 4: Ensuring autoqueue runs every 3 minutes...")

cron_path = f"{WORKSPACE}/artifacts/api-server/src/cron.ts"
with open(cron_path, "r") as f:
    c = f.read()

# Check if autoQueueAllCampaigns is already on the 3-min tick
three_min_section = c.split("*/3")[1] if "*/3" in c else ""
if "autoQueueAllCampaigns" in three_min_section:
    print("  Already on 3-min tick")
else:
    old_3min = '''    try {
      const autoQueued = await autoQueueNextStages();
      if (autoQueued > 0) {
        logger.info({ autoQueued }, "Auto-queued next follow-up stages");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue error");
    }
  });'''

    new_3min = '''    try {
      const autoQueued = await autoQueueNextStages();
      if (autoQueued > 0) {
        logger.info({ autoQueued }, "Auto-queued next follow-up stages (test)");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue error");
    }

    try {
      const allQueued = await autoQueueAllCampaigns();
      if (allQueued > 0) {
        logger.info({ allQueued }, "Auto-queued follow-up stages (all campaigns)");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue all error");
    }
  });'''

    if old_3min in c:
        c = c.replace(old_3min, new_3min)
        with open(cron_path, "w") as f:
            f.write(c)
        print("  cron.ts: autoQueueAllCampaigns added to 3-min tick")
    else:
        print("  WARNING: Could not find 3-min tick block to patch")

print("\n=== All fixes applied ===")
print("Run: cd /home/runner/workspace && bash source-code/sync.sh")
