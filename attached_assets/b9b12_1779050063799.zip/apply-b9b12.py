#!/usr/bin/env python3
"""
B9b.12 - AntiGhosting Email Inspector.

Four file edits:

  1. artifacts/api-server/src/routes/anti-ghosting.ts
     - Extend googleapis import: add `google`.
     - Insert helpers (getLegacyGmail, getGmailForRequest, extractEmail,
       extractName, isWithinSyncWindow) + two handlers
       (GET /gmail/sent-emails, POST /sync) before `export default router;`.

  2. artifacts/dashboard/src/pages/anti-ghosting-inspector.tsx
     - New file. Clone of context-inspector.tsx with field renames
       (hasContextLabel -> hasAntiGhostingLabel etc.), endpoint path
       changes, and title changes.

  3. artifacts/dashboard/src/App.tsx
     - Import the new page.
     - Add Route /anti-ghosting/inspector.

  4. artifacts/dashboard/src/components/layout.tsx
     - Extend AG navItems to include Email Inspector entry.

Each edit is idempotent (marker-checked) and anchor-uniqueness-verified.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
BACKEND = WORKSPACE / "artifacts/api-server/src/routes/anti-ghosting.ts"
FRONTEND_PAGE = WORKSPACE / "artifacts/dashboard/src/pages/anti-ghosting-inspector.tsx"
APP_TSX = WORKSPACE / "artifacts/dashboard/src/App.tsx"
LAYOUT_TSX = WORKSPACE / "artifacts/dashboard/src/components/layout.tsx"

TSX_CONTENT = r'''// B9b.12: AntiGhostingEmailInspector — clone of context-inspector.tsx retargeted to
// /api/anti-ghosting/gmail/sent-emails. The product-specific label field
// (hasContextLabel) is renamed to hasAntiGhostingLabel across types, response
// shape, and UI strings. wouldBePickedUp drops the 60-day-window gate because
// AG ingestion (ingestAntiGhostingLabeledThreads) does not filter by date —
// any AG-labeled thread is eligible regardless of age. Visual structure and
// layout match context-inspector.tsx so the team doesn't have to learn a
// new tool.
import React, { useState, useEffect, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { format } from "date-fns";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";
import { Card, Button, Badge, Input, Select } from "@/components/ui";
import {
  Search, RefreshCw, AlertCircle, Mail, Tag, ArrowRight,
  CheckCircle2, XCircle, ChevronDown, ChevronRight, Inbox,
  MessageSquare, Building2, Sparkles, Database, Loader2, Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";

type SentEmail = {
  id: string;
  threadId: string;
  from: string;
  to: string;
  recipientEmail: string;
  recipientName: string;
  subject: string;
  snippet: string;
  bodyPreview: string;
  date: string;
  timestamp: number;
  labelIds: string[];
  labelNames: string[];
  hasAntiGhostingLabel: boolean;
  matchedAntiGhostingLabels: string[];
  isSentByMe: boolean;
  detection: {
    wouldBePickedUp: boolean;
    whyNot?: string[];
    vertical: string;
    verticalReason: string;
    withinSyncWindow?: boolean;
    company: string;
  };
  inDatabase: boolean;
  dbRecord: { gmailMessageId: string; id: number; replied: number; vertical: string; matchType?: string } | null;
};

type SentEmailsMeta = {
  total: number;
  withAntiGhostingLabel: number;
  inDatabase: number;
  wouldBePickedUp: number;
};

const verticalLabels: Record<string, string> = {
  gaming_ua: "Gaming UA",
  non_gaming_ua: "Non-Gaming UA",
  cps: "CPS",
  retargeting: "Retargeting",
};

function StatusPill({ active, label }: { active: boolean; label: string }) {
  return (
    <span
      className="text-[11px] font-mono font-medium px-2 py-0.5 rounded"
      style={
        active
          ? { background: "var(--success-muted)", color: "var(--success)" }
          : { background: "var(--bg-tertiary)", color: "var(--text-tertiary)" }
      }
    >
      {label}
    </span>
  );
}

function DetectionPipeline({ email }: { email: SentEmail }) {
  const steps = [
    { label: "SENT", active: email.isSentByMe },
    { label: "LABEL", active: email.hasAntiGhostingLabel },
    { label: "DB", active: email.inDatabase },
  ];

  return (
    <div className="flex items-center gap-1.5">
      {steps.map((step, i) => (
        <React.Fragment key={step.label}>
          <StatusPill {...step} />
          {i < steps.length - 1 && (
            <ArrowRight
              className="h-3 w-3 flex-shrink-0"
              style={{ color: step.active ? "var(--text-tertiary)" : "var(--border-default)" }}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {
  // /api/gmail/thread is shared between products (a Gmail thread is product-agnostic).
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    if (!threadId) { setIsLoading(false); return; }
    let cancelled = false;
    setIsLoading(true);
    const base = import.meta.env.BASE_URL || "/";
    fetch(`${base}api/gmail/thread/${threadId}`, {
      headers: { "x-api-key": apiKey || "" },
    })
      .then((r) => {
        if (!r.ok) throw new Error("Failed to load thread");
        return r.json();
      })
      .then((d) => {
        if (cancelled) return;
        setData(d); setIsError(false); setIsLoading(false);
      })
      .catch(() => {
        if (cancelled) return;
        setIsError(true); setIsLoading(false);
      });
    return () => { cancelled = true; };
  }, [threadId, apiKey]);

  if (isLoading) {
    return (
      <div className="flex items-center gap-2 py-4 text-[13px]" style={{ color: "var(--text-secondary)" }}>
        <RefreshCw className="h-4 w-4 animate-spin" />
        Loading thread...
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="flex items-center gap-2 py-4 text-[13px]" style={{ color: "var(--danger)" }}>
        <AlertCircle className="h-4 w-4" />
        Failed to load thread
      </div>
    );
  }

  return (
    <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
      <div className="flex items-center gap-3 text-[11px] mb-2" style={{ color: "var(--text-secondary)" }}>
        <span>{data.messageCount} message{data.messageCount !== 1 ? "s" : ""}</span>
        {data.hasExternalReply ? (
          <Badge variant="success">REPLY</Badge>
        ) : (
          <Badge variant="outline">NO REPLY</Badge>
        )}
      </div>
      {data.messages?.map((msg: any) => (
        <div
          key={msg.id}
          className={cn("rounded-lg p-3 text-[13px]", msg.isFromMe ? "ml-6" : "mr-6")}
          style={{
            background: msg.isFromMe ? "var(--accent-muted)" : "var(--success-muted)",
            border: msg.isFromMe ? "1px solid var(--accent-border)" : "1px solid var(--success-border)",
          }}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-[12px]" style={{ color: "var(--text-primary)" }}>
              {msg.isFromMe ? "Me" : msg.from}
            </span>
            <span className="text-[11px]" style={{ color: "var(--text-tertiary)" }}>
              {msg.date ? format(new Date(msg.date), "MMM d, HH:mm") : ""}
            </span>
          </div>
          <p className="whitespace-pre-wrap text-[12px] leading-relaxed max-h-32 overflow-hidden" style={{ color: "var(--text-secondary)" }}>
            {msg.body || msg.snippet}
          </p>
        </div>
      ))}
    </div>
  );
}

function EmailCard({ email, apiKey }: { email: SentEmail; apiKey: string }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [showThread, setShowThread] = useState(false);

  const vertLabel = verticalLabels[email.detection.vertical] || email.detection.vertical;

  return (
    <Card className="overflow-hidden" style={{ animation: "fadeUp 0.3s ease both" }}>
      <div
        className="p-4 cursor-pointer transition-colors duration-100"
        style={{ borderLeft: email.detection.wouldBePickedUp ? "2px solid var(--success)" : "2px solid transparent" }}
        onClick={() => setIsExpanded(!isExpanded)}
        onMouseEnter={(e) => { e.currentTarget.style.background = "var(--bg-tertiary)"; }}
        onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
      >
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="font-semibold text-[13px] truncate" style={{ color: "var(--text-primary)" }}>
                  {email.subject || "(No Subject)"}
                </h3>
                <div className="flex items-center gap-2 mt-1 text-[12px]" style={{ color: "var(--text-secondary)" }}>
                  <span className="flex items-center gap-1">
                    <Building2 className="h-3 w-3" strokeWidth={1.5} />
                    {email.recipientName || email.recipientEmail}
                  </span>
                  <span style={{ color: "var(--text-tertiary)" }}>|</span>
                  <span>{email.recipientEmail}</span>
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <span className="font-mono text-[11px]" style={{ color: "var(--text-tertiary)" }}>
                  {email.date ? format(new Date(email.date), "MMM d, HH:mm") : ""}
                </span>
                {isExpanded ? (
                  <ChevronDown className="h-4 w-4" style={{ color: "var(--text-tertiary)" }} />
                ) : (
                  <ChevronRight className="h-4 w-4" style={{ color: "var(--text-tertiary)" }} />
                )}
              </div>
            </div>

            <div className="mt-3 flex items-center gap-2 flex-wrap">
              <DetectionPipeline email={email} />
              <div className="ml-auto flex items-center gap-1.5">
                {/* AG emails carry no vertical (same as context). Hide empty badge. */}
                {vertLabel && <Badge variant="outline">{vertLabel}</Badge>}
                {email.detection.wouldBePickedUp && (
                  email.inDatabase ? (
                    <Badge variant="success">SYNCED</Badge>
                  ) : (
                    <Badge variant="outline" style={{ background: "rgba(59, 130, 246, 0.12)", color: "var(--accent)", border: "1px solid rgba(59, 130, 246, 0.3)" }}>
                      PENDING SYNC
                    </Badge>
                  )
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-4 space-y-4 pt-4" style={{ borderTop: "1px solid var(--border-default)" }}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h4
                    className="font-medium uppercase tracking-[0.04em]"
                    style={{ fontSize: "11px", color: "var(--text-tertiary)" }}
                  >
                    DETECTION
                  </h4>
                  <div className="space-y-2 text-[13px]">
                    {[
                      ["Sent by me", email.isSentByMe],
                      ["AntiGhosting label", email.hasAntiGhostingLabel],
                      ["Would be picked up", email.detection.wouldBePickedUp],
                    ].map(([label, val]) => (
                      <div key={label as string} className="flex justify-between">
                        <span style={{ color: "var(--text-secondary)" }}>{label as string}</span>
                        <span
                          className="font-mono font-medium"
                          style={{ color: val ? "var(--success)" : "var(--text-tertiary)" }}
                        >
                          {val ? "YES" : "NO"}
                        </span>
                      </div>
                    ))}
                    {/* Hide Vertical/Reason rows when vertical inference is empty (AG). */}
                    {vertLabel && (
                      <>
                        <div className="flex justify-between">
                          <span style={{ color: "var(--text-secondary)" }}>Vertical</span>
                          <span style={{ color: "var(--text-primary)" }}>{vertLabel}</span>
                        </div>
                        <div className="flex justify-between">
                          <span style={{ color: "var(--text-secondary)" }}>Reason</span>
                          <span className="text-[12px]" style={{ color: "var(--text-secondary)" }}>{email.detection.verticalReason}</span>
                        </div>
                      </>
                    )}
                    {email.detection.withinSyncWindow !== undefined && (
                      <div className="flex justify-between">
                        <span style={{ color: "var(--text-secondary)" }}>60-day window</span>
                        <span className="font-mono font-medium" style={{ color: email.detection.withinSyncWindow ? "var(--success)" : "var(--text-tertiary)" }}>
                          {email.detection.withinSyncWindow ? "YES" : "NO"}
                        </span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span style={{ color: "var(--text-secondary)" }}>Company</span>
                      <span className="capitalize" style={{ color: "var(--text-primary)" }}>{email.detection.company || "\u2014"}</span>
                    </div>
                    {email.detection.whyNot && email.detection.whyNot.length > 0 && (
                      <div className="mt-2 p-3 rounded-lg" style={{ background: "var(--warning-muted)", border: "1px solid var(--warning-border)" }}>
                        <p className="font-medium uppercase tracking-[0.04em] mb-1" style={{ fontSize: "11px", color: "var(--warning)" }}>WHY NOT DETECTED</p>
                        <ul className="space-y-0.5">
                          {email.detection.whyNot.map((reason, i) => (
                            <li key={i} className="text-[12px] flex items-center gap-1.5" style={{ color: "var(--warning)" }}>
                              <XCircle className="h-3 w-3 flex-shrink-0" />
                              {reason}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span style={{ color: "var(--text-secondary)" }}>In database</span>
                      {email.inDatabase ? (
                        <span className="font-mono font-medium" style={{ color: "var(--success)" }}>
                          YES (ID: {email.dbRecord?.id}{email.dbRecord?.matchType === "thread" ? ", via thread" : ""})
                        </span>
                      ) : email.detection.wouldBePickedUp ? (
                        <span className="font-mono font-medium" style={{ color: "var(--warning)" }}>
                          PENDING SYNC
                        </span>
                      ) : (
                        <span className="font-mono font-medium" style={{ color: "var(--text-tertiary)" }}>
                          NO
                        </span>
                      )}
                    </div>
                    {!email.inDatabase && email.detection.wouldBePickedUp && (
                      <div className="rounded-lg p-2.5" style={{ background: "rgba(59, 130, 246, 0.08)", border: "1px solid rgba(59, 130, 246, 0.2)" }}>
                        <p className="text-[11px]" style={{ color: "var(--accent)" }}>
                          This thread will become an AntiGhosting prospect on the next Gmail sync. F1 will be queued automatically.
                        </p>
                      </div>
                    )}
                    {email.dbRecord && (
                      <div className="flex justify-between">
                        <span style={{ color: "var(--text-secondary)" }}>Reply status (DB)</span>
                        <span className="font-mono font-medium" style={{ color: email.dbRecord.replied ? "var(--success)" : "var(--warning)" }}>
                          {email.dbRecord.replied ? "REPLIED" : "UNREPLIED"}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="space-y-3">
                  <h4
                    className="font-medium uppercase tracking-[0.04em]"
                    style={{ fontSize: "11px", color: "var(--text-tertiary)" }}
                  >
                    LABELS
                  </h4>
                  <div className="flex flex-wrap gap-1.5">
                    {email.labelNames.map((label, i) => (
                      <span
                        key={i}
                        className="px-2 py-0.5 rounded text-[11px] font-mono font-medium"
                        style={
                          email.matchedAntiGhostingLabels.includes(label)
                            ? { background: "var(--success-muted)", color: "var(--success)" }
                            : { background: "var(--bg-tertiary)", color: "var(--text-secondary)" }
                        }
                      >
                        {label}
                      </span>
                    ))}
                    {email.labelNames.length === 0 && (
                      <span className="text-[12px]" style={{ color: "var(--text-tertiary)" }}>No labels</span>
                    )}
                  </div>

                  <h4
                    className="font-medium uppercase tracking-[0.04em] pt-2"
                    style={{ fontSize: "11px", color: "var(--text-tertiary)" }}
                  >
                    PREVIEW
                  </h4>
                  <p
                    className="text-[12px] leading-relaxed whitespace-pre-wrap max-h-32 overflow-y-auto rounded-lg p-3"
                    style={{
                      color: "var(--text-secondary)",
                      background: "var(--bg-primary)",
                      border: "1px solid var(--border-default)",
                    }}
                  >
                    {email.bodyPreview || email.snippet || "(No content)"}
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={(e) => { e.stopPropagation(); setShowThread(!showThread); }}
                  className="gap-2 text-[12px]"
                >
                  <MessageSquare className="h-3 w-3" />
                  {showThread ? "Hide thread" : "View thread"}
                </Button>
              </div>

              {showThread && (
                <div className="pt-2">
                  <ThreadView threadId={email.threadId} apiKey={apiKey} />
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}

export default function AntiGhostingEmailInspector() {
  const { apiKey } = useApiKey();
  const { user: currentUser } = useCurrentUser();
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [search, setSearch] = useState("");
  const [searchInput, setSearchInput] = useState("");
  const [limit, setLimit] = useState(30);
  const [filter, setFilter] = useState<"all" | "detected" | "labeled" | "unlabeled">("all");
  const [syncing, setSyncing] = useState(false);
  const [syncMsg, setSyncMsg] = useState<string | null>(null);

  // /api/gmail/accounts is shared between products.
  const [accountsData, setAccountsData] = useState<any>(null);
  useEffect(() => {
    if (!apiKey) return;
    let cancelled = false;
    const base = import.meta.env.BASE_URL || "/";
    fetch(`${base}api/gmail/accounts`, {
      headers: { "x-api-key": apiKey || "" },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (!cancelled) setAccountsData(d); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [apiKey]);
  const accounts: any[] = (accountsData as any)?.accounts || [];

  useEffect(() => {
    if (currentUser?.userId) {
      setSelectedUserId(String(currentUser.userId));
    }
  }, [currentUser?.userId]);

  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [refetchTrigger, setRefetchTrigger] = useState(0);
  const refetch = useCallback(() => setRefetchTrigger((t) => t + 1), []);

  useEffect(() => {
    if (!apiKey || !selectedUserId) return;
    let cancelled = false;
    setIsFetching(true);

    const params = new URLSearchParams();
    params.set("limit", String(limit));
    if (search) params.set("search", search);
    if (selectedUserId) params.set("userId", selectedUserId);

    const base = import.meta.env.BASE_URL || "/";
    fetch(`${base}api/anti-ghosting/gmail/sent-emails?${params.toString()}`, {
      headers: { "x-api-key": apiKey || "" },
    })
      .then((r) => {
        if (!r.ok) throw new Error("Failed to load sent emails");
        return r.json();
      })
      .then((d) => {
        if (cancelled) return;
        setData(d); setIsError(false); setIsLoading(false); setIsFetching(false);
      })
      .catch(() => {
        if (cancelled) return;
        setIsError(true); setIsLoading(false); setIsFetching(false);
      });
    return () => { cancelled = true; };
  }, [apiKey, selectedUserId, limit, search, refetchTrigger]);

  const emails: SentEmail[] = (data as any)?.emails || [];
  const meta: SentEmailsMeta = (data as any)?.meta || { total: 0, withAntiGhostingLabel: 0, inDatabase: 0, wouldBePickedUp: 0 };

  const pendingSyncCount = emails.filter(e => e.detection.wouldBePickedUp && !e.inDatabase).length;

  const handleSyncNow = async () => {
    setSyncing(true);
    setSyncMsg(null);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const res = await fetch(`${base}api/anti-ghosting/sync`, {
        method: "POST",
        headers: {
          "x-api-key": apiKey || "",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email: currentUser?.email }),
      });
      const data = await res.json();
      if (res.ok) {
        setSyncMsg(`Synced ${data.synced ?? 0} emails, ${data.repliesDetected ?? 0} replies detected.`);
        refetch();
      } else {
        setSyncMsg(data.error || "Sync failed");
      }
      setTimeout(() => setSyncMsg(null), 8000);
    } catch (err: any) {
      setSyncMsg(err.message || "Sync failed");
      setTimeout(() => setSyncMsg(null), 5000);
    } finally {
      setSyncing(false);
    }
  };

  const filteredEmails = emails.filter(e => {
    if (filter === "detected") return e.detection.wouldBePickedUp;
    if (filter === "labeled") return e.hasAntiGhostingLabel;
    if (filter === "unlabeled") return !e.hasAntiGhostingLabel;
    return true;
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearch(searchInput);
  };

  const statCards = [
    { label: "TOTAL FETCHED", value: meta.total },
    { label: "AG LABELED", value: meta.withAntiGhostingLabel },
    { label: "DETECTED", value: meta.wouldBePickedUp, highlight: pendingSyncCount > 0 },
    { label: "IN DATABASE", value: meta.inDatabase },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>AntiGhosting Email Inspector</h1>
        <Button
          variant="secondary"
          onClick={() => refetch()}
          isLoading={isFetching}
          className="gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {statCards.map((stat: any, i: number) => (
          <Card
            key={stat.label}
            className="p-4"
            style={{
              animation: `fadeUp 0.3s ease both`,
              animationDelay: `${i * 0.05}s`,
              ...(stat.highlight ? { border: "1px solid rgba(59, 130, 246, 0.3)", background: "rgba(59, 130, 246, 0.04)" } : {}),
            }}
          >
            <p
              className="font-medium uppercase tracking-[0.04em] mb-2"
              style={{ fontSize: "11px", color: stat.highlight ? "var(--accent)" : "var(--text-tertiary)" }}
            >
              {stat.label}
            </p>
            <p
              className="font-semibold font-mono"
              style={{ fontSize: "24px", letterSpacing: "-0.02em", color: "var(--text-primary)" }}
            >
              {stat.value}
            </p>
            {stat.highlight && (
              <p className="text-[11px] mt-1" style={{ color: "var(--accent)" }}>
                {pendingSyncCount} pending sync
              </p>
            )}
          </Card>
        ))}
      </div>

      {syncMsg && (
        <div
          className="rounded-lg px-4 py-3 text-[13px]"
          style={{
            background: "rgba(34, 197, 94, 0.1)",
            border: "1px solid rgba(34, 197, 94, 0.3)",
            color: "var(--success)",
          }}
        >
          {syncMsg}
        </div>
      )}

      {pendingSyncCount > 0 && (
        <div
          className="rounded-lg p-4 flex items-center justify-between"
          style={{
            background: "rgba(59, 130, 246, 0.06)",
            border: "1px solid rgba(59, 130, 246, 0.2)",
          }}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: "rgba(59, 130, 246, 0.12)" }}>
              <Zap className="h-4 w-4" style={{ color: "var(--accent)" }} />
            </div>
            <div>
              <p className="text-[13px] font-medium" style={{ color: "var(--text-primary)" }}>
                {pendingSyncCount} thread{pendingSyncCount !== 1 ? "s" : ""} detected but not yet synced
              </p>
              <p className="text-[12px]" style={{ color: "var(--text-secondary)" }}>
                Sync now to create AntiGhosting prospects, then F1 will be queued automatically.
              </p>
            </div>
          </div>
          <Button
            onClick={handleSyncNow}
            disabled={syncing}
            className="gap-2"
            size="sm"
            style={{ background: "var(--accent)", borderColor: "var(--accent)" }}
          >
            {syncing ? (
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
            ) : (
              <RefreshCw className="h-3.5 w-3.5" />
            )}
            Sync Now
          </Button>
        </div>
      )}

      <div className="flex gap-3">
        <div
          className="h-9 rounded-md px-3 text-[13px] flex items-center w-52"
          style={{
            background: "var(--bg-tertiary)",
            border: "1px solid var(--border-default)",
            color: "var(--text-secondary)",
          }}
        >
          {currentUser?.email || "Loading..."}
        </div>
        <form onSubmit={handleSearch} className="flex-1 flex gap-2">
          <div className="relative flex-1">
            <Search
              className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4"
              style={{ color: "var(--text-tertiary)" }}
            />
            <Input
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Gmail search query..."
              className="pl-10"
            />
          </div>
          <Button type="submit" className="gap-2">
            <Search className="h-4 w-4" />
            Search
          </Button>
        </form>
        <Select
          value={filter}
          onChange={(e) => setFilter(e.target.value as any)}
          className="w-40"
        >
          <option value="all">All emails</option>
          <option value="detected">Detected</option>
          <option value="labeled">Has label</option>
          <option value="unlabeled">No label</option>
        </Select>
        <Select
          value={limit.toString()}
          onChange={(e) => setLimit(parseInt(e.target.value))}
          className="w-20"
        >
          <option value="10">10</option>
          <option value="20">20</option>
          <option value="30">30</option>
          <option value="50">50</option>
        </Select>
      </div>

      {meta.total > 0 && meta.withAntiGhostingLabel === 0 && (
        <div
          className="rounded-lg p-4 flex items-start gap-3"
          style={{ background: "var(--warning-muted)", border: "1px solid var(--warning-border)" }}
        >
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" style={{ color: "var(--warning)" }} />
          <div>
            <p className="text-[13px] font-medium" style={{ color: "var(--warning)" }}>No emails have AntiGhosting labels</p>
            <p className="text-[12px] mt-1" style={{ color: "var(--text-secondary)" }}>
              The AntiGhosting flow only picks up threads with the AntiGhosting Gmail label. Apply that label in Gmail to mark threads for re-engagement.
            </p>
          </div>
        </div>
      )}

      {isError ? (
        <Card className="flex flex-col items-center justify-center h-64 text-center p-8">
          <AlertCircle className="h-6 w-6 mb-3" style={{ color: "var(--danger)" }} />
          <p className="font-medium text-[13px]" style={{ color: "var(--text-primary)" }}>Failed to load emails</p>
          <p className="text-[13px]" style={{ color: "var(--text-secondary)" }}>Check API key and server.</p>
        </Card>
      ) : isLoading ? (
        <div className="flex h-64 items-center justify-center">
          <RefreshCw className="h-5 w-5 animate-spin" style={{ color: "var(--text-tertiary)" }} />
        </div>
      ) : filteredEmails.length === 0 ? (
        <Card className="flex flex-col items-center justify-center h-64 text-center p-8" style={{ borderStyle: "dashed" }}>
          <Inbox className="h-6 w-6 mb-3" style={{ color: "var(--text-tertiary)" }} />
          <p className="font-medium text-[13px]" style={{ color: "var(--text-primary)" }}>No emails found</p>
          <p className="text-[13px] mt-1 max-w-sm" style={{ color: "var(--text-secondary)" }}>
            {filter !== "all" ? "Try a different filter." : "Search for emails or sync your Gmail account."}
          </p>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredEmails.map((email) => (
            <EmailCard key={email.id} email={email} apiKey={apiKey || ""} />
          ))}
        </div>
      )}
    </div>
  );
}
'''

# --------------------------------------------------------------------
# Backend: googleapis import extension
# --------------------------------------------------------------------
GAPI_IMPORT_OLD = 'import { gmail_v1 } from "googleapis";'
GAPI_IMPORT_NEW = 'import { google, gmail_v1 } from "googleapis";'

# --------------------------------------------------------------------
# Backend: helpers + 2 handlers before `export default router;`
# --------------------------------------------------------------------
EXPORT_ANCHOR = "export default router;"
HELPERS_MARKER = "B9b.12: GET /api/anti-ghosting/gmail/sent-emails"

HELPERS_AND_HANDLERS = r'''
// ====================================================================
// B9b.12: Email Inspector helpers + handlers
// ====================================================================
// Mirrors the structure of context's /gmail/sent-emails + /sync
// endpoints so the inspector page (cloned from context-inspector.tsx)
// has a near-identical UX. Differences:
//   - SCOPE = prospectsTable.app = "anti_ghosting".
//   - Label resolution uses resolveAntiGhostingLabelIds (already
//     imported above) which does proper Gmail label matching.
//   - wouldBePickedUp drops the 60-day-window gate because
//     ingestAntiGhostingLabeledThreads does not filter by date.

function getLegacyGmail(): gmail_v1.Gmail {
  const auth = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
  );
  auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
  return google.gmail({ version: "v1", auth });
}

async function getGmailForRequest(req: Request): Promise<{ gmail: gmail_v1.Gmail; senderEmail: string }> {
  const userId = req.query.userId ? parseInt(String(req.query.userId), 10) : null;

  if (userId) {
    const users = await db.select().from(usersTable).where(eq(usersTable.id, userId)).limit(1);
    if (users.length > 0 && users[0].googleRefreshToken && users[0].isConnected) {
      return {
        gmail: getGmailForUser({ refreshToken: users[0].googleRefreshToken, email: users[0].email }),
        senderEmail: users[0].email.toLowerCase(),
      };
    }
  }

  return {
    gmail: getLegacyGmail(),
    senderEmail: (process.env.SENDER_EMAIL || "").toLowerCase(),
  };
}

function extractEmailHeader(headerValue: string): string {
  const match = headerValue.match(/<([^>]+)>/) || headerValue.match(/([^\s,]+@[^\s,]+)/);
  return match ? match[1].trim() : headerValue.trim();
}

function extractNameHeader(headerValue: string): string {
  const match = headerValue.match(/^"?([^"<]+)"?\s*</);
  if (match) return match[1].trim();
  const email = extractEmailHeader(headerValue);
  return email.split("@")[0].replace(/[._-]/g, " ");
}

function isWithinSyncWindow(timestamp: number): boolean {
  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  return timestamp >= sixtyDaysAgo.getTime();
}

// ====================================================================
// B9b.12: GET /api/anti-ghosting/gmail/sent-emails
// ====================================================================
router.get("/gmail/sent-emails", async (req: Request, res: Response) => {
  try {
    const { gmail, senderEmail } = await getGmailForRequest(req);
    const maxResults = Math.min(parseInt(String(req.query.limit), 10) || 30, 50);

    // Build labelNameMap from the user's full label list.
    const allLabelsRes = await gmail.users.labels.list({ userId: "me" });
    const allLabels = allLabelsRes.data.labels || [];
    const labelNameMap: Record<string, string> = {};
    for (const label of allLabels) {
      if (label.id && label.name) {
        labelNameMap[label.id] = label.name;
      }
    }

    // Resolve AG label IDs using the existing helper. Falls back to
    // empty if no userId or no antiGhostingLabel configured.
    const userIdForLabels = req.query.userId ? parseInt(String(req.query.userId), 10) : null;
    let antiGhostingLabelStr = "";
    if (userIdForLabels) {
      const u = await db
        .select({ antiGhostingLabel: usersTable.antiGhostingLabel })
        .from(usersTable)
        .where(eq(usersTable.id, userIdForLabels))
        .limit(1);
      if (u.length > 0 && u[0].antiGhostingLabel) antiGhostingLabelStr = u[0].antiGhostingLabel;
    }
    const antiGhostingLabelIds = antiGhostingLabelStr
      ? await resolveAntiGhostingLabelIds(gmail, antiGhostingLabelStr)
      : [];
    const antiGhostingLabels = antiGhostingLabelStr.split(",").map((l) => l.trim()).filter(Boolean);

    let q = "in:sent";
    if (req.query.search) {
      q += ` ${req.query.search}`;
    }

    const listRes = await gmail.users.messages.list({
      userId: "me",
      q,
      maxResults,
    });

    const items = listRes.data.messages || [];
    const emails: any[] = [];

    for (const item of items) {
      if (!item.id) continue;
      try {
        const msgRes = await gmail.users.messages.get({
          userId: "me",
          id: item.id,
          format: "full",
        });

        const msg = msgRes.data;
        if (!msg.id || !msg.threadId) continue;

        const headers = msg.payload?.headers || [];
        const getHeader = (name: string) =>
          headers.find((h) => h.name?.toLowerCase() === name.toLowerCase())?.value || "";

        let body = "";
        const parts = msg.payload?.parts || [];
        if (msg.payload?.mimeType === "text/plain" && msg.payload?.body?.data) {
          body = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
        } else {
          for (const part of parts) {
            if (part.mimeType === "text/plain" && part.body?.data) {
              body = Buffer.from(part.body.data, "base64").toString("utf-8");
              break;
            }
          }
        }
        if (!body) {
          let htmlBody = "";
          if (msg.payload?.mimeType === "text/html" && msg.payload?.body?.data) {
            htmlBody = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
          } else {
            for (const part of parts) {
              if (part.mimeType === "text/html" && part.body?.data) {
                htmlBody = Buffer.from(part.body.data, "base64").toString("utf-8");
                break;
              }
            }
          }
          if (htmlBody) {
            body = htmlBody
              .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, "")
              .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, "")
              .replace(/<br\s*\/?>/gi, "\n")
              .replace(/<\/p>/gi, "\n")
              .replace(/<\/div>/gi, "\n")
              .replace(/<[^>]+>/g, "")
              .replace(/&nbsp;/g, " ")
              .replace(/&amp;/g, "&")
              .replace(/&lt;/g, "<")
              .replace(/&gt;/g, ">")
              .replace(/&quot;/g, '"')
              .replace(/&#39;/g, "'")
              .replace(/\n{3,}/g, "\n\n")
              .trim();
          }
        }

        const labelIds = msg.labelIds || [];
        const labelNames = labelIds.map((id) => labelNameMap[id] || id);
        const hasAntiGhostingLabel = labelIds.some((id) => antiGhostingLabelIds.includes(id));
        const matchedAntiGhostingLabels = labelIds
          .filter((id) => antiGhostingLabelIds.includes(id))
          .map((id) => labelNameMap[id] || id);

        const to = getHeader("To");
        const subject = getHeader("Subject");
        const from = getHeader("From");
        const date = getHeader("Date");
        const recipientEmail = extractEmailHeader(to);
        const recipientName = extractNameHeader(to);
        const timestamp = parseInt(msg.internalDate || "0", 10);

        const isSentByMe = senderEmail ? from.toLowerCase().includes(senderEmail) : false;
        const withinSyncWindow = isWithinSyncWindow(timestamp);

        // AG-specific: no 60-day-window gate because the ingest
        // helper picks up labeled threads regardless of age.
        const wouldBePickedUp = hasAntiGhostingLabel && isSentByMe;

        const reasons: string[] = [];
        if (!isSentByMe) reasons.push("Not sent by configured sender email");
        if (!hasAntiGhostingLabel) reasons.push("Missing AntiGhosting label");

        emails.push({
          id: msg.id,
          threadId: msg.threadId,
          from,
          to,
          recipientEmail,
          recipientName,
          subject,
          snippet: msg.snippet || "",
          bodyPreview: body.slice(0, 800).trim(),
          date,
          timestamp,
          labelIds,
          labelNames,
          hasAntiGhostingLabel,
          matchedAntiGhostingLabels,
          isSentByMe,
          detection: {
            wouldBePickedUp,
            whyNot: wouldBePickedUp ? [] : reasons,
            vertical: "",
            subVertical: "",
            verticalReason: "",
            withinSyncWindow,
            company: recipientEmail ? (recipientEmail.split("@")[1]?.split(".")[0] || "") : "",
          },
        });
      } catch (err) {
        logger.error({ err, messageId: item.id }, "AG email inspector - failed to fetch message");
      }
    }

    // DB cross-reference. Same query shape as context but gated on
    // app='anti_ghosting'.
    const messageIds = emails.map((e) => e.id);
    const threadIds = [...new Set(emails.map((e) => e.threadId).filter(Boolean))];
    const dbByMessageId: Record<string, any> = {};
    const dbByThreadId: Record<string, any> = {};

    const AG_SCOPE = eq(prospectsTable.app, "anti_ghosting");

    if (messageIds.length > 0) {
      const rows = await db
        .select({
          gmailMessageId: prospectsTable.gmailMessageId,
          gmailThreadId: prospectsTable.gmailThreadId,
          id: prospectsTable.id,
          replied: prospectsTable.replied,
        })
        .from(prospectsTable)
        .where(and(AG_SCOPE, inArray(prospectsTable.gmailMessageId, messageIds)));
      for (const row of rows) {
        if (row.gmailMessageId) dbByMessageId[row.gmailMessageId] = row;
      }
    }
    if (threadIds.length > 0) {
      const threadRows = await db
        .select({
          gmailMessageId: prospectsTable.gmailMessageId,
          gmailThreadId: prospectsTable.gmailThreadId,
          id: prospectsTable.id,
          replied: prospectsTable.replied,
        })
        .from(prospectsTable)
        .where(and(AG_SCOPE, inArray(prospectsTable.gmailThreadId, threadIds)));
      for (const row of threadRows) {
        if (row.gmailThreadId && !dbByThreadId[row.gmailThreadId]) {
          dbByThreadId[row.gmailThreadId] = row;
        }
      }
    }

    const enrichedEmails = emails.map((e) => {
      const directMatch = dbByMessageId[e.id];
      const threadMatch = dbByThreadId[e.threadId];
      const dbRecord = directMatch || threadMatch;
      const matchType = directMatch ? "message" : threadMatch ? "thread" : null;
      return {
        ...e,
        inDatabase: !!dbRecord,
        ...(dbRecord ? { dbRecord: { ...dbRecord, matchType } } : {}),
      };
    });

    res.json({
      emails: enrichedEmails,
      meta: {
        total: enrichedEmails.length,
        withAntiGhostingLabel: enrichedEmails.filter((e) => e.hasAntiGhostingLabel).length,
        inDatabase: enrichedEmails.filter((e) => e.inDatabase).length,
        wouldBePickedUp: enrichedEmails.filter((e) => e.detection.wouldBePickedUp).length,
        antiGhostingLabelIds,
        antiGhostingLabels,
      },
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logger.error({ err }, "AG email inspector error");
    res.status(500).json({ error: msg });
  }
});

// ====================================================================
// B9b.12: POST /api/anti-ghosting/sync
// ====================================================================
// Mirrors POST /api/context/sync. Both syncEmailsForUser and
// syncEmails internally call ingestAntiGhostingLabeledThreads so the
// AG-labeled threads get picked up. autoQueueAllCampaigns is
// product-blind and queues F1 for newly-synced prospects across both
// products, which is what we want here too.
router.post("/sync", async (req: Request, res: Response) => {
  try {
    const email = req.body?.email ? String(req.body.email) : undefined;
    let result;
    if (email) {
      const { syncEmailsForUser } = await import("../services/gmailSync");
      result = await syncEmailsForUser(email);
    } else {
      const { syncEmails } = await import("../services/gmailSync");
      result = await syncEmails();
    }
    const { autoQueueAllCampaigns } = await import("../services/scheduler");
    let autoQueued = 0;
    try {
      autoQueued = await autoQueueAllCampaigns();
    } catch (err) {
      logger.warn({ err }, "autoQueueAllCampaigns failed during /anti-ghosting/sync; cron will retry on next tick");
    }
    res.json({ ...result, auto_queued: autoQueued });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});

'''

# --------------------------------------------------------------------
# App.tsx: add import + route
# --------------------------------------------------------------------
APP_IMPORT_ANCHOR = 'import AntiGhostingPipeline from "@/pages/anti-ghosting-pipeline";'
APP_IMPORT_NEW = '''import AntiGhostingPipeline from "@/pages/anti-ghosting-pipeline";
// B9b.12: AntiGhosting Email Inspector page.
import AntiGhostingEmailInspector from "@/pages/anti-ghosting-inspector";'''

APP_ROUTE_ANCHOR = '      <Route path="/anti-ghosting/pipeline" component={AntiGhostingPipeline} />'
APP_ROUTE_NEW = '''      <Route path="/anti-ghosting/pipeline" component={AntiGhostingPipeline} />
      {/* B9b.12: AntiGhosting Email Inspector route. */}
      <Route path="/anti-ghosting/inspector" component={AntiGhostingEmailInspector} />'''

# --------------------------------------------------------------------
# layout.tsx: extend AG navItems
# --------------------------------------------------------------------
LAYOUT_NAV_OLD = '''const navItems = onAntiGhosting
    ? [
        // B9b.8.2: AntiGhosting nav. Icons reuse Workflow for both
        // entries; better-fit icons in a later cosmetic pass.
        { name: "Candidates", href: "/anti-ghosting", icon: Workflow },
        { name: "Pipeline", href: "/anti-ghosting/pipeline", icon: Workflow },
      ]'''

LAYOUT_NAV_NEW = '''const navItems = onAntiGhosting
    ? [
        // B9b.8.2 + B9b.12: AntiGhosting nav. Workflow icon reused for
        // Candidates and Pipeline; Eye icon (matching context inspector)
        // for the Email Inspector.
        { name: "Candidates", href: "/anti-ghosting", icon: Workflow },
        { name: "Pipeline", href: "/anti-ghosting/pipeline", icon: Workflow },
        { name: "Email Inspector", href: "/anti-ghosting/inspector", icon: Eye },
      ]'''


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def info(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker=None):
    check = marker if marker is not None else new
    if check in text:
        skip(f"{label} already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found: {old[:80]!r}")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    info(f"{label}: updated")
    return text.replace(old, new, 1), True


def insert_before_unique(text, anchor, insert, label, marker):
    if marker in text:
        skip(f"{label} already present")
        return text, False
    count = text.count(anchor)
    if count == 0:
        fail(f"{label}: anchor not found: {anchor!r}")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    info(f"{label}: inserted")
    return text.replace(anchor, insert.lstrip("\n") + "\n" + anchor, 1), True


def patch_backend():
    if not BACKEND.exists():
        fail(f"backend not found: {BACKEND}")
    text = BACKEND.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(text, GAPI_IMPORT_OLD, GAPI_IMPORT_NEW, "googleapis import (google)")
    text, _ = insert_before_unique(
        text, EXPORT_ANCHOR, HELPERS_AND_HANDLERS, "B9b.12 helpers + handlers",
        marker=HELPERS_MARKER,
    )

    if text != original:
        BACKEND.write_text(text, encoding="utf-8")
        info(f"wrote {BACKEND.relative_to(WORKSPACE)}")
    else:
        skip("backend already patched")


def patch_inspector_page():
    if not FRONTEND_PAGE.parent.exists():
        fail(f"pages dir does not exist: {FRONTEND_PAGE.parent}")
    if FRONTEND_PAGE.exists() and FRONTEND_PAGE.read_text(encoding="utf-8") == TSX_CONTENT:
        skip(f"{FRONTEND_PAGE.relative_to(WORKSPACE)} already matches")
        return
    action = "overwrote" if FRONTEND_PAGE.exists() else "created"
    FRONTEND_PAGE.write_text(TSX_CONTENT, encoding="utf-8")
    info(f"{action} {FRONTEND_PAGE.relative_to(WORKSPACE)}")


def patch_app():
    if not APP_TSX.exists():
        fail(f"App.tsx not found: {APP_TSX}")
    text = APP_TSX.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, APP_IMPORT_ANCHOR, APP_IMPORT_NEW, "App.tsx import",
        marker="AntiGhostingEmailInspector",
    )
    text, _ = replace_unique(
        text, APP_ROUTE_ANCHOR, APP_ROUTE_NEW, "App.tsx route",
        marker='path="/anti-ghosting/inspector"',
    )

    if text != original:
        APP_TSX.write_text(text, encoding="utf-8")
        info(f"wrote {APP_TSX.relative_to(WORKSPACE)}")
    else:
        skip("App.tsx already patched")


def patch_layout():
    if not LAYOUT_TSX.exists():
        fail(f"layout.tsx not found: {LAYOUT_TSX}")
    text = LAYOUT_TSX.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, LAYOUT_NAV_OLD, LAYOUT_NAV_NEW, "layout AG navItems",
        marker='href: "/anti-ghosting/inspector"',
    )

    if text != original:
        LAYOUT_TSX.write_text(text, encoding="utf-8")
        info(f"wrote {LAYOUT_TSX.relative_to(WORKSPACE)}")
    else:
        skip("layout.tsx already patched")


def main():
    patch_backend()
    patch_inspector_page()
    patch_app()
    patch_layout()
    print()
    print("B9b.12 AntiGhosting Email Inspector applied.")


if __name__ == "__main__":
    main()
