# Batch 7b — Context Based Followuper backend pipeline

## What this batch does

Adds the functional backend for the Context Based Followuper:

- **Generator pipeline** — Sonnet → Opus critic → Sonnet rewriter, all
  adaptive thinking. Same 3-call structure as the Doctrine flow, but
  with context-faithful prompts that explicitly forbid doctrine
  principles, marketing language, sales pitch, and any invention beyond
  what's in the prior email thread.
- **Gmail label sync** — `gmailSync.ts` now scans both `doctrineLabel`
  and `contextLabel` independently and tags each ingested prospect with
  the correct `app` value (`'doctrine'` or `'context'`). If a thread
  somehow appears in both label sets, doctrine wins.
- **Dispatcher routing** — `processDueFollowups` now SELECTs
  `prospects.app` and routes generation per-row: doctrine prospects go
  to the existing `generateFollowupEmail`, context prospects go to the
  new `generateContextFollowup`. All B6 send-window and budget gates
  remain in place for both.
- **Routes** — new `routes/context.ts` mounted at `/api/context/*`.
  Mirrors the essential Doctrine endpoints but scoped to
  `prospects.app = 'context'`.

## Files in this bundle

| File | Purpose |
|---|---|
| `apply-batch7b.mjs` | Idempotent code patch: 3 file installs + 11 str_replace edits + 17 self-verifies. |
| `audit-batch7b.mjs` | Beautiful-Squidward harness: 3 rounds × 9 passes = 171 assertions. |
| `payload/services/contextFollowupPrompts.ts`    | Generator/critic/rewriter system prompts + user-prompt builders. |
| `payload/services/contextFollowupGenerator.ts`  | 3-call orchestration with retry + JSON parse + critic-failure-non-fatal semantics. |
| `payload/routes/context.ts`                     | Focused subset of Doctrine routes scoped to `app='context'`. |

## Routes added at `/api/context/*`

- `GET    /context/stats` — pipeline counts (queued / sent / drafted / replied)
- `GET    /context/prospects` — list of context prospects
- `GET    /context/followups` — Pipeline-page data source
- `POST   /context/process` — manual dispatcher trigger
- `POST   /context/sync` — Gmail sync (optional `{email}` body for per-user sync)
- `POST   /context/followup-now/:prospectId` — Send Now (single)
- `POST   /context/followup/send-bulk` — Bulk Send (capped at 25 per B6)
- `POST   /context/followups/:id/approve` — review-in-app approve
- `POST   /context/followups/:id/reject` — review-in-app reject
- `POST   /context/prospect/:id/pause`
- `POST   /context/prospect/:id/resume`
- `POST   /context/prospect/pause-bulk`
- `POST   /context/cancel`
- `GET    /context/campaign/status` — Activity Log data source

All endpoints enforce `eq(prospectsTable.app, "context")` before
returning or mutating. A doctrine prospect is invisible (404) via any
`/api/context/*` endpoint.

## Models used

Three new constants in `lib/anthropic.ts`, all adaptive thinking:

| Constant | Model | Role |
|---|---|---|
| `MODEL_CONTEXT_GENERATOR` | `claude-sonnet-4-6` | Drafts the follow-up |
| `MODEL_CONTEXT_CRITIC`    | `claude-opus-4-7`   | Catches hallucinations, off-tone, length violations |
| `MODEL_CONTEXT_REWRITER`  | `claude-sonnet-4-6` | Applies critic feedback |

Failure semantics:
- Critic call fails → ship original draft (logs warning).
- Rewriter call fails or produces invalid JSON → ship original draft (logs warning).
- Generator JSON parse fails → retry once, then throw.

## Critic dimensions (1-10 each)

1. **context_faithfulness** — does the draft reference real prior-email content without invention? Inventions auto-cap at ≤4.
2. **tone_match** — formal/casual matches the original sender? Mismatch caps at ≤5.
3. **brevity** — body ≤4 sentences and not padded? 5 sentences caps at ≤6, 6+ at ≤4.
4. **neutral_close** — soft close, no sales language? Sales language auto-caps at ≤4.
5. **language_consistency** — same language as original? Different language auto-caps at ≤2.

`needs_rewrite = true` if `overall < 7` OR any individual score `< 6`.

## What this batch does NOT do

- **No UI.** The Context Based product picker, sidebar switcher, and
  themed clones of Pipeline/Email Inspector/Activity Log/Settings land
  in Batch 7c.
- **No doctrine route filter.** The existing `/api/stats`, `/api/followups`,
  `/api/prospect/*`, etc. continue to query all rows regardless of `app`.
  This is deferred to 7c, which will add `app = 'doctrine'` filtering to
  the doctrine routes as part of the UI isolation work.

## Known operational gap (CLOSES IN 7C)

> Until 7c ships, do **not** communicate the `"Context Followuper"`
> Gmail label name to your non-sales team.

Reason: with 7b live, anyone who labels a Gmail thread with `Context
Followuper` will (a) have a context prospect created, (b) have the
context generator/critic/rewriter produce a follow-up, and (c) have it
fired by the cron. All of this works correctly. **However**, the same
prospect will also appear in the existing Doctrine UI mixed with
doctrine prospects, because doctrine routes don't yet filter by app.
That's confusing for users.

This is dormant unless someone uses the label. Just keep the label name
internal to engineering until 7c lands.

## Manual smoke tests after deploy

```bash
# 1. Confirm the new route family is reachable
curl -H "x-api-key: $ADDON_API_KEY" "$BASE/api/context/stats"
# expect: {"total_sent":0,"unreplied":0,"replied":0,...}  (zeros — no context prospects yet)

# 2. Confirm context endpoint scope isolation: a known doctrine prospect
#    must 404 via /api/context/*
curl -X POST -H "x-api-key: $ADDON_API_KEY" \
  "$BASE/api/context/followup-now/<existing-doctrine-id>"
# expect: 404 with {"error":"Context prospect not found"}

# 3. Confirm models are loaded (start app, scan logs for any module load errors)

# 4. Confirm doctrine flow still works (ad-hoc — push the Send Now button
#    on any doctrine prospect via the existing UI; should behave exactly
#    as before B7b).
```

## Roll-forward note

Forward-only. To revert (only if you must):

```bash
# Remove the new files
rm artifacts/api-server/src/services/contextFollowupPrompts.ts
rm artifacts/api-server/src/services/contextFollowupGenerator.ts
rm artifacts/api-server/src/routes/context.ts

# Then revert the str_replace edits in:
#   - lib/anthropic.ts        (remove the 3 MODEL_CONTEXT_* constants)
#   - services/scheduler.ts   (remove the import, the SELECT field, and the branch)
#   - services/gmailSync.ts   (revert syncForUser type, label scan, insert app field, both call sites)
#   - routes/index.ts         (remove the import + mount line)
```

The B7a schema columns (`prospects.app`, `users.context_label`) are
forward-compatible — leaving them in place after a 7b code revert is
safe; existing rows continue to default to `'doctrine'`.
