#!/usr/bin/env python3
"""
B10.2 - Email Inspector: distinguish sibling-pending-sync from
sibling-not-syncing-no-label.

The current "In database" branch for kind === "thread" unconditionally
says "this message is pending sync" - a B7w-shaped lie. When the message
lacks a Doctrine/Context label, the sync gate rejects it; it will
NEVER auto-sync, but the UI keeps promising it will.

Fix: split kind === "thread" into two sub-branches.

  kind === "thread" && wouldBePickedUp:
    YELLOW "NO - sibling in thread (ID: N); this message is pending sync"
    (Unchanged: legitimate pending state, sync will pick it up.)

  kind === "thread" && !wouldBePickedUp:
    GREY  "NO - sibling in thread (ID: N); not syncing (missing label)"
    (New: explicit about why this never syncs. Grey, not warning -
     this isn't an action item, it's intentionally inert.)

The companion help text below already gates on `wouldBePickedUp`, so the
misleading "Click Sync Now" prompt only appears when sync is actually
imminent. No changes needed there.

Single anchor: the conditional chain in DetectionPipeline around line 371.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INSP = WORKSPACE / "artifacts/dashboard/src/pages/email-inspector.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


OLD = '''                            ) : kind === "thread" ? (
                              <span className="font-mono font-medium" style={{ color: "var(--warning)" }}>
                                NO — sibling in thread (ID: {email.dbRecord?.id}); this message is pending sync
                              </span>
                            ) : email.detection.wouldBePickedUp ? ('''

NEW = '''                            ) : kind === "thread" && email.detection.wouldBePickedUp ? (
                              <span className="font-mono font-medium" style={{ color: "var(--warning)" }}>
                                NO — sibling in thread (ID: {email.dbRecord?.id}); this message is pending sync
                              </span>
                            ) : kind === "thread" ? (
                              // B10.2: sibling exists in thread but this specific message
                              // wouldn't be picked up (missing Doctrine/Context label, or other
                              // detection gate failed). Distinguish from real "pending sync" —
                              // this message will NOT auto-sync. Grey, not warning.
                              <span className="font-mono font-medium" style={{ color: "var(--text-tertiary)" }}>
                                NO — sibling in thread (ID: {email.dbRecord?.id}); not syncing (missing label)
                              </span>
                            ) : email.detection.wouldBePickedUp ? ('''

MARKER = "B10.2: sibling exists in thread but this specific message"


def main():
    if not INSP.exists():
        fail(f"email-inspector.tsx not found: {INSP}")
    text = INSP.read_text(encoding="utf-8")

    if MARKER in text:
        print("[skip] B10.2 already applied")
        return

    count = text.count(OLD)
    if count == 0:
        fail("anchor not found - 'kind === \"thread\"' branch shape doesn't match")
    if count != 1:
        fail(f"anchor matched {count} times; expected exactly 1")

    text = text.replace(OLD, NEW)
    INSP.write_text(text, encoding="utf-8")
    ok("sibling label-less distinction added")
    ok(f"wrote {INSP.relative_to(WORKSPACE)}")
    print()
    print("B10.2 sibling-without-label text fix applied.")


if __name__ == "__main__":
    main()
