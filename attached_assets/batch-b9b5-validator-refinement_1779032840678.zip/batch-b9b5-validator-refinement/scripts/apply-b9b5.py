#!/usr/bin/env python3
r"""
B9b.5 — refine the third AntiGhosting validator from
"most recent outbound not in followups" to "no active follow-up campaign
running on this thread".

The bug:

  The original B9b validator checked whether the seed message's ID was
  present as a `followups.gmailMessageId` row for the user. That was too
  strict — when a Doctrine campaign completes (all F1/F2/F3 status='sent'),
  the message IDs ARE still in the followups table, so AntiGhosting
  refused to ingest. Result: operators couldn't ever AntiGhosting a
  thread that previously had a completed Doctrine flow — exactly the
  canonical re-engagement scenario.

The fix:

  Check for ANY follow-up row tied to a prospect on this thread (any
  app), where the status is NOT terminal. Terminal statuses are
  sent/cancelled/failed — the campaign is done. Non-terminal (queued,
  generating, drafted, pending_approval, stalled_awaiting_manual_send,
  plus any unknown future status) means something's still in flight and
  AntiGhosting would conflict.

Using `not(inArray(...terminal))` rather than `inArray(...active)` so
that new statuses default to BLOCKING. Failing safe is the right
default — incorrectly blocking is recoverable (operator manually waits
or cancels), incorrectly allowing risks double-send.

Three surgical edits in services/antiGhostingValidators.ts:

  1. Widen the drizzle-orm import to include inArray, not.
  2. Replace the Validator-3 query with the new active-followups check.
  3. Update the operator-facing failureReason to reflect the new check.

The ValidatorResults field name (mostRecentOutboundNotInFollowups) is
preserved because:
  - The dashboard chip already reads "Not already in active follow-up",
    which describes the new semantics accurately.
  - Renaming would cascade through the routes (/candidates response),
    dashboard types, and chip mapping. Behaviour change is the goal;
    a field rename is just churn.

Idempotency: generalized NEW-substring-of-OLD check.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    print("\n--- artifacts/api-server/src/services/antiGhostingValidators.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/services/antiGhostingValidators.ts",
        [
            # ─────────────────────────────────────────────────────
            # Edit 1: Widen the drizzle-orm import.
            # ─────────────────────────────────────────────────────
            (
                'import { and, eq } from "drizzle-orm";\n',
                'import { and, eq, inArray, not } from "drizzle-orm";\n',
                "widen drizzle-orm import to include inArray, not",
            ),
            # ─────────────────────────────────────────────────────
            # Edit 2: Replace Validator 3 query block.
            # ─────────────────────────────────────────────────────
            (
                '  // Validator 3: most recent outbound is NOT in the followups table.\n'
                '  // We scope to the current user\'s prospects to avoid cross-user leakage.\n'
                '  const inFollowups = await db\n'
                '    .select({ id: followupsTable.id })\n'
                '    .from(followupsTable)\n'
                '    .innerJoin(prospectsTable, eq(prospectsTable.id, followupsTable.prospectId))\n'
                '    .where(\n'
                '      and(\n'
                '        eq(prospectsTable.userId, userId),\n'
                '        eq(followupsTable.gmailMessageId, mostRecent.id),\n'
                '      ),\n'
                '    )\n'
                '    .limit(1);\n'
                '\n'
                '  results.mostRecentOutboundNotInFollowups = inFollowups.length === 0;\n',
                '  // Validator 3 (B9b.5 refinement): no active follow-up campaign is\n'
                '  // running on this thread. The original B9b check was "most recent\n'
                '  // outbound is not in followups" — too strict, because a completed\n'
                '  // Doctrine campaign (all status=\'sent\') still has its outbound\n'
                '  // message IDs in followups, so AntiGhosting refused to ingest. The\n'
                '  // refined check asks: does any prospect for this thread have a\n'
                '  // follow-up in a non-terminal status? Terminal = sent/cancelled/\n'
                '  // failed (campaign is done). Non-terminal = queued, generating,\n'
                '  // drafted, pending_approval, stalled_awaiting_manual_send, or any\n'
                '  // future status that defaults to "still in flight". Failing safe\n'
                '  // on unknowns avoids accidental double-sends.\n'
                '  //\n'
                '  // The ValidatorResults field name is preserved despite the\n'
                '  // semantics shift — the dashboard chip already reads "Not already\n'
                '  // in active follow-up", which describes the new check accurately.\n'
                '  const activeFollowups = await db\n'
                '    .select({ id: followupsTable.id })\n'
                '    .from(followupsTable)\n'
                '    .innerJoin(prospectsTable, eq(prospectsTable.id, followupsTable.prospectId))\n'
                '    .where(\n'
                '      and(\n'
                '        eq(prospectsTable.userId, userId),\n'
                '        eq(prospectsTable.gmailThreadId, gmailThreadId),\n'
                '        not(inArray(followupsTable.status, ["sent", "cancelled", "failed"])),\n'
                '      ),\n'
                '    )\n'
                '    .limit(1);\n'
                '\n'
                '  results.mostRecentOutboundNotInFollowups = activeFollowups.length === 0;\n',
                "replace Validator 3 query with active-followups check",
            ),
            # ─────────────────────────────────────────────────────
            # Edit 3: Update the operator-facing failureReason.
            # ─────────────────────────────────────────────────────
            (
                '      failureReason: "The most recent message was sent by an automated follow-up campaign. Active campaigns can\'t be marked for AntiGhosting; let the existing campaign run its course first.",\n',
                '      failureReason: "An active follow-up campaign (Doctrine or Context) is still running on this thread. AntiGhosting will be available once that campaign completes, is cancelled, or stops on its own.",\n',
                "update failureReason for Validator 3 to reflect the new check",
            ),
        ],
    )

    expected = 3
    seen = a + b
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {a}")
    print(f"  Already-applied:   {b}")
    print(f"  Warnings:          {w}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if w > 0:
        print("  Warning fired — see WARN line above.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
