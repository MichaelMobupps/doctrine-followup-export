#!/usr/bin/env node
/**
 * apply-batch7f.mjs — Phase 7f (Context Activity Log).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Two concerns:
 *   1. Reshape /api/context/campaign/status to return the rich per-user
 *      campaign aggregation that activity-log.tsx expects (active,
 *      queued_count, sent_count, unreplied_prospects, users[]). The
 *      previous shape returned only { followups: [...] }.
 *   2. Replace dashboard/pages/context-activity.tsx (placeholder from
 *      7d) with a clone of activity-log.tsx retargeted to
 *      /api/context/campaign/status, with `doctrine_label` renamed to
 *      `context_label` in both the type and the render.
 *
 * Email Inspector clone is deferred to 7g — its backend variant
 * (/context/gmail/sent-emails) is bigger and warrants its own batch.
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src DASH_BASE=artifacts/dashboard/src \
 *     node apply-batch7f.mjs
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync } from "fs";
import { join } from "path";

const API_BASE  = process.env.API_BASE  || "artifacts/api-server/src";
const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const log  = (msg) => console.log(`[apply-batch7f] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7f] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const contextRoutePath = join(API_BASE, "routes", "context.ts");
const activityLogPath  = join(DASH_BASE, "pages", "activity-log.tsx");
const ctxActivityPath  = join(DASH_BASE, "pages", "context-activity.tsx");

// ============================================================
// Step 1: Reshape context /campaign/status to rich per-user shape
// ============================================================
log("Step 1: Reshape /api/context/campaign/status...");

// 1a — inline a getFollowupCap helper at the top of context.ts.
//     Sentinel marker keeps the edit idempotent.
strReplace(
  contextRoutePath,
  `// All prospect queries are scoped to app='context' via this constant. If
// a request includes ?userId=N, it's also scoped to that user.
const SCOPE = eq(prospectsTable.app, "context");`,
  `// All prospect queries are scoped to app='context' via this constant. If
// a request includes ?userId=N, it's also scoped to that user.
const SCOPE = eq(prospectsTable.app, "context");

// Phase 7f: shared helper inlined for the /campaign/status aggregation.
// Mirrors the doctrine.ts copy (3 lines, no good place to extract yet).
function getFollowupCap(maxFollowups?: number | null): number | null {
  return typeof maxFollowups === "number" && maxFollowups > 0 ? maxFollowups : null;
}`,
  "context.ts: inline getFollowupCap",
  `// Phase 7f: shared helper inlined for the /campaign/status aggregation.`
);

// 1b — replace the entire /campaign/status handler with the rich aggregation.
strReplace(
  contextRoutePath,
  `router.get("/campaign/status", async (req: Request, res: Response) => {
  try {
    const userIdFilter = req.query.userId ? parseInt(req.query.userId as string) : null;

    const conds = [SCOPE];
    if (userIdFilter) conds.push(eq(prospectsTable.userId, userIdFilter));

    const recentFollowups = await db
      .select({
        followupId: followupsTable.id,
        prospectId: followupsTable.prospectId,
        stage: followupsTable.stage,
        status: followupsTable.status,
        scheduledAt: followupsTable.scheduledAt,
        sentAt: followupsTable.sentAt,
        errorMessage: followupsTable.errorMessage,
        prospectName: prospectsTable.prospectName,
        company: prospectsTable.company,
        email: prospectsTable.email,
      })
      .from(followupsTable)
      .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
      .where(and(...conds))
      .orderBy(desc(followupsTable.scheduledAt))
      .limit(200);

    res.json({ followups: recentFollowups });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});`,
  `// Phase 7f: rich per-user campaign aggregation matching the doctrine
// shape so the Context Activity Log UI clone can consume it without
// any divergence from activity-log.tsx beyond the label-field rename
// (doctrine_label → context_label).
router.get("/campaign/status", async (_req: Request, res: Response) => {
  try {
    const users = await db
      .select({
        id: usersTable.id,
        email: usersTable.email,
        name: usersTable.name,
        isConnected: usersTable.isConnected,
        maxFollowups: usersTable.maxFollowups,
        contextLabel: usersTable.contextLabel,
      })
      .from(usersTable)
      .where(eq(usersTable.isConnected, true));

    const userIds = users.map((u) => u.id);

    const campaignBreakdown = userIds.length > 0
      ? await db
          .select({
            userId: prospectsTable.userId,
            batchLabel: prospectsTable.batchLabel,
            total: sql<number>\`count(*)\`,
            unreplied: sql<number>\`count(*) filter (where \${prospectsTable.replied} = 0)\`,
            paused: sql<number>\`count(*) filter (where \${prospectsTable.replied} = 0 and \${prospectsTable.followupPaused} = true)\`,
          })
          .from(prospectsTable)
          .where(and(SCOPE, inArray(prospectsTable.userId!, userIds)))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel)
      : [];

    const actionableProspects = userIds.length > 0
      ? await db
          .select({
            prospectId: prospectsTable.id,
            userId: prospectsTable.userId,
            batchLabel: prospectsTable.batchLabel,
          })
          .from(prospectsTable)
          .where(
            and(
              SCOPE,
              eq(prospectsTable.replied, 0),
              eq(prospectsTable.followupPaused, false),
              inArray(prospectsTable.userId!, userIds),
            ),
          )
      : [];

    const activeFollowups = actionableProspects.length > 0
      ? await db
          .select({
            prospectId: followupsTable.prospectId,
            stage: followupsTable.stage,
            status: followupsTable.status,
          })
          .from(followupsTable)
          .where(inArray(followupsTable.prospectId, actionableProspects.map((p) => p.prospectId)))
      : [];

    const prospectFollowupState = new Map<number, { maxSentStage: number; hasActive: boolean }>();
    for (const f of activeFollowups) {
      const entry = prospectFollowupState.get(f.prospectId) || { maxSentStage: 0, hasActive: false };
      if (f.status === "sent" && f.stage > entry.maxSentStage) entry.maxSentStage = f.stage;
      if (["queued", "generating", "pending_approval", "drafted"].includes(f.status)) entry.hasActive = true;
      prospectFollowupState.set(f.prospectId, entry);
    }

    const actionableByUser = new Map<number, number>();
    for (const p of actionableProspects) {
      const state = prospectFollowupState.get(p.prospectId);
      if (state?.hasActive) continue;
      const userMaxFollowups = getFollowupCap(users.find((u) => u.id === p.userId)?.maxFollowups);
      const nextStage = (state?.maxSentStage || 0) + 1;
      if (userMaxFollowups !== null && nextStage > userMaxFollowups) continue;
      if (p.userId == null) continue;
      actionableByUser.set(p.userId, (actionableByUser.get(p.userId) || 0) + 1);
    }

    const followupBreakdown = userIds.length > 0
      ? await db
          .select({
            userId: prospectsTable.userId,
            batchLabel: prospectsTable.batchLabel,
            status: followupsTable.status,
            count: sql<number>\`count(*)\`,
          })
          .from(followupsTable)
          .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))
          .where(and(SCOPE, inArray(prospectsTable.userId!, userIds)))
          .groupBy(prospectsTable.userId, prospectsTable.batchLabel, followupsTable.status)
      : [];

    type CampaignStats = {
      total: number;
      unreplied: number;
      paused: number;
      queued: number;
      sent: number;
    };

    const perUserStats = new Map<number, CampaignStats>();
    const addStats = (uid: number | null, src: Partial<CampaignStats>) => {
      if (uid == null) return;
      const cur = perUserStats.get(uid) || { total: 0, unreplied: 0, paused: 0, queued: 0, sent: 0 };
      cur.total += src.total || 0;
      cur.unreplied += src.unreplied || 0;
      cur.paused += src.paused || 0;
      cur.queued += src.queued || 0;
      cur.sent += src.sent || 0;
      perUserStats.set(uid, cur);
    };

    for (const row of campaignBreakdown) {
      addStats(row.userId, {
        total: Number(row.total),
        unreplied: Number(row.unreplied),
        paused: Number(row.paused),
      });
    }

    for (const row of followupBreakdown) {
      if (row.status === "sent") addStats(row.userId, { sent: Number(row.count) });
      if (["queued", "generating"].includes(row.status)) addStats(row.userId, { queued: Number(row.count) });
    }

    const userCampaigns = users.map((u) => {
      const stats = perUserStats.get(u.id) || { total: 0, unreplied: 0, paused: 0, queued: 0, sent: 0 };
      return {
        id: u.id,
        email: u.email,
        name: u.name || u.email.split("@")[0],
        max_followups: u.maxFollowups,
        // Phase 7f: context_label (vs doctrine_label) so the Context UI
        // displays the user's Context Followuper label.
        context_label: u.contextLabel,
        campaigns: [
          {
            label: u.contextLabel,
            ...stats,
            actionable: actionableByUser.get(u.id) || 0,
          },
        ],
      };
    });

    const totalQueued = [...perUserStats.values()].reduce((a, b) => a + b.queued, 0);
    const totalSent = [...perUserStats.values()].reduce((a, b) => a + b.sent, 0);
    const totalUnreplied = [...perUserStats.values()].reduce((a, b) => a + b.unreplied, 0);

    res.json({
      active: totalQueued > 0,
      queued_count: totalQueued,
      sent_count: totalSent,
      unreplied_prospects: totalUnreplied,
      users: userCampaigns,
    });
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    res.status(500).json({ error: msg });
  }
});`,
  "context.ts: reshape /campaign/status",
  `// Phase 7f: rich per-user campaign aggregation matching the doctrine`
);

// ============================================================
// Step 2: Replace context-activity.tsx placeholder with the clone
// ============================================================
log("Step 2: Build context-activity.tsx from activity-log.tsx...");

const placeholderMarker = "Activity Log UI ships in Phase 7f";
const cloneMarker        = "// Phase 7f: ContextActivityLog — clone of activity-log.tsx retargeted to";

const ctxCurrent = readFileOrFail(ctxActivityPath);
if (ctxCurrent.includes(cloneMarker)) {
  log(`  [=] context-activity.tsx (already cloned)`);
} else if (ctxCurrent.includes(placeholderMarker)) {
  if (!existsSync(activityLogPath)) fail(`Source activity-log.tsx not found at ${activityLogPath}`);
  copyFileSync(activityLogPath, ctxActivityPath);
  log(`  [+] Copied activity-log.tsx → context-activity.tsx (will transform next)`);
} else if (ctxCurrent.includes("export default function ActivityLog()")) {
  log(`  [~] context-activity.tsx (partial transform — resuming)`);
} else {
  fail(`context-activity.tsx is in an unexpected state`);
}

// ----- Transform 1: header comment + rename component -----
strReplace(
  ctxActivityPath,
  `import React, { useState, useEffect, useCallback } from "react";`,
  `// Phase 7f: ContextActivityLog — clone of activity-log.tsx retargeted to
// /api/context/campaign/status. The only structural difference vs the
// doctrine Activity Log is the label-field rename (doctrine_label →
// context_label). Everything else — types, helpers, polling cadence,
// rendering — mirrors the doctrine version.
import React, { useState, useEffect, useCallback } from "react";`,
  "ctx-activity: header comment",
  `// Phase 7f: ContextActivityLog — clone of activity-log.tsx retargeted to`
);

// ----- Transform 2: rename component to ContextActivityLog -----
strReplace(
  ctxActivityPath,
  `export default function ActivityLog() {`,
  `export default function ContextActivityLog() {`,
  "ctx-activity: rename component",
  `export default function ContextActivityLog()`
);

// ----- Transform 3: API URL retarget -----
strReplace(
  ctxActivityPath,
  `      const res = await fetch(\`\${base}api/campaign/status\`, {`,
  `      const res = await fetch(\`\${base}api/context/campaign/status\`, {`,
  "ctx-activity: URL /campaign/status → /context/...",
  `\${base}api/context/campaign/status`
);

// ----- Transform 4: type field rename in UserActivity -----
strReplace(
  ctxActivityPath,
  `  max_followups: number;
  doctrine_label: string;
  campaigns: CampaignInfo[];`,
  `  max_followups: number;
  // Phase 7f: context_label (vs doctrine_label) — the user's Context Followuper Gmail label.
  context_label: string;
  campaigns: CampaignInfo[];`,
  "ctx-activity: type field rename",
  `// Phase 7f: context_label (vs doctrine_label) — the user's Context Followuper Gmail label.`
);

// ----- Transform 5: render rename -----
strReplace(
  ctxActivityPath,
  `Max {user.max_followups} follow-ups · Label: <span className="font-mono">{user.doctrine_label}</span>`,
  `Max {user.max_followups} follow-ups · Label: <span className="font-mono">{user.context_label}</span>`,
  "ctx-activity: render uses context_label",
  `Label: <span className="font-mono">{user.context_label}</span>`
);

// ----- Transform 6: title text -----
strReplace(
  ctxActivityPath,
  `          <h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>
            Activity Log
          </h1>`,
  `          <h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>
            Context Activity Log
          </h1>`,
  "ctx-activity: title text",
  `>
            Context Activity Log
          </h1>`
);

// ============================================================
// Step 3: Self-verify
// ============================================================
log("Step 3: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Backend
expectInFile(contextRoutePath, `// Phase 7f: shared helper inlined for the /campaign/status aggregation.`, "V1  getFollowupCap inlined");
expectInFile(contextRoutePath, `function getFollowupCap(maxFollowups?: number | null): number | null {`, "V2  getFollowupCap signature");
expectInFile(contextRoutePath, `// Phase 7f: rich per-user campaign aggregation matching the doctrine`, "V3  /campaign/status reshape comment");
expectInFile(contextRoutePath, `contextLabel: usersTable.contextLabel,`, "V4  /campaign/status projects contextLabel");
expectInFile(contextRoutePath, `context_label: u.contextLabel,`, "V5  /campaign/status response context_label");
expectInFile(contextRoutePath, `actionable: actionableByUser.get(u.id) || 0,`, "V6  /campaign/status returns actionable");
expectInFile(contextRoutePath, `active: totalQueued > 0,`, "V7  /campaign/status returns active");

// Frontend
expectInFile(ctxActivityPath, `// Phase 7f: ContextActivityLog — clone of activity-log.tsx retargeted to`, "V8  context-activity header comment");
expectInFile(ctxActivityPath, `export default function ContextActivityLog()`, "V9  ContextActivityLog component name");
expectInFile(ctxActivityPath, `api/context/campaign/status`, "V10 retargeted URL");
expectInFile(ctxActivityPath, `context_label: string;`, "V11 type uses context_label");
expectInFile(ctxActivityPath, `{user.context_label}`, "V12 render uses context_label");
expectInFile(ctxActivityPath, `Context Activity Log`, "V13 title text");

// Things that MUST be absent in context-activity.tsx (regression)
expectNotInFile(ctxActivityPath, `Activity Log UI ships in Phase 7f`, "V14 placeholder marker gone");
expectNotInFile(ctxActivityPath, `doctrine_label: string;`, "V15 doctrine_label type field gone");
expectNotInFile(ctxActivityPath, `{user.doctrine_label}`, "V16 doctrine_label render gone");
expectNotInFile(ctxActivityPath, `api/campaign/status`, "V17 doctrine /campaign/status URL gone");
expectNotInFile(ctxActivityPath, `function ActivityLog()`, "V18 ActivityLog default-export gone");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7f patch applied. /api/context/campaign/status returns the");
log("same shape as the doctrine endpoint (with context_label). Dashboard");
log("ContextActivityLog is the real Activity Log clone, not a placeholder.");
log("Email Inspector clone is deferred to 7g.");
log("================================================================");
