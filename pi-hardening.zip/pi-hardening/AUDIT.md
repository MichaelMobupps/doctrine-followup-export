# Prompt-injection audit and blast radius — Doctrine Follow-up

## Scope

I red-teamed the defense module and traced every path where external text reaches
a model, then mapped what an attacker gains if injection lands at each one. The
controlling fact for severity is that `followupMode` defaults to `auto_send`
(scheduler.ts:50), so any payload that survives a generator reaches a prospect
inbox from the MobUpps domain with no human in the loop.

## Findings

### F1 (Critical) — Inbound replies feed an auto-sending generator unfenced
Location: antiGhostingFollowupPrompts.ts (generator, critic, rewriter) and
antiGhostingFollowupGenerator.ts.
The anti-ghosting flow reads the prospect's own replies. `getAntiGhostingGeneratorUserPrompt`
interpolates `lastInbound.body`, the seed body, and the entire thread through
`fmtThread(thread_messages)`. Those inbound bodies come from `threadReader.ts:218`
(`extractPlainTextFromPayloadHelper`), so they are raw attacker-written text. The
critic shares the same untrusted slice, so the critic cannot serve as the guard.
This was missed in the first pass, which only covered the doctrine `original_body`.
Fix: fence every inbound body, the last-inbound block, and the seed; prepend the
data clause to the three system prompts; scan the inbound thread at generation
entry and refuse auto-send on a hit; add an egress guard at `finalize`. (Sites 6, 7.)

### F2 (High) — Reply classifier consumes the reply behind a forgeable delimiter
Location: replySentiment.ts:121.
The reply goes in behind a plain `---\nProspect's reply:` line. A crafted reply can
attempt to dictate the verdict (`{"class":"positive"...}`) or the `reason` string,
which is stored. Fix: scan first and fail to `unknown` with no cascade on a hit,
fence the reply and topic, prepend the data clause. (Site 1.)

### F3 (Medium) — Forgeable text fences around `original_body`
Location: followupPrompts.ts:180/274/337, contextFollowupPrompts.ts:160/189/220.
`---BEGIN/END ORIGINAL EMAIL---` is plain text the content can reproduce to escape
the fence. The body is enriched upstream from scraped/Apollo data, so it can carry
attacker substrings even though it is your outbound. Fix: replace with a
nonce fence and prepend the data clause. (Sites 2, 5.)

### F4 (Medium) — No egress check before auto-send
Location: followupGenerator.ts, contextFollowupGenerator.ts, antiGhostingFollowupGenerator.ts.
Nothing inspected generated output before dispatch. A leaked marker, a leaked
system prompt, or an injected link could ship. Fix: `checkOutputIntegrity` at each
generator's single return chokepoint (`humanizeFollowup` / `finalize`); throw on a
hit so the existing failure path marks it failed rather than sending. (Sites 3, 5, 7.)

### F5 (Low) — Summarizer ingests the body unfenced
Location: emailSummarizer.ts:201.
Output is short and sanitized, so impact is limited, but the body still entered a
prompt bare. Fix: fence it and prepend the data clause. (Site 4.)

## Module flaws I found and fixed in promptInjection.ts

- Detector evasion: the scan ran on raw text, so fullwidth or zero-width-split
  payloads slipped past. Added NFKC folding plus combining-mark and zero-width
  removal for the detection pass only. The content delivered to the model still
  uses NFC and stays intact.
- Weak nonce: raised from 32-bit to 64-bit. Secondary control, since the content
  is also marker-stripped, but cheap.
- Egress false positive: a bare "language model" match would have failed a
  legitimate email to an AI-company prospect on the auto-send path. Narrowed the
  rule to self-referential disclosure.
- Missing link defense: added an opt-in `allowedLinkDomains` check so an injected
  outbound URL is caught. Off by default to avoid blocking legitimate links until
  you supply the list.

## Blast radius by surface (post-fix)

| Surface | Attacker input | If injection succeeds (pre-fix) | Containment (post-fix) |
|---|---|---|---|
| Anti-ghosting generator (F1) | Prospect reply / thread | Free-text email auto-sent from MobUpps domain: attacker-chosen content, links, tone; brand and deliverability damage | Fence + clause neutralize instructions; inbound scan refuses auto-send on a hit; egress blocks marker/leak/off-allowlist link |
| Reply classifier (F2) | Prospect reply | Flipped verdict pauses or keeps a live campaign; poisoned `reason` stored | Scan fails to `unknown` (no cascade); fence + clause on the LLM path; deterministic unsubscribe/OOO still run first |
| Doctrine / context generator (F3,F4) | Enriched seed body | Steered follow-up auto-sent | Nonce fence + clause; egress guard at chokepoint |
| Summarizer (F5) | Enriched seed body | Poisoned topic phrase propagates to the generator | Fence + clause; topic also fenced downstream |
| Operator digest | Reply text rendered to operator | Content nuisance in the digest (internal, low) | Out of scope here; flag for a follow-up pass |

## Residual risks (not now)

1. Second-order: `previous_followups[].body` re-enters the critic and rewriter.
   These are prior generated outputs that already passed egress, so risk is low.
   Fence them in a later pass if you want full symmetry.
2. The detector is heuristic. The structural fence and the data clause are the
   load-bearing defense; the scan is the layer that lets fully-untrusted, auto-send
   paths fail toward human review. Treat a scan miss as expected, not as a breach.
3. `weeklyDigest.ts` sends reply-derived content to the operator. Lower priority
   because the recipient is internal. Worth a separate review.
4. The inbound scan on the anti-ghosting path will occasionally flag a legitimate
   reply (for example a developer prospect who literally writes "ignore my last
   message"). That follow-up is marked failed for manual handling. On an auto-send
   path this asymmetry is the safe one.
