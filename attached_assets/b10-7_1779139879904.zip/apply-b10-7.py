#!/usr/bin/env python3
"""
B10.7 - Drop App.tsx page-level staggerChildren.

B9d.8 added staggerChildren: 0.03 to pageVariants for a subtle entrance
cascade. After B10.4 removed the explicit per-card delay in Activity
Log, the inherited 30ms-per-card stagger remained, still producing a
visible cascade (~390ms for 13 user cards). User wants instant.

Single-value change: 0.03 -> 0. Cards now animate together. The 200ms
fade-in per card is preserved (just no per-card delay between them).

Affects every page using <Card>, not just Activity Log. Other pages get
a slightly snappier entrance too. Trade-off is acceptable per user's
"better to work normally than look nice" stance.

Single anchor. Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
APP = WORKSPACE / "artifacts/dashboard/src/App.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


OLD = '''        staggerChildren: 0.03,'''
NEW = '''        staggerChildren: 0, // B10.7: cascade removed - cards animate together.'''


def main():
    if not APP.exists():
        fail(f"App.tsx not found: {APP}")
    text = APP.read_text(encoding="utf-8")

    if "B10.7: cascade removed" in text:
        print("[skip] B10.7 already applied")
        return

    count = text.count(OLD)
    if count == 0:
        fail("anchor not found - 'staggerChildren: 0.03,' missing")
    if count != 1:
        fail(f"anchor matched {count} times; expected 1")

    text = text.replace(OLD, NEW)
    APP.write_text(text, encoding="utf-8")
    ok("staggerChildren 0.03 -> 0")
    ok(f"wrote {APP.relative_to(WORKSPACE)}")
    print()
    print("B10.7 cascade removed.")


if __name__ == "__main__":
    main()
