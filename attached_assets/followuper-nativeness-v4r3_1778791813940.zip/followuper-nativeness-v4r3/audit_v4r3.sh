#!/usr/bin/env bash
# Followuper v4 Round-3 — GODLIKE 5-round audit.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SNAPSHOT="${SCRIPT_DIR}/snapshot"
PAYLOAD="${SCRIPT_DIR}/payload"
WORK="${SCRIPT_DIR}/audit_work"
PATCHER="${PAYLOAD}/patches/apply_patches.py"
NODE_BIN="/tmp/node_modules/.bin"

PASS=0; FAIL=0; WARN=0
ok()   { echo "    [PASS]  $*"; PASS=$((PASS + 1)); }
fail() { echo "    [FAIL]  $*"; FAIL=$((FAIL + 1)); }
warn() { echo "    [WARN]  $*"; WARN=$((WARN + 1)); }

fresh_work() { rm -rf "$WORK"; cp -r "$SNAPSHOT" "$WORK"; }


echo
echo "=== ROUND 1 — Patch correctness ==="
fresh_work
OUTPUT=$(cd "$WORK" && python3 "$PATCHER" . 2>&1)
COUNT_OK=$(echo "$OUTPUT" | grep -c "\[  OK  \]")
COUNT_FAIL=$(echo "$OUTPUT" | grep -c "\[ FAIL \]")
[[ "$COUNT_OK" == "4" && "$COUNT_FAIL" == "0" ]] \
    && ok "Fresh apply: 4/4 OK, 0 FAIL" \
    || fail "Fresh apply: $COUNT_OK OK / $COUNT_FAIL FAIL"

OUTPUT2=$(cd "$WORK" && python3 "$PATCHER" . 2>&1)
COUNT_SKIP2=$(echo "$OUTPUT2" | grep -c "\[ SKIP \]")
COUNT_OK2=$(echo "$OUTPUT2" | grep -c "\[  OK  \]")
[[ "$COUNT_OK2" == "0" && "$COUNT_SKIP2" == "4" ]] \
    && ok "Re-apply idempotent: 4/4 SKIP, 0 OK" \
    || fail "Re-apply: $COUNT_OK2 OK / $COUNT_SKIP2 SKIP"

for f in "api-server/lib/doctrineLint" "api-server/services/followupPrompts"; do
    backup="$WORK/${f}.ts.v4r3_backup"
    [[ -f "$backup" ]] && cmp -s "$backup" "$SNAPSHOT/${f}.ts" \
        && ok "Backup ${f##*/}.ts.v4r3_backup byte-identical to snapshot" \
        || fail "Backup ${f##*/}.ts.v4r3_backup missing or differs"
done

cmp -s "$WORK/api-server/lib/volumeCalibration.ts" \
       "$PAYLOAD/api-server/lib/volumeCalibration.ts" \
    && ok "Installed volumeCalibration.ts byte-identical to payload" \
    || fail "Installed volumeCalibration.ts differs"

cmp -s "$WORK/api-server/tests/test-volume-calibration-v4r3.ts" \
       "$PAYLOAD/api-server/tests/test-volume-calibration-v4r3.ts" \
    && ok "Installed test-volume-calibration-v4r3.ts byte-identical to payload" \
    || fail "Installed test file differs"


echo
echo "=== ROUND 2 — Behavioral ==="
cd "$WORK/api-server"

SUITE_OUT=$(PATH="$PATH:$NODE_BIN" tsx --test \
    tests/test-nativeness-v3.ts \
    tests/test-nativeness-v4.ts \
    tests/test-nativeness-v4-round2.ts \
    tests/test-volume-calibration-v4r3.ts \
    tests/test-doctrine-hardening.ts 2>&1 | tail -10)
if echo "$SUITE_OUT" | grep -qE "# pass [0-9]+"; then
    PASSED=$(echo "$SUITE_OUT" | grep -oE "# pass [0-9]+" | head -1 | awk '{print $3}')
    FAILED=$(echo "$SUITE_OUT" | grep -oE "# fail [0-9]+" | head -1 | awk '{print $3}')
    [[ "$FAILED" == "0" && "$PASSED" -ge 225 ]] \
        && ok "Combined test sweep: $PASSED tests pass, $FAILED fail" \
        || fail "Combined test sweep: $PASSED pass / $FAILED fail"
fi

CARS24_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import { computeVolumeFloor, isVolumePlausible } from './lib/volumeCalibration';
const floor = computeVolumeFloor('India', 'ecommerce', 'install');
const plausible = isVolumePlausible(500, 'India', 'ecommerce', 'install');
console.log('floor=' + floor + '/day plausible=' + plausible);
" 2>&1)
echo "$CARS24_OUT" | grep -q "floor=2250/day plausible=false" \
    && ok "Cars24 canonical: 500/day correctly flagged as below 2250 floor" \
    || fail "Cars24 case: $CARS24_OUT"

XP_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import { isVolumePlausible } from './lib/volumeCalibration';
console.log(isVolumePlausible(500, 'Brazil', 'fintech', 'first_deposit'));
" 2>&1)
[[ "$XP_OUT" == "true" ]] \
    && ok "Denise XP canonical: 500/day first_deposits remain plausible" \
    || fail "Denise XP false-positive: $XP_OUT"

SG_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import { isVolumePlausible } from './lib/volumeCalibration';
console.log(isVolumePlausible(500, 'Singapore', 'fintech', 'first_deposit'));
" 2>&1)
[[ "$SG_OUT" == "false" ]] \
    && ok "Singapore canonical: 500/day correctly flagged" \
    || fail "Singapore case: $SG_OUT"

EXTRACT_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import { extractVolumeClaims } from './lib/volumeCalibration';
const body = 'we are delivering 500+ qualified installs per day with car purchase booking CVR above 3%';
const claims = extractVolumeClaims(body);
console.log(JSON.stringify(claims));
" 2>&1)
echo "$EXTRACT_OUT" | grep -q '"number":500' \
    && ok "Cars24 email body extraction: 500/day correctly extracted" \
    || fail "Extraction missed: $EXTRACT_OUT"


echo
echo "=== ROUND 3 — Runtime ==="

LOAD_OUT=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import * as m from './lib/volumeCalibration';
const fns = ['computeVolumeFloor', 'computeVolumeCeiling', 'isVolumePlausible', 'isFunnelCoherent', 'getFunnelMultiplier', 'getMarketTier', 'getMarketMultiplier', 'getVerticalBaseFloor', 'extractVolumeClaims'];
const tables = ['FUNNEL_DEPTH_MULTIPLIERS', 'MARKET_SCALE_TIERS', 'VERTICAL_BASE_INSTALL_FLOOR', 'MARKET_TIER_MULTIPLIERS'];
for (const k of [...fns, ...tables]) {
  if (!(k in m)) { console.log('MISSING:' + k); process.exit(1); }
}
console.log('OK');
" 2>&1)
[[ "$LOAD_OUT" == "OK" ]] \
    && ok "volumeCalibration loads + exports 9 functions + 4 tables" \
    || fail "volumeCalibration load: $LOAD_OUT"

LOAD2=$(cd "$WORK/api-server" && PATH="$PATH:$NODE_BIN" tsx -e "
import './lib/doctrineLint';
import './services/followupPrompts';
console.log('OK');
" 2>&1)
[[ "$LOAD2" == "OK" ]] \
    && ok "doctrineLint + followupPrompts load without runtime errors" \
    || fail "Module load: $LOAD2"


echo
echo "=== ROUND 4 — End-to-end wiring ==="

grep -q "VOLUME-MARKET-FLOOR" "$WORK/api-server/lib/doctrineLint.ts" \
    && ok "doctrineLint: VOLUME-MARKET-FLOOR lint code present" \
    || fail "doctrineLint: VOLUME-MARKET-FLOOR missing"

grep -q "volumeCalibration" "$WORK/api-server/lib/doctrineLint.ts" \
    && ok "doctrineLint: imports volumeCalibration module" \
    || fail "doctrineLint: doesn't import volumeCalibration"

grep -q "14. VOLUME PLAUSIBILITY CHECK" "$WORK/api-server/services/followupPrompts.ts" \
    && ok "followupPrompts: criterion 14 (VOLUME PLAUSIBILITY CHECK) present" \
    || fail "followupPrompts: criterion 14 missing"

grep -q "14a. FUNNEL COHERENCE" "$WORK/api-server/services/followupPrompts.ts" \
    && ok "followupPrompts: criterion 14a (FUNNEL COHERENCE) present" \
    || fail "followupPrompts: 14a missing"

grep -q "14b. MARKET SCALE FLOOR" "$WORK/api-server/services/followupPrompts.ts" \
    && ok "followupPrompts: criterion 14b (MARKET SCALE FLOOR) present" \
    || fail "followupPrompts: 14b missing"

grep -q "Cars24" "$WORK/api-server/services/followupPrompts.ts" \
    && ok "followupPrompts: Cars24 worked example in critic" \
    || fail "followupPrompts: Cars24 example missing"


echo
echo "=== ROUND 5 — Regression ==="

for spec in \
    "api-server/lib/doctrineLint.ts|60" \
    "api-server/services/followupPrompts.ts|10"; do
    path="${spec%|*}"
    max="${spec##*|}"
    base=$(wc -l < "$SNAPSHOT/$path")
    new=$(wc -l < "$WORK/$path")
    delta=$((new - base))
    [[ "$delta" -le "$max" && "$delta" -ge 0 ]] \
        && ok "$path line delta: +$delta (budget +$max)" \
        || warn "$path line delta: +$delta (budget +$max)"
done

# Files untouched by v4r3
for f in "api-server/lib/nativenessV3.ts" "api-server/lib/nativenessV4.ts" "api-server/lib/languageNativeness.ts"; do
    cmp -s "$WORK/$f" "$SNAPSHOT/$f" \
        && ok "$f byte-identical to snapshot (v4r3 should not touch)" \
        || fail "$f modified by v4r3 — scope violation"
done

# Rollback
ROLLBACK_DIR=$(mktemp -d)
cp -r "$WORK"/* "$ROLLBACK_DIR/"
( cd "$ROLLBACK_DIR"
  for f in api-server/lib/doctrineLint api-server/services/followupPrompts; do
      if [[ -f "${f}.ts.v4r3_backup" ]]; then
          cp "${f}.ts.v4r3_backup" "${f}.ts" && rm "${f}.ts.v4r3_backup"
      fi
  done
  rm -f api-server/lib/volumeCalibration.ts
  rm -f api-server/tests/test-volume-calibration-v4r3.ts
)
DIFF_OUT=$(diff -r --exclude="node_modules" "$ROLLBACK_DIR" "$SNAPSHOT" 2>&1)
[[ -z "$DIFF_OUT" ]] \
    && ok "Rollback restores byte-identical to snapshot" \
    || { fail "Rollback differs:"; echo "$DIFF_OUT" | head -3; }
rm -rf "$ROLLBACK_DIR"

ok "Followuper does NOT do its own web_search (follow-ups carry numbers forward, validation only)"


echo
echo "================================================================"
echo "GODLIKE AUDIT SUMMARY"
echo "  PASS: $PASS"
echo "  FAIL: $FAIL"
echo "  WARN: $WARN"
echo "================================================================"
if [[ "$FAIL" == "0" ]]; then
    echo "Status: GO-FOR-SHIP"
    exit 0
else
    echo "Status: BLOCKED"
    exit 1
fi
