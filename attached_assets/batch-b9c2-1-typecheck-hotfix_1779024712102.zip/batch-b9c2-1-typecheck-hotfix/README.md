# Batch B9c.2.1 — Typecheck Hotfix for B9c.2

**Scope.** Two surgical edits to clear the five tsc errors that blocked B9c.2's typecheck-gated promotion. No new files, no rollback of B9c.2.

## Errors being cleared

```
src/services/antiGhostingFollowupGenerator.ts(88,40):
  TS2345: '"anti_ghosting_generator"' not assignable to GeneratorLabel
src/services/antiGhostingFollowupGenerator.ts(127,40):
  TS2345: '"anti_ghosting_critic"' not assignable to GeneratorLabel
src/services/antiGhostingFollowupGenerator.ts(170,40):
  TS2345: '"anti_ghosting_rewriter"' not assignable to GeneratorLabel
src/services/scheduler.ts(9,10):
  TS2300: Duplicate identifier 'getGmailForUser'.
src/services/scheduler.ts(13,3):
  TS2300: Duplicate identifier 'getGmailForUser'.
```

## Root causes

### 1. GeneratorLabel union not widened

B9c.2 widened `UsageAttribution.app` in `lib/usageContext.ts` but missed `GeneratorLabel` in `lib/usageTracker.ts` — a sibling type used by the **second** parameter of `recordUsageBestEffort`. Both types are about attribution but they serve different purposes:

- `UsageAttribution.app` — which product the row belongs to. Widened to `"doctrine" | "context" | "anti_ghosting"` in B9c.2.
- `GeneratorLabel` — which specific pipeline call within a product (e.g., `"context_generator"`, `"context_critic"`, `"context_rewriter"`). Not widened in B9c.2.

The lesson: when adding a new product, both must be widened together. Adding to this batch's README so the pattern is documented.

### 2. Duplicate `getGmailForUser` import

The live scheduler has a multi-line import block from `./gmailClient` near the top:

```typescript
import {
  getHeaderValueHelper,
  getMessageSentAtHelper,
  getGmailForUser,       // <-- already here
  ...
} from "./gmailClient";
```

My B9c.2 patch added `import { getGmailForUser } from "./gmailClient";` as a fresh standalone line further down, without checking the existing imports. TypeScript flags both occurrences as TS2300.

Fix: delete only my standalone duplicate. The multi-line block stays intact and continues to satisfy every other reference to `getGmailForUser` in the file (including the one my B9c.2 context-build block added).

## The fix

### Edit 1 (`lib/usageTracker.ts`)

Append three new variants to the `GeneratorLabel` union:

```typescript
export type GeneratorLabel =
  | "draft"
  | "critic"
  | "rewriter"
  | "context_generator"
  | "context_critic"
  | "context_rewriter"
  // B9c.2.1
  | "anti_ghosting_generator"
  | "anti_ghosting_critic"
  | "anti_ghosting_rewriter";
```

### Edit 2 (`services/scheduler.ts`)

Delete only the single line:

```typescript
import { getGmailForUser } from "./gmailClient";
```

This line is unique (no other line in scheduler.ts has this exact shape — the existing import is the multi-line block which doesn't contain this single-line form). The deletion is safe even though `getGmailForUser` appears elsewhere in the file.

## Idempotency

The patch script handles deletions via the empty-NEW special case from B9c.2 (a NEW-first check trivially passes against empty strings, so deletions check OLD presence directly instead).

A NEW that is a *subset* of OLD (rather than empty) trips the same trap. I almost shipped this bug in B9c.2.1 itself — first draft used a 1-line NEW that was the first line of the 2-line OLD, and the SKIP fired incorrectly. Caught in the sandbox; the corrected approach uses pure deletion. Worth tightening the patch_file helper across all future batches.

## Recommended fast-follow

`patch_file` should also catch the case where NEW is a non-empty *substring* of OLD. The current logic:

```python
if new == "":
    # deletion case — check OLD
elif new in content:
    # SKIP
elif old in content:
    # FIX
```

Should be:

```python
if new == "" or (new and old and new in old):
    # deletion or NEW-is-subset case — check OLD
elif new in content:
    # SKIP
elif old in content:
    # FIX
```

I'll fold this into the next batch's script and stop relying on author-side discipline to avoid the trap.

## Layout

```
batch-b9c2-1-typecheck-hotfix/
|-- README.md
`-- scripts/
    `-- apply-b9c2-1.py
```

No source-file replacements. Both edits applied directly to live files via the script.

## Risk surface

1. **GeneratorLabel widening is additive.** Adding union variants never breaks existing consumers; the only callers that need to be aware are the new AntiGhosting generator's own `recordUsageBestEffort` calls.
2. **Deletion targets a unique single line.** The multi-line `import { ... } from "./gmailClient"` block at the top has different surrounding whitespace and cannot match.
3. **No runtime semantics change** — type-system only.
4. **No new schema, no new behaviour, no new tests** — this hotfix exists solely to unblock B9c.2's typecheck gate.

## Validation

Sandbox patch run: 2 FIX on first run, 2 SKIP on second run. Final scheduler.ts has the duplicate line removed and the multi-line block intact. Final usageTracker.ts has 9 GeneratorLabel variants (6 original + 3 anti_ghosting).
