# Batch B9b.6 — Relax prospects.gmail_message_id Uniqueness

**Scope.** Schema fix: scope `gmail_message_id` uniqueness from global to `(user_id, gmail_message_id, app)`. This is the constraint that's been silently blocking AntiGhosting ingest the whole time.

## The root cause (finally)

```typescript
gmailMessageId: text("gmail_message_id").notNull().unique(),
```

`.unique()` on this column is **global** — across all users, all products, all rows. So when AntiGhosting tries to create a prospect with the same seed message ID as an existing Doctrine prospect (the canonical re-engagement case: same thread, same outbound, different product), PostgreSQL rejects the insert with `duplicate key value violates unique constraint "prospects_gmail_message_id_unique"`.

This is what was causing:
- Mark button → Drizzle insert error in the UI (visible in screenshot)
- Auto-ingest pass → `synced: 0` with no apparent reason (silent insert failure caught by the route's try/catch)

The validators passing was real (B9b.5 worked). The schema was rejecting the insert that came AFTER validators.

## The fix

Change uniqueness from `(gmail_message_id)` globally to `(user_id, gmail_message_id, app)`. Same outbound message can now anchor:
- One doctrine prospect for user 2 → `(2, msg-A, "doctrine")` ✓
- One anti_ghosting prospect for user 2 → `(2, msg-A, "anti_ghosting")` ✓
- A doctrine prospect for user 3 (different user, same message somehow) → `(3, msg-A, "doctrine")` ✓ (previously blocked, but rare/never)

Still blocks duplicate inserts that ARE bugs: same user inserting the same (message, app) twice.

## Two surgical edits in `lib/db/src/schema/prospects.ts`

1. Remove `.unique()` from the gmailMessageId column declaration.
2. Add `uniqueIndex("uq_prospects_user_message_app").on(userId, gmailMessageId, app)` to the indexes array.

## Risk surface

- **Old UQ is strictly stronger than new UQ.** Anything satisfying the old (globally unique gmail_message_id) automatically satisfies the new. No data cleanup, no migration risk.
- **No application-code change.** Drizzle Inserts use the same column references. The constraint shift is transparent to all callers.
- **Idempotency check** in `ingestAntiGhostingThread` and POST /mark still works — both query by `(userId, gmailThreadId, app)`, which is the prevention layer ABOVE the schema UQ.

## Deploy steps (NOT in the patch script — needs Drizzle introspection)

```bash
python3 scripts/apply-b9b6.py

# Generate migration. Drizzle introspects the live DB to find the exact
# constraint name to drop (varies by Postgres version / Drizzle version).
cd lib/db
pnpm exec drizzle-kit generate --name relax_prospects_uq --config ./drizzle.config.ts
cd ../..

# Inspect the generated SQL before deploying. Should contain:
#   ALTER TABLE prospects DROP CONSTRAINT <something_about_gmail_message_id_unique>
#   CREATE UNIQUE INDEX uq_prospects_user_message_app ON prospects (user_id, gmail_message_id, app)
# Paste the migration file back if anything else appears unexpectedly.

pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server run build
bash source-code/sync.sh
```

Then restart the api-server workflow. The existing migration runner (which applied B9a on startup) will apply this one too.

## Validation after deploy

1. Trigger sync:
   ```bash
   curl -sS -X POST -H "x-api-key: $ADDON_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{"email":"michael@mobupps.com"}' \
     https://doctrine-followupv-2.replit.app/api/context/sync
   ```
2. Response should now show `synced: N` where N ≥ 2 (the Konami and Magnit threads from your candidates list).
3. Anti-ghosting page: those 2 passing candidates should disappear from the candidate list (they're now anti_ghosting prospects).
4. DB verification (or wait for the Pipeline view we'll ship in B9b.7):
   ```sql
   SELECT id, subject, app, cycle, created_at
   FROM prospects
   WHERE app = 'anti_ghosting' AND user_id = 2
   ORDER BY created_at DESC;
   ```
   Expect 2+ rows with cycle=1.

## On Michael's broader ask

You said: "I want the antighost followuper work exactly the same way functionally as the other 2 followupers: they should have their own email inspector, their own pipeline, etc."

That's the right end state. The roadmap from here:

- **B9b.6** ← this batch (schema fix, unblocks ingest)
- **B9b.7** AntiGhosting Pipeline page (parallel to /pipeline and /context/pipeline)
- **B9b.8** AntiGhosting Email Inspector tab (or "View" mode on the existing inspector that switches between Doctrine / Context / AntiGhosting context)
- **B9b.9** Stage timing card in Settings for AntiGhosting (F1/F2/F3 day ranges)
- **B9b.10** Per-product theming so menus differentiate visually

B9b.7 (Pipeline) is the biggest near-term unblock — that gives you a queue view of in-flight anti_ghosting prospects, same shape as Doctrine's pipeline. Ship after this lands.

## Layout

```
batch-b9b6-prospects-uq-relax/
|-- README.md
`-- scripts/
    `-- apply-b9b6.py
```

Sandbox-tested: 2 FIX on first run, 2 SKIP on second. Final schema verified clean.
