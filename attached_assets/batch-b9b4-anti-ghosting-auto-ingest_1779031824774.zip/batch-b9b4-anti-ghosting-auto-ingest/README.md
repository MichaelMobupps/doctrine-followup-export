# Batch B9b.4 — AntiGhosting Auto-Ingest from Labeled Threads

**Scope.** Pivot AntiGhosting from operator-Mark-button-driven to label-driven auto-ingest, matching how Doctrine and Context handle their respective labels. The operator's manual commitment point is applying the AntiGhosting label in Gmail. The next sync cycle auto-creates the prospect, schedules F1, runs the rest of the pipeline.

This is the design correction you asked for: "the user manually picks which mail threads to add the relevant label. that's the manual step."

## What changes for the operator

**Before B9b.4:**
1. Label a thread `AntiGhosting Followuper` in Gmail
2. Wait for sync (the label appears in Gmail, B9b.3 fix)
3. Open `/anti-ghosting` in the dashboard
4. Click Mark on the candidate

**After B9b.4:**
1. Label a thread `AntiGhosting Followuper` in Gmail
2. Wait for sync — prospect auto-created, F1 scheduled

The `/anti-ghosting` page still works the same way (Mark button stays); it just becomes redundant for normal flow. Its remaining value: force-ingest a newly-labeled thread immediately without waiting for the next sync cycle. The page will be reshaped in a later batch (B9b.5 — Pipeline view).

## Three pieces

### 1. NEW `services/antiGhostingIngest.ts` (~370 lines)

Five exports:

| Export | Purpose |
|---|---|
| `resolveAntiGhostingLabelIds(gmail, labelSetting)` | Moved from `routes/anti-ghosting.ts`. Maps the comma-separated label-name setting to Gmail label IDs. |
| `getAlreadyMarkedThreadIds(userId)` | Moved from `routes/anti-ghosting.ts`. Returns the set of thread IDs the user already has anti_ghosting prospects for. |
| `ingestAntiGhostingThread(args)` | NEW. Single-thread ingest: validators → prospect insert → thread sync → F1 schedule. Idempotent. Called by POST /mark and by the sync pass. |
| `ingestAntiGhostingLabeledThreads(args)` | NEW. Sync-pass orchestrator: lists labeled threads, filters already-marked, calls ingestAntiGhostingThread per thread. Returns counts. |
| `IngestResult` | Result type. |

### 2. REWRITTEN `routes/anti-ghosting.ts`

Full-file replacement. POST /mark becomes a thin wrapper around `ingestAntiGhostingThread`; GET /candidates imports the moved helpers; all response shapes preserved verbatim so the dashboard's existing call sites don't change.

Endpoints preserved:
- `POST /api/anti-ghosting/mark` — manual override / force-ingest. Body `{ email, gmailThreadId, seedMessageId? }`. Same response shape as B9b. Now also returns 409 if the thread was already auto-ingested by a previous sync.
- `GET /api/anti-ghosting/candidates?email=...` — unchanged behavior.

### 3. PATCH `services/gmailSync.ts` (2 surgical edits)

- Add `ingestAntiGhostingLabeledThreads` import.
- Wrap the final `logger.info` + `return` in `syncForUser` with the AntiGhosting ingest call. Adds `antiGhostingIngested` to the log line and includes it in the returned `synced` total.

The ingest pass runs after the existing doctrine/context message processing. Errors don't fail the whole sync — they're logged and the function returns.

## Latent bug fixed

`getAlreadyMarkedThreadIds` in B9b queried `threadMessagesTable` via JOIN with `prospectsTable`. Since `syncThreadFromGmail` is best-effort in B9b's POST /mark handler (failures are caught and logged but don't abort the mark), a prospect could exist without any thread_messages rows. The JOIN missed those, so the candidates endpoint kept showing the thread as "needs marking" and a second mark attempt would create a duplicate prospect.

The new direct query on `prospectsTable.gmailThreadId` catches every prospect regardless of thread_messages state. No more duplicates.

## What this batch does NOT do

- **No dashboard UI changes.** The `/anti-ghosting` page still works the same way. UX cleanup deferred per the "UX we can fix but later" call.
- **No removal of POST /mark.** Manual override / force-ingest is still useful for edge cases and admin testing.
- **No new validators or generator changes.** Same B9b validators, same B9c.2 generator. This batch is purely about the ingest entry point.
- **No "failed candidates" tracking table.** Threads that keep failing validators (e.g. most-recent inbound) get re-checked every sync cycle. Cheap (1 Gmail call per thread), acceptable for now. If volume grows, B9d can add a `last_validator_failure_at` column with throttling.

## Risk surface

1. **API surface preserved.** POST /mark and GET /candidates return identical shapes to B9b. Dashboard call sites unchanged.
2. **Idempotency on both sides.** ingestAntiGhostingThread checks for existing prospects before inserting; the sync pass also filters via getAlreadyMarkedThreadIds. Double-protected against duplicates.
3. **Non-fatal failures.** Validator rejection on a thread is logged at debug and the loop continues. An unexpected throw is logged at warn. The whole sync doesn't fail.
4. **Behaviour change at the SQL level.** `getAlreadyMarkedThreadIds` query is different (see "Latent bug fixed" above). The new query is strictly more correct — any thread that was being treated as "not yet marked" because of the JOIN miss will now be treated as marked. Operators may notice a few threads disappearing from `/anti-ghosting` candidates list after deploy; those threads already have prospects, they were just being shown incorrectly.
5. **Sync cost.** Each sync cycle now does one extra Gmail `threads.list` call per user (cheap) plus up to 50 thread reads + validator runs (cheap, short-circuits on first failure). For users not using AntiGhosting (no label setting matches), the pass exits in ~10ms.

## Validation

```bash
python3 scripts/apply-b9b4.py
pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server run build
```

Expect: 2 files copied, 2 edits applied, 0 typecheck errors, build succeeds.

After deploy and one sync cycle (≤5 min, or trigger via the per-user "Sync Gmail now" path):
- The 5 AntiGhosting-labeled threads currently showing as candidates / errors in `/anti-ghosting` get auto-ingested if they pass validators (anti_ghosting prospects appear in DB with `cycle=1`, F1 scheduled).
- Threads that fail validators stay in the candidate list (no change for those).
- Mark button on the page still works (now redundant but harmless).

## Layout

```
batch-b9b4-anti-ghosting-auto-ingest/
|-- README.md
|-- api-server/
|   |-- services/
|   |   `-- antiGhostingIngest.ts          (NEW, ~370 lines)
|   `-- routes/
|       `-- anti-ghosting.ts               (REWRITTEN)
`-- scripts/
    `-- apply-b9b4.py                       (2 file installs + 2 surgical edits)
```

Sandbox-tested: 2 FIX on first run, 2 SKIP on second run; both files install cleanly; brace + paren balance clean on both new files; expected shape verified in the patched gmailSync.
