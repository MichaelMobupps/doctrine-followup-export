import cron from "node-cron";
import { syncEmails } from "./services/gmailSync";
import { processDueFollowups, autoQueueAllCampaigns, stallDraftedFollowups } from "./services/scheduler";
import { logger } from "./lib/logger";

export function startCronJobs(): void {
  // Gmail sync + auto-queue every 15 minutes.
  cron.schedule("*/15 * * * *", async () => {
    logger.info("Running Gmail sync...");
    try {
      const result = await syncEmails();
      logger.info(
        { synced: result.synced, repliesDetected: result.repliesDetected },
        "Sync done",
      );
    } catch (err) {
      logger.error({ err }, "Sync error");
    }

    try {
      const autoQueued = await autoQueueAllCampaigns();
      if (autoQueued > 0) {
        logger.info({ autoQueued }, "Auto-queued follow-up stages");
      }
    } catch (err) {
      logger.error({ err }, "Auto-queue error");
    }
  });

  // Process due follow-ups four times per hour on the main tick.
  cron.schedule("5,20,35,50 * * * *", async () => {
    logger.info("Processing due follow-ups...");
    try {
      const result = await processDueFollowups();
      logger.info(
        { sent: result.sent, drafted: result.drafted, failed: result.failed },
        "Follow-up processing done",
      );
    } catch (err) {
      logger.error({ err }, "Scheduler error");
    }
  });


  // Daily stall watcher: draft-mode follow-ups that sit unsent for 30 days
  // pause the prospect and move the row to stalled_awaiting_manual_send.
  cron.schedule("30 0 * * *", async () => {
    logger.info("Running draft-mode stall watcher...");
    try {
      const stalled = await stallDraftedFollowups();
      if (stalled > 0) {
        logger.info({ stalled }, "Stalled stale Gmail draft follow-ups");
      }
    } catch (err) {
      logger.error({ err }, "Draft stall watcher error");
    }
  });

  // Fast tick every 3 minutes to pick up "Send now" items that were just
  // queued with scheduledAt=now and shouldn't wait 15 min for the main tick.
  // No longer tied to test mode — this runs for all users and is scoped to
  // picking up already-due rows only.
  cron.schedule("*/3 * * * *", async () => {
    try {
      const result = await processDueFollowups();
      if (result.sent > 0 || result.drafted > 0 || result.processed > 0) {
        logger.info(
          { sent: result.sent, drafted: result.drafted, failed: result.failed },
          "Fast-tick processed follow-ups",
        );
      }
    } catch (err) {
      logger.error({ err }, "Fast-tick error");
    }
  });

  logger.info("Cron jobs active: sync+auto-queue @*/15, process @5,20,35,50, draft-stall @00:30, fast-tick @*/3");
}
