#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const repoRoot = process.cwd();
const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const DB_BASE = process.env.DB_BASE || "lib/db/src";

function abs(...parts) { return path.join(repoRoot, ...parts); }
function read(...parts) { return fs.readFileSync(abs(...parts), "utf8"); }
function assert(condition, label) { if (!condition) throw new Error(label); }
function contains(file, text) { assert(read(file).includes(text), `${file} missing ${text}`); }
function regex(file, pattern) { assert(pattern.test(read(file)), `${file} failed ${pattern}`); }

const files = {
  gmailClient: path.join(API_BASE, "services/gmailClient.ts"),
  timingEngine: path.join(API_BASE, "services/timingEngine.ts"),
  scheduler: path.join(API_BASE, "services/scheduler.ts"),
  gmailSync: path.join(API_BASE, "services/gmailSync.ts"),
  cron: path.join(API_BASE, "cron.ts"),
  doctrine: path.join(API_BASE, "routes/doctrine.ts"),
  users: path.join(DB_BASE, "schema/users.ts"),
  followups: path.join(DB_BASE, "schema/followups.ts"),
};

const passes = [
  ["P1 file presence and Batch 3a schema", () => {
    for (const file of Object.values(files)) assert(fs.existsSync(abs(file)), `${file} missing`);
    contains(files.users, "followupMode");
    contains(files.users, "draftStageTiming");
    contains(files.followups, "draftMessageId");
  }],
  ["P2 Gmail draft helpers", () => {
    contains(files.gmailClient, "export async function createFollowupDraft");
    contains(files.gmailClient, "export async function deleteDraft");
    contains(files.gmailClient, "gmail.users.drafts.create");
    contains(files.gmailClient, "gmail.users.drafts.delete");
    contains(files.gmailClient, "X-Doctrine-Followup-Id");
  }],
  ["P3 manual-send detection", () => {
    contains(files.gmailClient, "export async function detectManualFollowupSend");
    contains(files.gmailClient, "draft_sent");
    contains(files.gmailClient, "custom_outbound");
    contains(files.gmailClient, "labels.includes(\"SENT\")");
  }],
  ["P4 draft timing semantics", () => {
    contains(files.timingEngine, "FollowupScheduleMode");
    contains(files.timingEngine, "computeDraftStageScheduledAt");
    contains(files.timingEngine, "mode === \"draft_in_gmail\"");
    regex(files.timingEngine, /generateScheduledTime\(window, lastFollowupSentAt\)/);
  }],
  ["P5 scheduler draft branch", () => {
    contains(files.scheduler, "createFollowupDraft");
    contains(files.scheduler, "status: \"drafted\"");
    contains(files.scheduler, "draftMessageId: draft.draftId");
    contains(files.scheduler, "drafted++");
    regex(files.scheduler, /ACTIVE_FOLLOWUP_STATUSES = \["queued", "generating", "pending_approval", "drafted"\]/);
  }],
  ["P6 next-stage queue and pause-on-user-reply", () => {
    contains(files.gmailSync, "queueNextFollowupStageForProspect");
    contains(files.gmailSync, "detectManualFollowupSend");
    contains(files.gmailSync, "Paused because the user sent a custom outbound message in the thread.");
    contains(files.gmailSync, "cancelActiveFollowupsForProspects");
  }],
  ["P7 stall watcher and resume", () => {
    contains(files.scheduler, "export async function stallDraftedFollowups");
    contains(files.scheduler, "stalled_awaiting_manual_send");
    contains(files.cron, "stallDraftedFollowups");
    contains(files.cron, "30 0 * * *");
    contains(files.doctrine, "requeueStalledDraftForProspect");
  }],
  ["P8 route regression guards", () => {
    contains(files.doctrine, "cancelActiveFollowupsForProspects");
    contains(files.doctrine, "draftStageTiming");
    contains(files.doctrine, "draft_in_gmail");
    regex(files.doctrine, /\["queued", "generating", "pending_approval", "drafted"\]\.includes/);
  }],
  ["P9 syntactic transpile", () => {
    let ts;
    try {
      ts = require("typescript");
    } catch {
      console.log("  TypeScript package not resolvable here; build step remains the source of truth.");
      return;
    }
    for (const file of [files.gmailClient, files.timingEngine, files.scheduler, files.gmailSync, files.cron, files.doctrine]) {
      const full = abs(file);
      const source = fs.readFileSync(full, "utf8");
      const sf = ts.createSourceFile(full, source, ts.ScriptTarget.ES2022, true);
      const out = ts.transpileModule(source, {
        fileName: full,
        reportDiagnostics: true,
        compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
      });
      const errors = (out.diagnostics || []).filter((d) => d.category === ts.DiagnosticCategory.Error);
      if (errors.length > 0) {
        const first = errors[0];
        const pos = typeof first.start === "number" ? ts.getLineAndCharacterOfPosition(sf, first.start) : null;
        throw new Error(`${file} syntax error ${pos ? `${pos.line + 1}:${pos.character + 1}` : ""}: ${ts.flattenDiagnosticMessageText(first.messageText, "\n")}`);
      }
    }
  }],
];

for (let round = 1; round <= 3; round++) {
  let passed = 0;
  for (const [name, fn] of passes) {
    fn();
    passed++;
  }
  console.log(`AUDIT ROUND ${round}: ${passed}/9 PASS`);
}
console.log("BATCH 3B AUDIT: 27/27 PASS");
