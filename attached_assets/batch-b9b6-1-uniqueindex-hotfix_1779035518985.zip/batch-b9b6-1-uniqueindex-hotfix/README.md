# Batch B9b.6.1 — uniqueIndex Anchor Hotfix

**Scope.** Add the composite uniqueIndex that B9b.6's second edit missed. One surgical edit.

## Why

B9b.6's anchor for the second edit was `index("idx_prospects_app").on(table.app),\n]);\n` — assumed `idx_prospects_app` was the last index in the array. B9a actually added two more indexes after it:

- `idx_prospects_app_replied_paused` (covering index for dispatcher)
- `idx_prospects_parent` (parent prospect lookups for renewal analytics)

The right anchor is `idx_prospects_parent` (which IS the last index before `]);`). This hotfix uses that anchor.

## State on disk going in

Partial — B9b.6's first edit applied (column `.unique()` removed), second edit warned. The schema currently has NO uniqueness on `gmail_message_id` at all. Don't run `drizzle-kit generate` in this state — it would only produce a `DROP CONSTRAINT` with no replacement.

## State on disk after this hotfix

Final — composite uniqueIndex on `(user_id, gmail_message_id, app)` is added. Schema is now consistent. Safe to run `drizzle-kit generate`.

## Deploy steps

```bash
python3 scripts/apply-b9b6-1.py

cd lib/db
pnpm exec drizzle-kit generate --name relax_prospects_uq --config ./drizzle.config.ts
cd ../..

# Paste the generated migration SQL before building so I can verify.

pnpm --filter @workspace/api-server run typecheck
pnpm --filter @workspace/api-server run build
bash source-code/sync.sh
```

Then restart the api-server workflow.

## Validation

Sandbox-tested against a fixture matching your actual tail output (with B9a's two extra indexes): 1 FIX on first run, 1 SKIP on second. Final shape verified: `uniqueIndex("uq_prospects_user_message_app").on(userId, gmailMessageId, app)` slotted in between `idx_prospects_parent` and `]);`.

## Layout

```
batch-b9b6-1-uniqueindex-hotfix/
|-- README.md
`-- scripts/
    `-- apply-b9b6-1.py
```
