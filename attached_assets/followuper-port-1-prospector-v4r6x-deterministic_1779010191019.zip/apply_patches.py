#!/usr/bin/env python3
"""
followuper-port-1 — Port prospector v4r6x deterministic fixes to followuper.

Three patches from the prospector that apply directly to followuper:

Patch 1 — iOS/Android Latin-keep restore (analog of prospector v4r6x Patch B):
  followupGenerator.ts gains a `restoreUniversalTechBrands(text)` helper that
  reverts over-transliterated Latin tech brands (Russian Андроид → Android,
  АйОС → iOS) back to Latin. Called from humanizeText.
  Same logic, same per-language map structure as core/brand_localization.py.

Patch 2a — BRAND ADAPTATION directive (analog of prospector v4r6x Patch 4a):
  followupPrompts.ts SYSTEM prompt gains an explicit Latin-keep list for
  universal tech brands (iOS, Android, Google, AppsFlyer, Adjust, etc.) in
  non-Latin target languages. Added after the existing GREETING NAME SCRIPT
  directive.

Patch 2b — Same BRAND ADAPTATION directive in REWRITER prompt:
  followupPrompts.ts REWRITER prompt gets the same directive — applies during
  the critic→rewriter iteration loop too.

Out of scope for Phase 1 (deferred to later phases):
  - Russian greeting brand-prefix strip (v4r6s/v4r6w): requires threading the
    prospect's brand+name through humanizeText, more invasive refactor.
  - Korean Haiku transliteration (v4r6x Patch A): LLM-backed, needs design
    for the followuper's single-contact (not template-substituted) model.
  - Brand localization Latin→native maps (v4r6u/v4r6v): only port if observed
    in followuper production.
  - contextFollowupPrompts.ts: minimal-content follow-ups don't introduce
    brand mentions; skip unless we see issues there.
  - contextFollowupGenerator.ts: has no humanize step at all (separate gap
    to address in its own ship if needed).

Idempotent. Run from any directory. Operates on ./source-code/ (the
followuper monorepo root mirror; in Replit this is artifacts/api-server).
"""
import os
import shutil
import sys
from pathlib import Path

BUNDLE_VERSION = "followuper-p1"
BACKUP_SUFFIX = f".{BUNDLE_VERSION}_backup"

SCRIPT_DIR = Path(__file__).resolve().parent
PAYLOAD_DIR = SCRIPT_DIR / "_payload" / "source-code"

TARGET_ROOTS = [
    # Replit live target: artifacts/api-server (per Michael's monorepo pattern)
    Path.cwd() / "artifacts" / "api-server",
    # source-code mirror
    Path.cwd() / "source-code" / "api-server",
    Path.cwd() / "api-server",
    # local sandbox
    Path("/home/claude/followuper_p1/test_apply/api-server"),
]
TARGET_DIR = None
for candidate in TARGET_ROOTS:
    if candidate.is_dir() and (candidate / "services" / "followupGenerator.ts").is_file():
        TARGET_DIR = candidate
        break
if TARGET_DIR is None:
    print("ERROR: cannot locate api-server/ directory.")
    print("  Tried:", [str(c) for c in TARGET_ROOTS])
    sys.exit(1)


def banner(msg):
    print(f"\n=== {msg} ===")


def backup(path):
    bk = path.with_suffix(path.suffix + BACKUP_SUFFIX)
    if not bk.exists():
        shutil.copy2(path, bk)


def patch_text(path, old, new, label, predecessor_marker=None, idempotency_marker=None):
    text = path.read_text()
    if idempotency_marker and idempotency_marker in text:
        print(f"  SKIP {label} (already up-to-date)")
        return False
    if predecessor_marker and predecessor_marker not in text:
        print(f"  ERROR {label}: predecessor marker not found in {path}")
        print(f"         marker: {predecessor_marker[:80]}")
        sys.exit(1)
    if old not in text:
        print(f"  SKIP {label} (old string not found — likely already patched)")
        return False
    backup(path)
    path.write_text(text.replace(old, new, 1))
    print(f"  OK   {label}")
    return True


def write_file(path, content, label):
    if path.exists():
        backup(path)
    path.write_text(content)
    print(f"  OK   {label}")


# ────────────────────────────────────────────────────────────────────
# Patch 1 — followupGenerator.ts: restoreUniversalTechBrands + humanizeText hook
# ────────────────────────────────────────────────────────────────────
def patch_humanize_text():
    p = TARGET_DIR / "services" / "followupGenerator.ts"

    # 1a — Insert restoreUniversalTechBrands helper before humanizeText
    OLD_FN_HEADER = (
        "function humanizeText(text: string): string {\n"
        "  let result = text;"
    )
    NEW_FN_HEADER = (
        "// followuper-p1: port of prospector v4r6x Patch B (core/brand_localization.py).\n"
        "// Reverts over-transliterations of universal Latin tech brands back to Latin in\n"
        "// non-Latin language emails. iOS, Android, etc. are always Latin in B2B media\n"
        "// across all languages — when the writer over-transliterates them (e.g. Russian\n"
        "// 'Андроид' / 'АйОС'), this restores them.\n"
        "//\n"
        "// Applied UNCONDITIONALLY (no language parameter needed): the source patterns\n"
        "// only appear in non-Latin scripts, so the map is a no-op on Latin-script bodies.\n"
        "// Map structure mirrors core/brand_localization._UNIVERSAL_TECH_RESTORE in the\n"
        "// prospector. Extensible per-language as production observations dictate.\n"
        "const UNIVERSAL_TECH_RESTORE: Record<string, string> = {\n"
        "  // Russian (observed in prospector production 2026-05-16 Magnit draft)\n"
        "  \"Андроид\": \"Android\",\n"
        "  \"АйОС\": \"iOS\",\n"
        "  \"АЙОС\": \"iOS\",\n"
        "  // Korean / Japanese / Chinese / Thai / Arabic: extend on observation.\n"
        "  // Empty for now — writer-prompt directive (BRAND ADAPTATION) keeps these\n"
        "  // Latin probabilistically across all languages.\n"
        "};\n"
        "\n"
        "function restoreUniversalTechBrands(text: string): string {\n"
        "  if (!text) return text;\n"
        "  let result = text;\n"
        "  for (const [nativeForm, latinForm] of Object.entries(UNIVERSAL_TECH_RESTORE)) {\n"
        "    if (result.includes(nativeForm)) {\n"
        "      result = result.split(nativeForm).join(latinForm);\n"
        "    }\n"
        "  }\n"
        "  return result;\n"
        "}\n"
        "\n"
        "function humanizeText(text: string): string {\n"
        "  let result = text;\n"
        "  // followuper-p1: revert universal Latin tech brand over-transliterations FIRST,\n"
        "  // before the existing humanize passes — the rest of humanizeText assumes Latin\n"
        "  // brand names won't be wrapped inside e.g. Cyrillic transliteration.\n"
        "  result = restoreUniversalTechBrands(result);"
    )
    patch_text(
        p,
        old=OLD_FN_HEADER,
        new=NEW_FN_HEADER,
        label="1  followupGenerator.ts += restoreUniversalTechBrands + humanizeText hook",
        predecessor_marker="function humanizeText(text: string): string {",
        idempotency_marker="followuper-p1: port of prospector v4r6x Patch B",
    )


# ────────────────────────────────────────────────────────────────────
# Patch 2 — followupPrompts.ts: BRAND ADAPTATION directive (2 locations)
# ────────────────────────────────────────────────────────────────────

# The directive text (kept identical across both insertion points)
BRAND_ADAPTATION_BLOCK = (
    "- BRAND ADAPTATION (CRITICAL — applies to ALL non-Latin target languages, severity: block, "
    "ported from prospector v4r6x): when writing in a non-Latin target language (Russian, "
    "Ukrainian, Thai, Chinese, Japanese, Korean, Arabic, Hebrew, Greek, Hindi, Bengali, "
    "Urdu, Persian, Amharic, etc.), name local-market brands and competitors in their "
    "native-script form as they appear in local B2B media. For example in Russian: "
    "\"Кинопоиск\" (not \"Kinopoisk\"), \"Окко\" (not \"Okko\"), \"Озон\" (not \"Ozon\"), "
    "\"Тинькофф\" (not \"Tinkoff\"). For Chinese: \"微信\" (not \"WeChat\" in Chinese-language "
    "B2B copy). EXPLICIT LATIN-KEEP LIST: the following universal Latin tech brands MUST stay "
    "in Latin script in EVERY non-Latin target language. NEVER transliterate them — they "
    "appear in Latin in B2B media everywhere: iOS, Android, Google, Apple, Microsoft, Amazon, "
    "AWS, Facebook, Meta, Netflix, AppsFlyer, Adjust, Singular, Branch, Kochava, Firebase, "
    "Mixpanel, Amplitude, Tableau, Salesforce, HubSpot. Brand names of mobile measurement "
    "partners (MMPs), analytics SaaS, and cloud platforms always stay Latin. Apply the same "
    "principle to any globally-Latin SaaS / platform / OS brand. Brands whose canonical "
    "identity is Latin even in local-language media (Wildberries, AliExpress, Lamoda in "
    "Russia; Rakuten in Japan in some contexts) should also be kept in Latin script."
)

def patch_followup_prompts():
    p = TARGET_DIR / "services" / "followupPrompts.ts"

    # The GREETING NAME SCRIPT directive ends with this exact substring (used in both
    # system and rewriter prompts). The line continues into the next directive after a
    # period. We insert BRAND ADAPTATION between the GREETING block end and whatever
    # comes next.
    GREETING_END = (
        "treat it as \"no name\" and use the neutral greeting."
    )

    # 2a — System prompt: GREETING NAME SCRIPT is followed by "- COMPANY:"
    OLD_SYS = GREETING_END + "\n- COMPANY:"
    NEW_SYS = GREETING_END + "\n" + BRAND_ADAPTATION_BLOCK + "\n- COMPANY:"
    patch_text(
        p,
        old=OLD_SYS,
        new=NEW_SYS,
        label="2a followupPrompts.ts SYSTEM prompt += BRAND ADAPTATION directive",
        predecessor_marker=GREETING_END + "\n- COMPANY:",
        idempotency_marker="BRAND ADAPTATION (CRITICAL — applies to ALL non-Latin target languages, severity: block, ported from prospector v4r6x)",
    )

    # 2b — Rewriter prompt: GREETING NAME SCRIPT is followed by "- Keep the email to 4-6 sentences maximum."
    OLD_RW = GREETING_END + "\n- Keep the email to 4-6 sentences maximum."
    NEW_RW = GREETING_END + "\n" + BRAND_ADAPTATION_BLOCK + "\n- Keep the email to 4-6 sentences maximum."
    # Skip if already done (idempotency marker covers this since both insertions add the
    # same marker — guard against double-fire here)
    text = p.read_text()
    # Count current occurrences of the marker to determine if the rewriter slot still needs the insert
    marker_count = text.count("BRAND ADAPTATION (CRITICAL — applies to ALL non-Latin target languages, severity: block, ported from prospector v4r6x)")
    if marker_count >= 2:
        print("  SKIP 2b followupPrompts.ts REWRITER prompt += BRAND ADAPTATION (already up-to-date)")
    elif OLD_RW not in text:
        print("  SKIP 2b followupPrompts.ts REWRITER prompt (anchor not found — already patched or absent)")
    else:
        backup(p)
        new_text = text.replace(OLD_RW, NEW_RW, 1)
        p.write_text(new_text)
        print("  OK   2b followupPrompts.ts REWRITER prompt += BRAND ADAPTATION directive")


# ────────────────────────────────────────────────────────────────────
# Install test file
# ────────────────────────────────────────────────────────────────────
def install_test_file():
    p = TARGET_DIR / "tests" / "test-followuper-port-1.ts"
    src = PAYLOAD_DIR / "api-server" / "tests" / "test-followuper-port-1.ts"
    if not src.is_file():
        print(f"  ERROR: payload missing: {src}")
        sys.exit(1)
    write_file(p, src.read_text(), "T  install api-server/tests/test-followuper-port-1.ts")


def main():
    banner(f"followuper-p1 apply - target: {TARGET_DIR}")
    patch_humanize_text()
    patch_followup_prompts()
    install_test_file()
    banner("followuper-p1 apply complete")


if __name__ == "__main__":
    main()
