#!/usr/bin/env python3
"""
B9d.7 - Page transition animations.

Wraps the wouter Switch with AnimatePresence keyed on location. Every
route change animates: 200ms fade + 8px slide on entrance, fade + -8px
slide on exit. mode="wait" ensures the old page completes exit before
the new one mounts.

Three anchors in App.tsx:
  A1: import updates - add useLocation from wouter + new framer-motion
      import line (motion + AnimatePresence).
  A2: open the motion wrapper around <Switch>. Adds useLocation hook,
      AnimatePresence with mode="wait", motion.div keyed on location.
  A3: close the motion wrapper after </Switch>.

The 20+ <Route> lines between A2 and A3 are left untouched - they
remain at their current indent. JSX doesn't care about indent so this
is functionally clean; if a future dev wants pixel-perfect indent
they can reformat.

No new dependencies (framer-motion already in package.json, used by
the Modal in components/ui.tsx).

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
APP = WORKSPACE / "artifacts/dashboard/src/App.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: imports - add useLocation to wouter + new framer-motion line
# ====================================================================
A1_OLD = '''import { Switch, Route, Router as WouterRouter } from "wouter";'''

A1_NEW = '''import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
// B9d.7: page transition animations via AnimatePresence keyed on location.
import { motion, AnimatePresence } from "framer-motion";'''


# ====================================================================
# A2: open motion wrap around <Switch>
# ====================================================================
A2_OLD = '''function Router() {
  return (
    <Switch>'''

A2_NEW = '''function Router() {
  // B9d.7: AnimatePresence wraps Switch so route changes animate as a fade+slide.
  // mode="wait" ensures the old page exits before the new one mounts.
  const [location] = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.2, ease: "easeOut" }}
      >
        <Switch>'''


# ====================================================================
# A3: close motion wrap after </Switch>
# ====================================================================
A3_OLD = '''      <Route component={NotFound} />
    </Switch>
  );
}'''

A3_NEW = '''      <Route component={NotFound} />
    </Switch>
      </motion.div>
    </AnimatePresence>
  );
}'''


def main():
    if not APP.exists():
        fail(f"App.tsx not found: {APP}")
    text = APP.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: imports (useLocation + framer-motion)",
        marker="B9d.7: page transition animations",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: open motion wrap",
        marker="B9d.7: AnimatePresence wraps Switch",
    )

    text, _ = replace_unique(
        text, A3_OLD, A3_NEW,
        "A3: close motion wrap",
        marker="      </motion.div>\n    </AnimatePresence>\n  );\n}",
    )

    if text != original:
        APP.write_text(text, encoding="utf-8")
        ok(f"wrote {APP.relative_to(WORKSPACE)}")
    else:
        skip("App.tsx already patched")

    print()
    print("B9d.7 page transitions applied.")


if __name__ == "__main__":
    main()
