# Batch 7n — Cron heartbeat

Phase 7n. Adds a `cron_heartbeats` table that records one row per
cron tick, regardless of whether the tick had work to do. Solves the
"is the cron actually firing?" visibility gap surfaced when we caught
the api-server process down without noticing.

## What's in this batch

**New schema** `lib/db/src/schema/cron-heartbeats.ts`:

| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `tick_name` | text NOT NULL | one of: `sync_and_autoqueue`, `process_due`, `draft_stall_watcher`, `fast_tick`, `weekly_digest` |
| `fired_at` | timestamptz NOT NULL DEFAULT now() | |
| `outcome` | text NOT NULL | `ok`, `partial`, or `error` |
| `duration_ms` | integer NOT NULL DEFAULT 0 | wall-clock time spent in the tick |
| `details` | jsonb | per-tick counts and any error messages |

**Schema barrel** `lib/db/src/schema/index.ts`:
- New `export * from "./cron-heartbeats";`

**New helper** `artifacts/api-server/src/lib/cronHeartbeat.ts`:
- `recordHeartbeat({tickName, durationMs, outcome, details?})` — single
  INSERT into `cron_heartbeats`. Wrapped in try/catch so a DB hiccup
  on heartbeat recording can never propagate and kill the actual cron
  work. Heartbeats are observability-only.

**`artifacts/api-server/src/cron.ts`** — each of the 5 cron ticks
wrapped with timing capture and a heartbeat write:

| Tick | Schedule | tickName | Captures |
|---|---|---|---|
| 1 | `*/15 * * * *` | `sync_and_autoqueue` | synced, repliesDetected, autoQueued, syncError, autoQueueError |
| 2 | `5,20,35,50 * * * *` | `process_due` | processed, sent, drafted, failed, error |
| 3 | `30 0 * * *` | `draft_stall_watcher` | stalled, error |
| 4 | `*/3 * * * *` | `fast_tick` | processed, sent, drafted, failed, error |
| 5 | `0 0 * * 2` | `weekly_digest` | considered, sent, skipped, failed, error |

Each wrap follows the same pattern:

```ts
const startedAt = Date.now();
let outcome: "ok" | "partial" | "error" = "ok";
const details: Record<string, unknown> = {};
try {
  // ... existing tick body, with details capture sprinkled in ...
} catch (err) {
  outcome = "error";
  details.wrapperError = err instanceof Error ? err.message : String(err);
} finally {
  await recordHeartbeat({
    tickName: "<tick>",
    durationMs: Date.now() - startedAt,
    outcome,
    details,
  });
}
```

The `outcome` distinction:
- `ok`: tick completed; all sub-steps succeeded.
- `partial`: tick completed but a sub-step (e.g., sync vs auto-queue
  in tick 1) failed. The partial outcome means "some work happened,
  some didn't" — useful for distinguishing OAuth issues from total
  cron failure.
- `error`: the wrapper-level catch fired. Should be rare. The work
  itself failed before any sub-step result was captured.

**Migration SQL** (`migrate-batch7n.sql`):

```sql
CREATE TABLE IF NOT EXISTS cron_heartbeats (...);
CREATE INDEX IF NOT EXISTS idx_cron_heartbeats_tick_fired_at
  ON cron_heartbeats (tick_name, fired_at DESC);
```

Idempotent — `IF NOT EXISTS` on both. Safe to re-run.

## What changes for the user

- **Direct cron-firing visibility**: query `SELECT tick_name, fired_at,
  outcome FROM cron_heartbeats ORDER BY fired_at DESC LIMIT 20;` to
  see the most recent ticks regardless of whether they had work.
- **Per-tick performance trends**: `SELECT tick_name, AVG(duration_ms)
  FROM cron_heartbeats WHERE fired_at > now() - interval '24 hours'
  GROUP BY tick_name;` — flag slow ticks before they become problems.
- **Outcome distribution**: `SELECT tick_name, outcome, COUNT(*) FROM
  cron_heartbeats WHERE fired_at > now() - interval '7 days' GROUP BY
  tick_name, outcome ORDER BY tick_name, outcome;` — see if a
  particular tick is regularly going `partial` or `error`.

## Files

```
batch7n/
├── apply-batch7n.mjs       # Idempotent patch (3 new files + 6 str_replaces)
├── audit-batch7n.mjs       # 9 passes × 3 rounds = 144 checks
├── migrate-batch7n.sql     # CREATE TABLE + index. Run before restart.
└── README.md
```

## Apply

This batch has FOUR steps (one extra: the SQL migration) — the apply
script handles code, but the table must be created in the DB before
api-server restart.

```bash
set -e

cd ~/workspace
unzip -o _inbox/batch7n-cron-heartbeat.zip -d _inbox/batch7n/

# 1. Apply code patch.
API_BASE=artifacts/api-server/src \
  DB_BASE=lib/db/src \
  node _inbox/batch7n/apply-batch7n.mjs

# 2. Audit (3 rounds × 48 = 144).
API_BASE=artifacts/api-server/src \
  DB_BASE=lib/db/src \
  node _inbox/batch7n/audit-batch7n.mjs

# 3. Build api-server (no dashboard change).
pnpm --filter @workspace/api-server run build

# 4. Run the migration. IF NOT EXISTS makes it idempotent.
psql "$DATABASE_URL" -f _inbox/batch7n/migrate-batch7n.sql

# 5. Mirror sync.
./source-code/sync.sh
```

Then **restart the api-server workflow**.

## Verify

After restart:

```bash
# 1. Confirm the table exists and is empty initially
psql "$DATABASE_URL" -c "SELECT COUNT(*) FROM cron_heartbeats;"
# Expect: count = 0 (or 1 if fast_tick fired in the seconds between
# restart and your query — the */3 schedule fires at minute boundaries
# divisible by 3 in wall-clock UTC).

# 2. Trigger a heartbeat by calling the same code path the cron uses.
#    /api/sync (no body) calls syncEmails + autoQueueAllCampaigns.
#    NOTE: this is /api/sync NOT a cron tick, so it does NOT write a
#    heartbeat. Heartbeats are written only by the cron itself.

# 3. Wait for the next cron tick (worst case: 3 min for fast_tick),
#    then query heartbeats.
sleep 200
psql "$DATABASE_URL" -c "
SELECT tick_name, fired_at, outcome, duration_ms, details
FROM cron_heartbeats
ORDER BY fired_at DESC
LIMIT 5;
"
# Expect at least one row — typically fast_tick first since it's */3.
```

Once heartbeats are flowing:

- **Cron alive**: rows appearing every 3+ minutes.
- **Cron stopped**: no rows for >3 minutes is the alert signal.
- **OAuth situation visible**: `details->>'syncError'` will be
  `"invalid_grant"` for the affected user — surfaces the per-user
  failure pattern at the heartbeat level too.

## Known residual

- The `cron_heartbeats` table will accumulate roughly 700 rows/day
  (`*/3` × 480 + `*/15` × 96 + `*/5,20,35,50` × 96 + daily/weekly).
  At this rate it'd be ~250k rows/year. JSONB details push storage
  to maybe 1MB/day. Not a problem for years. If retention becomes
  desired, a separate cleanup cron (e.g., `DELETE FROM cron_heartbeats
  WHERE fired_at < now() - interval '90 days'`) can be added in a
  follow-up — out of scope for B7n.
- Heartbeats are written `await`-ed at the end of each tick. If the
  DB is slow, this adds latency to the tick's wall-clock duration. In
  practice INSERT is sub-10ms; non-issue.
- A heartbeat write that fails (DB down, etc.) is logged and dropped
  — the cron tick's actual work is never blocked by heartbeat
  failures. This means: if the DB is down, you'd see no heartbeats
  AND no actual cron work happening. Both signals point to the same
  underlying issue.
