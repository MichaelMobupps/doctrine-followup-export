#!/usr/bin/env python3
"""
B9d.7 - Page transition animations + prefers-reduced-motion respect.

Wraps the wouter Switch with AnimatePresence keyed on location. Every
route change animates: 200ms fade + 8px slide on entrance, fade + -8px
slide on exit. mode="wait" ensures the old page completes exit before
the new one mounts.

ALSO respects prefers-reduced-motion via framer-motion's
useReducedMotion hook. When the user has motion-reduce preference set
at the OS level, motion.div receives no animation props - effectively
becoming a static wrapper.

Three anchors in App.tsx:
  A1: imports - add useLocation from wouter + motion, AnimatePresence,
      useReducedMotion from framer-motion.
  A2: open the motion wrapper around <Switch>. Adds useLocation +
      useReducedMotion hooks. Animation props are conditional on
      reduceMotion - empty object when user prefers no motion.
  A3: close the motion wrapper after </Switch>.

The 20+ <Route> lines between A2 and A3 are left untouched - they
remain at their current indent. JSX doesn't care about indent.

No new dependencies. Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
APP = WORKSPACE / "artifacts/dashboard/src/App.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: imports - add useLocation + framer-motion (with useReducedMotion)
# ====================================================================
A1_OLD = '''import { Switch, Route, Router as WouterRouter } from "wouter";'''

A1_NEW = '''import { Switch, Route, Router as WouterRouter, useLocation } from "wouter";
// B9d.7: page transition animations via AnimatePresence keyed on location.
// useReducedMotion respects OS-level prefers-reduced-motion setting.
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";'''


# ====================================================================
# A2: open motion wrap around <Switch> with reduced-motion gate
# ====================================================================
A2_OLD = '''function Router() {
  return (
    <Switch>'''

A2_NEW = '''function Router() {
  // B9d.7: AnimatePresence wraps Switch so route changes animate as a fade+slide.
  // mode="wait" ensures the old page exits before the new one mounts.
  // Animation props are gated on prefers-reduced-motion: users with that OS
  // preference get a static wrapper (no entrance/exit animation, no slide).
  const [location] = useLocation();
  const reduceMotion = useReducedMotion();
  const motionProps = reduceMotion ? {} : {
    initial: { opacity: 0, y: 8 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -8 },
    transition: { duration: 0.2, ease: "easeOut" as const },
  };
  return (
    <AnimatePresence mode="wait">
      <motion.div key={location} {...motionProps}>
        <Switch>'''


# ====================================================================
# A3: close motion wrap after </Switch>
# ====================================================================
A3_OLD = '''      <Route component={NotFound} />
    </Switch>
  );
}'''

A3_NEW = '''      <Route component={NotFound} />
    </Switch>
      </motion.div>
    </AnimatePresence>
  );
}'''


def main():
    if not APP.exists():
        fail(f"App.tsx not found: {APP}")
    text = APP.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: imports (useLocation + framer-motion + useReducedMotion)",
        marker="B9d.7: page transition animations",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: open motion wrap with reduced-motion gate",
        marker="B9d.7: AnimatePresence wraps Switch",
    )

    text, _ = replace_unique(
        text, A3_OLD, A3_NEW,
        "A3: close motion wrap",
        marker="      </motion.div>\n    </AnimatePresence>\n  );\n}",
    )

    if text != original:
        APP.write_text(text, encoding="utf-8")
        ok(f"wrote {APP.relative_to(WORKSPACE)}")
    else:
        skip("App.tsx already patched")

    print()
    print("B9d.7 page transitions (with reduced-motion respect) applied.")


if __name__ == "__main__":
    main()
