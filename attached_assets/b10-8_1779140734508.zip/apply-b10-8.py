#!/usr/bin/env python3
"""
B10.8 - Activity Log: strip motion.div wrappers around UserCard /
idle-card. After B10.4 (per-card delay removed) and B10.7 (staggerChildren
0), the remaining cascade comes from:
  (a) Each wrapper's 200ms fade-in (opacity 0->1, y N->0)
  (b) React reconciliation mounting 13 cards across ~13 frames (~200ms)
Together, the cards appear over ~400ms - visible.

Fix: drop the motion.div wrappers. Render <Card> directly with
`initial={false}` so the inherited cardVariants entrance animation
is also skipped. Card uses its CSS state immediately on mount.

The AnimatePresence/motion.div INSIDE UserCard (for expand/collapse,
lines 269-289) is preserved - it's a user-triggered animation, not
an initial-mount one.

Five anchors:
  A1: UserCard wrapper opening - replace with <Card initial={false}>
  A2: UserCard wrapper closing - drop </motion.div>, keep </Card>
  A3: Idle-user wrapper opening - replace with <Card key={...} initial={false} ...>
  A4: Idle-user wrapper closing - drop </motion.div>, keep </Card>
  A5: ui.tsx Card signature - accept `initial` prop (framer-motion passthrough)
      so TypeScript doesn't reject <Card initial={false}>.

Idempotent. Marker on each anchor.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
ACT = WORKSPACE / "artifacts/dashboard/src/pages/activity-log.tsx"
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def patch(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already applied")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor matched {count} times; expected 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: UserCard wrapper opening + <Card> open
# ====================================================================
A1_OLD = '''    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      // B10.4: explicit per-card delay removed. Cards animate together at duration: 0.2.
      // Inherited B9d.8 staggerChildren (30ms) still provides a subtle entrance cascade.
      transition={{ duration: 0.2 }}
    >
      <Card>'''

A1_NEW = '''    <Card initial={false}>'''


# ====================================================================
# A2: UserCard wrapper closing
# ====================================================================
A2_OLD = '''      </Card>
    </motion.div>'''

A2_NEW = '''    </Card>'''


# ====================================================================
# A3: Idle-user wrapper opening + <Card> open
# ====================================================================
A3_OLD = '''            <motion.div
              key={user.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              // B10.4: explicit per-card delay removed.
              transition={{ duration: 0.2 }}
            >
              <Card className="p-4">'''

A3_NEW = '''            <Card key={user.id} initial={false} className="p-4">'''


# ====================================================================
# A4: Idle-user wrapper closing
# ====================================================================
A4_OLD = '''              </Card>
            </motion.div>'''

A4_NEW = '''            </Card>'''


# ====================================================================
# A5: ui.tsx Card signature - allow `initial` prop passthrough.
# ====================================================================
A5_OLD = '''export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => ('''

A5_NEW = '''// B10.8: Card accepts framer-motion `initial` passthrough so callers can
// pass `initial={false}` to skip the cardVariants entrance animation.
export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement> & { initial?: any }) => ('''


def main():
    if not ACT.exists():
        fail(f"activity-log.tsx not found: {ACT}")
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = ACT.read_text(encoding="utf-8")
    original = text

    text, _ = patch(text, A1_OLD, A1_NEW,
                    "A1: UserCard wrapper open -> <Card initial={false}>",
                    marker="<Card initial={false}>")
    text, _ = patch(text, A2_OLD, A2_NEW,
                    "A2: UserCard wrapper close",
                    marker="    </Card>\n  );\n}")
    text, _ = patch(text, A3_OLD, A3_NEW,
                    "A3: Idle wrapper open -> <Card key=...>",
                    marker="<Card key={user.id} initial={false} className=")
    text, _ = patch(text, A4_OLD, A4_NEW,
                    "A4: Idle wrapper close",
                    marker="            </Card>\n          ))}")

    if text != original:
        ACT.write_text(text, encoding="utf-8")
        ok(f"wrote {ACT.relative_to(WORKSPACE)}")
    else:
        skip("activity-log.tsx already patched")

    # A5 on ui.tsx
    ui_text = UI.read_text(encoding="utf-8")
    ui_original = ui_text
    ui_text, _ = patch(ui_text, A5_OLD, A5_NEW,
                       "A5: Card accepts initial prop (ui.tsx)",
                       marker="B10.8: Card accepts framer-motion `initial` passthrough")
    if ui_text != ui_original:
        UI.write_text(ui_text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")

    print()
    print("B10.8 wrapper strip + Card initial passthrough applied.")


if __name__ == "__main__":
    main()
