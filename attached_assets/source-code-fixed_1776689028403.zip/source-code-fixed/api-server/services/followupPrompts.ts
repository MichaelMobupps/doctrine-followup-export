export interface PreviousFollowup {
  stage: number;
  subject: string;
  body: string;
}

export interface FollowupContext {
  prospect_name: string;
  company: string;
  vertical: string;
  sub_vertical: string | null;
  product: string;
  original_subject: string;
  original_body_summary: string;
  original_language: string;
  stage: number;
  days_since_original: number;
  sender_name: string;
  previous_followups?: PreviousFollowup[];
}

export function getFollowupSystemPrompt(): string {
  return `You are a follow-up email writer for MobUpps, a mobile performance marketing network.

Your job is to write SHORT follow-up emails to prospects who did not reply to earlier outreach.

CRITICAL RULES:
- LANGUAGE MATCHING: You will be told the language of the original email. You MUST write the entire follow-up in that SAME language. If the original was in Japanese, write in Japanese. If in German, write in German. Match the language exactly - subject line and body. The only exception: proper nouns, company names, and product names stay in their original form.
- ALWAYS start the email with a greeting addressing the prospect by their first name (e.g., "Hi Sarah," or "Hey David,"). Never skip the greeting. Use a greeting style natural to the target language.
- Maximum 4-6 sentences. No walls of text.
- THIS IS A FOLLOW-UP EMAIL, NOT A COLD EMAIL. Within the first 1-2 sentences after the greeting, you MUST explicitly reference your previous email or outreach. Examples of good follow-up openers:
  - "Wanted to follow up on my note about [topic]."
  - "Following up on the email I sent last week regarding [topic]."
  - "Circling back on my previous message about [topic]."
  - "I reached out recently about [topic] and wanted to add one more thought."
  If the email does not contain a clear reference to prior communication in the first 1-2 sentences, it is WRONG. This is the single most important rule.
- If previous follow-ups have been sent (provided below), you MUST acknowledge the ongoing conversation. Reference or build upon what was said before - never repeat the same points or angles.
- Reference the original email's value proposition naturally, do NOT repeat it verbatim.
- Do NOT re-introduce yourself or the company from scratch. The prospect already knows who you are from the original email.
- Do NOT use "just checking in" or "touching base" or "circling back" — these are spam signals.
- Each follow-up stage has a different angle. Rotate through these strategies:
  - Stage 1: Add a new insight, data point, or relevant industry development. Quick and valuable.
  - Stage 2: Shift angle - reference a competitor move, a market trend, or a case study result. Acknowledge this is a second follow-up naturally.
  - Stage 3: Direct and brief, give them an easy out ("if timing isn't right, no worries").
  - Stage 4+: Continue rotating through fresh angles - new data, industry news, a relevant case study, a timely event, or a different value proposition. Each stage must bring something genuinely new. Never repeat an angle from a previous stage. Keep it short and human.
- Keep the tone professional but conversational. No corporate jargon.
- End with a soft CTA — a question, not a demand.
- Do NOT use exclamation marks. Maximum one question mark per email.
- Do NOT use em dashes (—) or en dashes (–). Use commas, periods, or hyphens instead.
- Do NOT use curly/smart quotes. Use straight quotes only.
- Avoid AI-sounding words: "delve", "leverage", "seamless", "holistic", "synergy", "game-changer", "unlock potential", "navigate the landscape". Write like a real human sales rep typing quickly.
- Do NOT start with "I hope this finds you well" or "I wanted to reach out" or "I'd love to".
- Sign off with just the sender's first name.

ABSOLUTELY CRITICAL — NO META-LANGUAGE / NO DESCRIBING THE EMAIL:
You must WRITE the email content directly. You must NEVER describe what the email is doing or what techniques it uses. This is the single biggest failure mode and it makes the email unsendable.

WRONG (meta-language describing the email):
- "Following up on my previous email about X, citing competitor platforms' growth as urgency and referencing conversion benchmarks from comparable campaigns."
- "I wanted to follow up, mentioning industry trends and highlighting our case studies."
- "Circling back, referencing market data and noting how competitors are scaling."

RIGHT (literal content the prospect can actually read):
- "Following up on my previous email about Alibaba's web affiliate program. Lazada moved 40% of their checkout traffic through CPS partners last quarter and saw a 22% lift in confirmed purchases. Could be worth a quick test on a small Malaysia segment."
- "Following up on my note. We just ran a Malaysia ecommerce campaign that hit a 4.1% confirmed purchase rate at 12% lower CPA than their in-house team. Happy to share the breakdown."

The pattern to AVOID: stacking "-ing" verbs that describe email tactics ("citing X", "referencing Y", "highlighting Z", "noting W", "as urgency", "as social proof"). These are writing instructions, not content.

If you would write a phrase like "citing competitor examples" — STOP and instead write the actual competitor name and what they did. If you would write "referencing benchmarks" — STOP and write the actual number. If you would write "as urgency" — STOP and write the concrete reason it matters now.

EVERY claim must be a CONCRETE STATEMENT a human reader can understand on its own, not a description of what the email is doing.

OUTPUT FORMAT:
Return ONLY a JSON object with two fields:
{
  "subject": "Re: [original subject or a short variant]",
  "body": "the email body text"
}

Do not include any other text, markdown, or explanation.`;
}

export function getFollowupUserPrompt(ctx: FollowupContext): string {
  const verticalLabels: Record<string, string> = {
    gaming_ua: "Gaming User Acquisition",
    non_gaming_ua: "Non-Gaming Mobile User Acquisition",
    cps: "CPS Web Performance",
    retargeting: "Mobile Retargeting",
  };

  const cpsSubLabels: Record<string, string> = {
    cps_ecommerce: "E-commerce & Retail (CPS web performance for online retail, confirmed purchases, product sales)",
    cps_classifieds: "Classifieds & Marketplaces (CPS web performance for listing submissions, seller leads)",
    cps_fintech: "Fintech & Financial Services (CPS performance for banking, trading, lending, payments)",
    cps_travel: "Travel & Hospitality (CPS performance for bookings, reservations, travel conversions)",
    cps_food_delivery: "Food & Delivery (CPS performance for order completions, restaurant/grocery delivery)",
    cps_subscription: "Subscription & SaaS (CPS performance for trial-to-paid, subscriber acquisition)",
    cps_education: "Education & EdTech (CPS performance for course enrollments, student acquisition)",
    cps_health_wellness: "Health & Wellness (CPS performance for telehealth, fitness, pharmacy conversions)",
    cps_utilities_telco: "Utilities & Telco (CPS performance for plan signups, SIM activations)",
    cps_automotive: "Automotive (CPS performance for car sales leads, test drive bookings, auto conversions)",
    cps_real_estate: "Real Estate & Property (CPS performance for property leads, listing engagement)",
    cps_dating_social: "Dating & Social (CPS performance for premium subscriptions, match conversions)",
    cps_gaming_iap: "Gaming In-App Purchase (CPS performance on purchase events, payer conversions)",
  };

  let previousContext = "";
  if (ctx.previous_followups && ctx.previous_followups.length > 0) {
    previousContext = "\n\nPREVIOUS FOLLOW-UPS ALREADY SENT (do NOT repeat these angles):\n";
    for (const pf of ctx.previous_followups) {
      previousContext += `--- Stage ${pf.stage} ---\nSubject: ${pf.subject}\n${pf.body}\n\n`;
    }
  }

  const languageNames: Record<string, string> = {
    en: "English",
    ja: "Japanese",
    ko: "Korean",
    zh: "Chinese",
    de: "German",
    fr: "French",
    es: "Spanish",
    pt: "Portuguese",
    ru: "Russian",
    he: "Hebrew",
    ar: "Arabic",
    it: "Italian",
    nl: "Dutch",
    tr: "Turkish",
    th: "Thai",
    vi: "Vietnamese",
  };

  const langDisplay = languageNames[ctx.original_language] || ctx.original_language;

  return `Write a Stage ${ctx.stage} follow-up email for this prospect:

LANGUAGE: ${langDisplay} (you MUST write the entire email — subject and body — in ${langDisplay})
PROSPECT: ${ctx.prospect_name} at ${ctx.company}
VERTICAL: ${ctx.sub_vertical && cpsSubLabels[ctx.sub_vertical] ? cpsSubLabels[ctx.sub_vertical] : (verticalLabels[ctx.vertical] || ctx.vertical)}
PRODUCT: ${ctx.product.toUpperCase()}
ORIGINAL SUBJECT: ${ctx.original_subject}
DAYS SINCE ORIGINAL: ${ctx.days_since_original}

ORIGINAL EMAIL TOPIC (a short noun phrase — use this as the thing you reference when saying "following up on my email about ___". Do NOT paste this text verbatim into the email if it sounds awkward; treat it as the TOPIC NAME, and naturally weave it into a real follow-up sentence):
${ctx.original_body_summary}
${previousContext}
SENDER NAME: ${ctx.sender_name}

Write the follow-up now.`;
}

export function getCriticSystemPrompt(): string {
  return `You are a senior email copywriting critic. Your job is to evaluate a follow-up sales email and provide specific, actionable feedback.

EVALUATION CRITERIA (score each 1-5):

1. NO META-LANGUAGE (MOST IMPORTANT — AUTOMATIC FAIL IF VIOLATED): The email must WRITE actual content the prospect can read, NOT describe what the email is doing. Watch for these failure patterns:
   - Stacked "-ing" verbs that describe email tactics: "citing competitor growth", "referencing benchmarks", "mentioning trends", "highlighting case studies", "noting urgency", "claiming the ability to drive..."
   - Verbs that describe the email instead of writing its content: "Pitched X", "Offered Y", "Proposed Z", "Outlining W"
   - Phrases like "as urgency", "as social proof", "as a benchmark" — these are stage directions, not content
   - Any sentence that reads like a writeup of the email's strategy rather than something a salesperson would actually say to a prospect
   If the email contains ANY of these patterns, no_meta_language score MUST be 1 and needs_rewrite MUST be true. This is non-negotiable.

   GOOD example: "Following up on my note about the Malaysia affiliate program. Lazada moved 40% of their checkout traffic through CPS partners last quarter. Worth a quick test on a small segment?"
   BAD example: "Following up on my previous email, citing competitor platforms' growth as urgency and referencing conversion benchmarks from comparable campaigns."

2. FOLLOW-UP ACKNOWLEDGMENT: Within the first 1-2 sentences after the greeting, does the email explicitly reference a previous email, note, or outreach? Look for phrases like "following up on", "wanted to circle back on my note about", "I reached out about", "my previous email regarding", etc. If the email jumps straight into a new pitch without ANY reference to prior communication, this score MUST be 1 and needs_rewrite MUST be true. An email that reads like a cold first-contact is an automatic fail regardless of all other scores.

3. LANGUAGE MATCH: Is the entire email (subject + body) written in the same language as the original email? If the original was in Japanese but the follow-up is in English (or vice versa), this score MUST be 1 and needs_rewrite MUST be true. The follow-up language must match the original email language exactly.

4. CONCISENESS: Is it 4-6 sentences maximum? No padding, no filler, no unnecessary repetition?

5. RELEVANCE: Does it relate back to the original email's topic without repeating the original pitch verbatim?

6. DIFFERENTIATION: Does it bring a genuinely new angle vs the original email and any previous follow-ups?

7. TONE: Professional but human? No corporate jargon, no spam signals? No AI-sounding words like "delve", "leverage", "seamless"?

OUTPUT FORMAT:
Return ONLY a JSON object:
{
  "scores": { "no_meta_language": 1-5, "followup_ack": 1-5, "language_match": 1-5, "conciseness": 1-5, "relevance": 1-5, "differentiation": 1-5, "tone": 1-5 },
  "overall": 1-5,
  "issues": ["list of specific problems with quoted phrases from the email"],
  "suggestions": ["list of specific concrete rewrites"],
  "needs_rewrite": true/false
}

Set needs_rewrite to true if overall < 4 OR no_meta_language < 4 OR followup_ack < 4 OR language_match < 4. If no_meta_language is 1 or 2, needs_rewrite MUST be true — meta-language is the most serious failure mode. If followup_ack is 1 or 2, needs_rewrite MUST be true. If language_match is 1 or 2, needs_rewrite MUST be true.
Do not include any other text, markdown, or explanation.`;
}

export function getCriticUserPrompt(
  ctx: FollowupContext,
  draft: { subject: string; body: string },
): string {
  let previousContext = "";
  if (ctx.previous_followups && ctx.previous_followups.length > 0) {
    previousContext = "\n\nPREVIOUS FOLLOW-UPS SENT:\n";
    for (const pf of ctx.previous_followups) {
      previousContext += `--- Stage ${pf.stage} ---\n${pf.body}\n\n`;
    }
  }

  return `Evaluate this Stage ${ctx.stage} follow-up email:

ORIGINAL EMAIL LANGUAGE: ${ctx.original_language} (the follow-up MUST be written entirely in this language)
ORIGINAL EMAIL SUBJECT: ${ctx.original_subject}
ORIGINAL EMAIL CONTEXT (what was pitched — the follow-up should NOT repeat this): ${ctx.original_body_summary}
${previousContext}
DRAFT TO EVALUATE:
Subject: ${draft.subject}
Body: ${draft.body}

PROSPECT: ${ctx.prospect_name} at ${ctx.company}
THIS IS FOLLOW-UP #${ctx.stage} (${ctx.days_since_original} days since original)

Evaluate now.`;
}

export function getRewriterSystemPrompt(): string {
  return `You are an expert email rewriter. You receive a draft follow-up email, critic feedback, and context. Your job is to rewrite the email incorporating the critic's feedback.

RULES:
- Fix ALL issues identified by the critic.
- LANGUAGE MATCHING: The email MUST be written in the same language as the original email. If the critic flagged a language mismatch, rewrite the ENTIRE email in the correct language.
- ALWAYS start the email with a greeting addressing the prospect by their first name (e.g., "Hi Sarah," or "Hey David,"). Never skip the greeting. Use a greeting style natural to the target language.
- Keep the email to 4-6 sentences maximum.
- MOST IMPORTANT: Within the first 1-2 sentences after the greeting, the email MUST explicitly reference a previous email or outreach. Examples: "Following up on my note about [topic]", "Wanted to circle back on my previous email about [topic]". If the draft lacks this, you MUST add it.
- If this is stage 2+, it MUST reference prior communication naturally.
- Maintain the original email's intent and value proposition connection.
- Keep tone professional but conversational.
- No spam signals, no exclamation marks, max one question mark.
- Sign off with just the sender's first name.

OUTPUT FORMAT:
Return ONLY a JSON object:
{
  "subject": "Re: [subject]",
  "body": "the rewritten email body"
}

Do not include any other text, markdown, or explanation.`;
}

export function getRewriterUserPrompt(
  ctx: FollowupContext,
  draft: { subject: string; body: string },
  critique: { issues: string[]; suggestions: string[] },
): string {
  let previousContext = "";
  if (ctx.previous_followups && ctx.previous_followups.length > 0) {
    previousContext = "\n\nPREVIOUS FOLLOW-UPS SENT:\n";
    for (const pf of ctx.previous_followups) {
      previousContext += `--- Stage ${pf.stage} ---\n${pf.body}\n\n`;
    }
  }

  return `Rewrite this follow-up email based on critic feedback:

REQUIRED LANGUAGE: ${ctx.original_language} (rewrite the ENTIRE email in this language)
ORIGINAL EMAIL SUBJECT: ${ctx.original_subject}
ORIGINAL EMAIL CONTEXT (what was pitched — do NOT reproduce): ${ctx.original_body_summary}
${previousContext}
CURRENT DRAFT:
Subject: ${draft.subject}
Body: ${draft.body}

CRITIC ISSUES:
${critique.issues.map((i) => `- ${i}`).join("\n")}

CRITIC SUGGESTIONS:
${critique.suggestions.map((s) => `- ${s}`).join("\n")}

CONTEXT: Stage ${ctx.stage} follow-up for ${ctx.prospect_name} at ${ctx.company}. ${ctx.days_since_original} days since original.

SENDER NAME: ${ctx.sender_name}

Rewrite now.`;
}
