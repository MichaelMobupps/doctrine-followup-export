import React from "react";
import { Activity, Construction } from "lucide-react";

/**
 * Phase 7d: placeholder. Full Context Activity Log ships in 7f.
 */
export default function ContextActivityLog() {
  return (
    <div className="flex flex-col items-start py-2">
      <div className="mb-1 flex items-center gap-2">
        <Activity className="w-5 h-5" style={{ color: "var(--accent)" }} strokeWidth={1.75} />
        <h1 className="text-xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>
          Context Activity Log
        </h1>
      </div>
      <p className="text-[13px] mb-8" style={{ color: "var(--text-secondary)" }}>
        Sync runs, sends, errors, and per-prospect events for the context flow.
      </p>

      <div
        className="w-full max-w-2xl rounded-lg p-8"
        style={{
          background: "var(--bg-secondary)",
          border: "1px solid var(--border-default)",
        }}
      >
        <div
          className="w-10 h-10 rounded-md flex items-center justify-center mb-4"
          style={{ background: "var(--accent-muted)", color: "var(--accent)" }}
        >
          <Construction className="w-5 h-5" strokeWidth={1.75} />
        </div>
        <h2 className="text-[15px] font-semibold mb-2" style={{ color: "var(--text-primary)" }}>
          Activity Log UI ships in Phase 7f
        </h2>
        <p className="text-[13px] leading-relaxed" style={{ color: "var(--text-secondary)" }}>
          A clone of the Doctrine Activity Log retargeted to context endpoints.
        </p>
      </div>
    </div>
  );
}
