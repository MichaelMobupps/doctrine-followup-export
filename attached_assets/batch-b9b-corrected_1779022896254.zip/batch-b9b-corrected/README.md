# Batch B9b-corrected — Marking route schema-alignment fix

**Scope.** Corrects four mistakes in `routes/anti-ghosting.ts` shipped by B9b. Only that one file changes; the other four B9b files (`services/antiGhostingScheduling.ts`, `services/antiGhostingValidators.ts`, `routes/index.ts`, `tests/test-anti-ghosting-b9b.ts`) are already in place from the prior deploy and stay as-is.

## Mistakes corrected

1. `name: ...` → `prospectName: ...` (schema column is `prospectName`, not `name`)
2. `originalSubject: ...` → `subject: ...` (schema column is `subject`, not `originalSubject`)
3. `gmailThreadId` added to the prospect insert (column is `NOT NULL` with no default — was missing entirely)
4. `syncThreadFromGmail(prospectId, gmail, gmailThreadId, userEmail)` → `syncThreadFromGmail(prospectId, gmail, userEmail)` (the helper reads `gmailThreadId` from the prospect row, takes 3 args, not 4)

## Root cause

I wrote the `db.insert(prospectsTable).values({...})` block from memory instead of re-reading the live schema. The live schema (post-B9a) uses `prospectName` and `subject`, with `gmailThreadId` as a required column — none of which matched my mental model. The `syncThreadFromGmail` arg count was a parallel oversight: I copied the call shape from how I would have designed the helper, not how I actually wrote it in B9a.

## Verification

Standalone tsc sandbox now uses real Drizzle schema definitions (not `any` stubs) and the corrected `routes/anti-ghosting.ts` typechecks clean. Scheduling tests 6/6 pass; parseGmailThread + validator-structural tests will pass against the real B9a-shipped gmailClient helpers in the live workspace (sandbox stubs return defaults, masking those tests — expected).

## Layout

```
batch-b9b-corrected/
|-- README.md
`-- api-server/
    `-- routes/
        `-- anti-ghosting.ts   (replace — single-file fix)
```

No other files change. No schema migrations. Mirror sync IS needed since `routes/anti-ghosting.ts` (a src file) changes. Workflow restart IS needed to pick up the new compiled route handler.
