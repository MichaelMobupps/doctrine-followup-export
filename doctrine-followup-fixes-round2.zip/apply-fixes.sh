#!/usr/bin/env bash
#
# apply-fixes.sh — Doctrine Follow-up: pipeline + critic-cost fixes.
#
# Applies five fixes (plus audit hardening) as two git patches, idempotently.
# See README.md for the full description. Summary:
#   1. Opus banned as a critic everywhere (critic stages -> Sonnet + guard).
#   2. Pipeline sorts ACTIVE campaigns to the top.
#   3. Pipeline COMPANY filter.
#   4. Admin "kill all campaigns at a company" (POST /api/admin/company/kill).
#   5. Settings stage editor capped at 3 (the real HARD_FOLLOWUP_CAP).
#   + max_followups clamp across all three pipelines (stale "/4" / all_done fix).
#
# IMPORTANT: the patches carry full artifacts/.../src/... paths and are applied
# from the workspace ROOT, so they resolve correctly whether or not the
# workspace is a git repo. (Applying git patches from a subdirectory inside a
# repo silently no-ops, which is why an earlier subdir-based approach reported a
# false "already applied".)
#
# Idempotent (re-running skips already-applied patches), and all-or-nothing: a
# preflight classifies every patch and aborts before writing anything if any
# patch does not match the workspace.
#
# Usage:
#   bash apply-fixes.sh [WORKSPACE_DIR] [--no-gates] [--dry-run]
#
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH_DIR="$SCRIPT_DIR/patches"

WORKSPACE="/home/runner/workspace"
RUN_GATES=1
DRY_RUN=0
for arg in "$@"; do
  case "$arg" in
    --no-gates) RUN_GATES=0 ;;
    --dry-run)  DRY_RUN=1 ;;
    -*) echo "Unknown flag: $arg" >&2; exit 2 ;;
    *)  WORKSPACE="$arg" ;;
  esac
done

command -v git >/dev/null 2>&1 || { echo "ERROR: git not found on PATH." >&2; exit 1; }
[ -d "$WORKSPACE/artifacts/api-server/src" ] || { echo "ERROR: not found: $WORKSPACE/artifacts/api-server/src" >&2; echo "Pass your workspace dir as the first argument." >&2; exit 1; }
[ -d "$WORKSPACE/artifacts/dashboard/src" ]  || { echo "ERROR: not found: $WORKSPACE/artifacts/dashboard/src"  >&2; exit 1; }
[ -f "$PATCH_DIR/api-server.patch" ] || { echo "ERROR: missing $PATCH_DIR/api-server.patch (re-extract the bundle)." >&2; exit 1; }
[ -f "$PATCH_DIR/dashboard.patch" ]  || { echo "ERROR: missing $PATCH_DIR/dashboard.patch (re-extract the bundle)." >&2; exit 1; }

# Patches were produced from git-diffed staging trees, so the real path begins
# two components in (git's b/ prefix + the staging dir name). Applied from the
# workspace root these strip to artifacts/.../src/...
STRIP=2

cd "$WORKSPACE"

# Classify a patch against the current tree: APPLIED / APPLICABLE / DRIFT.
classify () {
  local patch="$1"
  if git apply -p$STRIP --reverse --check "$patch" 2>/dev/null; then echo APPLIED; return; fi
  if git apply -p$STRIP --check "$patch" 2>/dev/null; then echo APPLICABLE; return; fi
  echo DRIFT
}

echo "Workspace: $WORKSPACE"
echo "Preflight…"
S_API="$(classify "$PATCH_DIR/api-server.patch")"
S_DASH="$(classify "$PATCH_DIR/dashboard.patch")"
echo "  [api-server] $S_API"
echo "  [dashboard]  $S_DASH"

if [ "$S_API" = DRIFT ] || [ "$S_DASH" = DRIFT ]; then
  echo "CONTEXT DRIFT: a patch does not match the workspace. Nothing was written." >&2
  echo "The workspace has diverged from the snapshot these patches were built against." >&2
  exit 3
fi

if [ "$DRY_RUN" -eq 1 ]; then
  echo "Dry-run: both patches are $([ "$S_API" = APPLIED ] && echo "already applied" || echo "applicable cleanly") / would apply cleanly. No files changed."
  exit 0
fi

[ "$S_API"  = APPLICABLE ] && { git apply -p$STRIP "$PATCH_DIR/api-server.patch"; echo "  [api-server] applied ✓"; } || echo "  [api-server] already applied — skipping"
[ "$S_DASH" = APPLICABLE ] && { git apply -p$STRIP "$PATCH_DIR/dashboard.patch"; echo "  [dashboard]  applied ✓"; } || echo "  [dashboard]  already applied — skipping"

# Fast built-in post-checks (no toolchain needed).
echo "Post-checks…"
fail=0
ANT="$WORKSPACE/artifacts/api-server/src/lib/anthropic.ts"
for c in MODEL_CRITIC MODEL_CONTEXT_CRITIC MODEL_ANTI_GHOSTING_CRITIC; do
  if grep -E "export const ${c}:" "$ANT" | grep -qi opus; then
    echo "  ✗ $c still resolves to an Opus model" >&2; fail=1
  fi
done
[ "$fail" -eq 0 ] && echo "  ✓ no critic constant is an Opus model"
for f in "$WORKSPACE/artifacts/api-server/src/routes/admin-company-kill.ts" \
         "$WORKSPACE/artifacts/api-server/src/tests/test-critic-no-opus.ts" \
         "$WORKSPACE/artifacts/dashboard/src/components/company-kill-control.tsx"; do
  [ -f "$f" ] && echo "  ✓ present: ${f#$WORKSPACE/}" || { echo "  ✗ missing: $f" >&2; fail=1; }
done
[ "$fail" -eq 0 ] || { echo "Post-checks failed." >&2; exit 4; }

if [ "$RUN_GATES" -eq 0 ]; then
  echo "Skipping gates (--no-gates). Run them yourself before mirroring (see README)."
  exit 0
fi

if ! command -v pnpm >/dev/null 2>&1; then
  cat <<EOF
pnpm not found — skipping gates. Run these from the workspace root before mirroring:
  pnpm --filter @workspace/api-server typecheck
  pnpm --filter @workspace/api-server exec tsx --test src/tests/test-critic-no-opus.ts
  pnpm --filter @workspace/api-server build
  pnpm --filter @workspace/dashboard typecheck
  pnpm --filter @workspace/dashboard build
EOF
  exit 0
fi

echo "Running gates…"
( cd "$WORKSPACE"
  set -x
  pnpm --filter @workspace/api-server typecheck
  pnpm --filter @workspace/api-server exec tsx --test src/tests/test-critic-no-opus.ts
  pnpm --filter @workspace/api-server build
  pnpm --filter @workspace/dashboard typecheck
  pnpm --filter @workspace/dashboard build
)
echo "All gates passed ✓  —  safe to run sync.sh / mirror."
