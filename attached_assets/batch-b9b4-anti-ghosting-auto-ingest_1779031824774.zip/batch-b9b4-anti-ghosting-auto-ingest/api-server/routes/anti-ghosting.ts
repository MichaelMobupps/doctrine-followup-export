import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import { gmail_v1 } from "googleapis";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getGmailForUser } from "../services/gmailClient";
import { logger } from "../lib/logger";
import { validateThreadForMarking } from "../services/antiGhostingValidators";
import {
  ingestAntiGhostingThread,
  resolveAntiGhostingLabelIds,
  getAlreadyMarkedThreadIds,
} from "../services/antiGhostingIngest";

/**
 * B9b: AntiGhosting Followuper routes.
 *
 * Mounted under /api/anti-ghosting/*. The third product alongside
 * Doctrine and Context. Scoped to prospects with app='anti_ghosting'.
 *
 * Endpoints:
 *
 *   POST /api/anti-ghosting/mark
 *     Body: { email, gmailThreadId, seedMessageId? }
 *     Manual override / force-ingest path. As of B9b.4 the primary
 *     ingest happens automatically when gmailSync sees a thread tagged
 *     with the user's AntiGhosting label — labeling IS the operator's
 *     commit point, matching how Doctrine and Context work. This
 *     endpoint stays for two cases the auto path doesn't cover:
 *       1. Force-ingest a newly-labeled thread immediately instead of
 *          waiting for the next sync cycle.
 *       2. Override the validator's auto-detected seed with an explicit
 *          seedMessageId (operator picks a different anchor message).
 *     Response shape preserved verbatim from B9b for backward compat
 *     with the dashboard.
 *
 *   GET /api/anti-ghosting/candidates?email=...
 *     Lists Gmail threads tagged with the user's antiGhostingLabel that
 *     do not yet have an anti_ghosting prospect. Each candidate
 *     includes seed identification (date, subject, snippet,
 *     daysSinceSeed tier flag) and a per-thread validator preview. With
 *     B9b.4 auto-ingest, this list will typically contain only threads
 *     that failed validators on the last sync — successfully validated
 *     threads disappear from the list as soon as they're ingested.
 *
 * Pause / renewal flows and the dashboard pipeline view ship in B9d.
 */

const router: IRouter = Router();

function authMiddleware(req: Request, res: Response, next: NextFunction): void {
  const key = req.headers["x-api-key"];
  const expected = process.env.ADDON_API_KEY;

  if (!expected) {
    res.status(500).json({ error: "ADDON_API_KEY not set" });
    return;
  }

  if (!key || key !== expected) {
    res.status(401).json({ error: "Invalid API key" });
    return;
  }

  next();
}

router.use(authMiddleware);

// =====================================================================
// Helpers
// =====================================================================

interface ResolvedUser {
  id: number;
  email: string;
  antiGhostingLabel: string;
  gmail: gmail_v1.Gmail;
}

/**
 * Resolve the user from a request, build a Gmail client, and return both.
 * Throws a structured Error with `status` if the user is not found, not
 * connected, or missing credentials — the calling route handler catches
 * and translates to the matching HTTP status.
 */
async function resolveUserFromEmail(email: string): Promise<ResolvedUser> {
  if (!email) {
    const err = new Error("email is required") as Error & { status: number };
    err.status = 400;
    throw err;
  }

  const users = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email))
    .limit(1);

  if (users.length === 0) {
    const err = new Error(`User not found: ${email}`) as Error & { status: number };
    err.status = 404;
    throw err;
  }

  const user = users[0];
  if (!user.googleRefreshToken || !user.isConnected) {
    const err = new Error(`User ${email} is not connected to Gmail`) as Error & { status: number };
    err.status = 409;
    throw err;
  }

  const gmail = getGmailForUser({
    refreshToken: user.googleRefreshToken,
    email: user.email,
    name: user.name ?? undefined,
  });

  return {
    id: user.id,
    email: user.email,
    // Schema default ("AntiGhosting Followuper") covers existing rows that
    // were created before the column gained a value. Treat null defensively.
    antiGhostingLabel: user.antiGhostingLabel ?? "AntiGhosting Followuper",
    gmail,
  };
}

/**
 * Classify a seed message's age into the three tone tiers used by the
 * downstream generator and by the dashboard's candidate cards.
 */
function daysSinceSeedTier(sentAt: Date, now: Date): "lt_30d" | "30d_to_6mo" | "gt_6mo" {
  const diffMs = now.getTime() - sentAt.getTime();
  const days = diffMs / (24 * 60 * 60 * 1000);
  if (days < 30) return "lt_30d";
  if (days < 180) return "30d_to_6mo";
  return "gt_6mo";
}

// =====================================================================
// POST /api/anti-ghosting/mark
// =====================================================================
//
// B9b.4 refactor: the entire ingest pipeline (validators → prospect
// insert → thread sync → F1 schedule) now lives in
// services/antiGhostingIngest.ts and is shared with the gmailSync
// auto-ingest pass. This handler is a thin wrapper that translates the
// service's IngestResult into the existing HTTP response shape so the
// dashboard's existing call site doesn't change.
//
router.post("/mark", async (req: Request, res: Response): Promise<void> => {
  try {
    const email = req.body?.email ? String(req.body.email) : "";
    const gmailThreadId = req.body?.gmailThreadId ? String(req.body.gmailThreadId) : "";
    const overrideSeedMessageId = req.body?.seedMessageId
      ? String(req.body.seedMessageId)
      : undefined;

    if (!gmailThreadId) {
      res.status(400).json({ error: "gmailThreadId is required" });
      return;
    }

    const user = await resolveUserFromEmail(email);

    const result = await ingestAntiGhostingThread({
      userId: user.id,
      gmail: user.gmail,
      userEmail: user.email,
      gmailThreadId,
      overrideSeedMessageId,
    });

    // Idempotency — caller marked a thread that the auto-ingest pass
    // already picked up. 409 Conflict + the existing prospectId so the
    // dashboard can navigate there if useful.
    if (result.alreadyMarked) {
      res.status(409).json({
        error: "Thread already marked",
        prospectId: result.prospectId,
      });
      return;
    }

    // Validator rejection or seed-override error. 200 OK with the
    // structured preview, matching the existing dashboard contract.
    if (!result.success) {
      res.json({
        ok: false,
        results: result.validatorResults,
        prospect: result.prospect,
        failureReason: result.reason,
      });
      return;
    }

    // Success — preserve the B9b response shape verbatim.
    res.json({
      ok: true,
      prospectId: result.prospectId,
      scheduledAt: result.scheduledAt?.toISOString(),
      seed: result.seed
        ? {
            gmailMessageId: result.seed.gmailMessageId,
            subject: result.seed.subject,
            sentAt: result.seed.sentAt.toISOString(),
          }
        : undefined,
      prospect: result.prospect,
      results: result.validatorResults,
    });
  } catch (err: unknown) {
    const status = (err as { status?: number }).status ?? 500;
    const msg = err instanceof Error ? err.message : String(err);
    if (status >= 500) logger.error({ err }, "POST /anti-ghosting/mark failed");
    res.status(status).json({ error: msg });
  }
});

// =====================================================================
// GET /api/anti-ghosting/candidates
// =====================================================================
router.get("/candidates", async (req: Request, res: Response): Promise<void> => {
  try {
    const email = req.query.email ? String(req.query.email) : "";
    const maxResults = Math.min(
      parseInt((req.query.limit as string) ?? "20", 10) || 20,
      50,
    );

    const user = await resolveUserFromEmail(email);

    // 1. Resolve antiGhosting label IDs.
    const labelIds = await resolveAntiGhostingLabelIds(user.gmail, user.antiGhostingLabel);
    if (labelIds.length === 0) {
      res.json({
        ok: true,
        candidates: [],
        note: `No Gmail labels matching "${user.antiGhostingLabel}" found in user's mailbox. Apply that label in Gmail to mark threads for re-engagement.`,
      });
      return;
    }

    // 2. List label-tagged threads.
    const threadsRes = await user.gmail.users.threads.list({
      userId: "me",
      labelIds,
      maxResults,
    });
    const threads = threadsRes.data.threads || [];

    // 3. Filter out threads that already have an anti_ghosting prospect.
    //    Direct query on prospectsTable.gmailThreadId via the moved
    //    helper — more correct than B9b's JOIN through thread_messages
    //    (which missed prospects whose thread sync failed).
    const alreadyMarked = await getAlreadyMarkedThreadIds(user.id);

    // 4. For each remaining thread, run validators to populate the preview.
    //    Validators short-circuit on first failure so this is cheap for
    //    most threads (typically 1 Gmail call + 1 DB lookup).
    const now = new Date();
    const candidates: unknown[] = [];
    for (const t of threads) {
      if (!t.id) continue;
      if (alreadyMarked.has(t.id)) continue;

      try {
        const outcome = await validateThreadForMarking(t.id, user.gmail, user.email, user.id);
        candidates.push({
          gmailThreadId: t.id,
          ok: outcome.ok,
          results: outcome.results,
          failureReason: outcome.failureReason,
          prospect: outcome.prospect,
          seed: outcome.seed
            ? {
                gmailMessageId: outcome.seed.id,
                subject: outcome.seed.subject,
                snippet: outcome.seed.snippet,
                sentAt: outcome.seed.sentAt.toISOString(),
                daysSinceSeedTier: daysSinceSeedTier(outcome.seed.sentAt, now),
              }
            : null,
        });
      } catch (err) {
        logger.warn({ err, threadId: t.id }, "validator failed for candidate thread; skipping");
      }
    }

    res.json({ ok: true, candidates });
  } catch (err: unknown) {
    const status = (err as { status?: number }).status ?? 500;
    const msg = err instanceof Error ? err.message : String(err);
    if (status >= 500) logger.error({ err }, "GET /anti-ghosting/candidates failed");
    res.status(status).json({ error: msg });
  }
});

export default router;
