#!/usr/bin/env python3
r"""
B9b.6 — relax prospects.gmail_message_id uniqueness.

Bug discovered when Mark button fired Drizzle insert error:
  duplicate key violation on prospects_gmail_message_id_unique

The schema has `.unique()` on gmail_message_id globally. That blocks the
canonical AntiGhosting case where the same outbound message anchors both
a doctrine prospect (cold outreach) and an anti_ghosting prospect
(re-engagement after the doctrine campaign exhausted).

Fix: scope uniqueness to (user_id, gmail_message_id, app). Same message
can be a doctrine AND an anti_ghosting prospect for the same user —
different products, shouldn't collide. Cross-user scoping also tightens
correctness (was implicit before; explicit now).

Schema patch is two surgical edits in lib/db/src/schema/prospects.ts:
  1. Remove `.unique()` modifier from gmailMessageId column.
  2. Add `uniqueIndex("uq_prospects_user_message_app")` to the indexes
     array on (userId, gmailMessageId, app).

After the patch, Michael runs `drizzle-kit generate` to produce the
migration file. Drizzle introspects the current DB to find the exact
constraint name to drop, so generating against the live DB is the
safest path (constraint names differ across Postgres versions).

Idempotency: generalized NEW-substring-of-OLD check.

Risk surface: nil. Old UQ (global) was strictly stronger than new UQ
(per user+app). Any row that satisfied old also satisfies new. No data
cleanup needed.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    print("\n--- lib/db/src/schema/prospects.ts ---")
    a, b, w = patch_file(
        "lib/db/src/schema/prospects.ts",
        [
            # ─────────────────────────────────────────────────────
            # Edit 1: drop the global .unique() from gmailMessageId.
            # ─────────────────────────────────────────────────────
            (
                '  gmailMessageId: text("gmail_message_id").notNull().unique(),\n',
                '  gmailMessageId: text("gmail_message_id").notNull(),\n',
                "remove global UQ from gmailMessageId column",
            ),
            # ─────────────────────────────────────────────────────
            # Edit 2: add composite uniqueIndex after idx_prospects_app.
            # Mirroring B9a's app index as the anchor so we slot in
            # adjacent to per-product scoping.
            # ─────────────────────────────────────────────────────
            (
                '  index("idx_prospects_app").on(table.app),\n'
                ']);\n',
                '  index("idx_prospects_app").on(table.app),\n'
                '  // B9b.6: scope gmail_message_id uniqueness to (user, app) so\n'
                '  // a thread can carry both a doctrine prospect and an\n'
                '  // anti_ghosting prospect that share the same outbound seed\n'
                '  // message. The previous global UQ on the column blocked the\n'
                '  // canonical re-engagement-after-doctrine pattern.\n'
                '  uniqueIndex("uq_prospects_user_message_app").on(\n'
                '    table.userId,\n'
                '    table.gmailMessageId,\n'
                '    table.app,\n'
                '  ),\n'
                ']);\n',
                "add (user_id, gmail_message_id, app) uniqueIndex",
            ),
        ],
    )

    expected = 2
    seen = a + b
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {a}")
    print(f"  Already-applied:   {b}")
    print(f"  Warnings:          {w}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if w > 0:
        print("  Warning fired — see WARN line above.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2

    print()
    print("=== Next steps (run manually in the workspace shell) ===")
    print("  cd lib/db")
    print("  pnpm exec drizzle-kit generate --name relax_prospects_uq --config ./drizzle.config.ts")
    print("  cd ../..")
    print("  pnpm --filter @workspace/api-server run typecheck")
    print("  pnpm --filter @workspace/api-server run build")
    print("  bash source-code/sync.sh")
    print("  # Restart the api-server workflow; existing migration runner")
    print("  # auto-applies the new file on startup (same as B9a).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
