# Followuper v4 Round-4 — Verb-fronted lead-with detector + dedup autofix module

TS twin of Prospector v4 Round-4. Same two layers:

1. **NEW DETECTOR** — Verb-fronted "lead with" calque across EN/PT/ES/FR/IT.
2. **AUTOFIX MODULE** — Deterministic dedup stripper that consumes
   language-specific complementizers ("que" in PT/ES/FR, "che" in IT,
   "dass" in DE, "that" in EN, and 30+ more) so duplicate discourse
   markers come out grammatically.

## Note on wiring

The Followuper autofix module is installed but NOT wired into a pipeline
stage. Followuper's primary job is to validate carried-forward email text
rather than generate fresh copy, so the LLM-vs-deterministic gap that
made hardening necessary in Prospector doesn't apply the same way. The
module is available as a building block if Michael decides to wire it
into the follow-up generator later.

## Stacking

Apply AFTER v4r2 and v4r3 are already on the target.
Order: v4 → v4r2 → v4r3 → v4r4.

## Operations (8)

1. NewFile `api-server/lib/discourseMarkerAutofix.ts` — autofix module
2. NewFile `api-server/tests/test-discourse-autofix-v4r4.ts` — 22 tests for autofix
3. NewFile `api-server/tests/test-nativeness-v4-round4.ts` — 26 tests for verb-fronted detector
4. Patch `api-server/lib/nativenessV4.ts` — install detector block
5. Patch `api-server/lib/nativenessV4.ts` — extend `NativenessV4Report` interface
6. Patch `api-server/lib/nativenessV4.ts` — wire detector into report return
7. Patch `api-server/lib/nativenessV4.ts` — wire into `hasAnyViolationV4`
8. Patch `api-server/tests/test-nativeness-v4.ts` — extend expected-keys list

## Test counts after this bundle

- v3:                24
- v4:                47
- v4r2:              40
- v4r3:              42
- v4r4 detector:     26
- v4r4 autofix:      22
- Doctrine hardening: 72
- Other:              5
- **Total: 278** (all green)

## Files modified

- `api-server/lib/nativenessV4.ts`             (+63 lines)
- `api-server/tests/test-nativeness-v4.ts`     (+3 lines)

## Backups

`.v4r4_backup` siblings restore exact pre-patch state. Rollback is byte-identical.

## Idempotency

Re-running the patcher reports 8/8 SKIP with no changes.
