#!/usr/bin/env python3
r"""
B9b.2 — close the Settings UI gap: surface antiGhostingLabel as an
editable field, mirroring the existing Doctrine and Context label inputs.

Schema column users.antiGhostingLabel was added in B9a (default
"AntiGhosting Followuper"). The marking flow already reads it via
resolveUserFromEmail / resolveAntiGhostingLabelIds. Two things were
missing for the operator to be able to customize the label name without
SQL:

  1. The GET /api/gmail/accounts SELECT projection didn't include the
     column, so the dashboard's account object never carried it.
  2. The PUT /api/gmail/accounts/:id/settings handler didn't destructure
     or persist the field, so even if the dashboard sent it, the
     api-server would have silently dropped it.
  3. The Accounts page form had no input for it.

Six surgical edits across two files:

  artifacts/api-server/src/routes/gmail-auth.ts
    - Add antiGhostingLabel to GET SELECT projection
    - Add antiGhostingLabel to PUT body destructure
    - Add antiGhostingLabel persistence in PUT updates handler

  artifacts/dashboard/src/pages/accounts.tsx
    - Add antiGhostingLabel state variable
    - Add antiGhostingLabel to save body
    - Add new <div> markup block between Context label and Weekly Digest

Idempotency: generalized NEW-substring-of-OLD check (from B9c.2.1+).

Note on dashboard typing: the read uses
`(account as Record<string, any>).antiGhostingLabel` rather than direct
property access because the Orval-generated GmailAccount type may not
yet include the new field (depending on how the type regen pipeline
runs). The cast is intentional and noted at the call site so a future
Orval regen can replace it with direct access.
"""

import os
import sys

ROOT = os.getcwd()


def patch_file(path: str, edits: list[tuple[str, str, str]]) -> tuple[int, int, int]:
    abs_path = os.path.join(ROOT, path)
    if not os.path.isfile(abs_path):
        print(f"  ERROR: {path} not found")
        return (0, 0, len(edits))

    with open(abs_path) as f:
        content = f.read()

    applied = 0
    already = 0
    warns = 0
    for old, new, label in edits:
        new_is_in_old = bool(new and old and new in old)
        if new == "" or new_is_in_old:
            if old in content:
                content = content.replace(old, new, 1)
                tag = " (deletion)" if new == "" else " (insertion next to OLD)"
                print(f"  FIX  {path}: {label}{tag}")
                applied += 1
            else:
                print(f"  SKIP {path}: {label} — already applied")
                already += 1
        elif new in content:
            print(f"  SKIP {path}: {label} — already applied")
            already += 1
        elif old in content:
            content = content.replace(old, new, 1)
            print(f"  FIX  {path}: {label}")
            applied += 1
        else:
            print(f"  WARN {path}: {label} — neither OLD nor NEW pattern found")
            warns += 1

    if applied > 0:
        with open(abs_path, "w") as f:
            f.write(content)
        print(f"  Wrote {path}")
    return (applied, already, warns)


def main() -> int:
    totals = [0, 0, 0]

    # ─────────────────────────────────────────────────────────────
    # API: routes/gmail-auth.ts — three edits
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/api-server/src/routes/gmail-auth.ts ---")
    a, b, w = patch_file(
        "artifacts/api-server/src/routes/gmail-auth.ts",
        [
            (
                '  doctrineLabel: usersTable.doctrineLabel,\n'
                '  contextLabel: usersTable.contextLabel,\n',
                '  doctrineLabel: usersTable.doctrineLabel,\n'
                '  contextLabel: usersTable.contextLabel,\n'
                '  // B9b.2: surface the AntiGhosting label to the dashboard so the\n'
                '  // operator can rename it via Settings rather than SQL.\n'
                '  antiGhostingLabel: usersTable.antiGhostingLabel,\n',
                "add antiGhostingLabel to GET /gmail/accounts SELECT",
            ),
            (
                '      doctrineLabel,\n'
                '      contextLabel,\n'
                '      followupMode,\n',
                '      doctrineLabel,\n'
                '      contextLabel,\n'
                '      antiGhostingLabel,\n'
                '      followupMode,\n',
                "add antiGhostingLabel to PUT body destructure",
            ),
            (
                '    if (doctrineLabel !== undefined) updates.doctrineLabel = String(doctrineLabel);\n'
                '    if (contextLabel !== undefined) updates.contextLabel = String(contextLabel);\n',
                '    if (doctrineLabel !== undefined) updates.doctrineLabel = String(doctrineLabel);\n'
                '    if (contextLabel !== undefined) updates.contextLabel = String(contextLabel);\n'
                '    if (antiGhostingLabel !== undefined) updates.antiGhostingLabel = String(antiGhostingLabel);\n',
                "persist antiGhostingLabel in PUT updates",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    # ─────────────────────────────────────────────────────────────
    # Dashboard: pages/accounts.tsx — three edits
    # ─────────────────────────────────────────────────────────────
    print("\n--- artifacts/dashboard/src/pages/accounts.tsx ---")
    a, b, w = patch_file(
        "artifacts/dashboard/src/pages/accounts.tsx",
        [
            (
                '  const [doctrineLabel, setDoctrineLabel] = useState<string>(account.doctrineLabel || "Doctrine SDR");\n'
                '  // Phase 7d: Context Followuper label, settable per-account.\n'
                '  const [contextLabel, setContextLabel] = useState<string>(account.contextLabel || "Context Followuper");\n',
                '  const [doctrineLabel, setDoctrineLabel] = useState<string>(account.doctrineLabel || "Doctrine SDR");\n'
                '  // Phase 7d: Context Followuper label, settable per-account.\n'
                '  const [contextLabel, setContextLabel] = useState<string>(account.contextLabel || "Context Followuper");\n'
                '  // B9b.2: AntiGhosting label, settable per-account. Cast through\n'
                '  // Record<string, any> until the Orval-generated GmailAccount type\n'
                '  // is regenerated to include the new field.\n'
                '  const [antiGhostingLabel, setAntiGhostingLabel] = useState<string>(\n'
                '    ((account as Record<string, any>).antiGhostingLabel as string) || "AntiGhosting Followuper",\n'
                '  );\n',
                "add antiGhostingLabel state variable",
            ),
            (
                '        doctrineLabel,\n'
                '        contextLabel,\n'
                '        weeklyDigestEnabled,\n',
                '        doctrineLabel,\n'
                '        contextLabel,\n'
                '        antiGhostingLabel,\n'
                '        weeklyDigestEnabled,\n',
                "add antiGhostingLabel to save body",
            ),
            (
                '              {/* Phase 7d: Gmail label — Context */}\n'
                '              <div>\n'
                '                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>\n'
                '                  Context Gmail label\n'
                '                </label>\n'
                '                <Input\n'
                '                  value={contextLabel}\n'
                '                  onChange={(e) => setContextLabel(e.target.value)}\n'
                '                  placeholder="Context Followuper"\n'
                '                  className="max-w-xs"\n'
                '                />\n'
                '                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync into the Context flow</p>\n'
                '              </div>\n'
                '\n'
                '              {/* Phase 4: Weekly digest toggle */}\n',
                '              {/* Phase 7d: Gmail label — Context */}\n'
                '              <div>\n'
                '                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>\n'
                '                  Context Gmail label\n'
                '                </label>\n'
                '                <Input\n'
                '                  value={contextLabel}\n'
                '                  onChange={(e) => setContextLabel(e.target.value)}\n'
                '                  placeholder="Context Followuper"\n'
                '                  className="max-w-xs"\n'
                '                />\n'
                '                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync into the Context flow</p>\n'
                '              </div>\n'
                '\n'
                '              {/* B9b.2: Gmail label — AntiGhosting */}\n'
                '              <div>\n'
                '                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>\n'
                '                  Anti-Ghosting Gmail label\n'
                '                </label>\n'
                '                <Input\n'
                '                  value={antiGhostingLabel}\n'
                '                  onChange={(e) => setAntiGhostingLabel(e.target.value)}\n'
                '                  placeholder="AntiGhosting Followuper"\n'
                '                  className="max-w-xs"\n'
                '                />\n'
                '                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync into the Anti-Ghosting flow</p>\n'
                '              </div>\n'
                '\n'
                '              {/* Phase 4: Weekly digest toggle */}\n',
                "add Anti-Ghosting label markup block",
            ),
        ],
    )
    totals[0] += a; totals[1] += b; totals[2] += w

    expected = 6
    seen = totals[0] + totals[1]
    print(f"\n=== Summary ===")
    print(f"  Edits applied:     {totals[0]}")
    print(f"  Already-applied:   {totals[1]}")
    print(f"  Warnings:          {totals[2]}")
    print(f"  Expected total:    {expected} (seen {seen})")
    if totals[2] > 0:
        print("  At least one edit could not be applied. Inspect WARN lines.")
        return 2
    if seen < expected:
        print("  Fewer edits than expected — file shape may have drifted.")
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
