#!/usr/bin/env node
/**
 * apply-batch7a.mjs — Phase 7a (Context Based foundation) code patch.
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Touches:
 *   - lib/db/src/schema/prospects.ts   (add `app` field + ProspectApp type)
 *   - lib/db/src/schema/users.ts       (add `contextLabel` field)
 *   - artifacts/api-server/src/routes/gmail-auth.ts
 *                                      (project + accept contextLabel)
 *
 * Does NOT touch:
 *   - scheduler.ts, gmailSync.ts, cron.ts, or any service file
 *   - any UI file
 *   - any new route or generator
 *
 * The intent is: zero behavior drift on existing flows. The new column
 * sits ready for Batch 7b to read and route on.
 *
 * No new packages.
 *
 * Usage:
 *   node apply-batch7a.mjs
 *   DB_BASE=lib/db/src API_BASE=artifacts/api-server/src node apply-batch7a.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const DB_BASE  = process.env.DB_BASE  || "lib/db/src";
const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[apply-batch7a] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7a] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

// ============================================================
// Step 1: lib/db/src/schema/prospects.ts — add `app` field
// ============================================================
log("Step 1: Patching schema (prospects)...");
const prospectsSchemaPath = join(DB_BASE, "schema", "prospects.ts");

// 1a: Add the ProspectApp type and PROSPECT_APPS constant at the top of the file
strReplace(
  prospectsSchemaPath,
  `import { pgTable, serial, text, integer, timestamp, boolean, index, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";`,
  `import { pgTable, serial, text, integer, timestamp, boolean, index, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { usersTable } from "./users";

// Phase 7a: discriminator that splits prospects into the two products
// running in this app:
//   'doctrine' — Sales Doctrine Followuper (default; existing flow)
//   'context'  — Context Based Followuper (new flow added in Phase 7b)
// The CHECK constraint at the DB level enforces this enum; this TS type
// is the application-level mirror.
export type ProspectApp = "doctrine" | "context";
export const PROSPECT_APPS: ProspectApp[] = ["doctrine", "context"];`,
  "prospects.ts: add ProspectApp type + PROSPECT_APPS const",
  `export type ProspectApp = "doctrine" | "context";`
);

// 1b: Add the `app` column to the table definition
strReplace(
  prospectsSchemaPath,
  `  followupPaused: boolean("followup_paused").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [`,
  `  followupPaused: boolean("followup_paused").notNull().default(false),
  // Phase 7a: which product this prospect belongs to.
  app: text("app").$type<ProspectApp>().notNull().default("doctrine"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [`,
  "prospects.ts: add `app` column",
  `app: text("app").$type<ProspectApp>().notNull().default("doctrine"),`
);

// 1c: Add an index on the `app` column for efficient per-product filtering
strReplace(
  prospectsSchemaPath,
  `  index("idx_prospects_user").on(table.userId),
]);`,
  `  index("idx_prospects_user").on(table.userId),
  // Phase 7a: per-product filter index. Most queries (sync, dispatcher,
  // pipeline list) will scope to a single app value.
  index("idx_prospects_app").on(table.app),
]);`,
  "prospects.ts: add index on `app`",
  `index("idx_prospects_app").on(table.app),`
);

// ============================================================
// Step 2: lib/db/src/schema/users.ts — add `contextLabel` field
// ============================================================
log("Step 2: Patching schema (users)...");
const usersSchemaPath = join(DB_BASE, "schema", "users.ts");

strReplace(
  usersSchemaPath,
  `  doctrineLabel: text("doctrine_label").notNull().default("Doctrine SDR"),`,
  `  doctrineLabel: text("doctrine_label").notNull().default("Doctrine SDR"),
  // Phase 7a: Gmail label that scopes ingest into the Context Based
  // Followuper. User must add this label to threads they want followed
  // up on a context-only basis (no doctrine prompts). Default chosen
  // to be self-explanatory for non-technical team members.
  contextLabel: text("context_label").notNull().default("Context Followuper"),`,
  "users.ts: add `contextLabel` column",
  `contextLabel: text("context_label").notNull().default("Context Followuper"),`
);

// ============================================================
// Step 3: gmail-auth.ts — project + accept contextLabel
// ============================================================
log("Step 3: Patching gmail-auth.ts (contextLabel projection + write)...");
const gmailAuthPath = join(API_BASE, "routes", "gmail-auth.ts");

// 3a: Add to ACCOUNT_SELECT projection
strReplace(
  gmailAuthPath,
  `  doctrineLabel: usersTable.doctrineLabel,`,
  `  doctrineLabel: usersTable.doctrineLabel,
  contextLabel: usersTable.contextLabel,`,
  "gmail-auth.ts: project contextLabel in ACCOUNT_SELECT",
  `contextLabel: usersTable.contextLabel,`
);

// 3b: Add to PUT body destructure
strReplace(
  gmailAuthPath,
  `      doctrineLabel,
      followupMode,`,
  `      doctrineLabel,
      contextLabel,
      followupMode,`,
  "gmail-auth.ts: destructure contextLabel from PUT body",
  `      doctrineLabel,
      contextLabel,
      followupMode,`
);

// 3c: Add the write line after the doctrineLabel handling
strReplace(
  gmailAuthPath,
  `    if (doctrineLabel !== undefined) updates.doctrineLabel = String(doctrineLabel);`,
  `    if (doctrineLabel !== undefined) updates.doctrineLabel = String(doctrineLabel);
    if (contextLabel !== undefined) updates.contextLabel = String(contextLabel);`,
  "gmail-auth.ts: accept contextLabel writes",
  `if (contextLabel !== undefined) updates.contextLabel = String(contextLabel);`
);

// ============================================================
// Step 4: Self-verify
// ============================================================
log("Step 4: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found: ${needle.slice(0, 70)}...`);
  log(`  [OK] ${label}`);
}

expectInFile(prospectsSchemaPath, `export type ProspectApp = "doctrine" | "context";`, "V1a ProspectApp type");
expectInFile(prospectsSchemaPath, `export const PROSPECT_APPS: ProspectApp[]`, "V1b PROSPECT_APPS const");
expectInFile(prospectsSchemaPath, `app: text("app").$type<ProspectApp>().notNull().default("doctrine")`, "V1c app column");
expectInFile(prospectsSchemaPath, `index("idx_prospects_app").on(table.app)`, "V1d app index");
expectInFile(usersSchemaPath, `contextLabel: text("context_label").notNull().default("Context Followuper")`, "V2  contextLabel column");
expectInFile(gmailAuthPath, `contextLabel: usersTable.contextLabel,`, "V3a contextLabel projection");
expectInFile(gmailAuthPath, `if (contextLabel !== undefined) updates.contextLabel = String(contextLabel);`, "V3b contextLabel PUT write");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7a patch applied. Schema is ready for the Context Based");
log("Followuper. Run migrate-batch7a.mjs from inside lib/db/ to add");
log("the corresponding DB columns, then build + restart.");
log("================================================================");
