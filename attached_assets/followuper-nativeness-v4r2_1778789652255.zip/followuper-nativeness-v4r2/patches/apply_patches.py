#!/usr/bin/env python3
"""
apply_patches.py — Followuper v4 Round-2 (universal native-style detectors).

TypeScript twin of the Prospector v4 Round-2 work. Adds 3 new detectors:
  - findRepeatingDiscourseMarkers (26 languages)
  - findSemicolonWithoutConnector (17 languages, skips ja/zh/ko/th/ar/he/fa/ur/hi/bn/vi/id/ms/fil/tr/el)
  - findNonReflexiveRomanceVerbs (pt, pt-BR, es, fr, it)

Idempotent count-marker pattern.
"""

import shutil
import sys
from pathlib import Path


class Op:
    def __init__(self, name, path):
        self.name = name
        self.path = path

    def apply(self, root): raise NotImplementedError


class NewFile(Op):
    def __init__(self, name, path, content):
        super().__init__(name, path)
        self.content = content

    def apply(self, root):
        target = root / self.path
        if target.exists():
            existing = target.read_text(encoding="utf-8")
            if existing == self.content:
                return ("SKIP", f"{self.path} already installed (byte-identical)")
            return ("FAIL", f"{self.path} exists but differs from payload")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(self.content, encoding="utf-8")
        return ("OK", f"{self.path} installed ({len(self.content)} bytes)")


class Patch(Op):
    def __init__(self, name, path, anchor, marker, new_text, expected_count=1):
        super().__init__(name, path)
        self.anchor = anchor
        self.marker = marker
        self.new_text = new_text
        self.expected_count = expected_count

    def apply(self, root):
        target = root / self.path
        if not target.exists():
            return ("FAIL", f"{self.path} not found")
        text = target.read_text(encoding="utf-8")
        actual = text.count(self.marker)
        if actual >= self.expected_count:
            return ("SKIP", f"{self.path}: marker present {actual}x (>= {self.expected_count})")
        if self.anchor not in text:
            return ("FAIL", f"{self.path}: anchor not found AND marker count {actual} < {self.expected_count}")
        backup = target.with_suffix(target.suffix + ".v4r2_backup")
        if not backup.exists():
            shutil.copy2(target, backup)
        new_text = text.replace(self.anchor, self.new_text, 1)
        target.write_text(new_text, encoding="utf-8")
        return ("OK", f"{self.path}: anchor patched (marker now {new_text.count(self.marker)}x)")


SCRIPT_DIR = Path(__file__).resolve().parent
PAYLOAD_DIR = SCRIPT_DIR.parent

_DETECTOR_SRC = (PAYLOAD_DIR / "v44Detectors.ts").read_text(encoding="utf-8")
_TEST_FILE = (PAYLOAD_DIR / "api-server" / "tests" / "test-nativeness-v4-round2.ts").read_text(encoding="utf-8")


# ============================================================================
# Op 1 — Inject detectors before NativenessV4Report interface
# ============================================================================

DETECTOR_INJECT_ANCHOR = """export interface NativenessV4Report extends NativenessV3Report {
  translationese: string[];
  greeting_name_adaptation: string[];
}"""

DETECTOR_INJECT_NEW = _DETECTOR_SRC.rstrip() + "\n\n\n" + """export interface NativenessV4Report extends NativenessV3Report {
  translationese: string[];
  greeting_name_adaptation: string[];
  // v4 Round-2 detector keys
  repeating_discourse_markers: RepeatingMarkerHit[];
  semicolon_no_connector: SemicolonHit[];
  non_reflexive_romance_verbs: NonReflexiveHit[];
}"""

DETECTOR_INJECT_MARKER = "v4 Round-2 (Universal native-style detectors)"


# ============================================================================
# Op 2 — Extend findAllNativenessViolationsV4 aggregator
# ============================================================================

AGGREGATOR_ANCHOR = """    translationese: findTranslationese(text, lang),
    greeting_name_adaptation: findGreetingNameAdaptationIssues(text, lang),
  };
}"""

AGGREGATOR_NEW = """    translationese: findTranslationese(text, lang),
    greeting_name_adaptation: findGreetingNameAdaptationIssues(text, lang),
    // v4 Round-2 detectors
    repeating_discourse_markers: findRepeatingDiscourseMarkers(text, lang),
    semicolon_no_connector: findSemicolonWithoutConnector(text, lang),
    non_reflexive_romance_verbs: findNonReflexiveRomanceVerbs(text, lang),
  };
}"""

AGGREGATOR_MARKER = "// v4 Round-2 detectors"


# ============================================================================
# Op 3 — Extend hasAnyViolationV4
# ============================================================================

HAS_ANY_ANCHOR = """  if (report.translationese.length > 0) return true;
  if (report.greeting_name_adaptation.length > 0) return true;
  return false;
}"""

HAS_ANY_NEW = """  if (report.translationese.length > 0) return true;
  if (report.greeting_name_adaptation.length > 0) return true;
  // v4 Round-2 detectors
  if (report.repeating_discourse_markers.length > 0) return true;
  if (report.semicolon_no_connector.length > 0) return true;
  if (report.non_reflexive_romance_verbs.length > 0) return true;
  return false;
}"""


# ============================================================================
# Op 4 — Wire lint emissions in doctrineLint.ts
# ============================================================================

LINT_ANCHOR = """  if (report.translationese.length > 0) {
    const sample = report.translationese.slice(0, 5).map(t => `"${t}"`).join(", ");
    issues.push(
      `TRANSLATIONESE-PATTERN \\u2014 literal-translated English idiom(s) ` +
      `inside ${languageTag} prose (${sample}). v4 native-style rule: ` +
      `native speakers do not use these constructions even though the ` +
      `individual words are correct local-language tokens.`
    );
    suggestions.push(
      "Rewrite each flagged phrase using native alternatives from the " +
      "v4 NATIVE STYLE GUIDE for this language."
    );
    matches.push(...report.translationese);
  }"""

LINT_NEW = """  if (report.translationese.length > 0) {
    const sample = report.translationese.slice(0, 5).map(t => `"${t}"`).join(", ");
    issues.push(
      `TRANSLATIONESE-PATTERN \\u2014 literal-translated English idiom(s) ` +
      `inside ${languageTag} prose (${sample}). v4 native-style rule: ` +
      `native speakers do not use these constructions even though the ` +
      `individual words are correct local-language tokens.`
    );
    suggestions.push(
      "Rewrite each flagged phrase using native alternatives from the " +
      "v4 NATIVE STYLE GUIDE for this language."
    );
    matches.push(...report.translationese);
  }

  // v4 Round-2: REPEATING-DISCOURSE-MARKER
  if (report.repeating_discourse_markers.length > 0) {
    const markerList = report.repeating_discourse_markers
      .slice(0, 5)
      .map(h => `"${h.marker}" (${h.count}x)`)
      .join(", ");
    issues.push(
      `REPEATING-DISCOURSE-MARKER \\u2014 sentence-starter discourse ` +
      `marker(s) used 2+ times inside ${languageTag} prose (${markerList}). ` +
      `Native business style varies phrasing rather than reusing the same ` +
      `"worth mentioning"-class sentence-starter.`
    );
    suggestions.push(
      "Replace the second (and later) occurrences with a different " +
      "connector or rephrase the sentence to avoid the marker entirely."
    );
    matches.push(...report.repeating_discourse_markers.map(h => h.marker));
  }

  // v4 Round-2: SEMICOLON-NO-CONNECTOR
  if (report.semicolon_no_connector.length > 0) {
    const first = report.semicolon_no_connector[0];
    const sugg = first.suggestions.slice(0, 3).map(s => `"${s}"`).join(", ");
    issues.push(
      `SEMICOLON-NO-CONNECTOR \\u2014 semicolon followed by ` +
      `"${first.followedBy}" instead of a connector word in ` +
      `${languageTag} prose. Native style anchors the post-semicolon ` +
      `clause with a connector.`
    );
    suggestions.push(
      `Add one of: ${sugg} after the semicolon, or replace the semicolon ` +
      `with a period and start the next sentence with a connector.`
    );
    matches.push(...report.semicolon_no_connector.map(h => h.followedBy));
  }

  // v4 Round-2: NON-REFLEXIVE-ROMANCE-VERB
  if (report.non_reflexive_romance_verbs.length > 0) {
    const verbList = report.non_reflexive_romance_verbs
      .slice(0, 5)
      .map(h => `"${h.verb}" -> "${h.expected}"`)
      .join(", ");
    issues.push(
      `NON-REFLEXIVE-ROMANCE-VERB \\u2014 Romance verb(s) used in bare ` +
      `form where the reflexive is canonical for business prose in ` +
      `${languageTag} (${verbList}).`
    );
    suggestions.push(
      "Add the reflexive pronoun before the verb when the subject is the " +
      "offering/structure/integration itself (most business contexts)."
    );
    matches.push(...report.non_reflexive_romance_verbs.map(h => h.verb));
  }"""

LINT_MARKER = "v4 Round-2: REPEATING-DISCOURSE-MARKER"


# ============================================================================
# Op 5 — Add criteria 13i, 13j, 13k to followupPrompts.ts (criterion 13)
# ============================================================================

CRITIC_ANCHOR = """13h. LOANWORD INCONSISTENCY (adtech-heavy languages)."""

CRITIC_NEW = """13i. REPEATING DISCOURSE MARKERS (universal): Native business style varies sentence-starter phrases. If "vale mencionar"/"vale destacar"/"worth mentioning"/"il convient de mentionner"/"es ist erwähnenswert"/"стоит отметить"/"ראוי לציין" or any other "worth-mentioning"-class marker appears 2+ times in the email, score language_naturalness 1-2 and set needs_rewrite=true. Native writers vary phrasing across markers/direct statement/connectors ("além disso"/"moreover"/"par ailleurs"/"darüber hinaus"/"кроме того"/"בנוסף"). Deterministic linter emits REPEATING-DISCOURSE-MARKER. 13j. SEMICOLON CONNECTOR (Romance/Germanic/Slavic + English): When a semicolon joins two independent clauses, the second clause must begin with a connector that anchors it grammatically. PT: logo/portanto/dessa forma/assim/por isso. ES: por lo tanto/así pues/en consecuencia. FR: ainsi/par conséquent/de ce fait. DE: daher/folglich/somit. EN: therefore/thus/hence/consequently. A semicolon followed by a bare noun phrase reads as translated-from-English. Score language_naturalness 1-2 and set needs_rewrite=true. NOTE: rule does NOT apply to ja/zh/ko/th/ar/he/fa/ur/hi/bn/vi/id/ms/fil/tr — semicolons follow different conventions in those languages. Deterministic linter emits SEMICOLON-NO-CONNECTOR. 13k. ROMANCE REFLEXIVE VERBS (pt, pt-BR, es, fr, it): Native Romance business prose uses reflexive forms for verbs whose subject is the offering/structure/integration. PT: "a oferta SE encaixa" (not "a oferta encaixa"). ES: "la oferta SE aplica". FR: "l'offre S'applique". IT: "l'offerta SI applica". Verb class: encaixa/encaja/applique/applica, aplica/aplica/applique/applica, adequa/adapta/adapte/adatta, ajusta/ajusta/ajuste/adatta, integra/integra/intègre/integra, alinha/alinea/aligne/allinea. Score language_naturalness 2-3 (lower severity than 13i/13j because false positives possible for transitive meanings). Deterministic linter emits NON-REFLEXIVE-ROMANCE-VERB. 13h. LOANWORD INCONSISTENCY (adtech-heavy languages)."""

CRITIC_MARKER = "13i. REPEATING DISCOURSE MARKERS"


# ============================================================================
# Op 7 — Update v4 baseline test expected-keys list to include Round-2 keys
# ============================================================================

V4_TEST_ANCHOR = """  const expected = [
    "forbidden_phrases", "forbidden_singletons", "greeting_name_adaptation",
    "latin_token_runs", "translationese", "untransliterated_greeting_name",
    "x_not_y",
  ];"""

V4_TEST_NEW = """  const expected = [
    "forbidden_phrases", "forbidden_singletons", "greeting_name_adaptation",
    "latin_token_runs",
    // v4 Round-2 keys
    "non_reflexive_romance_verbs", "repeating_discourse_markers",
    "semicolon_no_connector",
    "translationese", "untransliterated_greeting_name", "x_not_y",
  ];"""

V4_TEST_MARKER = "// v4 Round-2 keys"


OPS = [
    NewFile(
        name="install v4 Round-2 test suite",
        path="api-server/tests/test-nativeness-v4-round2.ts",
        content=_TEST_FILE,
    ),
    Patch(
        name="nativenessV4: inject 3 new detector functions + extend report interface",
        path="api-server/lib/nativenessV4.ts",
        anchor=DETECTOR_INJECT_ANCHOR,
        marker=DETECTOR_INJECT_MARKER,
        new_text=DETECTOR_INJECT_NEW,
    ),
    Patch(
        name="nativenessV4: extend findAllNativenessViolationsV4 aggregator",
        path="api-server/lib/nativenessV4.ts",
        anchor=AGGREGATOR_ANCHOR,
        marker=AGGREGATOR_MARKER,
        new_text=AGGREGATOR_NEW,
        expected_count=1,
    ),
    Patch(
        name="nativenessV4: extend hasAnyViolationV4",
        path="api-server/lib/nativenessV4.ts",
        anchor=HAS_ANY_ANCHOR,
        marker=AGGREGATOR_MARKER,
        new_text=HAS_ANY_NEW,
        expected_count=2,
    ),
    Patch(
        name="doctrineLint: emit 3 new v4 Round-2 lint codes",
        path="api-server/lib/doctrineLint.ts",
        anchor=LINT_ANCHOR,
        marker=LINT_MARKER,
        new_text=LINT_NEW,
    ),
    Patch(
        name="followupPrompts: add criteria 13i, 13j, 13k to critic prompt",
        path="api-server/services/followupPrompts.ts",
        anchor=CRITIC_ANCHOR,
        marker=CRITIC_MARKER,
        new_text=CRITIC_NEW,
    ),
    Patch(
        name="test-nativeness-v4: extend expected-keys list to include Round-2 keys",
        path="api-server/tests/test-nativeness-v4.ts",
        anchor=V4_TEST_ANCHOR,
        marker=V4_TEST_MARKER,
        new_text=V4_TEST_NEW,
    ),
]


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path.cwd()
    print(f"Followuper v4 Round-2 — applying {len(OPS)} operations")
    print(f"Target root: {root}\n")
    counts = {"OK": 0, "SKIP": 0, "FAIL": 0}
    for op in OPS:
        try:
            status, msg = op.apply(root)
        except Exception as exc:
            status, msg = ("FAIL", f"{type(exc).__name__}: {exc}")
        counts[status] = counts.get(status, 0) + 1
        sigil = {"OK": "  OK  ", "SKIP": " SKIP ", "FAIL": " FAIL "}[status]
        print(f"[{sigil}] {op.name}")
        print(f"         {msg}")
    print(f"\nSummary: {counts['OK']} OK, {counts['SKIP']} SKIP, {counts['FAIL']} FAIL")
    if counts["FAIL"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
