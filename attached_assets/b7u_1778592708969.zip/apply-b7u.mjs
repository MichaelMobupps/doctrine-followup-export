// B7u apply script.
//
// Adds Excel export and admin pause/resume:
//   - SCHEMA: users.paused_by_admin (boolean, default false)
//   - DB MIGRATION: ALTER TABLE users ADD COLUMN IF NOT EXISTS (run at startup)
//   - ROUTE: /api/admin/activity-report (XLSX download)
//   - ROUTE: /api/admin/users/:id/pause and /resume
//   - SCHEDULER: skip users where paused_by_admin = true
//   - ROUTE: /api/admin/activity returns paused_by_admin in users[]
//   - DEP: api-server adds "xlsx" (SheetJS)
//   - UI: dashboard page replaced with B7u version (Excel button + pause/resume)
//
// New behaviour for paused users:
//   - sync_and_autoqueue does not auto-queue new stages for them
//   - processDueFollowups skips their queued rows
//   - existing queued rows stay queued (not cancelled), waiting for resume
//
// Schema migration uses CREATE COLUMN IF NOT EXISTS so re-applying is safe.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";
const PATCH_DIR = path.dirname(new URL(import.meta.url).pathname);

async function copyFile(src, dst) {
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
  console.log(`wrote: ${dst}`);
}

async function patchFile(relativePath, edits) {
  const absPath = path.join(WORKSPACE, relativePath);
  let content;
  try { content = await fs.readFile(absPath, "utf8"); }
  catch (err) { throw new Error(`Cannot read ${absPath}: ${err.message}`); }
  let applied = 0, alreadyApplied = 0;
  for (const edit of edits) {
    if (edit.marker && content.includes(edit.marker)) {
      console.log(`  [skip] ${edit.name} (already applied)`);
      alreadyApplied++; continue;
    }
    const occurrences = content.split(edit.search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Edit "${edit.name}" NOT FOUND in ${relativePath}. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Edit "${edit.name}" matched ${occurrences} times in ${relativePath}. Need a more specific anchor.`);
    }
    content = content.replace(edit.search, edit.replace);
    applied++;
    console.log(`  [ok]   ${edit.name}`);
  }
  if (applied > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${relativePath} (applied ${applied}, skipped ${alreadyApplied})`);
  } else {
    console.log(`no-op: ${relativePath} (all ${alreadyApplied} edits already applied)`);
  }
}

// ============================================================
// Step 1 — copy new route files + new page.
// ============================================================
async function copyNewFiles() {
  await copyFile(
    path.join(PATCH_DIR, "files/routes/admin-activity-report.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/routes/admin-activity-report.ts"),
  );
  await copyFile(
    path.join(PATCH_DIR, "files/routes/admin-user-controls.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/routes/admin-user-controls.ts"),
  );
  await copyFile(
    path.join(PATCH_DIR, "files/pages/admin-activity.tsx"),
    path.join(WORKSPACE, "artifacts/dashboard/src/pages/admin-activity.tsx"),
  );
}

// ============================================================
// Step 2 — schema: add pausedByAdmin to users.ts
// ============================================================
const USERS_SCHEMA_EDITS = [
  {
    name: "users.ts: add pausedByAdmin column",
    marker: "B7u: pausedByAdmin column",
    search: `  testMode: boolean("test_mode").notNull().default(false),`,
    replace: `  testMode: boolean("test_mode").notNull().default(false),
  // B7u: pausedByAdmin column. When true, scheduler skips this user
  // entirely (no auto-queueing, no processing of queued follow-ups).
  // Existing queued rows are left in place and resume when unpaused.
  pausedByAdmin: boolean("paused_by_admin").notNull().default(false),`,
  },
];

// ============================================================
// Step 3 — startupMigrations.ts: add ALTER TABLE for users.
// ============================================================
const STARTUP_MIGRATIONS_EDITS = [
  {
    name: "startupMigrations: add users.paused_by_admin migration",
    marker: "B7u: users.paused_by_admin migration",
    search: `  \`CREATE INDEX IF NOT EXISTS idx_followup_usage_app ON followup_usage(app)\`,
];`,
    replace: `  \`CREATE INDEX IF NOT EXISTS idx_followup_usage_app ON followup_usage(app)\`,
  // B7u: users.paused_by_admin migration. ALTER TABLE ADD COLUMN IF
  // NOT EXISTS is idempotent — safe to re-run on every boot.
  \`ALTER TABLE users ADD COLUMN IF NOT EXISTS paused_by_admin BOOLEAN NOT NULL DEFAULT false\`,
];`,
  },
  {
    name: "startupMigrations: rename success log to include B7u",
    marker: "B7r/B7u: migrations applied",
    search: `    logger.info("B7r: followup_usage table ready");`,
    replace: `    logger.info("B7r/B7u: migrations applied (followup_usage table, users.paused_by_admin)");`,
  },
];

// ============================================================
// Step 4 — scheduler.ts: skip paused users in two places.
// ============================================================
const SCHEDULER_EDITS = [
  {
    name: "scheduler: processDueFollowups skips paused users (inline)",
    marker: "B7u: skip paused users in process",
    search: `      if (item.userId && !gmail) {
        logger.warn(
          { followupId: item.followupId, prospectId: item.prospectId, userId: item.userId },
          "User Gmail credentials unavailable — skipping follow-up",
        );
        continue;`,
    replace: `      // B7u: skip paused users in process. Don't generate, don't send.
      // Existing queued rows stay queued until the user is resumed.
      if (item.userId) {
        const cached = userCache.get(item.userId);
        if (cached && cached.pausedByAdmin) {
          logger.info(
            { followupId: item.followupId, prospectId: item.prospectId, userId: item.userId },
            "B7u: user paused by admin — skipping follow-up",
          );
          continue;
        }
      }
      if (item.userId && !gmail) {
        logger.warn(
          { followupId: item.followupId, prospectId: item.prospectId, userId: item.userId },
          "User Gmail credentials unavailable — skipping follow-up",
        );
        continue;`,
  },
  {
    name: "scheduler: sync_and_autoqueue filters out paused users",
    marker: "B7u: exclude paused users from sync",
    search: `  const connectedUsers = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.isConnected, true));`,
    replace: `  // B7u: exclude paused users from sync. Admin-paused users do not
  // auto-queue new stages until they are resumed.
  const connectedUsers = await db
    .select()
    .from(usersTable)
    .where(and(eq(usersTable.isConnected, true), eq(usersTable.pausedByAdmin, false)));`,
  },
];

// ============================================================
// Step 5 — admin-activity.ts: include paused_by_admin in users[] response.
// ============================================================
const ADMIN_ACTIVITY_EDITS = [
  {
    name: "admin-activity: select paused_by_admin in users query",
    marker: "B7u: paused_by_admin in users response",
    search: `    // Q8 — full user list for filter UI dropdown (independent of window).
    const users = await db
      .select({ id: usersTable.id, email: usersTable.email, name: usersTable.name })
      .from(usersTable)
      .orderBy(usersTable.email);`,
    replace: `    // Q8 — full user list for filter UI dropdown (independent of window).
    // B7u: paused_by_admin in users response so the dashboard can show
    // pause/resume buttons in the correct state.
    const users = await db
      .select({
        id: usersTable.id,
        email: usersTable.email,
        name: usersTable.name,
        paused_by_admin: usersTable.pausedByAdmin,
      })
      .from(usersTable)
      .orderBy(usersTable.email);`,
  },
];

// ============================================================
// Step 6 — routes/index.ts: register two new admin routers.
// ============================================================
const ROUTES_INDEX_EDITS = [
  {
    name: "routes/index.ts: import adminActivityReportRouter",
    marker: "B7u: admin activity report",
    search: `// B7s: admin activity rollup (reads followup_usage populated by B7r).
import adminActivityRouter from "./admin-activity";`,
    replace: `// B7s: admin activity rollup (reads followup_usage populated by B7r).
import adminActivityRouter from "./admin-activity";
// B7u: admin activity report (XLSX export).
import adminActivityReportRouter from "./admin-activity-report";
// B7u: admin user controls (pause/resume).
import adminUserControlsRouter from "./admin-user-controls";`,
  },
  {
    name: "routes/index.ts: mount adminActivityReportRouter + adminUserControlsRouter",
    marker: "B7u: mount admin activity report + user controls",
    search: `// B7s: mount admin activity router (X-API-Key gated).
router.use(adminActivityRouter);`,
    replace: `// B7s: mount admin activity router (X-API-Key gated).
router.use(adminActivityRouter);
// B7u: mount admin activity report + user controls (X-API-Key gated).
router.use(adminActivityReportRouter);
router.use(adminUserControlsRouter);`,
  },
];

// ============================================================
// Step 7 — api-server/package.json: add xlsx dependency.
// We patch JSON via the same string-replace pattern. The anchor
// is unique enough that we don't risk false matches.
// ============================================================
const API_SERVER_PACKAGE_EDITS = [
  {
    name: "api-server/package.json: add xlsx dep",
    marker: `"xlsx"`,
    search: `    "pino": "^9",
    "pino-http": "^10"`,
    replace: `    "pino": "^9",
    "pino-http": "^10",
    "xlsx": "0.18.5"`,
  },
];

// ============================================================
// Main.
// ============================================================
async function main() {
  console.log("B7u: Excel export + admin pause/resume for Email Followuper\n");

  console.log("[1/7] copying new files (2 routes + 1 page)");
  await copyNewFiles();
  console.log();

  console.log("[2/7] lib/db/src/schema/users.ts — add pausedByAdmin column");
  await patchFile("lib/db/src/schema/users.ts", USERS_SCHEMA_EDITS);
  console.log();

  console.log("[3/7] api-server/src/lib/startupMigrations.ts — ALTER TABLE for users");
  await patchFile("artifacts/api-server/src/lib/startupMigrations.ts", STARTUP_MIGRATIONS_EDITS);
  console.log();

  console.log("[4/7] api-server/src/services/scheduler.ts — skip paused users");
  await patchFile("artifacts/api-server/src/services/scheduler.ts", SCHEDULER_EDITS);
  console.log();

  console.log("[5/7] api-server/src/routes/admin-activity.ts — return paused_by_admin");
  await patchFile("artifacts/api-server/src/routes/admin-activity.ts", ADMIN_ACTIVITY_EDITS);
  console.log();

  console.log("[6/7] api-server/src/routes/index.ts — register 2 new routers");
  await patchFile("artifacts/api-server/src/routes/index.ts", ROUTES_INDEX_EDITS);
  console.log();

  console.log("[7/7] artifacts/api-server/package.json — add xlsx dep");
  await patchFile("artifacts/api-server/package.json", API_SERVER_PACKAGE_EDITS);
  console.log();

  console.log("B7u applied.");
  console.log("");
  console.log("Next steps (run in the shell):");
  console.log("  1. pnpm install                            (picks up the new xlsx dep)");
  console.log("  2. ./source-code/sync.sh                   (mirror)");
  console.log("  3. pnpm --filter @workspace/api-server run build");
  console.log("  4. pnpm --filter @workspace/dashboard run build");
  console.log("  5. Restart the workflow.");
  console.log("");
  console.log("Boot will log:");
  console.log("  \"B7r/B7u: migrations applied (followup_usage table, users.paused_by_admin)\"");
}

main().catch((err) => {
  console.error("\nB7u apply failed:", err.message);
  process.exit(1);
});
