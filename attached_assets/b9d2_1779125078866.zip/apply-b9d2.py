#!/usr/bin/env python3
"""
B9d.2 - Button polish: focus rings, depth, hierarchy, refined disabled state.

Two anchors in components/ui.tsx, both inside the Button component:
  A1: variants object \u2014 redo all 5 variants with proper focus-visible
      rings, shadow on the primary CTA, clearer hierarchy between
      secondary and outline (currently identical), and accent-tinted
      focus state across the board.
  A2: base className composition \u2014 smoother transition timing,
      better disabled visuals (opacity 40 + cursor not-allowed instead
      of opacity 30 alone), keep active:scale.

Variants after this patch:
  default     - solid accent, white text, subtle shadow, accent ring with
                offset on focus. The premium CTA.
  secondary   - bg-tertiary fill, bordered, lifts to bg-elevated on
                hover. Now visually distinct from outline (was identical).
  outline     - transparent with border, fills on hover. Minimal action.
  ghost       - no border, no bg, picks up text + bg on hover.
  destructive - red border + tint, deepens on hover, danger ring.

Cross-product: all colors via CSS vars. Doctrine/Context dark theme +
AG light theme both inherit correctly because the tokens differ per
[data-product] but the structure is the same.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: variants object
# ====================================================================
A1_OLD = '''    const variants = {
      default: "bg-[var(--accent)] text-white hover:bg-[var(--accent-hover)] border-none",
      secondary: "bg-transparent text-[var(--text-secondary)] border border-[var(--border-default)] hover:text-[var(--text-primary)] hover:border-[var(--border-hover)] hover:bg-[var(--bg-tertiary)]",
      outline: "bg-transparent text-[var(--text-secondary)] border border-[var(--border-default)] hover:text-[var(--text-primary)] hover:border-[var(--border-hover)] hover:bg-[var(--bg-tertiary)]",
      ghost: "bg-transparent text-[var(--text-tertiary)] border-none hover:text-[var(--text-secondary)]",
      destructive: "bg-transparent text-[var(--danger)] border border-[var(--danger-border)] hover:bg-[var(--danger-muted)]",
    };'''

A1_NEW = '''    // B9d.2: refined variants \u2014 shadow + focus rings on primary CTAs,
    // proper secondary vs outline differentiation, accent-tinted focus.
    const variants = {
      default: "bg-[var(--accent)] text-white border border-[var(--accent)] shadow-sm hover:bg-[var(--accent-hover)] hover:border-[var(--accent-hover)] focus-visible:ring-2 focus-visible:ring-[var(--accent)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]",
      secondary: "bg-[var(--bg-tertiary)] text-[var(--text-primary)] border border-[var(--border-default)] hover:bg-[var(--bg-elevated)] hover:border-[var(--border-hover)] focus-visible:ring-2 focus-visible:ring-[var(--accent)]",
      outline: "bg-transparent text-[var(--text-secondary)] border border-[var(--border-default)] hover:text-[var(--text-primary)] hover:border-[var(--border-hover)] hover:bg-[var(--bg-tertiary)] focus-visible:ring-2 focus-visible:ring-[var(--accent)]",
      ghost: "bg-transparent text-[var(--text-tertiary)] border border-transparent hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)] focus-visible:ring-2 focus-visible:ring-[var(--accent)]",
      destructive: "bg-transparent text-[var(--danger)] border border-[var(--danger-border)] hover:bg-[var(--danger-muted)] hover:border-[var(--danger)] focus-visible:ring-2 focus-visible:ring-[var(--danger)] focus-visible:ring-offset-2 focus-visible:ring-offset-[var(--bg-primary)]",
    };'''


# ====================================================================
# A2: base className composition
# ====================================================================
A2_OLD = '''        className={cn(
          "inline-flex items-center justify-center font-medium rounded-md transition-all duration-150 focus-visible:outline-none disabled:opacity-30 disabled:pointer-events-none active:scale-[0.98]",'''

A2_NEW = '''        className={cn(
          // B9d.2: smoother 200ms transition + better disabled state.
          "inline-flex items-center justify-center font-medium rounded-md transition-all duration-200 focus-visible:outline-none disabled:opacity-40 disabled:cursor-not-allowed disabled:pointer-events-none active:scale-[0.98]",'''


def main():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: refined Button variants",
        marker="B9d.2: refined variants",
    )

    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: base className composition",
        marker="B9d.2: smoother 200ms transition",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already patched")

    print()
    print("B9d.2 button polish applied.")


if __name__ == "__main__":
    main()
