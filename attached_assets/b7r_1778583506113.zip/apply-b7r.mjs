// B7r apply script.
//
// Adds per-LLM-call usage tracking to the Email Followuper:
//   - new table `followup_usage` (created at server startup, idempotent)
//   - new files: schema, pricing, usage context (AsyncLocalStorage), tracker
//   - 6 generator call sites wrapped to record usage best-effort
//   - scheduler wraps generator calls with the usage context
//   - index.ts runs the startup migration before listen()
//
// All capture is wrapped in try/catch so a tracker bug cannot break
// follow-up sends. The table uses CREATE TABLE IF NOT EXISTS so
// re-applying after the table already exists is a clean no-op.
//
// Same surgical string-replace pattern as B7p/B7q with idempotency markers.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";
const PATCH_DIR = path.dirname(new URL(import.meta.url).pathname);

// ---- helpers ----

async function copyFile(src, dst) {
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
  console.log(`wrote: ${dst}`);
}

async function patchFile(relativePath, edits) {
  const absPath = path.join(WORKSPACE, relativePath);
  let content;
  try { content = await fs.readFile(absPath, "utf8"); }
  catch (err) { throw new Error(`Cannot read ${absPath}: ${err.message}`); }
  let applied = 0, alreadyApplied = 0;
  for (const edit of edits) {
    if (edit.marker && content.includes(edit.marker)) {
      console.log(`  [skip] ${edit.name} (already applied)`);
      alreadyApplied++; continue;
    }
    const occurrences = content.split(edit.search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Edit "${edit.name}" NOT FOUND in ${relativePath}. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Edit "${edit.name}" matched ${occurrences} times in ${relativePath}. Need a more specific anchor.`);
    }
    content = content.replace(edit.search, edit.replace);
    applied++;
    console.log(`  [ok]   ${edit.name}`);
  }
  if (applied > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${relativePath} (applied ${applied}, skipped ${alreadyApplied})`);
  } else {
    console.log(`no-op: ${relativePath} (all ${alreadyApplied} edits already applied)`);
  }
}

// ============================================================
// Step 1: copy new files into the workspace.
// ============================================================
async function copyNewFiles() {
  await copyFile(
    path.join(PATCH_DIR, "files/schema/followup-usage.ts"),
    path.join(WORKSPACE, "lib/db/src/schema/followup-usage.ts"),
  );
  await copyFile(
    path.join(PATCH_DIR, "files/lib/pricing.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/lib/pricing.ts"),
  );
  await copyFile(
    path.join(PATCH_DIR, "files/lib/usageContext.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/lib/usageContext.ts"),
  );
  await copyFile(
    path.join(PATCH_DIR, "files/lib/usageTracker.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/lib/usageTracker.ts"),
  );
  await copyFile(
    path.join(PATCH_DIR, "files/lib/startupMigrations.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/lib/startupMigrations.ts"),
  );
}

// ============================================================
// Step 2: schema index export.
// ============================================================
const SCHEMA_INDEX_EDITS = [
  {
    name: "schema/index: re-export followup-usage",
    marker: "B7r: followup_usage usage ledger",
    search: `// Phase 7n: cron heartbeat table for liveness observability.
export * from "./cron-heartbeats";`,
    replace: `// Phase 7n: cron heartbeat table for liveness observability.
export * from "./cron-heartbeats";
// B7r: followup_usage usage ledger (per-LLM-call attribution).
export * from "./followup-usage";`,
  },
];

// ============================================================
// Step 3: scheduler wraps generator calls with usage context.
// ============================================================
const SCHEDULER_EDITS = [
  {
    name: "scheduler: import runWithUsageContext",
    marker: "B7r: usage context import",
    search: `import { generateContextFollowup } from "./contextFollowupGenerator";`,
    replace: `import { generateContextFollowup } from "./contextFollowupGenerator";
// B7r: usage context import. Wraps generator calls so the recordUsage
// helper inside the generators knows which followup the LLM call is for.
import { runWithUsageContext } from "../lib/usageContext";`,
  },
  {
    name: "scheduler: wrap generator dispatch with usage context",
    marker: "B7r: wrap generator dispatch",
    search: `      const generated = item.app === "context"
        ? await generateContextFollowup(ctx)
        : await generateFollowupEmail(ctx);`,
    replace: `      // B7r: wrap generator dispatch with the usage context so
      // recordUsageBestEffort() inside the generator knows what to attribute.
      const generated = await runWithUsageContext(
        {
          followupId: item.followupId,
          prospectId: item.prospectId,
          userId: item.userId,
          app: item.app === "context" ? "context" : "doctrine",
          stage: item.stage,
        },
        () => item.app === "context"
          ? generateContextFollowup(ctx)
          : generateFollowupEmail(ctx),
      );`,
  },
];

// ============================================================
// Step 4: followupGenerator — wrap 3 anthropic call sites.
// Pattern: insert recordUsageBestEffort(response, "label") after each
// `await withAnthropicRetry(...)` returns.
// ============================================================
const FOLLOWUP_GEN_EDITS = [
  {
    name: "followupGenerator: import recordUsageBestEffort",
    marker: "B7r: usage tracker import",
    search: `import { withAnthropicRetry } from "./anthropicRetry";`,
    replace: `import { withAnthropicRetry } from "./anthropicRetry";
// B7r: usage tracker import. recordUsageBestEffort is no-op when called
// outside a runWithUsageContext scope, so safe to call from any path.
import { recordUsageBestEffort } from "../lib/usageTracker";`,
  },
  {
    name: "followupGenerator draft: record usage",
    marker: `recordUsageBestEffort(response, "draft")`,
    search: `  const response = await withAnthropicRetry(
    () => anthropic.messages.create({
      model: MODEL_DRAFT_GENERATOR,
      max_tokens: 8192,
      system: getFollowupSystemPrompt(),
      messages: [{ role: "user", content: getFollowupUserPrompt(ctx) }],
    }),
    { label: "draft" },
  );`,
    replace: `  const response = await withAnthropicRetry(
    () => anthropic.messages.create({
      model: MODEL_DRAFT_GENERATOR,
      max_tokens: 8192,
      system: getFollowupSystemPrompt(),
      messages: [{ role: "user", content: getFollowupUserPrompt(ctx) }],
    }),
    { label: "draft" },
  );
  // B7r: capture token usage for the activity log. Fire-and-forget.
  void recordUsageBestEffort(response, "draft");`,
  },
  {
    name: "followupGenerator critic: record usage",
    marker: `recordUsageBestEffort(response, "critic")`,
    search: `  const response = await withAnthropicRetry(
    () => anthropic.messages.create({
      model: MODEL_CRITIC,
      max_tokens: 8192,
      system: getCriticSystemPrompt(),
      messages: [{ role: "user", content: getCriticUserPrompt(ctx, draft) }],
    }),
    { label: "critic" },
  );`,
    replace: `  const response = await withAnthropicRetry(
    () => anthropic.messages.create({
      model: MODEL_CRITIC,
      max_tokens: 8192,
      system: getCriticSystemPrompt(),
      messages: [{ role: "user", content: getCriticUserPrompt(ctx, draft) }],
    }),
    { label: "critic" },
  );
  // B7r: capture token usage for the activity log.
  void recordUsageBestEffort(response, "critic");`,
  },
  {
    name: "followupGenerator rewriter: record usage",
    marker: `recordUsageBestEffort(response, "rewriter")`,
    search: `  const response = await withAnthropicRetry(
    () => anthropic.messages.create({
      model: MODEL_REWRITER,
      max_tokens: 8192,
      system: getRewriterSystemPrompt(),
      messages: [{
        role: "user",
        content: getRewriterUserPrompt(ctx, draft, {
          issues: critique.issues,
          suggestions: critique.suggestions,
        }),
      }],
    }),
    { label: "rewriter" },
  );`,
    replace: `  const response = await withAnthropicRetry(
    () => anthropic.messages.create({
      model: MODEL_REWRITER,
      max_tokens: 8192,
      system: getRewriterSystemPrompt(),
      messages: [{
        role: "user",
        content: getRewriterUserPrompt(ctx, draft, {
          issues: critique.issues,
          suggestions: critique.suggestions,
        }),
      }],
    }),
    { label: "rewriter" },
  );
  // B7r: capture token usage for the activity log.
  void recordUsageBestEffort(response, "rewriter");`,
  },
];

// ============================================================
// Step 5: contextFollowupGenerator — wrap 3 anthropic call sites.
// ============================================================
const CONTEXT_GEN_EDITS = [
  {
    name: "contextFollowupGenerator: import recordUsageBestEffort",
    marker: "B7r: usage tracker import",
    search: `import { withAnthropicRetry } from "./anthropicRetry";`,
    replace: `import { withAnthropicRetry } from "./anthropicRetry";
// B7r: usage tracker import. Safe outside a runWithUsageContext scope.
import { recordUsageBestEffort } from "../lib/usageTracker";`,
  },
];

// ============================================================
// Step 6: index.ts — run startup migration before listen().
// ============================================================
const INDEX_EDITS = [
  {
    name: "index.ts: import startup migration",
    marker: "B7r: startup migrations import",
    search: `import app from "./app";
import { logger } from "./lib/logger";
import { startCronJobs } from "./cron";`,
    replace: `import app from "./app";
import { logger } from "./lib/logger";
import { startCronJobs } from "./cron";
// B7r: startup migrations import (currently: ensure followup_usage table exists).
import { runStartupMigrations } from "./lib/startupMigrations";`,
  },
  {
    name: "index.ts: kick off startup migration before listen call",
    marker: "B7r: kick off startup migrations",
    search: `const server = app.listen(port, (err) => {`,
    replace: `// B7r: kick off startup migrations. Fire-and-forget so a slow DB
// connection cannot block the listen() call (Replit healthchecks
// could time out otherwise). recordUsageBestEffort() is already
// best-effort, so the rare window where the table is not yet
// present just results in warnings, not failed sends.
runStartupMigrations().catch((err) =>
  logger.error({ err }, "B7r: startup migration kickoff failed (non-fatal)"),
);

const server = app.listen(port, (err) => {`,
  },
];

// ============================================================
// Main.
// ============================================================
async function main() {
  console.log("B7r: per-call usage tracking for Email Followuper\n");

  console.log("[1/6] copying new files");
  await copyNewFiles();
  console.log();

  console.log("[2/6] lib/db/src/schema/index.ts — re-export followup-usage");
  await patchFile("lib/db/src/schema/index.ts", SCHEMA_INDEX_EDITS);
  console.log();

  console.log("[3/6] api-server/src/services/scheduler.ts — wrap generator dispatch");
  await patchFile("artifacts/api-server/src/services/scheduler.ts", SCHEDULER_EDITS);
  console.log();

  console.log("[4/6] api-server/src/services/followupGenerator.ts — record usage for draft/critic/rewriter");
  await patchFile("artifacts/api-server/src/services/followupGenerator.ts", FOLLOWUP_GEN_EDITS);
  console.log();

  console.log("[5/6] api-server/src/services/contextFollowupGenerator.ts — import tracker");
  await patchFile("artifacts/api-server/src/services/contextFollowupGenerator.ts", CONTEXT_GEN_EDITS);
  // The 3 context generator call sites use varying labels — patched separately:
  await patchContextGeneratorCallSites();
  console.log();

  console.log("[6/6] api-server/src/index.ts — run startup migration before listen");
  await patchFile("artifacts/api-server/src/index.ts", INDEX_EDITS);
  console.log();

  console.log("B7r applied. Next: build api-server, restart workflow, deploy to production.");
  console.log("On first boot you should see in the logs: \"B7r: followup_usage table ready\".");
  console.log("On the next follow-up generation the followup_usage table will start receiving rows.");
}

// The three context generator call sites all use the same structure
// but different model constants and labels. We patch them generically
// by matching the model constant + label combo and inserting one line.
async function patchContextGeneratorCallSites() {
  const file = "artifacts/api-server/src/services/contextFollowupGenerator.ts";
  const absPath = path.join(WORKSPACE, file);
  let content = await fs.readFile(absPath, "utf8");

  const triples = [
    { model: "MODEL_CONTEXT_GENERATOR", label: "context_generator", scope: "context-draft" },
    { model: "MODEL_CONTEXT_CRITIC",    label: "context_critic",    scope: "context-critic" },
    { model: "MODEL_CONTEXT_REWRITER",  label: "context_rewriter",  scope: "context-rewriter" },
  ];

  let appliedCount = 0;
  let skippedCount = 0;

  for (const { label, scope } of triples) {
    const marker = `recordUsageBestEffort(response, "${label}")`;
    if (content.includes(marker)) {
      console.log(`  [skip] context call site: ${label} (already applied)`);
      skippedCount++;
      continue;
    }
    // Match the closing of withAnthropicRetry that has { label: "<scope>" }.
    const search = `    { label: "${scope}" },\n  );`;
    const occurrences = content.split(search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Context call site for label "${scope}" not found. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Context call site for label "${scope}" matched ${occurrences} times — anchor not specific enough.`);
    }
    const replace = `    { label: "${scope}" },\n  );\n  // B7r: capture token usage for the activity log.\n  void recordUsageBestEffort(response, "${label}");`;
    content = content.replace(search, replace);
    appliedCount++;
    console.log(`  [ok]   context call site: ${label}`);
  }
  if (appliedCount > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${file} (applied ${appliedCount}, skipped ${skippedCount})`);
  } else {
    console.log(`no-op: ${file} (all 3 call sites already applied)`);
  }
}

main().catch((err) => {
  console.error("\nB7r apply failed:", err.message);
  console.error("\nNo partial writes happened for any file that failed mid-edit.");
  process.exit(1);
});
