# Followuper Doctrine + Language-Nativeness Hardening — v1

Companion to the Prospector v1/v2 work. Brings the same hardening layer to
the Followuper api-server: deterministic doctrine + language-nativeness
checks that run alongside the existing `detectMetaLanguage` pre-flight,
plus a doctrine block in the writer/critic/rewriter prompts.

## What ships in this bundle

```
followuper-doctrine-v1/
├── lib/
│   ├── doctrineRules.ts            NEW  916 lines  36-lang data tables + helpers
│   └── doctrineLint.ts             NEW  ~280 lines  deterministic detectors
├── tests/
│   └── test-doctrine-hardening.ts  NEW  29 tests, node --test runner
├── patches/
│   └── apply_patches.py            NEW  10 ops, idempotent anchor-based
└── README.md
```

The patches modify three existing files via anchor-based string replacement:

* `services/followupPrompts.ts` (writer block + critic criterion 9 + JSON
  schema field + needs_rewrite trigger + rewriter doctrine line — 5 ops)
* `services/followupGenerator.ts` (import + detector call + merge block — 3 ops)
* `services/contextFollowupGenerator.ts` (import + detector wiring — 2 ops)

Backups go to `.backups/followuper-doctrine-v1/` under the base directory.
Re-running the patch script after success is a no-op (marker-based
idempotency).

## What gets detected

**Doctrine** (applies to every follow-up, all languages):
* HEDGED NUMBER — "around 250", "приблизительно 250", "ungefähr 250",
  "ประมาณ 250", and 30+ more language-specific patterns
* HYPE ADJECTIVES — "strong", "powerful", "significant", "innovative",
  "best-in-class", "industry-leading", plus inflected forms in
  Latin-script languages (German "starke" matches "stark" stem)
* MULTI-EVENT OPTIMIZATION — "anchor on installs or signups or sessions"
* CPA-AS-DIFFERENTIATOR — "we pay only for X, not Y" framing

**Language nativeness** (only for non-Latin-script target languages):
* LATIN-TOKEN-LEAK — 2+ consecutive lowercase English words inside
  Thai / Chinese / Japanese / Korean / Hebrew / Arabic / Russian / Greek /
  Hindi / Bengali / Persian / Urdu / Ukrainian prose
* Permitted: industry-standard acronyms (UA, LTV, ROAS, CPI, CPA, MMP,
  DSP, SDK, IAP, KPI, MAU, DAU, ARPU, plus iOS/AI/ML/SaaS/etc) and
  proper-noun runs (all-capitalized: "Brand Day", "King Power Online",
  "Watsons Thailand")

## Test fixtures

The test suite includes the verbatim Thai email body from the production
failure screenshot. The detector flags ONLY "quality user acquisition" —
the multi-word lowercase English phrase — while letting through every
acceptable token: UA, LTV, "Brand Day", "Super Brand Day", "Central App",
"King Power Online", "Watsons Thailand", and the per-Thai-guide-allowed
singletons (cohort, acquire, event, convert, campaign, email).

## How to apply

See the bash block shipped alongside this README in chat.
