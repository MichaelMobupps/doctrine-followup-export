#!/usr/bin/env node
/**
 * apply-batch7b.mjs — Phase 7b (Context Based backend pipeline).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Touches:
 *   - artifacts/api-server/src/lib/anthropic.ts             (3 new MODEL_CONTEXT_* consts)
 *   - artifacts/api-server/src/services/scheduler.ts        (dispatcher branches on app)
 *   - artifacts/api-server/src/services/gmailSync.ts        (scan both labels, tag inserts)
 *   - artifacts/api-server/src/services/contextFollowupGenerator.ts (NEW from payload)
 *   - artifacts/api-server/src/services/contextFollowupPrompts.ts   (NEW from payload)
 *   - artifacts/api-server/src/routes/context.ts            (NEW from payload)
 *   - artifacts/api-server/src/routes/index.ts              (register context router under /context)
 *
 * Does NOT touch routes/doctrine.ts. The doctrine route filter (so
 * /api/stats etc. don't return context prospects) is deferred to 7c
 * along with the UI work.
 *
 * After this script runs, the context flow is functionally live for any
 * thread labeled with the user's `contextLabel` (default "Context
 * Followuper"). Until 7c ships, the existing Doctrine UI may show
 * context prospects mixed with doctrine prospects — see README.
 *
 * Usage:
 *   node apply-batch7b.mjs
 *   API_BASE=artifacts/api-server/src node apply-batch7b.mjs
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const PAYLOAD_DIR = join(SCRIPT_DIR, "payload");

const log  = (msg) => console.log(`[apply-batch7b] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7b] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

function copyPayload(srcRel, dstAbs, label) {
  const src = join(PAYLOAD_DIR, srcRel);
  if (!existsSync(src)) fail(`payload missing: ${src}`);
  copyFileSync(src, dstAbs);
  log(`  [+] ${label}`);
}

// ============================================================
// Step 1: Install payload service files
// ============================================================
log("Step 1: Installing payload services...");
const servicesDir = join(API_BASE, "services");
if (!existsSync(servicesDir)) fail(`api-server services dir missing: ${servicesDir}`);

copyPayload(
  "services/contextFollowupPrompts.ts",
  join(servicesDir, "contextFollowupPrompts.ts"),
  "services/contextFollowupPrompts.ts installed",
);
copyPayload(
  "services/contextFollowupGenerator.ts",
  join(servicesDir, "contextFollowupGenerator.ts"),
  "services/contextFollowupGenerator.ts installed",
);

// ============================================================
// Step 2: Install routes/context.ts
// ============================================================
log("Step 2: Installing routes/context.ts...");
const routesDir = join(API_BASE, "routes");
if (!existsSync(routesDir)) fail(`api-server routes dir missing: ${routesDir}`);

copyPayload(
  "routes/context.ts",
  join(routesDir, "context.ts"),
  "routes/context.ts installed",
);

// ============================================================
// Step 3: Add MODEL_CONTEXT_* constants to lib/anthropic.ts
// ============================================================
log("Step 3: Patching lib/anthropic.ts (add 3 MODEL_CONTEXT_* exports)...");
const anthropicLibPath = join(API_BASE, "lib", "anthropic.ts");

strReplace(
  anthropicLibPath,
  `export const MODEL_REWRITER:        "claude-sonnet-4-6" = "claude-sonnet-4-6";`,
  `export const MODEL_REWRITER:        "claude-sonnet-4-6" = "claude-sonnet-4-6";

/**
 * Phase 7b: model identifiers for the Context Based Followuper.
 *
 * Same 3-call pipeline shape as the Doctrine flow (Sonnet → Opus → Sonnet),
 * separate constants so the two products can be retuned independently.
 *
 * Roles:
 *   CONTEXT_GENERATOR — drafts the follow-up referencing prior thread context
 *   CONTEXT_CRITIC    — Opus critic; catches hallucinations, off-tone, length violations
 *   CONTEXT_REWRITER  — applies critic feedback to produce the final draft
 */
export const MODEL_CONTEXT_GENERATOR: "claude-sonnet-4-6" = "claude-sonnet-4-6";
export const MODEL_CONTEXT_CRITIC:    "claude-opus-4-7"   = "claude-opus-4-7";
export const MODEL_CONTEXT_REWRITER:  "claude-sonnet-4-6" = "claude-sonnet-4-6";`,
  "lib/anthropic.ts: add 3 MODEL_CONTEXT_* constants",
  `export const MODEL_CONTEXT_GENERATOR:`
);

// ============================================================
// Step 4: Patch scheduler.ts — dispatcher branches on prospects.app
// ============================================================
log("Step 4: Patching scheduler.ts (dispatcher branches on prospects.app)...");
const schedulerPath = join(API_BASE, "services", "scheduler.ts");

// 4a: Import the context generator at the top
strReplace(
  schedulerPath,
  `import { isInSendWindow } from "../lib/scheduleWindow";
import { checkSendBudget } from "../lib/sendBudget";`,
  `import { isInSendWindow } from "../lib/scheduleWindow";
import { checkSendBudget } from "../lib/sendBudget";
import { generateContextFollowup } from "./contextFollowupGenerator";`,
  "scheduler.ts: import generateContextFollowup",
  `import { generateContextFollowup } from "./contextFollowupGenerator";`
);

// 4b: SELECT prospects.app in the due-rows query so we can branch on it
strReplace(
  schedulerPath,
  `      gmailMessageId: prospectsTable.gmailMessageId,
      sentAt: prospectsTable.sentAt,
      userId: prospectsTable.userId,
    })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))`,
  `      gmailMessageId: prospectsTable.gmailMessageId,
      sentAt: prospectsTable.sentAt,
      userId: prospectsTable.userId,
      // Phase 7b: discriminator for which generator to use per row.
      app: prospectsTable.app,
    })
    .from(followupsTable)
    .innerJoin(prospectsTable, eq(followupsTable.prospectId, prospectsTable.id))`,
  "scheduler.ts: SELECT prospects.app in due-rows query",
  `// Phase 7b: discriminator for which generator to use per row.`
);

// 4c: Branch generation: doctrine → existing generateFollowupEmail; context → generateContextFollowup
strReplace(
  schedulerPath,
  `      const generated = await generateFollowupEmail(ctx);`,
  `      // Phase 7b: route generation by product. Doctrine flow uses the
      // doctrine prompts + 3-call pipeline. Context flow uses its own
      // prompts (no doctrine, faithful-to-context).
      const generated = item.app === "context"
        ? await generateContextFollowup(ctx)
        : await generateFollowupEmail(ctx);`,
  "scheduler.ts: branch generator on item.app",
  `Phase 7b: route generation by product.`
);

// ============================================================
// Step 5: Patch gmailSync.ts — scan both labels, tag inserts
// ============================================================
log("Step 5: Patching gmailSync.ts (scan both labels, tag inserts)...");
const gmailSyncPath = join(API_BASE, "services", "gmailSync.ts");

// 5a: Update the syncForUser type signature to also receive contextLabel
strReplace(
  gmailSyncPath,
  `async function syncForUser(user: {
  id: number;
  email: string;
  name: string;
  googleRefreshToken: string;
  doctrineLabel: string;
}): Promise<{ synced: number; repliesDetected: number }> {`,
  `async function syncForUser(user: {
  id: number;
  email: string;
  name: string;
  googleRefreshToken: string;
  doctrineLabel: string;
  // Phase 7b: Gmail label that scopes ingest into the Context Based flow.
  contextLabel: string;
}): Promise<{ synced: number; repliesDetected: number }> {`,
  "gmailSync.ts: add contextLabel to syncForUser type",
  `// Phase 7b: Gmail label that scopes ingest into the Context Based flow.`
);

// 5b: After the doctrine ingest loop, add a parallel context ingest loop
//
// Anchor: the existing block that does the doctrine ingest. We replace
// the entire doctrine ingest block (parsing labels, fetching, looping)
// with an extended version that also handles context.
strReplace(
  gmailSyncPath,
  `  const labels = user.doctrineLabel.split(",").map((l) => l.trim()).filter(Boolean);

  await ensureLabelsExist(labels, gmail);

  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  const afterDate = sixtyDaysAgo.toISOString().split("T")[0].replace(/-/g, "/");

  logger.info({ labels, afterDate, userId: user.id, email: user.email }, "Syncing emails for user");
  const messages = await fetchLabeledSentEmails(labels, afterDate, gmail);
  logger.info({ count: messages.length, userId: user.id }, "Found labeled sent emails");

  let synced = 0;
  let conflicts = 0;
  let skipped = 0;
  for (const msg of messages) {`,
  `  const doctrineLabels = user.doctrineLabel.split(",").map((l) => l.trim()).filter(Boolean);
  // Phase 7b: parallel ingest path for context-labeled threads. Each
  // discovered thread is tagged with prospects.app='context' so the
  // dispatcher routes it to the context generator instead of the
  // doctrine pipeline.
  const contextLabels = (user.contextLabel || "").split(",").map((l) => l.trim()).filter(Boolean);
  const allLabels = [...doctrineLabels, ...contextLabels];

  await ensureLabelsExist(allLabels, gmail);

  const sixtyDaysAgo = new Date();
  sixtyDaysAgo.setDate(sixtyDaysAgo.getDate() - 60);
  const afterDate = sixtyDaysAgo.toISOString().split("T")[0].replace(/-/g, "/");

  // Fetch doctrine and context label sets independently so we know which
  // bucket each message belongs to. Doctrine messages may share threads
  // with context messages; the per-message label list is what disambiguates.
  logger.info({ doctrineLabels, contextLabels, afterDate, userId: user.id, email: user.email }, "Syncing emails for user");
  const doctrineMessages = doctrineLabels.length > 0
    ? await fetchLabeledSentEmails(doctrineLabels, afterDate, gmail)
    : [];
  const contextMessages = contextLabels.length > 0
    ? await fetchLabeledSentEmails(contextLabels, afterDate, gmail)
    : [];

  // Tag each message with its app bucket. If a message somehow appears
  // in both label sets (user labeled the same thread with both labels),
  // doctrine wins — the doctrine flow is the original product.
  const taggedMessages: Array<{ msg: typeof doctrineMessages[number]; app: "doctrine" | "context" }> = [];
  const seenIds = new Set<string>();
  for (const m of doctrineMessages) {
    if (seenIds.has(m.id)) continue;
    seenIds.add(m.id);
    taggedMessages.push({ msg: m, app: "doctrine" });
  }
  for (const m of contextMessages) {
    if (seenIds.has(m.id)) continue;
    seenIds.add(m.id);
    taggedMessages.push({ msg: m, app: "context" });
  }

  logger.info(
    { doctrine: doctrineMessages.length, context: contextMessages.length, total: taggedMessages.length, userId: user.id },
    "Found labeled sent emails (split by app)",
  );

  let synced = 0;
  let conflicts = 0;
  let skipped = 0;
  for (const { msg, app } of taggedMessages) {`,
  "gmailSync.ts: split label scan into doctrine + context buckets",
  `// Phase 7b: parallel ingest path for context-labeled threads.`
);

// 5c: When inserting the prospect, set the `app` field accordingly. Also
//     keep batchLabel pointing to the right user-side label.
strReplace(
  gmailSyncPath,
  `    const insertResult = await db
      .insert(prospectsTable)
      .values({
        userId: user.id,
        gmailMessageId: msg.id,
        gmailThreadId: msg.threadId,
        prospectName: recipientName,
        company: inferCompany(recipientEmail),
        email: recipientEmail,
        vertical,
        subVertical,
        product: inferProduct(vertical),
        subject: msg.subject,
        originalBodySummary: bodySummary,
        originalBody: prepareOriginalBody(msg.body),
        originalLanguage,
        batchLabel: user.doctrineLabel,
        sentAt: new Date(msg.date),
      })
      .onConflictDoNothing({ target: prospectsTable.gmailMessageId });`,
  `    const insertResult = await db
      .insert(prospectsTable)
      .values({
        userId: user.id,
        gmailMessageId: msg.id,
        gmailThreadId: msg.threadId,
        prospectName: recipientName,
        company: inferCompany(recipientEmail),
        email: recipientEmail,
        vertical,
        subVertical,
        product: inferProduct(vertical),
        subject: msg.subject,
        originalBodySummary: bodySummary,
        originalBody: prepareOriginalBody(msg.body),
        originalLanguage,
        // Phase 7b: per-row app + corresponding label.
        batchLabel: app === "context" ? user.contextLabel : user.doctrineLabel,
        app,
        sentAt: new Date(msg.date),
      })
      .onConflictDoNothing({ target: prospectsTable.gmailMessageId });`,
  "gmailSync.ts: tag insert with app + correct batchLabel",
  `// Phase 7b: per-row app + corresponding label.`
);

// 5d: The two callers of syncForUser pass `user.doctrineLabel`. They need
//     to also pass `contextLabel`. Update both call sites.
// Call site 1 (line ~385): top-level `return syncForUser({...})` inline literal.
strReplace(
  gmailSyncPath,
  `  return syncForUser({
    id: user.id,
    email: user.email,
    name: user.name,
    googleRefreshToken: user.googleRefreshToken,
    doctrineLabel: user.doctrineLabel,
  });`,
  `  return syncForUser({
    id: user.id,
    email: user.email,
    name: user.name,
    googleRefreshToken: user.googleRefreshToken,
    doctrineLabel: user.doctrineLabel,
    // Phase 7b: forward the user's context label into syncForUser.
    contextLabel: user.contextLabel,
  });`,
  "gmailSync.ts: pass contextLabel into syncForUser (call site 1)",
  `// Phase 7b: forward the user's context label into syncForUser.`
);

// Call site 2 (line ~420): `const result = await syncForUser({...})` inline literal in the loop.
strReplace(
  gmailSyncPath,
  `      const result = await syncForUser({
        id: user.id,
        email: user.email,
        name: user.name,
        googleRefreshToken: user.googleRefreshToken,
        doctrineLabel: user.doctrineLabel,
      });`,
  `      const result = await syncForUser({
        id: user.id,
        email: user.email,
        name: user.name,
        googleRefreshToken: user.googleRefreshToken,
        doctrineLabel: user.doctrineLabel,
        // Phase 7b: forward the user's context label into syncForUser (loop).
        contextLabel: user.contextLabel,
      });`,
  "gmailSync.ts: pass contextLabel into syncForUser (call site 2)",
  `// Phase 7b: forward the user's context label into syncForUser (loop).`
);

// ============================================================
// Step 6: Register context router in routes/index.ts under /context
// ============================================================
log("Step 6: Patching routes/index.ts (register context router)...");
const routesIndexPath = join(API_BASE, "routes", "index.ts");

strReplace(
  routesIndexPath,
  `import doctrineRouter from "./doctrine";
import gmailAuthRouter from "./gmail-auth";
import emailInspectorRouter from "./email-inspector";`,
  `import doctrineRouter from "./doctrine";
import gmailAuthRouter from "./gmail-auth";
import emailInspectorRouter from "./email-inspector";
import contextRouter from "./context";`,
  "routes/index.ts: import contextRouter",
  `import contextRouter from "./context";`
);

strReplace(
  routesIndexPath,
  `router.use(doctrineRouter);
router.use(emailInspectorRouter);`,
  `router.use(doctrineRouter);
router.use(emailInspectorRouter);
// Phase 7b: Context Based Followuper. Mounted under /context so URLs are
// /api/context/stats, /api/context/followups, etc. The doctrine router
// stays at the root (existing UI routes) until 7c adds parallel scoping.
router.use("/context", contextRouter);`,
  "routes/index.ts: mount contextRouter under /context",
  `router.use("/context", contextRouter);`
);

// ============================================================
// Step 7: Self-verify
// ============================================================
log("Step 7: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found: ${needle.slice(0, 70)}...`);
  log(`  [OK] ${label}`);
}

expectInFile(join(servicesDir, "contextFollowupPrompts.ts"),    `export const CONTEXT_GENERATOR_SYSTEM`, "V1a prompts file installed");
expectInFile(join(servicesDir, "contextFollowupGenerator.ts"),  `export async function generateContextFollowup`, "V1b generator file installed");
expectInFile(join(routesDir, "context.ts"),                     `eq(prospectsTable.app, "context")`, "V1c context routes scoped to context");

expectInFile(anthropicLibPath, `export const MODEL_CONTEXT_GENERATOR:`, "V2a MODEL_CONTEXT_GENERATOR");
expectInFile(anthropicLibPath, `export const MODEL_CONTEXT_CRITIC:`,    "V2b MODEL_CONTEXT_CRITIC");
expectInFile(anthropicLibPath, `export const MODEL_CONTEXT_REWRITER:`,  "V2c MODEL_CONTEXT_REWRITER");

expectInFile(schedulerPath, `import { generateContextFollowup }`,                  "V3a scheduler imports context generator");
expectInFile(schedulerPath, `app: prospectsTable.app,`,                            "V3b scheduler selects prospects.app");
expectInFile(schedulerPath, `item.app === "context"`,                              "V3c scheduler branches on item.app");
expectInFile(schedulerPath, `await generateContextFollowup(ctx)`,                  "V3d scheduler calls generateContextFollowup");

expectInFile(gmailSyncPath, `contextLabel: string;`,                               "V4a gmailSync syncForUser type");
expectInFile(gmailSyncPath, `const contextLabels = (user.contextLabel`,            "V4b gmailSync parses contextLabel");
expectInFile(gmailSyncPath, `taggedMessages.push({ msg: m, app: "context" })`,     "V4c gmailSync tags messages by app");
expectInFile(gmailSyncPath, `app === "context" ? user.contextLabel : user.doctrineLabel`, "V4d gmailSync chooses correct batchLabel");
expectInFile(gmailSyncPath, `app,
        sentAt: new Date(msg.date),`,                                              "V4e gmailSync inserts app field");

expectInFile(routesIndexPath, `import contextRouter from "./context";`,            "V5a routes/index imports contextRouter");
expectInFile(routesIndexPath, `router.use("/context", contextRouter);`,            "V5b routes/index mounts under /context");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7b patch applied. Context Based Followuper backend is now");
log("functional. Mount path: /api/context/*");
log("");
log("KNOWN GAP (closes in 7c):");
log("  Doctrine routes (/api/stats, /api/followups, etc.) do NOT yet");
log("  filter to app='doctrine'. If a context prospect exists, it");
log("  shows up in the existing Doctrine UI. Until 7c ships, do not");
log("  communicate the 'Context Followuper' Gmail label name to users.");
log("================================================================");
