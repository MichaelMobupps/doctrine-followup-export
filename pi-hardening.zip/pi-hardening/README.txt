PROMPT-INJECTION HARDENING — PLUG AND PLAY
==========================================

You do NOT pick folders. The installer finds the api-server itself, puts the two
new files in the right place, applies every edit, runs the typecheck gate, and
rolls back if anything does not match.

INSTALL (two ways)

A) If you unzip with Replit's file UI:
   1. Upload pi-hardening.zip to the repo (top level).
   2. Right-click -> Extract.
   3. In the Shell, run:
        bash pi-hardening/install.sh

B) All in the Shell from the repo root:
        python3 -c "import zipfile; zipfile.ZipFile('pi-hardening.zip').extractall('.')"
        bash pi-hardening/install.sh

It asks one yes/no to confirm the folder it found. Add -y to skip the prompt.
If it cannot find the folder, pass it:  bash pi-hardening/install.sh artifacts/api-server

WHAT IT DOES
  - Places lib/promptInjection.ts and tests/promptInjection.test.ts (correct folders, automatically).
  - Edits 8 service files to fence untrusted text, add the data clause, scan inbound replies, and guard output before send.
  - Backs up every file it changes to .pi-backup-<timestamp>/ first.
  - Runs the typecheck gate; rolls back automatically on a regression.
  - Safe to re-run (idempotent). A second run says "Already installed" and changes nothing.

AFTER IT FINISHES
  1. Restart.
  2. Republish.
  3. Paste RELAY_VERIFICATION_PROMPT.md to the Relay to confirm the live deploy.

IF IT STOPS WITH "FAIL ... anchor not found"
  Nothing was changed. One of your live files differs from the version I built against.
  Send me that one file and I will re-cut the installer.

REVERT
  bash pi-hardening/uninstall.sh
  (restores the original 8 files from the oldest backup and removes the two added files)

FILES IN THIS BUNDLE
  install.sh        the installer (run this)
  uninstall.sh      the revert
  patch.py          the edit engine (called by install.sh)
  promptInjection.ts        the defense module (placed for you)
  promptInjection.test.ts   its tests, 22 of them (placed for you)
  RELAY_VERIFICATION_PROMPT.md   give to the Relay after Republish
  AUDIT.md          findings and blast radius (reference only)
