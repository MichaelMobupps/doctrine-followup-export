# B7x — Pipeline chronological sort

## What this changes

`dashboard/pages/pipeline.tsx` — `groupByThread()` sort comparator only.

Old order: active prospects first, within active by next-follow-up scheduled_at ASC (soonest firing on top), paused below by current_stage DESC.

New order:
1. Closed (replied or all stages done) at the bottom.
2. Everything else by `original_sent_at` DESC — newest sent on top.
3. Tiebreaker: `current_stage` DESC.

## Why

The old "soonest next follow-up first" was a worklist view: it answered "what should I look at next?" That made a freshly-sent prospect with F1 six days out land below older prospects whose F2/F3 fired tomorrow. After B7w made names visible, the next complaint was that a brand-new send did not appear at the top of the pipeline.

The new sort answers "what did I just send and how is the recent stuff progressing?" — closer to how every other inbox / pipeline tool orders rows.

## Files touched

```
artifacts/dashboard/src/pages/pipeline.tsx
```

No API change. No DB change. Dashboard-only build needed.

## Smoke

After deploy, the May 13 `두나무 & MobUpps` row should be at the top of the pipeline. The May 9 active campaign that was previously at the top (because its F1 was 1d 22h out) drops below it.
