#!/usr/bin/env python3
"""
patch.py — apply the prompt-injection wiring to artifacts/api-server/services.

Atomic: every edit is validated in memory first. If any anchor is missing (and
its post-edit form is not already present), NOTHING is written and the script
exits non-zero naming the failure. Idempotent: a file that already imports
../lib/promptInjection is treated as done and skipped.

Usage:  python3 patch.py <services_dir>
"""
import sys, os

CLAUSE = "UNTRUSTED_DATA_SYSTEM_CLAUSE"

def sysw(expr):
    # `system: X,`  ->  `system: `${CLAUSE}\n\n${X}`,`
    return ("system: " + expr + ",",
            "system: `${" + CLAUSE + "}\\n\\n${" + expr + "}`,", 1)

# Per-file plan: import line to add, the anchor after which to add it
# (or "BEFORE:<text>" to insert before that text), and the replacements.
PLAN = {
  "replySentiment.ts": {
    "import": 'import { wrapUntrusted, scanForInjection, UNTRUSTED_DATA_SYSTEM_CLAUSE } from "../lib/promptInjection";',
    "after": 'import { logger } from "../lib/logger";',
    "edits": [
      ('  const trimmed = body.slice(0, 2000);\n'
       '  const userContent = outreachTopic\n'
       '    ? `Original outreach was about: ${outreachTopic}\\n\\n---\\nProspect\'s reply:\\n${trimmed}`\n'
       '    : `Prospect\'s reply:\\n${trimmed}`;',
       '  const trimmed = body.slice(0, 2000);\n'
       '\n'
       '  const _scan = scanForInjection(trimmed);\n'
       '  if (_scan.suspicious) {\n'
       '    logger.warn(\n'
       '      { latestInboundMessageId, signals: _scan.signals.map((s) => s.kind), score: _scan.score },\n'
       '      "replySentiment: injection markers in reply - classifying unknown, no cascade",\n'
       '    );\n'
       '    return { replyClass: "unknown", confidence: 0, reason: "injection suspected in reply", source: "fallback" };\n'
       '  }\n'
       '  const _replyBlock = wrapUntrusted("PROSPECT_REPLY", trimmed);\n'
       '  const _topicWrap = outreachTopic ? wrapUntrusted("OUTREACH_TOPIC", outreachTopic) : null;\n'
       '  const userContent = _topicWrap\n'
       '    ? `Original outreach was about:\\n${_topicWrap.block}\\n\\nProspect\'s reply:\\n${_replyBlock.block}`\n'
       '    : `Prospect\'s reply:\\n${_replyBlock.block}`;', 1),
      sysw("SENTIMENT_SYSTEM"),
    ],
  },
  "emailSummarizer.ts": {
    "import": 'import { wrapUntrusted, UNTRUSTED_DATA_SYSTEM_CLAUSE } from "../lib/promptInjection";',
    "after": 'import { logger } from "../lib/logger";',
    "edits": [
      ('content: body.slice(0, 1000) }',
       'content: wrapUntrusted("EMAIL_BODY", body.slice(0, 1000)).block }', 1),
      sysw("SUMMARIZE_SYSTEM"),
    ],
  },
  "followupPrompts.ts": {
    "import": 'import { wrapUntrusted } from "../lib/promptInjection";',
    "after": 'import { buildNativenessBlock, buildCriticNativenessBlock } from "../lib/languageNativeness";',
    "edits": [
      ('---BEGIN ORIGINAL EMAIL---\n${rawBody}\n---END ORIGINAL EMAIL---',
       '${wrapUntrusted("ORIGINAL_EMAIL", rawBody).block}', 1),
      ('---BEGIN ORIGINAL EMAIL---\\n${ctx.original_body.trim()}\\n---END ORIGINAL EMAIL---',
       '${wrapUntrusted("ORIGINAL_EMAIL", ctx.original_body.trim()).block}', 2),
    ],
  },
  "contextFollowupPrompts.ts": {
    "import": 'import { wrapUntrusted } from "../lib/promptInjection";',
    "after": 'import type { FollowupContext, PreviousFollowup } from "./followupPrompts";',
    "edits": [
      ('${bodyForContext}', '${wrapUntrusted("PRIOR_EMAIL", bodyForContext).block}', 3),
    ],
  },
  "antiGhostingFollowupPrompts.ts": {
    "import": 'import { wrapUntrusted } from "../lib/promptInjection";',
    "before": 'export type DaysSinceSeedTier = "lt_30d" | "30d_to_6mo" | "gt_6mo";',
    "edits": [
      ('${lastInbound.body.slice(0, 500)}',
       '${wrapUntrusted("LAST_INBOUND", lastInbound.body.slice(0, 500)).block}', 1),
      ('${m.body}', '${wrapUntrusted("THREAD_MSG", m.body).block}', 1),
      ('${lastInbound.body}', '${wrapUntrusted("LAST_INBOUND", lastInbound.body).block}', 2),
      ('${ctx.seed_body}', '${wrapUntrusted("SEED_EMAIL", ctx.seed_body).block}', 2),
    ],
  },
  "followupGenerator.ts": {
    "import": 'import { checkOutputIntegrity, UNTRUSTED_DATA_SYSTEM_CLAUSE } from "../lib/promptInjection";',
    "after": 'import { stripClosingFromBody } from "./signatureStripper";',
    "edits": [
      sysw("getFollowupSystemPrompt()"),
      sysw("getCriticSystemPrompt()"),
      sysw("getRewriterSystemPrompt()"),
      ('  const humanizedBody = humanizeText(followup.body);\n'
       '  return {\n'
       '    subject: humanizeText(followup.subject),\n'
       '    body: stripClosingFromBody(humanizedBody),\n'
       '  };',
       '  const humanizedBody = humanizeText(followup.body);\n'
       '  const result = {\n'
       '    subject: humanizeText(followup.subject),\n'
       '    body: stripClosingFromBody(humanizedBody),\n'
       '  };\n'
       '  const _egress = checkOutputIntegrity(`${result.subject}\\n${result.body}`);\n'
       '  if (_egress.compromised) {\n'
       '    throw new Error(`Output integrity check failed: ${_egress.reasons.join("; ")}`);\n'
       '  }\n'
       '  return result;', 1),
    ],
  },
  "contextFollowupGenerator.ts": {
    "import": 'import { checkOutputIntegrity, UNTRUSTED_DATA_SYSTEM_CLAUSE } from "../lib/promptInjection";',
    "after": 'import { stripClosingFromBody } from "./signatureStripper";',
    "edits": [
      sysw("CONTEXT_GENERATOR_SYSTEM"),
      sysw("CONTEXT_CRITIC_SYSTEM"),
      sysw("CONTEXT_REWRITER_SYSTEM"),
      ('  const finalize = (draft: GeneratedContextFollowup): GeneratedContextFollowup => ({\n'
       '    subject: draft.subject,\n'
       '    body: stripClosingFromBody(draft.body),\n'
       '  });',
       '  const finalize = (draft: GeneratedContextFollowup): GeneratedContextFollowup => {\n'
       '    const out = { subject: draft.subject, body: stripClosingFromBody(draft.body) };\n'
       '    const _egress = checkOutputIntegrity(`${out.subject}\\n${out.body}`);\n'
       '    if (_egress.compromised) throw new Error(`Output integrity check failed: ${_egress.reasons.join("; ")}`);\n'
       '    return out;\n'
       '  };', 1),
    ],
  },
  "antiGhostingFollowupGenerator.ts": {
    "import": 'import { scanForInjection, checkOutputIntegrity, UNTRUSTED_DATA_SYSTEM_CLAUSE } from "../lib/promptInjection";',
    "after": 'import { stripClosingFromBody } from "./signatureStripper";',
    "edits": [
      sysw("ANTI_GHOSTING_GENERATOR_SYSTEM"),
      sysw("ANTI_GHOSTING_CRITIC_SYSTEM"),
      sysw("ANTI_GHOSTING_REWRITER_SYSTEM"),
      ('  const finalize = (draft: GeneratedAntiGhostingFollowup): GeneratedAntiGhostingFollowup => ({\n'
       '    subject: draft.subject,\n'
       '    body: stripClosingFromBody(draft.body),\n'
       '  });',
       '  const finalize = (draft: GeneratedAntiGhostingFollowup): GeneratedAntiGhostingFollowup => {\n'
       '    const out = { subject: draft.subject, body: stripClosingFromBody(draft.body) };\n'
       '    const _egress = checkOutputIntegrity(`${out.subject}\\n${out.body}`);\n'
       '    if (_egress.compromised) throw new Error(`Output integrity check failed: ${_egress.reasons.join("; ")}`);\n'
       '    return out;\n'
       '  };', 1),
      ('  const draft = await generateAntiGhostingDraft(ctx);',
       '  const _inboundText = ctx.thread_messages\n'
       '    .filter((m) => m.direction === "inbound")\n'
       '    .map((m) => m.body)\n'
       '    .join("\\n");\n'
       '  const _inboundScan = scanForInjection(_inboundText);\n'
       '  if (_inboundScan.suspicious) {\n'
       '    throw new Error("Injection suspected in inbound thread; not auto-sending");\n'
       '  }\n'
       '\n'
       '  const draft = await generateAntiGhostingDraft(ctx);', 1),
    ],
  },
}

def plan_file(path, spec):
    """Return (new_text, status) where status in {applied, already, fail:<msg>}."""
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    if 'from "../lib/promptInjection"' in text:
        return text, "already"
    # import insertion
    if "after" in spec:
        anchor = spec["after"]
        if anchor not in text:
            return text, f"fail: import anchor not found ({anchor[:40]}...)"
        text = text.replace(anchor, anchor + "\n" + spec["import"], 1)
    else:  # before
        anchor = spec["before"]
        if anchor not in text:
            return text, f"fail: import anchor not found ({anchor[:40]}...)"
        text = text.replace(anchor, spec["import"] + "\n\n" + anchor, 1)
    # edits
    for old, new, count in spec["edits"]:
        n = text.count(old)
        if n != count:
            return text, f"fail: expected {count}x but found {n}x of [{old[:50].strip()}...]"
        text = text.replace(old, new)
    return text, "applied"

def main():
    if len(sys.argv) != 2:
        print("usage: python3 patch.py <services_dir>"); sys.exit(2)
    sdir = sys.argv[1]
    results, writes = [], []
    for fname, spec in PLAN.items():
        p = os.path.join(sdir, fname)
        if not os.path.isfile(p):
            print(f"FAIL  {fname}: file not found at {p}"); sys.exit(1)
        new_text, status = plan_file(p, spec)
        if status.startswith("fail"):
            print(f"FAIL  {fname}: {status}")
            print("No files were modified. Resolve the anchor mismatch and re-run.")
            sys.exit(1)
        results.append((fname, status))
        if status == "applied":
            writes.append((p, new_text))
    # atomic: all validated; now write
    for p, new_text in writes:
        with open(p, "w", encoding="utf-8") as f:
            f.write(new_text)
    for fname, status in results:
        print(f"{'OK   ' if status=='applied' else 'SKIP '} {fname} ({status})")
    print(f"\nPatched {len(writes)} file(s); {len(results)-len(writes)} already done.")

if __name__ == "__main__":
    main()
