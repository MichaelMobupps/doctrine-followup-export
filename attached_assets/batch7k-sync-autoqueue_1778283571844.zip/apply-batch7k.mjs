#!/usr/bin/env node
/**
 * apply-batch7k.mjs — Phase 7k (sync→autoqueue gap fix).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * The bug: manual /api/sync and /api/context/sync handlers create
 * prospect rows via gmailSync but do NOT call autoQueueAllCampaigns
 * after the sync completes. autoQueueAllCampaigns is the only path
 * that creates F1 follow-up rows for newly-synced prospects, and it's
 * wired only to the every-15-minute cron tick (cron.ts line 22).
 * Result: clicking "Sync now" creates prospects but no F1 queued —
 * the Pipeline (which inner-joins followups + prospects) shows
 * nothing for the new campaign for up to 15 minutes.
 *
 * The fix: append autoQueueAllCampaigns() to both /sync handlers
 * after the sync call returns. autoQueueAllCampaigns is idempotent
 * (uq_followups_prospect_stage + onConflictDoNothing prevent
 * duplicates) so calling it on a sync that produced 0 new prospects
 * is a cheap no-op. On a sync that DID produce prospects, F1 is
 * inserted in the same request lifecycle and the Pipeline updates
 * on next refresh.
 *
 * Two files touched:
 *   - routes/doctrine.ts: /sync handler (per-user + all-users branches).
 *   - routes/context.ts:  /sync handler (per-user + all-users branches).
 *
 * Response shape extension: each /sync now returns an additional
 * `auto_queued: N` field showing how many F1 stages were queued. The
 * existing fields are preserved — purely additive.
 *
 * Usage:
 *   API_BASE=artifacts/api-server/src node apply-batch7k.mjs
 */

import { existsSync, readFileSync, writeFileSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const log  = (msg) => console.log(`[apply-batch7k] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7k] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

const doctrineRoutePath = join(API_BASE, "routes", "doctrine.ts");
const contextRoutePath  = join(API_BASE, "routes", "context.ts");

// ============================================================
// Step 1: doctrine.ts /sync — restructure to capture result, then auto-queue
// ============================================================
log("Step 1: doctrine.ts /sync — auto-queue after sync...");

strReplace(
  doctrineRoutePath,
  `    if (email) {
      logger.info({ email, mode: "per_user" }, "Manual sync requested");
      const result = await syncEmailsForUser(email);
      res.json(result);
      return;
    }

    logger.info({ mode: "all_users" }, "Manual sync requested");
    const result = await syncEmails();
    res.json(result);`,
  `    let result;
    if (email) {
      logger.info({ email, mode: "per_user" }, "Manual sync requested");
      result = await syncEmailsForUser(email);
    } else {
      logger.info({ mode: "all_users" }, "Manual sync requested");
      result = await syncEmails();
    }

    // Phase 7k: trigger autoQueueAllCampaigns so newly-synced prospects
    // get F1 queued in this request lifecycle. Without this, manual sync
    // creates prospect rows but no follow-up rows until the next 15-min
    // cron tick, leaving the Pipeline empty for synced campaigns. The
    // function is idempotent (uq_followups_prospect_stage +
    // onConflictDoNothing prevent duplicates), so re-running on syncs
    // with 0 new prospects is a cheap no-op.
    const { autoQueueAllCampaigns } = await import("../services/scheduler");
    let autoQueued = 0;
    try {
      autoQueued = await autoQueueAllCampaigns();
    } catch (err) {
      logger.warn({ err }, "autoQueueAllCampaigns failed during /sync; cron will retry on next tick");
    }

    res.json({ ...result, auto_queued: autoQueued });`,
  "doctrine.ts: /sync auto-queue after sync",
  `// Phase 7k: trigger autoQueueAllCampaigns so newly-synced prospects`
);

// ============================================================
// Step 2: context.ts /sync — same fix
// ============================================================
log("Step 2: context.ts /sync — auto-queue after sync...");

strReplace(
  contextRoutePath,
  `    const email = req.body?.email ? String(req.body.email) : undefined;
    if (email) {
      const { syncEmailsForUser } = await import("../services/gmailSync");
      const result = await syncEmailsForUser(email);
      res.json(result);
    } else {
      const { syncEmails } = await import("../services/gmailSync");
      const result = await syncEmails();
      res.json(result);
    }`,
  `    const email = req.body?.email ? String(req.body.email) : undefined;
    let result;
    if (email) {
      const { syncEmailsForUser } = await import("../services/gmailSync");
      result = await syncEmailsForUser(email);
    } else {
      const { syncEmails } = await import("../services/gmailSync");
      result = await syncEmails();
    }

    // Phase 7k: same fix as doctrine /sync — auto-queue F1 follow-ups
    // for newly-synced prospects so they appear in the Pipeline
    // immediately instead of waiting up to 15 minutes for the cron.
    // autoQueueAllCampaigns is product-blind (walks all unreplied
    // non-paused prospects across both products) so calling it from
    // either /sync or /context/sync produces identical correct
    // behavior for whichever product is currently being synced.
    const { autoQueueAllCampaigns } = await import("../services/scheduler");
    let autoQueued = 0;
    try {
      autoQueued = await autoQueueAllCampaigns();
    } catch (err) {
      logger.warn({ err }, "autoQueueAllCampaigns failed during /context/sync; cron will retry on next tick");
    }

    res.json({ ...result, auto_queued: autoQueued });`,
  "context.ts: /sync auto-queue after sync",
  `// Phase 7k: same fix as doctrine /sync — auto-queue F1 follow-ups`
);

// ============================================================
// Step 3: Self-verify
// ============================================================
log("Step 3: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Doctrine
expectInFile(doctrineRoutePath, `// Phase 7k: trigger autoQueueAllCampaigns so newly-synced prospects`, "V1 doctrine Phase 7k comment");
expectInFile(doctrineRoutePath, `const { autoQueueAllCampaigns } = await import("../services/scheduler");`, "V2 doctrine dynamic import");
expectInFile(doctrineRoutePath, `autoQueued = await autoQueueAllCampaigns();`, "V3 doctrine call site");
expectInFile(doctrineRoutePath, `res.json({ ...result, auto_queued: autoQueued });`, "V4 doctrine response extension");
// Old shape gone — nothing in doctrine /sync should still do `const result = await syncEmailsForUser` followed immediately by `res.json(result)`.
expectNotInFile(doctrineRoutePath, `const result = await syncEmailsForUser(email);
      res.json(result);`, "V5 doctrine old per-user pattern gone");

// Context
expectInFile(contextRoutePath, `// Phase 7k: same fix as doctrine /sync — auto-queue F1 follow-ups`, "V6 context Phase 7k comment");
expectInFile(contextRoutePath, `const { autoQueueAllCampaigns } = await import("../services/scheduler");`, "V7 context dynamic import");
expectInFile(contextRoutePath, `autoQueued = await autoQueueAllCampaigns();`, "V8 context call site");
expectInFile(contextRoutePath, `res.json({ ...result, auto_queued: autoQueued });`, "V9 context response extension");

// Sanity: the existing per-user / all-users logic is preserved (same imports, same logger lines on doctrine).
expectInFile(doctrineRoutePath, `logger.info({ email, mode: "per_user" }, "Manual sync requested");`, "V10 doctrine per_user log preserved");
expectInFile(doctrineRoutePath, `logger.info({ mode: "all_users" }, "Manual sync requested");`, "V11 doctrine all_users log preserved");
expectInFile(doctrineRoutePath, `if (rawEmail !== undefined && rawEmail !== null && typeof rawEmail !== "string")`, "V12 doctrine input validation preserved");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7k patch applied. Manual /sync (both products) now triggers");
log("autoQueueAllCampaigns immediately after the Gmail sync completes,");
log("so newly-synced prospects get F1 follow-ups queued in the same");
log("request lifecycle and appear in the Pipeline on next refresh.");
log("================================================================");
