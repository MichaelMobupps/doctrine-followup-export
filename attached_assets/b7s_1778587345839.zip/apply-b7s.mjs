// B7s apply script.
//
// Adds the admin /activity rollup endpoint:
//   - NEW    artifacts/api-server/src/routes/admin-activity.ts
//   - PATCH  artifacts/api-server/src/routes/index.ts (import + mount)
//
// Reads from the followup_usage table that B7r populates.
//
// No DB migration. No schema change. No generator change. The endpoint
// is read-only and gated by X-API-Key.

import { promises as fs } from "node:fs";
import path from "node:path";

const WORKSPACE = "/home/runner/workspace";
const PATCH_DIR = path.dirname(new URL(import.meta.url).pathname);

async function copyFile(src, dst) {
  await fs.mkdir(path.dirname(dst), { recursive: true });
  await fs.copyFile(src, dst);
  console.log(`wrote: ${dst}`);
}

async function patchFile(relativePath, edits) {
  const absPath = path.join(WORKSPACE, relativePath);
  let content;
  try { content = await fs.readFile(absPath, "utf8"); }
  catch (err) { throw new Error(`Cannot read ${absPath}: ${err.message}`); }
  let applied = 0, alreadyApplied = 0;
  for (const edit of edits) {
    if (edit.marker && content.includes(edit.marker)) {
      console.log(`  [skip] ${edit.name} (already applied)`);
      alreadyApplied++; continue;
    }
    const occurrences = content.split(edit.search).length - 1;
    if (occurrences === 0) {
      throw new Error(`Edit "${edit.name}" NOT FOUND in ${relativePath}. Aborting before any writes.`);
    }
    if (occurrences > 1) {
      throw new Error(`Edit "${edit.name}" matched ${occurrences} times in ${relativePath}. Need a more specific anchor.`);
    }
    content = content.replace(edit.search, edit.replace);
    applied++;
    console.log(`  [ok]   ${edit.name}`);
  }
  if (applied > 0) {
    await fs.writeFile(absPath, content);
    console.log(`wrote: ${relativePath} (applied ${applied}, skipped ${alreadyApplied})`);
  } else {
    console.log(`no-op: ${relativePath} (all ${alreadyApplied} edits already applied)`);
  }
}

// ============================================================
// Step 1: copy the new route file.
// ============================================================
async function copyNewFiles() {
  await copyFile(
    path.join(PATCH_DIR, "files/admin-activity.ts"),
    path.join(WORKSPACE, "artifacts/api-server/src/routes/admin-activity.ts"),
  );
}

// ============================================================
// Step 2: register the new router in routes/index.ts.
// ============================================================
const ROUTES_INDEX_EDITS = [
  {
    name: "routes/index.ts: import adminActivityRouter",
    marker: "B7s: admin activity rollup",
    search: `// B7o: admin salvage endpoint for stuck prospects.
import adminSalvageRouter from "./admin-salvage";`,
    replace: `// B7o: admin salvage endpoint for stuck prospects.
import adminSalvageRouter from "./admin-salvage";
// B7s: admin activity rollup (reads followup_usage populated by B7r).
import adminActivityRouter from "./admin-activity";`,
  },
  {
    name: "routes/index.ts: mount adminActivityRouter",
    marker: "B7s: mount admin activity router",
    search: `// B7o: admin endpoints (X-API-Key gated).
router.use(adminSalvageRouter);`,
    replace: `// B7o: admin endpoints (X-API-Key gated).
router.use(adminSalvageRouter);
// B7s: mount admin activity router (X-API-Key gated).
router.use(adminActivityRouter);`,
  },
];

// ============================================================
// Main.
// ============================================================
async function main() {
  console.log("B7s: admin activity rollup endpoint for Email Followuper\n");

  console.log("[1/2] copying admin-activity.ts");
  await copyNewFiles();
  console.log();

  console.log("[2/2] api-server/src/routes/index.ts — register router");
  await patchFile("artifacts/api-server/src/routes/index.ts", ROUTES_INDEX_EDITS);
  console.log();

  console.log("B7s applied. Next: build api-server, restart workflow, deploy to production.");
  console.log("Verify with: curl -H \"X-API-Key: $ADDON_API_KEY\" $URL/api/admin/activity");
}

main().catch((err) => {
  console.error("\nB7s apply failed:", err.message);
  process.exit(1);
});
