#!/usr/bin/env bash
# install.sh — one-command install of the prompt-injection hardening.
# Finds the api-server itself, places the two new files in the correct folders,
# applies all edits atomically, runs the typecheck gate, and rolls back on a
# typecheck regression. Idempotent and safe to re-run.
#
# Usage:
#   bash install.sh            # auto-detect the api-server dir, ask to confirm
#   bash install.sh -y         # auto-detect, no prompt
#   bash install.sh <dir>      # use an explicit api-server dir
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
AUTO_YES=0
EXPLICIT_DIR=""
for a in "$@"; do
  if [ "$a" = "-y" ]; then AUTO_YES=1; else EXPLICIT_DIR="$a"; fi
done

say(){ printf "%s\n" "$*"; }
die(){ printf "ERROR: %s\n" "$*" >&2; exit 1; }

# 1. Locate the api-server directory.
if [ -n "$EXPLICIT_DIR" ]; then
  API_DIR="$EXPLICIT_DIR"
else
  HIT="$(find . -type f -path '*/services/replySentiment.ts' 2>/dev/null | head -1 || true)"
  [ -n "$HIT" ] || die "Could not find services/replySentiment.ts under $(pwd). Run from the repo root, or pass the api-server dir: bash install.sh artifacts/api-server"
  API_DIR="$(cd "$(dirname "$HIT")/.." && pwd)"
fi
[ -f "$API_DIR/services/replySentiment.ts" ] || die "Not an api-server dir (no services/replySentiment.ts): $API_DIR"
say "Target api-server: $API_DIR"

if [ "$AUTO_YES" -ne 1 ]; then
  printf "Apply prompt-injection hardening here? [y/N] "
  read -r ANS </dev/tty || ANS="n"
  case "$ANS" in y|Y) ;; *) die "Aborted by user." ;; esac
fi

# 2. Typecheck baseline (skips cleanly if pnpm/tsc is unavailable here).
tsc_errors(){ ( cd "$API_DIR" && pnpm exec tsc --noEmit 2>&1 ) | grep -cE "error TS" || true; }
TSC_PRE="SKIP"
if ( cd "$API_DIR" && pnpm exec tsc --version >/dev/null 2>&1 ); then
  TSC_PRE="$(tsc_errors)"; say "Typecheck baseline: $TSC_PRE error(s)"
else
  say "Typecheck baseline: SKIP (pnpm/tsc not runnable here; run the gate yourself after)"
fi

SERVICES="replySentiment.ts emailSummarizer.ts followupPrompts.ts contextFollowupPrompts.ts antiGhostingFollowupPrompts.ts followupGenerator.ts contextFollowupGenerator.ts antiGhostingFollowupGenerator.ts"

# Which services still need patching? (already-patched ones import the module.)
NEED=""
for f in $SERVICES; do
  grep -q 'from "../lib/promptInjection"' "$API_DIR/services/$f" || NEED="$NEED $f"
done
if [ -z "$NEED" ] && [ -f "$API_DIR/lib/promptInjection.ts" ]; then
  say "Already installed (all services patched, module present). Nothing to do."
  say "Next: Restart, then Republish."
  exit 0
fi

# 3. Back up ONLY the files that will change + write a manifest.
STAMP="$(date +%Y%m%d-%H%M%S)"
BK="$API_DIR/.pi-backup-$STAMP"
mkdir -p "$BK/services"
for f in $NEED; do cp "$API_DIR/services/$f" "$BK/services/$f"; done
MODULE_WAS_PRESENT=0; [ -f "$API_DIR/lib/promptInjection.ts" ] && MODULE_WAS_PRESENT=1
{
  echo "{"
  echo "  \"stamp\": \"$STAMP\","
  echo "  \"api_dir\": \"$API_DIR\","
  echo "  \"module_was_present\": $MODULE_WAS_PRESENT,"
  echo "  \"placed\": [\"lib/promptInjection.ts\", \"tests/promptInjection.test.ts\"],"
  echo "  \"backed_up_services\": [$(echo $NEED | sed 's/^ //; s/ /", "/g; s/^/"/; s/$/"/')]"
  echo "}"
} > "$BK/manifest.json"
say "Backup: $BK"

rollback(){
  say "Rolling back..."
  for f in $NEED; do cp "$BK/services/$f" "$API_DIR/services/$f"; done
  # Remove the files we placed only if the module was not already present before.
  if [ "$MODULE_WAS_PRESENT" -eq 0 ]; then
    for p in "$API_DIR/lib/promptInjection.ts" "$API_DIR/tests/promptInjection.test.ts"; do
      [ -f "$p" ] && grep -q "promptInjection" "$p" 2>/dev/null && rm -f "$p"
    done
  fi
  say "Rollback complete. No changes remain. Backup kept at $BK"
}

# 4. Place the two new files in the correct folders (auto, no guessing).
mkdir -p "$API_DIR/lib" "$API_DIR/tests"
cp "$SCRIPT_DIR/promptInjection.ts" "$API_DIR/lib/promptInjection.ts"
cp "$SCRIPT_DIR/promptInjection.test.ts" "$API_DIR/tests/promptInjection.test.ts"
say "Placed lib/promptInjection.ts and tests/promptInjection.test.ts"

# 5. Apply the edits atomically.
if ! python3 "$SCRIPT_DIR/patch.py" "$API_DIR/services"; then
  rollback
  die "Patch failed (see message above). Nothing left applied."
fi

# 6. Typecheck gate: rollback only on a real regression.
if [ "$TSC_PRE" != "SKIP" ]; then
  TSC_POST="$(tsc_errors)"; say "Typecheck after: $TSC_POST error(s)"
  if [ "$TSC_POST" -gt "$TSC_PRE" ]; then
    rollback
    die "Typecheck regressed ($TSC_PRE -> $TSC_POST). Rolled back."
  fi
fi

# 7. Tests: the module ships 22 node:test cases. The typecheck gate above already
#    compiled them clean. Run the repo's normal test command to execute them.
say "Tests: tests/promptInjection.test.ts adds 22 node:test cases (compiled clean by the typecheck gate above)."
say "       Run your usual test command to execute them."

say ""
say "DONE. Hardening installed at $API_DIR"
say "Next: Restart, then Republish (separate steps)."
say "To revert: bash $SCRIPT_DIR/uninstall.sh \"$API_DIR\""
