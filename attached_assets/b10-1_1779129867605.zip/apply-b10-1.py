#!/usr/bin/env python3
"""
B10.1 - Fix onConflictDoNothing target to match the composite unique index.

The unique index on prospectsTable since B9b.6 is:
    uq_prospects_user_message_app (user_id, gmail_message_id, app)

But gmailSync.ts has two identical onConflict calls referencing just
gmail_message_id, which PG rejects with code 42P10:

    .onConflictDoNothing({ target: prospectsTable.gmailMessageId });

Symptom: POST /api/sync returns 500 for every new email since B9b.6
shipped. Existing prospects work because the SELECT pre-check at
line ~286 skips them before they hit the broken INSERT path.

Fix: switch target to the composite array matching the actual index.

Single replace, applies to BOTH occurrences (lines 315 and 572).
Idempotency: marker check for the composite target string.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
GMAIL_SYNC = WORKSPACE / "artifacts/api-server/src/services/gmailSync.ts"

OLD = '      .onConflictDoNothing({ target: prospectsTable.gmailMessageId });'
NEW = '      // B10.1: composite target matches uq_prospects_user_message_app (B9b.6).\n      .onConflictDoNothing({ target: [prospectsTable.userId, prospectsTable.gmailMessageId, prospectsTable.app] });'

MARKER = '[prospectsTable.userId, prospectsTable.gmailMessageId, prospectsTable.app]'


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def main():
    if not GMAIL_SYNC.exists():
        fail(f"gmailSync.ts not found: {GMAIL_SYNC}")
    text = GMAIL_SYNC.read_text(encoding="utf-8")
    original = text

    if MARKER in text:
        print("[skip] onConflict composite target already applied")
        return

    count = text.count(OLD)
    if count == 0:
        fail("anchor not found in gmailSync.ts; expected the broken onConflict line")
    if count != 2:
        fail(f"expected exactly 2 occurrences of broken onConflict line; found {count}")

    text = text.replace(OLD, NEW)
    GMAIL_SYNC.write_text(text, encoding="utf-8")
    print(f"[ok]   replaced 2 onConflict targets with composite array")
    print(f"[ok]   wrote {GMAIL_SYNC.relative_to(WORKSPACE)}")
    print()
    print("B10.1 sync onConflict composite target fix applied.")


if __name__ == "__main__":
    main()
