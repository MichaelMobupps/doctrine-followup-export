// B7t: admin activity dashboard.
//
// Reads /api/admin/activity (B7s endpoint, backed by the
// followup_usage table populated by B7r). Renders:
//   - Top stat cards (events, follow-ups, total cost, in-flight)
//   - Filters (user / app / time window)
//   - Per-user totals table with row-expand showing by_app /
//     by_stage / by_model breakdowns
//   - Recent events table (200-row cap from the endpoint)
//
// No mutation. No auto-refresh in this batch (the manual refresh
// button is enough until B7v adds live polling). No Excel export
// (that's B7u). No admin pause/resume (also B7u).
//
// Style follows the existing activity-log.tsx conventions: CSS
// variables, no framer-motion (kept it simple), the same Card and
// Button components from @/components/ui.

import React, { useState, useEffect, useCallback, useMemo } from "react";
import { useApiKey } from "@/hooks/use-api-key";
import { Card, Button } from "@/components/ui";
import {
  RefreshCw, Users, Zap, DollarSign, Activity,
  ChevronDown, ChevronRight, Filter,
} from "lucide-react";

// ── Types matching the /api/admin/activity response shape ──────────

interface UserSummary {
  id: number;
  email: string;
  name: string;
}

interface AppRollup {
  events: number;
  input_tokens: number;
  output_tokens: number;
  cost_usd: number;
}

interface StageRollup {
  events: number;
  cost_usd: number;
}

interface ModelRollup {
  events: number;
  input_tokens: number;
  output_tokens: number;
  cost_usd: number;
}

interface UserTotal {
  user_id: number | null;
  email: string | null;
  name: string | null;
  events: number;
  followups: number;
  input_tokens: number;
  output_tokens: number;
  cache_creation_tokens: number;
  cache_read_tokens: number;
  web_searches: number;
  cost_usd: number;
  by_app: Record<string, AppRollup>;
  by_stage: Record<string, StageRollup>;
  by_model: Record<string, ModelRollup>;
}

interface UsageEvent {
  id: number;
  followup_id: number | null;
  prospect_id: number | null;
  user_id: number | null;
  user_email: string | null;
  user_name: string | null;
  prospect_name: string | null;
  prospect_company: string | null;
  app: string;
  stage: number;
  label: string;
  model: string;
  input_tokens: number;
  output_tokens: number;
  cache_creation_tokens: number;
  cache_read_tokens: number;
  web_searches: number;
  cost_usd: number;
  generated_at: string;
}

interface ActivityResponse {
  window: { since: string; until: string };
  filter: { user_id: number | null; app: string | null };
  active_generations: number;
  totals: {
    events: number;
    followups: number;
    input_tokens: number;
    output_tokens: number;
    cache_creation_tokens: number;
    cache_read_tokens: number;
    web_searches: number;
    cost_usd: number;
  };
  users: UserSummary[];
  user_totals: UserTotal[];
  events: UsageEvent[];
}

// ── Helpers ────────────────────────────────────────────────────────

function formatTokens(n: number): string {
  if (!n || n < 1000) return String(n || 0);
  if (n < 1_000_000) return `${(n / 1000).toFixed(1)}k`;
  return `${(n / 1_000_000).toFixed(2)}M`;
}

function formatCost(usd: number): string {
  if (!usd || usd === 0) return "—";
  if (usd < 0.01) return "<$0.01";
  if (usd < 1) return `$${usd.toFixed(3)}`;
  if (usd < 100) return `$${usd.toFixed(2)}`;
  return `$${usd.toFixed(0)}`;
}

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString("en-GB", { day: "2-digit", month: "short" });
  const time = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} ${time}`;
}

function formatRelative(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  const ms = Date.now() - d.getTime();
  const s = Math.round(ms / 1000);
  if (s < 60) return `${s}s ago`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h}h ago`;
  const dys = Math.round(h / 24);
  return `${dys}d ago`;
}

// Empty prospect_name fallback noted in the post-B7s review: production
// rows can have empty strings here because the schema default is "".
function prospectLabel(e: UsageEvent): string {
  const name = (e.prospect_name || "").trim();
  const company = (e.prospect_company || "").trim();
  if (name && company) return `${name} · ${company}`;
  if (name) return name;
  if (company) return company;
  if (e.prospect_id) return `Prospect #${e.prospect_id}`;
  return "—";
}

function userLabel(name: string | null, email: string | null): string {
  if (name && name.trim()) return name;
  if (email) return email.split("@")[0];
  return "—";
}

// Window presets: returns ISO since/until pair.
type WindowPreset = "24h" | "7d" | "30d";
function windowFor(preset: WindowPreset): { since: string; until: string } {
  const now = new Date();
  const since = new Date(now.getTime());
  if (preset === "24h") since.setHours(since.getHours() - 24);
  else if (preset === "7d") since.setDate(since.getDate() - 7);
  else if (preset === "30d") since.setDate(since.getDate() - 30);
  return { since: since.toISOString(), until: now.toISOString() };
}

// ── Page ───────────────────────────────────────────────────────────

export default function AdminActivity() {
  const { apiKey } = useApiKey();
  const [data, setData] = useState<ActivityResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [windowPreset, setWindowPreset] = useState<WindowPreset>("7d");
  const [userFilter, setUserFilter] = useState<string>("all");
  const [appFilter, setAppFilter] = useState<string>("all");
  const [expandedUser, setExpandedUser] = useState<number | null>(null);

  const fetchActivity = useCallback(async () => {
    if (!apiKey) return;
    setLoading(true);
    setError(null);
    try {
      const base = import.meta.env.BASE_URL || "/";
      const { since, until } = windowFor(windowPreset);
      const params = new URLSearchParams({ since, until });
      if (userFilter !== "all") params.set("user_id", userFilter);
      if (appFilter !== "all") params.set("app", appFilter);
      const res = await fetch(`${base}api/admin/activity?${params.toString()}`, {
        headers: { "x-api-key": apiKey },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = (await res.json()) as ActivityResponse;
      setData(json);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load activity");
    } finally {
      setLoading(false);
    }
  }, [apiKey, windowPreset, userFilter, appFilter]);

  useEffect(() => { fetchActivity(); }, [fetchActivity]);

  const allUsers = useMemo(() => data?.users ?? [], [data]);

  return (
    <div className="p-6 max-w-[1400px] mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1
            className="text-[20px] font-semibold tracking-tight"
            style={{ color: "var(--text-primary)" }}
          >
            Admin Activity
          </h1>
          <p
            className="text-[12px] mt-1"
            style={{ color: "var(--text-tertiary)" }}
          >
            Per-LLM-call usage and cost ledger for follow-up generation.
            One row in followup_usage = one Anthropic API call.
          </p>
        </div>
        <Button onClick={fetchActivity} disabled={loading} variant="outline" size="sm">
          <RefreshCw className={`h-3.5 w-3.5 mr-1.5 ${loading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <div
        className="rounded-lg p-3 mb-5 flex items-center gap-3 flex-wrap"
        style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
      >
        <Filter className="h-3.5 w-3.5" style={{ color: "var(--text-tertiary)" }} />
        <FilterSelect
          label="Window"
          value={windowPreset}
          options={[
            { value: "24h", label: "Last 24h" },
            { value: "7d", label: "Last 7 days" },
            { value: "30d", label: "Last 30 days" },
          ]}
          onChange={(v) => setWindowPreset(v as WindowPreset)}
        />
        <FilterSelect
          label="User"
          value={userFilter}
          options={[
            { value: "all", label: "All users" },
            ...allUsers.map((u) => ({ value: String(u.id), label: u.name || u.email })),
          ]}
          onChange={setUserFilter}
        />
        <FilterSelect
          label="App"
          value={appFilter}
          options={[
            { value: "all", label: "Both" },
            { value: "doctrine", label: "Doctrine" },
            { value: "context", label: "Context" },
          ]}
          onChange={setAppFilter}
        />
        {data && (
          <span
            className="ml-auto text-[11px]"
            style={{ color: "var(--text-tertiary)" }}
          >
            {formatDateTime(data.window.since)} → {formatDateTime(data.window.until)}
          </span>
        )}
      </div>

      {error && (
        <div
          className="rounded-lg p-3 mb-5 text-[12px]"
          style={{ background: "var(--danger-muted)", border: "1px solid var(--danger-border)", color: "var(--danger)" }}
        >
          {error}
        </div>
      )}

      {/* Stat cards */}
      {data && (
        <div className="grid grid-cols-4 gap-3 mb-6">
          <StatCard
            icon={Zap}
            label="Events"
            value={data.totals.events.toLocaleString()}
            sublabel={`${data.totals.followups} follow-ups`}
          />
          <StatCard
            icon={DollarSign}
            label="Total cost"
            value={formatCost(data.totals.cost_usd)}
            sublabel={`${formatTokens(data.totals.input_tokens + data.totals.output_tokens)} tokens`}
          />
          <StatCard
            icon={Activity}
            label="In flight"
            value={String(data.active_generations)}
            sublabel="rows generating right now"
          />
          <StatCard
            icon={Users}
            label="Active users"
            value={String(data.user_totals.length)}
            sublabel={`${allUsers.length} users total`}
          />
        </div>
      )}

      {/* Per-user totals */}
      {data && data.user_totals.length > 0 && (
        <Card className="mb-6 overflow-hidden">
          <div
            className="px-4 py-3 text-[11px] font-medium uppercase tracking-wider"
            style={{ color: "var(--text-tertiary)", borderBottom: "1px solid var(--border-default)" }}
          >
            Per-user totals (click a row to expand breakdowns)
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[12px]">
              <thead>
                <tr style={{ color: "var(--text-tertiary)" }}>
                  <th className="text-left px-4 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>User</th>
                  <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Events</th>
                  <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Follow-ups</th>
                  <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Input tok</th>
                  <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Output tok</th>
                  <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Cache R</th>
                  <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Cost</th>
                </tr>
              </thead>
              <tbody>
                {data.user_totals.map((u) => {
                  const key = u.user_id ?? -1;
                  const isExpanded = expandedUser === key;
                  return (
                    <React.Fragment key={key}>
                      <tr
                        onClick={() => setExpandedUser(isExpanded ? null : key)}
                        className="cursor-pointer"
                        style={{
                          background: isExpanded ? "var(--bg-tertiary)" : "transparent",
                          borderBottom: "1px solid var(--border-subtle)",
                        }}
                      >
                        <td className="px-4 py-2.5" style={{ color: "var(--text-primary)" }}>
                          <div className="flex items-center gap-2">
                            {isExpanded
                              ? <ChevronDown className="h-3 w-3" style={{ color: "var(--text-tertiary)" }} />
                              : <ChevronRight className="h-3 w-3" style={{ color: "var(--text-tertiary)" }} />}
                            <span>{userLabel(u.name, u.email)}</span>
                            {!u.user_id && (
                              <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: "var(--bg-tertiary)", color: "var(--text-tertiary)" }}>
                                no user
                              </span>
                            )}
                          </div>
                        </td>
                        <td className="px-3 py-2.5 text-right font-mono" style={{ color: "var(--text-primary)" }}>{u.events}</td>
                        <td className="px-3 py-2.5 text-right font-mono" style={{ color: "var(--text-primary)" }}>{u.followups}</td>
                        <td className="px-3 py-2.5 text-right font-mono" style={{ color: "var(--text-secondary)" }}>{formatTokens(u.input_tokens)}</td>
                        <td className="px-3 py-2.5 text-right font-mono" style={{ color: "var(--text-secondary)" }}>{formatTokens(u.output_tokens)}</td>
                        <td className="px-3 py-2.5 text-right font-mono" style={{ color: "var(--text-tertiary)" }}>{formatTokens(u.cache_read_tokens)}</td>
                        <td className="px-3 py-2.5 text-right font-mono font-semibold" style={{ color: "var(--accent)" }}>{formatCost(u.cost_usd)}</td>
                      </tr>
                      {isExpanded && (
                        <tr style={{ background: "var(--bg-secondary)" }}>
                          <td colSpan={7} className="px-4 py-3">
                            <UserBreakdown user={u} />
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Recent events table */}
      {data && (
        <Card className="overflow-hidden">
          <div
            className="px-4 py-3 text-[11px] font-medium uppercase tracking-wider flex items-center justify-between"
            style={{ color: "var(--text-tertiary)", borderBottom: "1px solid var(--border-default)" }}
          >
            <span>Recent events</span>
            <span className="text-[10px] normal-case tracking-normal">
              {data.events.length} shown {data.events.length === 200 ? "(capped at 200)" : ""}
            </span>
          </div>
          {data.events.length === 0 ? (
            <div className="p-8 text-center text-[12px]" style={{ color: "var(--text-tertiary)" }}>
              No events in this window. Follow-up generations write rows here as they happen.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-[12px]">
                <thead>
                  <tr style={{ color: "var(--text-tertiary)" }}>
                    <th className="text-left px-4 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Time</th>
                    <th className="text-left px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>User</th>
                    <th className="text-left px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Prospect</th>
                    <th className="text-left px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>App</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Stage</th>
                    <th className="text-left px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Step</th>
                    <th className="text-left px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Model</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>In</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Out</th>
                    <th className="text-right px-3 py-2 font-medium" style={{ borderBottom: "1px solid var(--border-default)" }}>Cost</th>
                  </tr>
                </thead>
                <tbody>
                  {data.events.map((e) => (
                    <tr key={e.id} style={{ borderBottom: "1px solid var(--border-subtle)" }}>
                      <td className="px-4 py-2 font-mono text-[11px]" style={{ color: "var(--text-tertiary)" }} title={formatDateTime(e.generated_at)}>
                        {formatRelative(e.generated_at)}
                      </td>
                      <td className="px-3 py-2" style={{ color: "var(--text-secondary)" }}>
                        {userLabel(e.user_name, e.user_email)}
                      </td>
                      <td className="px-3 py-2" style={{ color: "var(--text-secondary)" }}>
                        <span title={`prospect_id=${e.prospect_id}`}>{prospectLabel(e)}</span>
                      </td>
                      <td className="px-3 py-2 font-mono text-[11px]" style={{ color: "var(--text-tertiary)" }}>{e.app}</td>
                      <td className="px-3 py-2 text-right font-mono" style={{ color: "var(--text-secondary)" }}>{e.stage}</td>
                      <td className="px-3 py-2 font-mono text-[11px]" style={{ color: "var(--text-tertiary)" }}>{e.label}</td>
                      <td className="px-3 py-2 font-mono text-[11px]" style={{ color: "var(--text-tertiary)" }} title={e.model}>
                        {modelShort(e.model)}
                      </td>
                      <td className="px-3 py-2 text-right font-mono" style={{ color: "var(--text-secondary)" }}>{formatTokens(e.input_tokens)}</td>
                      <td className="px-3 py-2 text-right font-mono" style={{ color: "var(--text-secondary)" }}>{formatTokens(e.output_tokens)}</td>
                      <td className="px-3 py-2 text-right font-mono font-semibold" style={{ color: "var(--accent)" }}>{formatCost(e.cost_usd)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      )}

      {loading && !data && (
        <div className="text-[12px] py-8 text-center" style={{ color: "var(--text-tertiary)" }}>
          Loading activity...
        </div>
      )}
    </div>
  );
}

// ── Subcomponents ──────────────────────────────────────────────────

function StatCard({ icon: Icon, label, value, sublabel }: {
  icon: React.ElementType;
  label: string;
  value: string;
  sublabel?: string;
}) {
  return (
    <Card>
      <div className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <Icon className="h-3.5 w-3.5" style={{ color: "var(--text-tertiary)" }} strokeWidth={1.5} />
          <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: "var(--text-tertiary)" }}>{label}</span>
        </div>
        <div className="text-[22px] font-semibold" style={{ color: "var(--text-primary)" }}>{value}</div>
        {sublabel && <div className="text-[11px] mt-0.5" style={{ color: "var(--text-tertiary)" }}>{sublabel}</div>}
      </div>
    </Card>
  );
}

function FilterSelect({ label, value, options, onChange }: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-[11px] uppercase tracking-wider" style={{ color: "var(--text-tertiary)" }}>{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="px-2.5 py-1.5 rounded text-[12px] focus:outline-none"
        style={{
          background: "var(--bg-primary)",
          border: "1px solid var(--border-default)",
          color: "var(--text-primary)",
        }}
      >
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>{opt.label}</option>
        ))}
      </select>
    </div>
  );
}

function UserBreakdown({ user }: { user: UserTotal }) {
  const apps = Object.entries(user.by_app).sort((a, b) => b[1].cost_usd - a[1].cost_usd);
  const stages = Object.entries(user.by_stage).sort((a, b) => Number(a[0]) - Number(b[0]));
  const models = Object.entries(user.by_model).sort((a, b) => b[1].cost_usd - a[1].cost_usd);

  return (
    <div className="grid grid-cols-3 gap-4">
      <BreakdownTable
        title="By app"
        rows={apps.map(([k, v]) => ({ key: k, label: k, events: v.events, cost: v.cost_usd }))}
      />
      <BreakdownTable
        title="By stage"
        rows={stages.map(([k, v]) => ({ key: k, label: `Stage ${k}`, events: v.events, cost: v.cost_usd }))}
      />
      <BreakdownTable
        title="By model"
        rows={models.map(([k, v]) => ({ key: k, label: modelShort(k), events: v.events, cost: v.cost_usd }))}
      />
    </div>
  );
}

function BreakdownTable({ title, rows }: {
  title: string;
  rows: { key: string; label: string; events: number; cost: number }[];
}) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider mb-1.5 font-medium" style={{ color: "var(--text-tertiary)" }}>{title}</div>
      <table className="w-full text-[11px]">
        <tbody>
          {rows.map((r) => (
            <tr key={r.key}>
              <td className="py-1 pr-2" style={{ color: "var(--text-secondary)" }}>{r.label}</td>
              <td className="py-1 px-2 text-right font-mono" style={{ color: "var(--text-tertiary)" }}>{r.events}</td>
              <td className="py-1 pl-2 text-right font-mono" style={{ color: "var(--accent)" }}>{formatCost(r.cost)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// Compact model names so the events table doesn't word-wrap.
function modelShort(model: string): string {
  if (model.startsWith("claude-opus-")) return "Opus";
  if (model.startsWith("claude-sonnet-")) return "Sonnet";
  if (model.startsWith("claude-haiku-")) return "Haiku";
  return model;
}
