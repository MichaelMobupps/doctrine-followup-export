#!/usr/bin/env node
// audit-hotfix-1.mjs
//
// Beautiful-Squidward audit: 3 rounds × 9 passes. Convergence: 2 consecutive
// fully-clean rounds. Otherwise FAIL.

import { readFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";
const SCHEDULER_TS = join(API_BASE, "services/scheduler.ts");
const DOCTRINE_TS = join(API_BASE, "routes/doctrine.ts");

function load(path) {
  if (!existsSync(path)) return null;
  return readFileSync(path, "utf8");
}

function countOccurrences(haystack, needle) {
  if (!haystack) return 0;
  let count = 0;
  let from = 0;
  while (true) {
    const i = haystack.indexOf(needle, from);
    if (i === -1) break;
    count++;
    from = i + needle.length;
  }
  return count;
}

const passes = [
  {
    name: "S1: scheduler.ts exports queueStageForProspect (exactly once)",
    run: () => {
      const s = load(SCHEDULER_TS);
      if (s === null) return { ok: false, why: `${SCHEDULER_TS} not found` };
      const n = countOccurrences(s, `export async function queueStageForProspect(`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "S2: scheduler.ts helper uses isActiveFollowupStatus guard",
    run: () => {
      const s = load(SCHEDULER_TS);
      // Within the helper body (between its declaration and end-of-fn marker
      // 'no prior row'), isActiveFollowupStatus must be referenced.
      const declIdx = s.indexOf("export async function queueStageForProspect(");
      if (declIdx === -1) return { ok: false, why: "helper declaration missing" };
      const tail = s.slice(declIdx, declIdx + 1800);
      return tail.includes("isActiveFollowupStatus(")
        ? { ok: true }
        : { ok: false, why: "isActiveFollowupStatus call missing in helper body" };
    },
  },
  {
    name: "S3: scheduler.ts autoQueueAllCampaigns calls helper (exactly once)",
    run: () => {
      const s = load(SCHEDULER_TS);
      const n = countOccurrences(s, `await queueStageForProspect(prospect.id, nextStage, scheduledAt)`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "S4: scheduler.ts queueNextFollowupStageForProspect calls helper (exactly once)",
    run: () => {
      const s = load(SCHEDULER_TS);
      const n = countOccurrences(s, `await queueStageForProspect(prospectId, nextStage, scheduledAt)`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "D1: doctrine.ts imports queueStageForProspect (exactly once)",
    run: () => {
      const s = load(DOCTRINE_TS);
      if (s === null) return { ok: false, why: `${DOCTRINE_TS} not found` };
      // Match within the scheduler import line specifically.
      const importLine = s.split("\n").find((l) => l.includes(`from "../services/scheduler"`));
      if (!importLine) return { ok: false, why: "scheduler import line not found" };
      return importLine.includes("queueStageForProspect")
        ? { ok: true }
        : { ok: false, why: `queueStageForProspect not in: ${importLine}` };
    },
  },
  {
    name: "D2: doctrine.ts /queue and /queue-batch each call helper (2 total)",
    run: () => {
      const s = load(DOCTRINE_TS);
      const n = countOccurrences(s, `await queueStageForProspect(pid, stage, new Date(scheduledAt))`);
      return n === 2 ? { ok: true } : { ok: false, why: `found ${n}, want 2` };
    },
  },
  {
    name: "D3: doctrine.ts /prospect/resume-bulk calls helper (exactly once)",
    run: () => {
      const s = load(DOCTRINE_TS);
      const n = countOccurrences(s, `await queueStageForProspect(p.id, nextStage, scheduledAt)`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "D4: doctrine.ts /prospect/:id/resume calls helper (exactly once)",
    run: () => {
      const s = load(DOCTRINE_TS);
      const n = countOccurrences(s, `await queueStageForProspect(prospectId, nextStage, scheduledAt)`);
      return n === 1 ? { ok: true } : { ok: false, why: `found ${n}, want 1` };
    },
  },
  {
    name: "R: regression — no blind followup-stage inserts remain in patched call sites",
    run: () => {
      const sch = load(SCHEDULER_TS);
      const doc = load(DOCTRINE_TS);
      const checks = [
        // Old autoQueueAllCampaigns pattern
        { file: "scheduler.ts", body: sch, needle: `await db.insert(followupsTable).values({\n        prospectId: prospect.id,` },
        // Old queueNextFollowupStageForProspect pattern
        { file: "scheduler.ts", body: sch, needle: `.onConflictDoNothing()\n    .returning({ id: followupsTable.id })` },
        // Old resume-bulk pattern
        { file: "doctrine.ts",  body: doc, needle: `await db.insert(followupsTable).values({\n              prospectId: p.id,` },
        // Old single-resume pattern
        { file: "doctrine.ts",  body: doc, needle: `await db.insert(followupsTable).values({\n            prospectId,\n            stage: nextStage,` },
      ];
      const leftovers = checks.filter((c) => c.body && c.body.includes(c.needle));
      return leftovers.length === 0
        ? { ok: true }
        : { ok: false, why: `leftover blind inserts: ${leftovers.map((c) => c.file).join(", ")}` };
    },
  },
];

if (passes.length !== 9) {
  console.error(`AUDIT HARNESS BUG: expected 9 passes, got ${passes.length}`);
  process.exit(2);
}

function runRound(roundNum) {
  console.log(`--- Round ${roundNum} ---`);
  let allOk = true;
  for (const pass of passes) {
    const r = pass.run();
    if (r.ok) {
      console.log(`  PASS  ${pass.name}`);
    } else {
      console.log(`  FAIL  ${pass.name} :: ${r.why}`);
      allOk = false;
    }
  }
  return allOk;
}

let cleanStreak = 0;
let overallOk = false;
for (let i = 1; i <= 3; i++) {
  const ok = runRound(i);
  if (ok) cleanStreak++;
  else cleanStreak = 0;
  if (cleanStreak >= 2) {
    overallOk = true;
    break;
  }
}

console.log("");
if (overallOk) {
  console.log("CONVERGED: 2 consecutive clean rounds. AUDIT PASS.");
  process.exit(0);
} else {
  console.log("DID NOT CONVERGE within 3 rounds. AUDIT FAIL.");
  process.exit(1);
}
