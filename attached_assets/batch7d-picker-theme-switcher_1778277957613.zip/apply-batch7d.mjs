#!/usr/bin/env node
/**
 * apply-batch7d.mjs — Phase 7d (Picker + theme + Layout + accounts contextLabel).
 *
 * Idempotent. Sentinel-based str_replace.
 *
 * Scope:
 *   - New page: dashboard/pages/picker.tsx (product picker landing)
 *   - New placeholder pages: dashboard/pages/context-pipeline.tsx,
 *                            dashboard/pages/context-inspector.tsx,
 *                            dashboard/pages/context-activity.tsx
 *   - dashboard/App.tsx — register 4 new routes
 *   - dashboard/components/layout.tsx — product-aware (data-product attr,
 *     brand text, nav hrefs, "Switch product" link)
 *   - dashboard/index.css — amber theme via [data-product="context"]
 *   - dashboard/pages/accounts.tsx — Context Followuper Label field
 *
 * Doctrine UI is not touched semantically. `/`, `/pipeline`, `/inspector`,
 * `/activity`, `/accounts` continue to behave exactly as today.
 *
 * Usage:
 *   DASH_BASE=artifacts/dashboard/src FILES_BASE=files/dashboard \
 *     node apply-batch7d.mjs
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync, mkdirSync } from "fs";
import { join, dirname } from "path";

const DASH_BASE  = process.env.DASH_BASE  || "artifacts/dashboard/src";
const FILES_BASE = process.env.FILES_BASE || "files/dashboard";

const log  = (msg) => console.log(`[apply-batch7d] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7d] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function ensureDir(path) { mkdirSync(dirname(path), { recursive: true }); }

function installFile(srcRel, dstRel, label) {
  const src = join(FILES_BASE, srcRel);
  const dst = join(DASH_BASE, dstRel);
  if (!existsSync(src)) fail(`Source missing: ${src}`);
  ensureDir(dst);
  // Idempotent: if dst exists with identical content, skip.
  if (existsSync(dst)) {
    const a = readFileSync(src, "utf-8");
    const b = readFileSync(dst, "utf-8");
    if (a === b) { log(`  [=] ${label} (already installed)`); return "skipped"; }
  }
  copyFileSync(src, dst);
  log(`  [+] ${label}`);
  return "applied";
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

function appendIfAbsent(path, block, sentinel, label) {
  if (!block.includes(sentinel)) fail(`Sentinel for "${label}" is not in block`);
  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }
  // Ensure clean newline boundary.
  const sep = original.endsWith("\n") ? "" : "\n";
  writeFileSync(path, original + sep + block);
  log(`  [+] ${label}`);
  return "applied";
}

// ============================================================
// Step 1: Install new pages
// ============================================================
log("Step 1: Install new pages...");

installFile("pages/picker.tsx",            "pages/picker.tsx",            "pages/picker.tsx (new)");
installFile("pages/context-pipeline.tsx",  "pages/context-pipeline.tsx",  "pages/context-pipeline.tsx (new)");
installFile("pages/context-inspector.tsx", "pages/context-inspector.tsx", "pages/context-inspector.tsx (new)");
installFile("pages/context-activity.tsx",  "pages/context-activity.tsx",  "pages/context-activity.tsx (new)");

// ============================================================
// Step 2: App.tsx — register 4 new routes
// ============================================================
log("Step 2: Register routes in App.tsx...");

const appPath = join(DASH_BASE, "App.tsx");

strReplace(
  appPath,
  `import Pipeline from "@/pages/pipeline";
import EmailInspector from "@/pages/email-inspector";
import Accounts from "@/pages/accounts";
import ActivityLog from "@/pages/activity-log";
import NotFound from "@/pages/not-found";`,
  `import Pipeline from "@/pages/pipeline";
import EmailInspector from "@/pages/email-inspector";
import Accounts from "@/pages/accounts";
import ActivityLog from "@/pages/activity-log";
import NotFound from "@/pages/not-found";

// Phase 7d: Context Based Followuper UI scaffolding.
import Picker from "@/pages/picker";
import ContextPipeline from "@/pages/context-pipeline";
import ContextEmailInspector from "@/pages/context-inspector";
import ContextActivityLog from "@/pages/context-activity";`,
  "App.tsx: import context page modules",
  `// Phase 7d: Context Based Followuper UI scaffolding.
import Picker from "@/pages/picker";`
);

strReplace(
  appPath,
  `      <Route path="/inspector" component={EmailInspector} />
      <Route path="/accounts" component={Accounts} />
      <Route path="/activity" component={ActivityLog} />
      <Route component={NotFound} />`,
  `      <Route path="/inspector" component={EmailInspector} />
      <Route path="/accounts" component={Accounts} />
      <Route path="/activity" component={ActivityLog} />
      {/* Phase 7d: picker + context routes. Doctrine routes above are unchanged. */}
      <Route path="/picker" component={Picker} />
      <Route path="/context/pipeline" component={ContextPipeline} />
      <Route path="/context/inspector" component={ContextEmailInspector} />
      <Route path="/context/activity" component={ContextActivityLog} />
      <Route component={NotFound} />`,
  "App.tsx: register context routes",
  `{/* Phase 7d: picker + context routes. Doctrine routes above are unchanged. */}
      <Route path="/picker" component={Picker} />`
);

// ============================================================
// Step 3: index.css — amber theme override
// ============================================================
log("Step 3: Append amber theme to index.css...");

const cssPath = join(DASH_BASE, "index.css");

appendIfAbsent(
  cssPath,
  `
/* Phase 7d: Context Based Followuper theme override.
   Applied via [data-product="context"] on the Layout root. Overrides the
   accent palette only — bg, text, and border tokens stay shared. */
[data-product="context"] {
  --accent: #f59e0b;
  --accent-hover: #d97706;
  --accent-muted: rgba(245,158,11,0.10);
  --accent-border: rgba(245,158,11,0.25);
}
`,
  `/* Phase 7d: Context Based Followuper theme override.`,
  "index.css: amber theme block"
);

// ============================================================
// Step 4: Layout — product-aware sidebar
// ============================================================
log("Step 4: Layout component product awareness...");

const layoutPath = join(DASH_BASE, "components", "layout.tsx");

// Step 4a: extend lucide-react icon imports — add ArrowLeftRight (switcher icon)
strReplace(
  layoutPath,
  `import { Eye, LogOut, Workflow, Radio, Activity, Settings as SettingsIcon } from "lucide-react";`,
  `import { Eye, LogOut, Workflow, Radio, Activity, Settings as SettingsIcon, ArrowLeftRight } from "lucide-react";`,
  "layout.tsx: import ArrowLeftRight icon",
  `import { Eye, LogOut, Workflow, Radio, Activity, Settings as SettingsIcon, ArrowLeftRight } from "lucide-react";`
);

// Step 4b: derive productScope right after location
strReplace(
  layoutPath,
  `export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { apiKey, clearApiKey } = useApiKey();`,
  `export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  // Phase 7d: derive product scope from URL. /context/* → context (amber theme),
  // anything else → doctrine (blue, default). The picker route renders inside
  // the doctrine theme since localStorage is not yet read here.
  const onContext = location.startsWith("/context");
  const dataProduct = onContext ? "context" : "doctrine";
  const brandLabel = onContext ? "Context Based" : "Doctrine AI";
  const { apiKey, clearApiKey } = useApiKey();`,
  "layout.tsx: derive productScope from URL",
  `// Phase 7d: derive product scope from URL. /context/* → context (amber theme),`
);

// Step 4c: replace nav items definition with product-aware version
strReplace(
  layoutPath,
  `  const navItems = [
    { name: "Pipeline", href: "/", icon: Workflow },
    { name: "Email Inspector", href: "/inspector", icon: Eye },
    { name: "Activity Log", href: "/activity", icon: Activity },
  ];

  const isSettingsActive = location === "/accounts";`,
  `  // Phase 7d: nav items target the active product's URL family.
  const navItems = onContext
    ? [
        { name: "Pipeline", href: "/context/pipeline", icon: Workflow },
        { name: "Email Inspector", href: "/context/inspector", icon: Eye },
        { name: "Activity Log", href: "/context/activity", icon: Activity },
      ]
    : [
        { name: "Pipeline", href: "/", icon: Workflow },
        { name: "Email Inspector", href: "/inspector", icon: Eye },
        { name: "Activity Log", href: "/activity", icon: Activity },
      ];

  const isSettingsActive = location === "/accounts";`,
  "layout.tsx: product-aware navItems",
  `// Phase 7d: nav items target the active product's URL family.
  const navItems = onContext`
);

// Step 4d: apply data-product to the outermost div
strReplace(
  layoutPath,
  `  return (
    <div className="flex min-h-screen w-full">
      <aside`,
  `  return (
    <div className="flex min-h-screen w-full" data-product={dataProduct}>
      <aside`,
  "layout.tsx: data-product attribute on root",
  `<div className="flex min-h-screen w-full" data-product={dataProduct}>`
);

// Step 4e: replace hardcoded brand text "Doctrine AI" with the dynamic label
strReplace(
  layoutPath,
  `            style={{ fontSize: "14px", letterSpacing: "-0.01em", color: "var(--text-primary)" }}
          >
            Doctrine AI
          </span>`,
  `            style={{ fontSize: "14px", letterSpacing: "-0.01em", color: "var(--text-primary)" }}
          >
            {brandLabel}
          </span>`,
  "layout.tsx: dynamic brand label",
  `style={{ fontSize: "14px", letterSpacing: "-0.01em", color: "var(--text-primary)" }}
          >
            {brandLabel}`
);

// Step 4f: insert "Switch product" link above the Sign out button
strReplace(
  layoutPath,
  `          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-2.5 px-3 py-2.5 rounded-md text-[13px] font-medium transition-all duration-150"
            style={{ color: "var(--text-tertiary)" }}`,
  `          {/* Phase 7d: Switch product — flips between Doctrine and Context. */}
          <Link href="/picker" className="block">
            <div
              className="flex items-center gap-2.5 px-3 py-2 rounded-md text-[12px] font-medium transition-all duration-150"
              style={{ color: "var(--text-secondary)" }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = "var(--text-primary)";
                e.currentTarget.style.background = "var(--bg-tertiary)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = "var(--text-secondary)";
                e.currentTarget.style.background = "transparent";
              }}
            >
              <ArrowLeftRight className="h-3.5 w-3.5" strokeWidth={1.5} />
              Switch product
            </div>
          </Link>

          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-2.5 px-3 py-2.5 rounded-md text-[13px] font-medium transition-all duration-150"
            style={{ color: "var(--text-tertiary)" }}`,
  "layout.tsx: insert Switch-product link",
  `{/* Phase 7d: Switch product — flips between Doctrine and Context. */}
          <Link href="/picker" className="block">`
);

// ============================================================
// Step 5: accounts.tsx — Context Followuper Label field
// ============================================================
log("Step 5: Accounts contextLabel field...");

const accountsPath = join(DASH_BASE, "pages", "accounts.tsx");

// Step 5a: add useState for contextLabel right next to doctrineLabel
strReplace(
  accountsPath,
  `  const [doctrineLabel, setDoctrineLabel] = useState<string>(account.doctrineLabel || "Doctrine SDR");`,
  `  const [doctrineLabel, setDoctrineLabel] = useState<string>(account.doctrineLabel || "Doctrine SDR");
  // Phase 7d: Context Followuper label, settable per-account.
  const [contextLabel, setContextLabel] = useState<string>(account.contextLabel || "Context Followuper");`,
  "accounts.tsx: contextLabel useState",
  `// Phase 7d: Context Followuper label, settable per-account.
  const [contextLabel, setContextLabel] = useState<string>(account.contextLabel || "Context Followuper");`
);

// Step 5b: add contextLabel to the body sent on save
strReplace(
  accountsPath,
  `        sendDays,
        sendHourStart,
        sendHourEnd,
        doctrineLabel,
        weeklyDigestEnabled,
      };`,
  `        sendDays,
        sendHourStart,
        sendHourEnd,
        doctrineLabel,
        contextLabel,
        weeklyDigestEnabled,
      };`,
  "accounts.tsx: contextLabel in save body",
  `        sendDays,
        sendHourStart,
        sendHourEnd,
        doctrineLabel,
        contextLabel,
        weeklyDigestEnabled,
      };`
);

// Step 5c: render the Context label input under the Doctrine label input
strReplace(
  accountsPath,
  `              {/* Gmail label */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Gmail label
                </label>
                <Input
                  value={doctrineLabel}
                  onChange={(e) => setDoctrineLabel(e.target.value)}
                  placeholder="Doctrine SDR"
                  className="max-w-xs"
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync</p>
              </div>`,
  `              {/* Gmail label — Doctrine */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Doctrine Gmail label
                </label>
                <Input
                  value={doctrineLabel}
                  onChange={(e) => setDoctrineLabel(e.target.value)}
                  placeholder="Doctrine SDR"
                  className="max-w-xs"
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync into the Doctrine flow</p>
              </div>

              {/* Phase 7d: Gmail label — Context */}
              <div>
                <label className="block mb-1.5 font-medium uppercase tracking-[0.04em]" style={{ fontSize: "11px", color: "var(--text-tertiary)" }}>
                  Context Gmail label
                </label>
                <Input
                  value={contextLabel}
                  onChange={(e) => setContextLabel(e.target.value)}
                  placeholder="Context Followuper"
                  className="max-w-xs"
                />
                <p className="text-[11px] mt-1" style={{ color: "var(--text-tertiary)" }}>Comma-separated label names to sync into the Context flow</p>
              </div>`,
  "accounts.tsx: Context label input",
  `{/* Phase 7d: Gmail label — Context */}`
);

// ============================================================
// Step 6: Self-verify
// ============================================================
log("Step 6: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

expectInFile(join(DASH_BASE, "pages", "picker.tsx"),            `STORAGE_KEY = "doctrine.lastProduct"`,           "V1  picker.tsx installed");
expectInFile(join(DASH_BASE, "pages", "context-pipeline.tsx"),  `Pipeline UI ships in Phase 7e`,                 "V2  context-pipeline.tsx installed");
expectInFile(join(DASH_BASE, "pages", "context-inspector.tsx"), `Inspector UI ships in Phase 7f`,                "V3  context-inspector.tsx installed");
expectInFile(join(DASH_BASE, "pages", "context-activity.tsx"),  `Activity Log UI ships in Phase 7f`,             "V4  context-activity.tsx installed");

expectInFile(appPath, `import Picker from "@/pages/picker";`,                                                     "V5  App.tsx imports Picker");
expectInFile(appPath, `<Route path="/picker" component={Picker} />`,                                              "V6  App.tsx routes /picker");
expectInFile(appPath, `<Route path="/context/pipeline" component={ContextPipeline} />`,                           "V7  App.tsx routes /context/pipeline");
expectInFile(appPath, `<Route path="/context/inspector" component={ContextEmailInspector} />`,                    "V8  App.tsx routes /context/inspector");
expectInFile(appPath, `<Route path="/context/activity" component={ContextActivityLog} />`,                        "V9  App.tsx routes /context/activity");

expectInFile(cssPath, `[data-product="context"]`,                                                                  "V10 index.css amber override");
expectInFile(cssPath, `--accent: #f59e0b;`,                                                                        "V11 index.css amber accent");

expectInFile(layoutPath, `ArrowLeftRight`,                                                                         "V12 layout.tsx ArrowLeftRight import");
expectInFile(layoutPath, `const onContext = location.startsWith("/context");`,                                     "V13 layout.tsx onContext derive");
expectInFile(layoutPath, `const dataProduct = onContext ? "context" : "doctrine";`,                                "V14 layout.tsx dataProduct value");
expectInFile(layoutPath, `data-product={dataProduct}`,                                                             "V15 layout.tsx attr applied");
expectInFile(layoutPath, `{brandLabel}`,                                                                           "V16 layout.tsx dynamic brand");
expectInFile(layoutPath, `Switch product`,                                                                         "V17 layout.tsx switcher link");

expectInFile(accountsPath, `const [contextLabel, setContextLabel]`,                                                "V18 accounts.tsx contextLabel state");
expectInFile(accountsPath, `        contextLabel,`,                                                                "V19 accounts.tsx contextLabel in save body");
expectInFile(accountsPath, `Context Gmail label`,                                                                  "V20 accounts.tsx contextLabel input rendered");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7d patch applied. Picker, theme, switcher, and contextLabel");
log("are live. Doctrine UI is unchanged. /context/pipeline shows the");
log("placeholder; full Context Pipeline ships in 7e.");
log("================================================================");
