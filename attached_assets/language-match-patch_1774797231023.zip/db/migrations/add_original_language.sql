-- Migration: Add original_language column to prospects table
-- This column stores the ISO 639-1 language code of the original outbound email
-- so follow-up emails are generated in the same language.

ALTER TABLE prospects
ADD COLUMN IF NOT EXISTS original_language TEXT NOT NULL DEFAULT 'en';

-- Backfill existing prospects: detect language from subject line using basic heuristics.
-- Japanese (Hiragana/Katakana/CJK mix)
UPDATE prospects
SET original_language = 'ja'
WHERE original_language = 'en'
  AND subject ~ '[\u3040-\u309F\u30A0-\u30FF]';

-- Korean (Hangul)
UPDATE prospects
SET original_language = 'ko'
WHERE original_language = 'en'
  AND subject ~ '[\uAC00-\uD7AF]';

-- Chinese (CJK without Japanese kana)
UPDATE prospects
SET original_language = 'zh'
WHERE original_language = 'en'
  AND subject ~ '[\u4E00-\u9FFF]'
  AND subject !~ '[\u3040-\u309F\u30A0-\u30FF]';

-- Hebrew
UPDATE prospects
SET original_language = 'he'
WHERE original_language = 'en'
  AND subject ~ '[\u0590-\u05FF]';

-- Arabic
UPDATE prospects
SET original_language = 'ar'
WHERE original_language = 'en'
  AND subject ~ '[\u0600-\u06FF]';

-- Russian / Cyrillic
UPDATE prospects
SET original_language = 'ru'
WHERE original_language = 'en'
  AND subject ~ '[\u0400-\u04FF]';
