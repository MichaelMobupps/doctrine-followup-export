#!/usr/bin/env bash
#
# Gemini critic model switch.
#
#   Patched (idempotent, anchored on verbatim current text):
#     src/lib/gemini.ts          GEMINI_CRITIC_MODEL becomes env-configurable
#                                (default gemini-3-flash-preview)
#     src/lib/pricing.ts         add gemini-3.1-pro + gemini-3-flash-preview rows
#     src/services/criticProvider.ts  add GEMINI_CRITIC_FOCUS, append to Gemini
#                                prompt only (Anthropic prompt untouched)
#   Overwritten:
#     src/scripts/smoke-critic.ts  model-agnostic, prod-faithful, judgment draft
#
# Gates: typecheck -> full test suite -> build -> mirror. Backup + restore.sh.
# Does NOT run the smoke test (billed Gemini call) and does NOT flip production.

set -uo pipefail

WORKSPACE="/home/runner/workspace"
API_PKG="$WORKSPACE/artifacts/api-server"
API_SRC="$API_PKG/src"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PAYLOAD="$SCRIPT_DIR/payload"
BACKUP="$SCRIPT_DIR/backup"

say() { echo "[model-switch] $*"; }
die() { echo ""; echo "[model-switch] HALT: $*"; exit 1; }

[ -d "$API_SRC" ] || die "api-server src not found at $API_SRC"
[ -f "$PAYLOAD/scripts/smoke-critic.ts" ] || die "missing payload/scripts/smoke-critic.ts"
for f in lib/gemini.ts lib/pricing.ts services/criticProvider.ts scripts/smoke-critic.ts; do
  [ -f "$API_SRC/$f" ] || die "$f not found in tree"
done

# ---- backup + restore ----
mkdir -p "$BACKUP"
for f in lib/gemini.ts lib/pricing.ts services/criticProvider.ts scripts/smoke-critic.ts; do
  mkdir -p "$BACKUP/$(dirname "$f")"
  cp "$API_SRC/$f" "$BACKUP/$f.bak"
done
cat > "$SCRIPT_DIR/restore.sh" <<RESTORE
#!/usr/bin/env bash
set -e
for f in lib/gemini.ts lib/pricing.ts services/criticProvider.ts scripts/smoke-critic.ts; do
  cp "$BACKUP/\$f.bak" "$API_SRC/\$f"
done
echo "[model-switch] reverted all four files. Re-run typecheck/build and re-mirror."
RESTORE
chmod +x "$SCRIPT_DIR/restore.sh"
say "backup written; restore.sh ready"

# ---- overwrite smoke test ----
say "installing rewritten smoke-critic.ts"
cp "$PAYLOAD/scripts/smoke-critic.ts" "$API_SRC/scripts/smoke-critic.ts"

# ---- idempotent patches ----
say "patching gemini.ts, pricing.ts, criticProvider.ts (idempotent)"
python3 "$SCRIPT_DIR/apply.py" "$API_SRC" || die "patch failed (see message above). Run restore.sh."

# ---- GATE 1: typecheck ----
say "GATE typecheck (tsc -b)"
( cd "$API_PKG" && pnpm run typecheck ) || die "typecheck failed. Run restore.sh."
say "typecheck passed"

# ---- GATE 2: full test suite (smoke test excluded by design) ----
say "GATE tests: full suite"
( cd "$API_PKG" && node --import tsx --test src/tests/*.ts ) || die "test suite failed. Run restore.sh."
say "tests passed"

# ---- GATE 3: build ----
say "GATE build"
( cd "$API_PKG" && pnpm run build ) || die "build failed. Run restore.sh."
say "build passed"

# ---- mirror ----
if [ -f "$WORKSPACE/source-code/sync.sh" ]; then
  say "mirroring artifacts -> source-code"
  bash "$WORKSPACE/source-code/sync.sh" || say "WARN: mirror failed (non-fatal)"
fi

echo ""
say "SUCCESS. Model switch installed. Production is unchanged until you flip CRITIC_PROVIDER."
echo ""
echo "  The critic model is now an env var. Default is gemini-3-flash-preview."
echo "    GEMINI_CRITIC_MODEL=gemini-3-flash-preview   (default, ~70% off the critic)"
echo "    GEMINI_CRITIC_MODEL=gemini-3.1-pro           (quality-safe, ~46% off)"
echo "    GEMINI_CRITIC_MODEL=gemini-3.5-flash         (still priced, overloaded)"
echo ""
echo "  Validate before flipping production:"
echo "    1. Run the smoke test (billed, needs GEMINI_API_KEY):"
echo "         cd $API_PKG && node --import tsx src/scripts/smoke-critic.ts"
echo "    2. Run in shadow first to compare against Opus on live drafts:"
echo "         set CRITIC_PROVIDER=shadow, then read CRITIC_SHADOW agree_needs_rewrite"
echo "    3. When satisfied, flip CRITIC_PROVIDER=gemini."
echo ""
echo "  Revert the code anytime: bash $SCRIPT_DIR/restore.sh"
