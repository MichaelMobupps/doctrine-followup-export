import React from "react";
import { Workflow, Construction } from "lucide-react";

/**
 * Phase 7d: placeholder. The full ContextPipeline UI ships in 7e as a
 * clone of pipeline.tsx retargeted to /api/context/* endpoints.
 *
 * Intentionally minimal — no fetches, no mutations. Renders inside the
 * Layout, which applies the amber theme via data-product="context".
 */
export default function ContextPipeline() {
  return (
    <div className="flex flex-col items-start py-2">
      <div className="mb-1 flex items-center gap-2">
        <Workflow className="w-5 h-5" style={{ color: "var(--accent)" }} strokeWidth={1.75} />
        <h1 className="text-xl font-semibold tracking-tight" style={{ color: "var(--text-primary)" }}>
          Context Pipeline
        </h1>
      </div>
      <p className="text-[13px] mb-8" style={{ color: "var(--text-secondary)" }}>
        Reply-driven follow-ups for context-labelled threads.
      </p>

      <div
        className="w-full max-w-2xl rounded-lg p-8"
        style={{
          background: "var(--bg-secondary)",
          border: "1px solid var(--border-default)",
        }}
      >
        <div
          className="w-10 h-10 rounded-md flex items-center justify-center mb-4"
          style={{ background: "var(--accent-muted)", color: "var(--accent)" }}
        >
          <Construction className="w-5 h-5" strokeWidth={1.75} />
        </div>
        <h2 className="text-[15px] font-semibold mb-2" style={{ color: "var(--text-primary)" }}>
          Pipeline UI ships in Phase 7e
        </h2>
        <p className="text-[13px] leading-relaxed mb-4" style={{ color: "var(--text-secondary)" }}>
          The Context backend is fully wired. Prospects, follow-ups, drafts, scheduling,
          and approvals all run through <code style={{ color: "var(--text-primary)", background: "var(--bg-tertiary)", padding: "1px 6px", borderRadius: "3px" }}>/api/context/*</code> endpoints.
          The Pipeline UI for this surface — a clone of the Doctrine Pipeline retargeted
          to those endpoints, with the vertical filter and queue-batch removed — lands in 7e.
        </p>
        <p className="text-[13px] leading-relaxed" style={{ color: "var(--text-secondary)" }}>
          Until then, you can still set your Context Followuper Gmail label name in
          Settings, and the cron sync will pick up labelled threads on the next 15-minute tick.
          Drafts and follow-ups will be generated, but you cannot review them in this UI yet.
        </p>
      </div>
    </div>
  );
}
