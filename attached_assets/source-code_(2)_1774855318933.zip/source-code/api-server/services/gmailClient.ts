import { google, gmail_v1 } from "googleapis";
import { logger } from "../lib/logger";

export interface GmailMessageMeta {
  id: string;
  threadId: string;
  from: string;
  to: string;
  subject: string;
  snippet: string;
  body: string;
  date: string;
  labels: string[];
}

export interface GmailCredentials {
  refreshToken: string;
  email: string;
  name?: string;
}

function getAuth() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
  );
}

export function getGmailForUser(creds: GmailCredentials): gmail_v1.Gmail {
  const auth = getAuth();
  auth.setCredentials({ refresh_token: creds.refreshToken });
  return google.gmail({ version: "v1", auth });
}

function getGmail(): gmail_v1.Gmail {
  const auth = getAuth();
  auth.setCredentials({ refresh_token: process.env.GOOGLE_REFRESH_TOKEN });
  return google.gmail({ version: "v1", auth });
}

export async function ensureLabelsExist(
  labelNames: string[],
  gmail: gmail_v1.Gmail,
): Promise<Map<string, string>> {
  const labelIdToName = new Map<string, string>();
  try {
    const res = await gmail.users.labels.list({ userId: "me" });
    const allLabels = res.data.labels || [];
    const existing = new Set(
      allLabels.map((l) => l.name?.toLowerCase()).filter(Boolean),
    );

    for (const l of allLabels) {
      if (l.id && l.name) {
        labelIdToName.set(l.id, l.name);
      }
    }

    for (const name of labelNames) {
      if (existing.has(name.toLowerCase())) continue;
      try {
        const created = await gmail.users.labels.create({
          userId: "me",
          requestBody: {
            name,
            labelListVisibility: "labelShow",
            messageListVisibility: "show",
          },
        });
        logger.info({ label: name }, "Created missing Gmail label");
        if (created.data.id && created.data.name) {
          labelIdToName.set(created.data.id, created.data.name);
        }
      } catch (err: any) {
        if (err.code === 409) {
          logger.debug({ label: name }, "Label already exists (conflict)");
        } else {
          logger.error({ err, label: name }, "Failed to create Gmail label");
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "Failed to list Gmail labels for auto-creation");
  }
  return labelIdToName;
}

export async function fetchLabeledSentEmails(
  labels: string[],
  afterDate?: string,
  gmail?: gmail_v1.Gmail,
): Promise<GmailMessageMeta[]> {
  if (!gmail) gmail = getGmail();

  const labelQuery = labels.map((l) => `label:${l.replace(/\s+/g, "-")}`).join(" OR ");
  let q = `in:sent (${labelQuery})`;
  if (afterDate) {
    q += ` after:${afterDate}`;
  }

  const messages: GmailMessageMeta[] = [];
  let pageToken: string | undefined;

  do {
    const res = await gmail.users.messages.list({
      userId: "me",
      q,
      maxResults: 100,
      pageToken,
    });

    const items = res.data.messages || [];
    for (const item of items) {
      if (!item.id) continue;
      try {
        const msg = await fetchMessageDetail(gmail, item.id);
        if (msg) messages.push(msg);
      } catch (err) {
        logger.error({ err, messageId: item.id }, "Failed to fetch message detail");
      }
    }

    pageToken = res.data.nextPageToken ?? undefined;
  } while (pageToken);

  return messages;
}

async function fetchMessageDetail(
  gmail: gmail_v1.Gmail,
  messageId: string,
): Promise<GmailMessageMeta | null> {
  const res = await gmail.users.messages.get({
    userId: "me",
    id: messageId,
    format: "full",
  });

  const msg = res.data;
  if (!msg.id || !msg.threadId) return null;

  const headers = msg.payload?.headers || [];
  const getHeader = (name: string) =>
    headers.find((h) => h.name?.toLowerCase() === name.toLowerCase())?.value || "";

  let body = "";
  const parts = msg.payload?.parts || [];
  if (msg.payload?.mimeType === "text/plain" && msg.payload?.body?.data) {
    body = Buffer.from(msg.payload.body.data, "base64").toString("utf-8");
  } else {
    for (const part of parts) {
      if (part.mimeType === "text/plain" && part.body?.data) {
        body = Buffer.from(part.body.data, "base64").toString("utf-8");
        break;
      }
    }
  }

  const summary = body.slice(0, 500).trim();
  const labelIds = msg.labelIds || [];

  return {
    id: msg.id,
    threadId: msg.threadId,
    from: getHeader("From"),
    to: getHeader("To"),
    subject: getHeader("Subject"),
    snippet: msg.snippet || "",
    body: summary,
    date: getHeader("Date"),
    labels: labelIds,
  };
}

export async function checkThreadForReplies(
  threadId: string,
  senderEmail: string,
  gmail?: gmail_v1.Gmail,
): Promise<boolean> {
  if (!gmail) gmail = getGmail();
  const res = await gmail.users.threads.get({
    userId: "me",
    id: threadId,
    format: "metadata",
    metadataHeaders: ["From"],
  });

  const messages = res.data.messages || [];
  if (messages.length < 2) return false;

  const senderLower = senderEmail.toLowerCase();

  for (const msg of messages) {
    const from =
      msg.payload?.headers
        ?.find((h) => h.name?.toLowerCase() === "from")
        ?.value?.toLowerCase() || "";
    if (senderLower && !from.includes(senderLower)) {
      return true;
    }
  }

  return false;
}

function mimeEncodeHeader(value: string): string {
  if (/^[\x20-\x7E]*$/.test(value)) return value;
  const encoded = Buffer.from(value, "utf-8").toString("base64");
  return `=?UTF-8?B?${encoded}?=`;
}

async function getRfc822MessageId(gmail: gmail_v1.Gmail, messageId: string): Promise<string | null> {
  try {
    const msg = await gmail.users.messages.get({
      userId: "me",
      id: messageId,
      format: "metadata",
      metadataHeaders: ["Message-ID", "Message-Id"],
    });
    const headers = msg.data.payload?.headers || [];
    const messageIdHeader = headers.find(
      (h) => h.name?.toLowerCase() === "message-id"
    );
    return messageIdHeader?.value || null;
  } catch {
    return null;
  }
}

async function getGmailSignatureHtml(gmail: gmail_v1.Gmail, senderEmail: string): Promise<string> {
  try {
    const res = await gmail.users.settings.sendAs.get({
      userId: "me",
      sendAsEmail: senderEmail,
    });
    return res.data.signature || "";
  } catch {
    return "";
  }
}

function plainTextToHtml(text: string): string {
  let result = text;
  result = result.replace(/\\n/g, "\n");
  result = result.replace(/&/g, "&amp;");
  result = result.replace(/</g, "&lt;");
  result = result.replace(/>/g, "&gt;");
  result = result.replace(/\n/g, "<br>");
  return result;
}

export async function sendFollowupReply(params: {
  threadId: string;
  originalMessageId: string;
  to: string;
  subject: string;
  body: string;
  senderName: string;
  senderEmail: string;
  gmail?: gmail_v1.Gmail;
}): Promise<string> {
  const gmail = params.gmail || getGmail();

  const rfc822Id = await getRfc822MessageId(gmail, params.originalMessageId);
  const inReplyTo = rfc822Id || `<${params.originalMessageId}>`;
  const references = rfc822Id || `<${params.originalMessageId}>`;

  const signatureHtml = await getGmailSignatureHtml(gmail, params.senderEmail);
  const bodyHtml = plainTextToHtml(params.body);
  const fontStyle = 'font-family: "Calibri Light", Calibri, sans-serif; font-size: 11pt;';
  const fullHtml = signatureHtml
    ? `<div dir="ltr" style="${fontStyle}">${bodyHtml}<br><br><div class="gmail_signature">${signatureHtml}</div></div>`
    : `<div dir="ltr" style="${fontStyle}">${bodyHtml}</div>`;

  const replySubject = params.subject.startsWith("Re:")
    ? params.subject
    : `Re: ${params.subject}`;

  const encodedSubject = mimeEncodeHeader(replySubject);
  const encodedSenderName = mimeEncodeHeader(params.senderName);

  const rawMessage = [
    `From: ${encodedSenderName} <${params.senderEmail}>`,
    `To: ${params.to}`,
    `Subject: ${encodedSubject}`,
    `In-Reply-To: ${inReplyTo}`,
    `References: ${references}`,
    `MIME-Version: 1.0`,
    `Content-Type: text/html; charset="UTF-8"`,
    `Content-Transfer-Encoding: base64`,
    "",
    Buffer.from(fullHtml, "utf-8").toString("base64"),
  ].join("\r\n");

  const encoded = Buffer.from(rawMessage)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  const res = await gmail.users.messages.send({
    userId: "me",
    requestBody: {
      raw: encoded,
      threadId: params.threadId,
    },
  });

  return res.data.id || "";
}

export function extractEmail(headerValue: string): string {
  const match =
    headerValue.match(/<([^>]+)>/) || headerValue.match(/([^\s,]+@[^\s,]+)/);
  return match ? match[1].trim() : headerValue.trim();
}

export function extractName(headerValue: string): string {
  const match = headerValue.match(/^"?([^"<]+)"?\s*</);
  if (match) return match[1].trim();
  const email = extractEmail(headerValue);
  return email.split("@")[0].replace(/[._-]/g, " ");
}
