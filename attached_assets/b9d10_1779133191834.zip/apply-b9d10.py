#!/usr/bin/env python3
"""
B9d.10 - Sidebar active-state accent treatment.

The sidebar already has an active state (location-matched nav item),
but uses a subtle bg-tertiary tint + thin right border. On the new
darker AG bg + with the product themes (B9d.4), the active item
should pop visually with accent-colored treatment.

Single anchor in layout.tsx that replaces the active-state styling:

  Before:
    - Active: text-primary, bg-tertiary, borderRight accent 2px
    - Icon: text-primary on active

  After:
    - Active: accent text, accent-muted bg, accent-border (rounded box)
    - Active: font-semibold (vs font-medium)
    - Inactive: border-transparent to keep box size consistent
    - Inactive hover unchanged (bg-tertiary tint)
    - Icon: accent color on active

Per-product result:
  Doctrine - blue active items
  Context  - amber active items
  AG       - blue active items (darker variant)

Inline borderRight style removed - replaced by full Tailwind border.
duration-150 -> duration-200 to match Button transitions.

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
LAYOUT = WORKSPACE / "artifacts/dashboard/src/components/layout.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already updated")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected exactly 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: Active nav item styling - accent treatment
# Anchor on the existing main nav item <div> + <item.icon> block.
# ====================================================================
A1_OLD = '''                <div
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2.5 rounded-md text-[13px] font-medium transition-all duration-150",
                    isActive
                      ? "text-[var(--text-primary)] bg-[var(--bg-tertiary)]"
                      : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)]"
                  )}
                  style={isActive ? { borderRight: "2px solid var(--accent)" } : {}}
                >
                  <item.icon
                    className="h-4 w-4"
                    style={{ color: isActive ? "var(--text-primary)" : "var(--text-secondary)" }}
                  />'''

A1_NEW = '''                {/* B9d.10: active nav item gets accent-tinted treatment. */}
                <div
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2.5 rounded-md text-[13px] transition-all duration-200 border",
                    isActive
                      ? "font-semibold text-[var(--accent)] bg-[var(--accent-muted)] border-[var(--accent-border)]"
                      : "font-medium text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-tertiary)] border-transparent"
                  )}
                >
                  <item.icon
                    className="h-4 w-4"
                    style={{ color: isActive ? "var(--accent)" : "var(--text-secondary)" }}
                  />'''


def main():
    if not LAYOUT.exists():
        fail(f"layout.tsx not found: {LAYOUT}")
    text = LAYOUT.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: accent-tinted active nav item",
        marker="B9d.10: active nav item gets accent-tinted treatment",
    )

    if text != original:
        LAYOUT.write_text(text, encoding="utf-8")
        ok(f"wrote {LAYOUT.relative_to(WORKSPACE)}")
    else:
        skip("layout.tsx already patched")

    print()
    print("B9d.10 sidebar active-state accent applied.")


if __name__ == "__main__":
    main()
