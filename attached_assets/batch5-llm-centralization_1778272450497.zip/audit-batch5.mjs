#!/usr/bin/env node
/**
 * audit-batch5.mjs — Beautiful-Squidward audit for Phase 5.
 * 3 rounds × 9 passes per round.
 *
 * Verifies LLM call site centralization: zero hardcoded model strings,
 * zero thinking-budget overrides anywhere in the codebase, and all
 * call sites import named MODEL_* constants from lib/anthropic.
 *
 * Run AFTER apply-batch5.mjs.
 *
 * Env vars:
 *   API_BASE = path to api-server source (default: artifacts/api-server/src)
 */

import { existsSync, readFileSync, readdirSync, statSync } from "fs";
import { join } from "path";

const API_BASE = process.env.API_BASE || "artifacts/api-server/src";

const anthropicLibPath = join(API_BASE, "lib", "anthropic.ts");
const summarizerPath   = join(API_BASE, "services", "emailSummarizer.ts");
const generatorPath    = join(API_BASE, "services", "followupGenerator.ts");

let totalPasses = 0;
let totalFails = 0;
const failureMessages = [];

function read(path) {
  if (!existsSync(path)) throw new Error(`File missing: ${path}`);
  return readFileSync(path, "utf-8");
}

function check(label, condition, detail = "") {
  totalPasses++;
  if (condition) {
    console.log(`    [PASS] ${label}`);
  } else {
    totalFails++;
    failureMessages.push(`${label}${detail ? " — " + detail : ""}`);
    console.log(`    [FAIL] ${label}${detail ? " — " + detail : ""}`);
  }
}

function countIn(path, needle) {
  return read(path).split(needle).length - 1;
}

/** Walk every .ts file under a directory, excluding *.bak and .d.ts. */
function walkTs(dir) {
  const out = [];
  if (!existsSync(dir)) return out;
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    const st = statSync(full);
    if (st.isDirectory()) {
      out.push(...walkTs(full));
    } else if (st.isFile() && full.endsWith(".ts") && !full.endsWith(".bak") && !full.endsWith(".d.ts")) {
      out.push(full);
    }
  }
  return out;
}

function runOneRound(roundNum) {
  console.log(`\n--- Round ${roundNum} ---`);

  // PASS 1: All 4 MODEL_* constants exported with explicit literal types
  console.log(`  PASS 1: MODEL_* exports`);
  const lib = read(anthropicLibPath);
  check("1a. MODEL_SUMMARIZER exported as literal type",
    /export const MODEL_SUMMARIZER:\s*"claude-[\w.-]+"\s*=\s*"claude-[\w.-]+";/.test(lib));
  check("1b. MODEL_DRAFT_GENERATOR exported as literal type",
    /export const MODEL_DRAFT_GENERATOR:\s*"claude-[\w.-]+"\s*=\s*"claude-[\w.-]+";/.test(lib));
  check("1c. MODEL_CRITIC exported as literal type",
    /export const MODEL_CRITIC:\s*"claude-[\w.-]+"\s*=\s*"claude-[\w.-]+";/.test(lib));
  check("1d. MODEL_REWRITER exported as literal type",
    /export const MODEL_REWRITER:\s*"claude-[\w.-]+"\s*=\s*"claude-[\w.-]+";/.test(lib));

  // PASS 2: emailSummarizer imports and uses MODEL_SUMMARIZER
  console.log(`  PASS 2: emailSummarizer wiring`);
  const summarizer = read(summarizerPath);
  check("2a. emailSummarizer imports MODEL_SUMMARIZER",
    summarizer.includes(`import { anthropic, MODEL_SUMMARIZER } from "../lib/anthropic"`));
  check("2b. emailSummarizer uses MODEL_SUMMARIZER constant",
    summarizer.includes(`model: MODEL_SUMMARIZER,`));
  check("2c. emailSummarizer has zero hardcoded claude-* model strings",
    !/model:\s*"claude-/.test(summarizer));

  // PASS 3: followupGenerator imports and uses 3 constants
  console.log(`  PASS 3: followupGenerator wiring`);
  const generator = read(generatorPath);
  check("3a. followupGenerator imports all 3 model constants",
    generator.includes(`MODEL_DRAFT_GENERATOR, MODEL_CRITIC, MODEL_REWRITER`));
  check("3b. followupGenerator uses MODEL_DRAFT_GENERATOR",
    generator.includes(`model: MODEL_DRAFT_GENERATOR,`));
  check("3c. followupGenerator uses MODEL_CRITIC",
    generator.includes(`model: MODEL_CRITIC,`));
  check("3d. followupGenerator uses MODEL_REWRITER",
    generator.includes(`model: MODEL_REWRITER,`));
  check("3e. followupGenerator has zero hardcoded claude-* model strings",
    !/model:\s*"claude-/.test(generator));

  // PASS 4: Each MODEL_* constant used exactly once in services
  console.log(`  PASS 4: Single-use of each constant in services`);
  check("4a. MODEL_SUMMARIZER used exactly once in emailSummarizer",
    countIn(summarizerPath, `model: MODEL_SUMMARIZER,`) === 1);
  check("4b. MODEL_DRAFT_GENERATOR used exactly once in followupGenerator",
    countIn(generatorPath, `model: MODEL_DRAFT_GENERATOR,`) === 1);
  check("4c. MODEL_CRITIC used exactly once in followupGenerator",
    countIn(generatorPath, `model: MODEL_CRITIC,`) === 1);
  check("4d. MODEL_REWRITER used exactly once in followupGenerator",
    countIn(generatorPath, `model: MODEL_REWRITER,`) === 1);

  // PASS 5: Zero thinking budget / adaptive overrides anywhere in api-server
  console.log(`  PASS 5: Adaptive thinking integrity`);
  const tsFiles = walkTs(API_BASE);
  let thinkingHits = 0;
  let budgetHits = 0;
  let adaptiveDisableHits = 0;
  for (const f of tsFiles) {
    const content = read(f);
    // Look for object property usage like `thinking: {`, not function names
    if (/thinking\s*:\s*\{/.test(content)) thinkingHits++;
    if (/budget_tokens\s*:/.test(content)) budgetHits++;
    // Match actual env-var usage (process.env.X, X=, X==, X===), not documentation
    // mentions of the variable name in comments.
    if (/process\.env\.CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING|CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING\s*[=!]/.test(content)) {
      adaptiveDisableHits++;
    }
  }
  check("5a. zero `thinking: {...}` config blocks anywhere in api-server",
    thinkingHits === 0,
    `found in ${thinkingHits} file(s)`);
  check("5b. zero `budget_tokens` overrides anywhere in api-server",
    budgetHits === 0,
    `found in ${budgetHits} file(s)`);
  check("5c. zero CLAUDE_CODE_DISABLE_ADAPTIVE_THINKING runtime usage (doc mentions OK)",
    adaptiveDisableHits === 0,
    `found in ${adaptiveDisableHits} file(s)`);

  // PASS 6: Total LLM call site count is exactly 4 (no new sites slipped in)
  console.log(`  PASS 6: Call site inventory`);
  let messagesCreateCount = 0;
  for (const f of tsFiles) {
    if (f.endsWith("anthropicRetry.ts")) continue; // retry layer wraps the SDK; not a call site
    if (f.endsWith("anthropic.ts"))      continue; // client setup; not a call site
    messagesCreateCount += countIn(f, `anthropic.messages.create(`);
  }
  check("6a. exactly 4 anthropic.messages.create call sites in services",
    messagesCreateCount === 4,
    `found ${messagesCreateCount}`);

  // PASS 7: Every call site imports MODEL_* (no orphan call sites still
  // hardcoding strings, hidden in some other service file).
  console.log(`  PASS 7: All call sites use named constants`);
  let hardcodedHits = 0;
  const offenders = [];
  for (const f of tsFiles) {
    if (f.endsWith("anthropic.ts")) continue; // the lib intentionally has the literal strings
    const content = read(f);
    const matches = content.match(/model:\s*"claude-[^"]+"/g) || [];
    if (matches.length > 0) {
      hardcodedHits += matches.length;
      offenders.push(`${f} (${matches.length})`);
    }
  }
  check("7a. zero hardcoded `model: \"claude-...\"` strings outside lib/anthropic.ts",
    hardcodedHits === 0,
    offenders.join(", "));

  // PASS 8: No leftover *.bak files anywhere (including any stragglers)
  console.log(`  PASS 8: No backup files`);
  const allFiles = (function walkAll(d) {
    const out = [];
    if (!existsSync(d)) return out;
    for (const n of readdirSync(d)) {
      const full = join(d, n);
      const st = statSync(full);
      if (st.isDirectory()) out.push(...walkAll(full));
      else if (st.isFile()) out.push(full);
    }
    return out;
  })(API_BASE);
  const bakFiles = allFiles.filter((f) => f.endsWith(".bak"));
  check("8a. zero .bak files in api-server tree",
    bakFiles.length === 0,
    bakFiles.join(", "));

  // PASS 9: Adaptive thinking doctrine block present in lib/anthropic.ts
  // (provenance for future operators reading the file)
  console.log(`  PASS 9: Doctrine block present`);
  check("9a. lib/anthropic.ts contains the Phase 5 audit doctrine note",
    lib.includes("Phase 5 audit") && lib.includes("adaptive"));
  check("9b. lib/anthropic.ts notes Opus 4.7 always-adaptive behavior",
    /Opus 4\.7 always uses adaptive/i.test(lib));
  check("9c. lib/anthropic.ts notes Sonnet 4.6 default-adaptive behavior",
    /Sonnet 4\.6 supports adaptive thinking by default/i.test(lib));
}

console.log("================================================================");
console.log("Batch 5 audit — 3 rounds × 9 passes (Beautiful-Squidward)");
console.log("================================================================");

for (let round = 1; round <= 3; round++) {
  runOneRound(round);
}

console.log("");
console.log("================================================================");
console.log(`Total: ${totalPasses - totalFails}/${totalPasses} passed across 3 rounds.`);
if (totalFails > 0) {
  console.log(`FAILURES (${totalFails}):`);
  for (const m of failureMessages) console.log(`  - ${m}`);
  console.log("================================================================");
  process.exit(1);
} else {
  console.log("All passes succeeded across all 3 rounds.");
  console.log("================================================================");
}
