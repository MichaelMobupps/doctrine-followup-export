# Batch 7e — Context Pipeline UI

Phase 7e. Replaces the placeholder at `/context/pipeline` with a real
ContextPipeline page derived from the Doctrine Pipeline. Aligns the
backend wire format so the same UI shapes work for both products.

## What's in this batch

**Backend changes (`routes/context.ts`):**

- **Reshape `/api/context/followups` response** to match the doctrine
  endpoint exactly: snake_case keys, projects `original_subject`,
  `original_body`, `original_body_summary`, `original_language`,
  `original_sent_at`, `gmail_thread_id`, `created_at`, `vertical`,
  `max_followups`, `followup_mode`. Order changed from `desc` to `asc`
  by `scheduledAt` to match doctrine's render order. Same DB join
  (followups → prospects → users) plus the SCOPE filter.
- **New `/api/context/cancel-followup` endpoint** with
  `{ followup_ids: [...] }` contract — mirrors the doctrine `/api/cancel`
  semantics. Defense-in-depth via `inArray` sub-select that gates on
  `prospects.app = 'context'`. The existing `/api/context/cancel`
  (whole-prospect) endpoint stays — different operation.

**Frontend changes (`dashboard/pages/context-pipeline.tsx`):**

The B7d placeholder is replaced with a transformed clone of
`pipeline.tsx`. The apply script copies pipeline.tsx in place and runs
15 idempotent str_replace transformations:

1. Trim imports — drop `@tanstack/react-query`, `@workspace/api-client-react`,
   `Modal`/`Input`/`Badge`/`Layers`. Add Phase 7e header comment.
2. Rename component `Pipeline` → `ContextPipeline`. Drop `useQueryClient`.
3. Drop `filterVertical` state.
4. Drop queue-batch state (`isQueueModalOpen`, `queueVertical`, `queueDate`,
   `queueStage`).
5. Replace `useGetFollowups` / `useCancelFollowups` / `useQueueBatch`
   with raw fetch + `setInterval(fetchFollowups, 30000)` polling +
   `refetchTrigger` state. Add `cancelStageById` helper for single-stage
   cancel.
6. `invalidateAll` bumps `refetchTrigger`.
7. `filteredThreads` drops the vertical filter clause.
8. Eight URL retargets: `/api/...` → `/api/context/...` for followups,
   send-bulk, pause-bulk, prospect/{id}/{pause|resume},
   prospect/{id}/resume (stalled), followup-now, followups/{id}/approve,
   followups/{id}/reject.
9. Title text "Pipeline" → "Context Pipeline".
10. Drop the "Queue follow-ups" header button.
11. Drop the VERTICAL filter Select.
12. Replace `cancelMutation.mutate(...)` with `cancelStageById(...)`.
13. Drop the queue-batch Modal (~50 lines of form).
14. Empty-state copy: "Adjust filters or label a Gmail thread with the
    Context label."
15. Drop the vertical label render in the expanded thread view.

## What changes for the user

- **`/context/pipeline`** is now a working Pipeline page. Lists context
  follow-ups grouped by thread. Stage progress dots, mode pill, stall
  pill, countdown timer, status summary, expanded view with stage list,
  preview toggle, approve/reject actions, single-stage cancel,
  per-prospect pause/resume/add-stage, bulk send-now and bulk pause
  actions, original email modal — all working.
- **What's missing vs doctrine**: vertical filter, queue follow-ups
  batch button + modal. Both are doctrine-specific surfaces and don't
  apply to the context flow (context follow-ups are reply-driven from
  labelled threads, not queued from a batch UI).
- **Polling**: 30 seconds (matches doctrine's `refetchInterval: 30000`).
  Background polling continues regardless of window focus (different
  from React Query's smart polling); refining this is deferred.

## Files

```
batch7e/
├── apply-batch7e.mjs       # Idempotent patch + clone-from-pipeline.tsx
├── audit-batch7e.mjs       # 9 passes × 3 rounds = 171 checks
└── README.md
```

## Apply

Standard pattern — single bash block in the ship instruction. Build
both api-server and dashboard. Mirror sync. Restart workflow.

## Verify

After applying:

- The apply script self-verifies 26 anchors (5 backend + 21 frontend).
- The audit script runs 171 checks (57 per round × 3 rounds): /followups
  reshape (Drizzle projection + result map shape), /cancel-followup
  endpoint, ContextPipeline component identity + title, all 9 URL
  retargets, raw-fetch data layer, typed hooks fully removed, doctrine-
  specific UI removed, doctrine UI not regressed, B7c/B7a regression.

Backend smoke after restart:

```bash
curl -s "http://localhost:8080/api/context/followups" -H "x-api-key: $ADDON_API_KEY" | head -c 400
```

The response should be a JSON array (likely empty since no context
prospects exist yet). Field names should be snake_case
(`prospect_id`, `scheduled_at`, etc.) — not camelCase.

Browser smoke after dashboard rebuild + reload:

1. Navigate to `/context/pipeline`. Should render an empty-state card
   ("No email threads found. Adjust filters or label a Gmail thread
   with the Context label.") instead of the placeholder.
2. Sidebar still shows amber accent on Pipeline nav item, brand still
   reads "Context Based".
3. The state filter dropdown is present (no vertical filter).
4. The "Queue follow-ups" header button is absent.
5. To exercise data flow, label a Gmail thread with your Context
   Followuper label, wait one 15-minute sync cycle, then refresh the
   page — the thread should appear with its first stage queued.

## Known residual

- ContextPipeline polls `/api/context/followups` every 30 seconds via
  `setInterval`. Unlike React Query's `refetchInterval`, this continues
  regardless of window focus. Refinable later.
- Sidebar bottom activity indicator still polls `/api/my/activity`
  (doctrine endpoint) on context routes. Will surface as "All caught
  up" or doctrine queue numbers regardless of what's happening on the
  context side. Refining to per-product activity is open.
- Email Inspector and Activity Log for context still render the 7d
  placeholders. They ship in 7f.
