# Batch 7g — Context Email Inspector backend

Phase 7g. Adds the `/api/context/gmail/sent-emails` endpoint that the
ContextEmailInspector UI clone (shipping in 7h) will consume. Backend
only — no frontend changes in this batch.

The new endpoint mirrors `/api/gmail/sent-emails` (in
`routes/email-inspector.ts`) with four deliberate differences:

1. **Per-user label resolution.** The doctrine version reads labels
   from `process.env.DOCTRINE_LABELS`. The context version reads from
   `users.contextLabel` (the value the user set in Settings). Multi-user
   correctness — env-var labels don't scale across multiple connected
   inboxes.
2. **Renamed response fields.** `hasContextLabel`,
   `matchedContextLabels`, `meta.withContextLabel`, `meta.contextLabelIds`,
   `meta.contextLabels` (instead of the `Doctrine`-named equivalents).
3. **DB cross-reference scoped to `app='context'`.** The endpoint
   cross-references each Gmail message/thread against the prospects
   table; only context prospects can match. A doctrine prospect with the
   same `gmailMessageId` would not light up `inDatabase: true`.
4. **No vertical inference.** Context prospects don't carry verticals.
   The `detection.vertical / subVertical / verticalReason` fields
   return empty strings to keep the response shape stable for the UI
   clone.

## What's in this batch

**Backend changes (`routes/context.ts`):**

- **Imports added**: `google, gmail_v1` from `googleapis`,
  `getGmailForUser` from `../services/gmailClient`.
- **Helpers inlined** below the `getFollowupCap` block:
  `getLegacyGmail` (8 lines), `getGmailForRequest` (15 lines),
  `extractEmail` (4 lines), `extractName` (5 lines),
  `isWithinSyncWindow` (5 lines). These mirror the module-private
  copies in `routes/email-inspector.ts`. Future cleanup: extract to a
  shared lib once a third consumer exists.
- **New handler `GET /gmail/sent-emails`** (~210 lines) inserted just
  before `/campaign/status`. Same Gmail-fetch + body-parsing structure
  as the doctrine version. The label resolution, flagging, vertical
  handling, DB cross-ref, and response meta are the four differences
  listed above.

**Routes shared with doctrine (no changes in this batch):**

- `/api/gmail/thread/:threadId` stays at the root mount — Gmail threads
  are product-agnostic. The 7h frontend clone calls the shared endpoint.
- `/api/gmail/accounts` stays at the root mount — same reason.

## What changes for the user

- **Server-side only.** No UI surface change in this batch. Visiting
  `/context/inspector` still renders the 7d placeholder until 7h ships.
- A new endpoint is callable: `GET /api/context/gmail/sent-emails`.
  Returns sent emails from the connected user's Gmail with context-label
  flagging.

## Files

```
batch7g/
├── apply-batch7g.mjs       # Idempotent patch — imports + helpers + handler
├── audit-batch7g.mjs       # 9 passes × 3 rounds = 162 checks
└── README.md
```

## Apply

Standard pattern — single bash block. Build api-server only (no
dashboard changes). Mirror sync. Restart api-server.

## Verify

After applying:

- The apply script self-verifies 24 anchors (2 imports + 5 helpers +
  17 handler structure/shape/scope checks).
- The audit script runs 162 checks (54 per round × 3 rounds): imports,
  every inlined helper, route declaration + per-user label resolution,
  per-email computation (hasContextLabel + matchedContextLabels +
  wouldBePickedUp + reason text), vertical inference skipped (empty
  strings + no inferVertical call), DB cross-ref scoped to context,
  response shape (emails + meta with contextLabel-named fields),
  doctrine inspector NOT regressed (still uses DOCTRINE_LABELS,
  hasDoctrineLabel, inferVertical), B7c/B7e/B7f regression.

Backend smoke after restart:

```bash
# 1. Endpoint responds. With no userId, it falls back to legacy Gmail.
#    With userId set, uses the connected user's Gmail + their contextLabel.
curl -s "http://localhost:8080/api/context/gmail/sent-emails?userId=1&limit=5" \
  -H "x-api-key: $ADDON_API_KEY" | head -c 800

# 2. Verify shape: should return { emails: [...], meta: { total, withContextLabel,
#    inDatabase, wouldBePickedUp, contextLabelIds, contextLabels } }
curl -s "http://localhost:8080/api/context/gmail/sent-emails?userId=1&limit=3" \
  -H "x-api-key: $ADDON_API_KEY" | grep -o '"with[A-Z][a-zA-Z]*":[0-9]*'
```

Expected: a JSON response with `emails: [...]` (5 most recent sent
emails from the user's Gmail) and `meta` with `withContextLabel`,
`contextLabelIds`, `contextLabels` fields. Each email has
`hasContextLabel: bool`, `matchedContextLabels: string[]`,
`detection.wouldBePickedUp: bool`, `detection.vertical: ""`,
`inDatabase: bool`.

The `withContextLabel` count reflects how many of the returned emails
have the user's `Context Followuper` label (or whatever the user set).
If you've never labelled a sent email with that label, the count is 0
and that's correct.

Doctrine regression smoke (should be unchanged):

```bash
curl -s "http://localhost:8080/api/gmail/sent-emails?userId=1&limit=3" \
  -H "x-api-key: $ADDON_API_KEY" | head -c 400
```

Should still return the doctrine-flavored response with
`hasDoctrineLabel`, `matchedDoctrineLabels`, `withDoctrineLabel`, and
vertical inference populated.

## Known residual

- `getLegacyGmail` and the helper set are now duplicated between
  `routes/email-inspector.ts` and `routes/context.ts`. Two copies of
  ~30 lines. When a third consumer arrives or a maintainer changes one
  copy, both should move together — extracting to a shared lib at that
  point is appropriate. Not a blocker for this batch.
- The frontend `/context/inspector` page still renders the 7d
  placeholder until 7h ships.
- ContextEmailInspector frontend clone (664 lines, 3 typed-hook
  replacements, ~10 string renames) is the entirety of 7h.
