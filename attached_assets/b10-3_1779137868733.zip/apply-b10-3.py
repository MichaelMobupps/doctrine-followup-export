#!/usr/bin/env python3
"""
B10.3 - Email Inspector ThreadView: bypass generated useGetThread.

The generated `useGetThread` from @workspace/api-client-react silently
drops the `request.headers` option, so the page-side request goes
out without an `x-api-key` header. Backend's email-inspector router
gates with authMiddleware -> 401 Invalid API key.

Observed in the captured cURL: the page's fetch for
/api/gmail/thread/<id> has only cookie + standard browser headers,
no x-api-key, despite ThreadView's call explicitly setting
`request: { headers: { "x-api-key": apiKey } }`. Same call site
on /api/gmail/sent-emails (useGetSentEmails) works because its
signature is (params, options) where options.request.headers IS
respected — useGetThread takes a path param threadId directly,
suggesting a different generated-client signature shape that
treats the second arg differently.

Fix: replace useGetThread with raw fetch through useQuery. Same
query key for cache compatibility, explicit headers, gate on
!!apiKey to avoid firing before the key loads, and surface the
actual server error instead of the generic "Failed to load
thread" so future failures are debuggable inline.

Anchors:
  A1: imports - swap useGetThread out, add useQuery import
  A2: ThreadView function body - raw fetch via useQuery

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
INSP = WORKSPACE / "artifacts/dashboard/src/pages/email-inspector.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker):
    if marker in text:
        skip(f"{label}: already applied")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected 1")
    ok(f"{label}: updated")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: imports - drop useGetThread (no longer used after this patch),
# add useQuery from @tanstack/react-query.
# ====================================================================
A1_OLD = '''import { useGetSentEmails, useGetThread, useGetGmailAccounts } from "@workspace/api-client-react";'''

A1_NEW = '''import { useGetSentEmails, useGetGmailAccounts } from "@workspace/api-client-react";
// B10.3: ThreadView now uses raw fetch via useQuery; generated useGetThread
// dropped the request.headers option, causing 401 Invalid API key.
import { useQuery } from "@tanstack/react-query";'''


# ====================================================================
# A2: ThreadView function body - raw fetch + useQuery + better error display.
# ====================================================================
A2_OLD = '''function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {
  const { data, isLoading, isError } = useGetThread(threadId, {
    request: { headers: { "x-api-key": apiKey } },
    query: { queryKey: ["/api/thread", threadId], enabled: !!threadId },
  });
  if (isLoading) {
    return (
      <div className="flex items-center gap-2 py-4 text-[13px]" style={{ color: "var(--text-secondary)" }}>
        <RefreshCw className="h-4 w-4 animate-spin" />
        Loading thread...
      </div>
    );
  }
  if (isError || !data) {
    return (
      <div className="flex items-center gap-2 py-4 text-[13px]" style={{ color: "var(--danger)" }}>
        <AlertCircle className="h-4 w-4" />
        Failed to load thread
      </div>
    );
  }'''

A2_NEW = '''function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {
  // B10.3: raw fetch via useQuery. Generated useGetThread silently dropped
  // request.headers (path-param signature mismatch), causing 401 from
  // the auth middleware. Raw fetch sends x-api-key reliably, gates on
  // !!apiKey to avoid pre-load misfires, and surfaces the real error.
  const { data, isLoading, isError, error } = useQuery<{
    messageCount: number;
    hasExternalReply: boolean;
    messages: any[];
  }>({
    queryKey: ["/api/thread", threadId],
    queryFn: async () => {
      const res = await fetch(`/api/gmail/thread/${threadId}`, {
        headers: { "x-api-key": apiKey },
      });
      if (!res.ok) {
        let detail = "";
        try {
          const body = await res.json();
          detail = body?.error || JSON.stringify(body);
        } catch {
          detail = await res.text().catch(() => "");
        }
        throw new Error(`HTTP ${res.status}${detail ? `: ${detail}` : ""}`);
      }
      return res.json();
    },
    enabled: !!threadId && !!apiKey,
  });
  if (isLoading) {
    return (
      <div className="flex items-center gap-2 py-4 text-[13px]" style={{ color: "var(--text-secondary)" }}>
        <RefreshCw className="h-4 w-4 animate-spin" />
        Loading thread...
      </div>
    );
  }
  if (isError || !data) {
    return (
      <div className="flex flex-col gap-1 py-4 text-[13px]" style={{ color: "var(--danger)" }}>
        <div className="flex items-center gap-2">
          <AlertCircle className="h-4 w-4" />
          Failed to load thread
        </div>
        {error instanceof Error && error.message && (
          <div className="text-[11px] ml-6 font-mono" style={{ color: "var(--text-tertiary)" }}>
            {error.message}
          </div>
        )}
      </div>
    );
  }'''


def main():
    if not INSP.exists():
        fail(f"email-inspector.tsx not found: {INSP}")
    text = INSP.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: swap useGetThread for useQuery import",
        marker="B10.3: ThreadView now uses raw fetch via useQuery",
    )
    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: ThreadView raw fetch via useQuery",
        marker="B10.3: raw fetch via useQuery",
    )

    if text != original:
        INSP.write_text(text, encoding="utf-8")
        ok(f"wrote {INSP.relative_to(WORKSPACE)}")
    else:
        skip("email-inspector.tsx already patched")

    print()
    print("B10.3 ThreadView raw fetch applied.")


if __name__ == "__main__":
    main()
