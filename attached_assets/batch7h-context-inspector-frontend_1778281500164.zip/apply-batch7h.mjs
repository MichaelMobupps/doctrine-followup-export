#!/usr/bin/env node
/**
 * apply-batch7h.mjs — Phase 7h (Context Email Inspector frontend).
 *
 * Idempotent. Sentinel-based str_replace for unique anchors and
 * sentinel-gated globalStrReplace for multi-occurrence renames.
 *
 * One concern: replace dashboard/pages/context-inspector.tsx
 * (placeholder from 7d) with a clone of email-inspector.tsx retargeted
 * to /api/context/gmail/sent-emails (B7g endpoint). The 3 typed hooks
 * (useGetSentEmails, useGetThread, useGetGmailAccounts) are replaced
 * with raw fetch + setState. /api/gmail/thread and /api/gmail/accounts
 * stay shared (Gmail threads + connected accounts are
 * product-agnostic). The doctrine_label-flavored fields rename to
 * context_label-flavored across all functional uses.
 *
 * Usage:
 *   DASH_BASE=artifacts/dashboard/src node apply-batch7h.mjs
 */

import { existsSync, readFileSync, writeFileSync, copyFileSync } from "fs";
import { join } from "path";

const DASH_BASE = process.env.DASH_BASE || "artifacts/dashboard/src";

const log  = (msg) => console.log(`[apply-batch7h] ${msg}`);
const fail = (msg) => { console.error(`[apply-batch7h] FAIL: ${msg}`); process.exit(1); };

function readFileOrFail(path) {
  if (!existsSync(path)) fail(`File not found: ${path}`);
  return readFileSync(path, "utf-8");
}

function strReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`strReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const oldOccurrences = original.split(oldStr).length - 1;
  if (oldOccurrences === 0) fail(`Anchor for "${label}" not found in ${path} and sentinel absent`);
  if (oldOccurrences > 1) fail(`Anchor for "${label}" matched ${oldOccurrences} times in ${path}; expected 1.`);

  writeFileSync(path, original.replace(oldStr, newStr));
  log(`  [+] ${label}`);
  return "applied";
}

/**
 * Global string replace: replaces ALL occurrences of `oldStr` with
 * `newStr`. Idempotency is enforced by `sentinel` — once any sentinel
 * is present in the file, the replace is skipped on subsequent runs.
 *
 * The sentinel must be in `newStr` (post-replacement marker), and must
 * NOT be in `oldStr` (so we don't false-positive on the original).
 *
 * Use this only for renames where every occurrence of `oldStr` is
 * intended to flip to `newStr` (e.g., field-name renames). Don't use
 * it for anything ambiguous.
 */
function globalStrReplace(path, oldStr, newStr, label, sentinel) {
  if (!sentinel) fail(`globalStrReplace called without sentinel for "${label}"`);
  if (!newStr.includes(sentinel)) fail(`Sentinel for "${label}" is not in newStr`);
  if (oldStr.includes(sentinel)) fail(`Sentinel for "${label}" is also in oldStr (must be new-only)`);

  const original = readFileOrFail(path);
  if (original.includes(sentinel)) {
    log(`  [=] ${label} (already applied)`);
    return "skipped";
  }

  const occurrences = original.split(oldStr).length - 1;
  if (occurrences === 0) fail(`No occurrences of oldStr found for "${label}"`);

  // Replace all occurrences. Use split-join (safe for special regex chars).
  const updated = original.split(oldStr).join(newStr);

  // Sanity: confirm the replacement landed AND the sentinel is now present.
  if (!updated.includes(sentinel)) {
    fail(`After global replace for "${label}", sentinel still not present`);
  }
  if (updated.includes(oldStr)) {
    fail(`After global replace for "${label}", oldStr still present (split-join failed)`);
  }

  writeFileSync(path, updated);
  log(`  [+] ${label} (${occurrences} occurrence${occurrences !== 1 ? "s" : ""})`);
  return "applied";
}

const inspectorPath    = join(DASH_BASE, "pages", "email-inspector.tsx");
const ctxInspectorPath = join(DASH_BASE, "pages", "context-inspector.tsx");

// ============================================================
// Step 1: Detect state, copy if placeholder
// ============================================================
log("Step 1: Build context-inspector.tsx from email-inspector.tsx...");

const placeholderMarker = "Phase 7d: placeholder. Full Context Email Inspector ships in";
const cloneMarker        = "// Phase 7h: ContextEmailInspector — clone of email-inspector.tsx retargeted to";

const ctxCurrent = readFileOrFail(ctxInspectorPath);
if (ctxCurrent.includes(cloneMarker)) {
  log(`  [=] context-inspector.tsx (already cloned)`);
} else if (ctxCurrent.includes(placeholderMarker)) {
  if (!existsSync(inspectorPath)) fail(`Source email-inspector.tsx not found at ${inspectorPath}`);
  copyFileSync(inspectorPath, ctxInspectorPath);
  log(`  [+] Copied email-inspector.tsx → context-inspector.tsx (will transform next)`);
} else if (ctxCurrent.includes("export default function EmailInspector()")) {
  // Mid-state: file is a copy of email-inspector.tsx but transforms haven't
  // landed. Resume.
  log(`  [~] context-inspector.tsx (partial transform — resuming)`);
} else {
  fail(`context-inspector.tsx is in an unexpected state — neither placeholder nor inspector-clone nor transform marker present`);
}

// ============================================================
// Step 2: Header comment + drop typed hook imports
// ============================================================
log("Step 2: Header comment + trim imports...");

strReplace(
  ctxInspectorPath,
  `import React, { useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { format } from "date-fns";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";
import { useGetSentEmails, useGetThread, useGetGmailAccounts } from "@workspace/api-client-react";
import { Card, Button, Badge, Input, Select } from "@/components/ui";`,
  `// Phase 7h: ContextEmailInspector — clone of email-inspector.tsx retargeted to
// /api/context/gmail/sent-emails (the B7g endpoint). The 3 typed hooks
// (useGetSentEmails, useGetThread, useGetGmailAccounts) are replaced
// with raw fetch + setState. /api/gmail/thread and /api/gmail/accounts
// stay shared between products. The doctrine_label-flavored response
// fields rename to context_label-flavored across all functional uses.
import React, { useState, useEffect, useCallback } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { format } from "date-fns";
import { useApiKey } from "@/hooks/use-api-key";
import { useCurrentUser } from "@/hooks/use-current-user";
import { Card, Button, Badge, Input, Select } from "@/components/ui";`,
  "ctx-inspector: header + trim hook imports",
  `// Phase 7h: ContextEmailInspector — clone of email-inspector.tsx retargeted to`
);

// ============================================================
// Step 3: Rename default export EmailInspector → ContextEmailInspector
// ============================================================
log("Step 3: Rename component...");

strReplace(
  ctxInspectorPath,
  `export default function EmailInspector() {`,
  `export default function ContextEmailInspector() {`,
  "ctx-inspector: rename component",
  `export default function ContextEmailInspector()`
);

// ============================================================
// Step 4: ThreadView — replace useGetThread with raw fetch
// ============================================================
log("Step 4: ThreadView raw fetch...");

strReplace(
  ctxInspectorPath,
  `function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {
  const { data, isLoading, isError } = useGetThread(threadId, {
    request: { headers: { "x-api-key": apiKey } },
    query: { enabled: !!threadId },
  });`,
  `function ThreadView({ threadId, apiKey }: { threadId: string; apiKey: string }) {
  // Phase 7h: useGetThread → raw fetch. /api/gmail/thread is shared
  // between products (a Gmail thread is product-agnostic).
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  useEffect(() => {
    if (!threadId) { setIsLoading(false); return; }
    let cancelled = false;
    setIsLoading(true);
    const base = import.meta.env.BASE_URL || "/";
    fetch(\`\${base}api/gmail/thread/\${threadId}\`, {
      headers: { "x-api-key": apiKey || "" },
    })
      .then((r) => {
        if (!r.ok) throw new Error("Failed to load thread");
        return r.json();
      })
      .then((d) => {
        if (cancelled) return;
        setData(d); setIsError(false); setIsLoading(false);
      })
      .catch(() => {
        if (cancelled) return;
        setIsError(true); setIsLoading(false);
      });
    return () => { cancelled = true; };
  }, [threadId, apiKey]);`,
  "ctx-inspector: ThreadView raw fetch",
  `// Phase 7h: useGetThread → raw fetch. /api/gmail/thread is shared`
);

// ============================================================
// Step 5: useGetGmailAccounts → raw fetch
// ============================================================
log("Step 5: useGetGmailAccounts raw fetch...");

strReplace(
  ctxInspectorPath,
  `  const requestOpts = { request: { headers: { "x-api-key": apiKey || "" } } };

  const { data: accountsData } = useGetGmailAccounts({
    ...requestOpts,
    query: { enabled: !!apiKey },
  });
  const accounts: any[] = (accountsData as any)?.accounts || [];`,
  `  // Phase 7h: useGetGmailAccounts → raw fetch. /api/gmail/accounts
  // is shared between products (the connected-accounts list is the
  // same regardless of which product the user is viewing).
  const [accountsData, setAccountsData] = useState<any>(null);
  useEffect(() => {
    if (!apiKey) return;
    let cancelled = false;
    const base = import.meta.env.BASE_URL || "/";
    fetch(\`\${base}api/gmail/accounts\`, {
      headers: { "x-api-key": apiKey || "" },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => { if (!cancelled) setAccountsData(d); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, [apiKey]);
  const accounts: any[] = (accountsData as any)?.accounts || [];`,
  "ctx-inspector: useGetGmailAccounts raw fetch",
  `// Phase 7h: useGetGmailAccounts → raw fetch. /api/gmail/accounts`
);

// ============================================================
// Step 6: useGetSentEmails → raw fetch with refetch + isFetching
// ============================================================
log("Step 6: useGetSentEmails raw fetch...");

strReplace(
  ctxInspectorPath,
  `  const { data, isLoading, isError, refetch, isFetching } = useGetSentEmails(
    { limit, ...(search ? { search } : {}), ...(selectedUserId ? { userId: selectedUserId } : {}) },
    { ...requestOpts, query: { enabled: !!apiKey && !!selectedUserId } },
  );`,
  `  // Phase 7h: useGetSentEmails → raw fetch hitting /api/context/gmail/sent-emails.
  // refetchTrigger forces an immediate refetch when bumped.
  const [data, setData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [isFetching, setIsFetching] = useState(false);
  const [refetchTrigger, setRefetchTrigger] = useState(0);
  const refetch = useCallback(() => setRefetchTrigger((t) => t + 1), []);

  useEffect(() => {
    if (!apiKey || !selectedUserId) return;
    let cancelled = false;
    setIsFetching(true);

    const params = new URLSearchParams();
    params.set("limit", String(limit));
    if (search) params.set("search", search);
    if (selectedUserId) params.set("userId", selectedUserId);

    const base = import.meta.env.BASE_URL || "/";
    fetch(\`\${base}api/context/gmail/sent-emails?\${params.toString()}\`, {
      headers: { "x-api-key": apiKey || "" },
    })
      .then((r) => {
        if (!r.ok) throw new Error("Failed to load sent emails");
        return r.json();
      })
      .then((d) => {
        if (cancelled) return;
        setData(d); setIsError(false); setIsLoading(false); setIsFetching(false);
      })
      .catch(() => {
        if (cancelled) return;
        setIsError(true); setIsLoading(false); setIsFetching(false);
      });
    return () => { cancelled = true; };
  }, [apiKey, selectedUserId, limit, search, refetchTrigger]);`,
  "ctx-inspector: useGetSentEmails raw fetch",
  `// Phase 7h: useGetSentEmails → raw fetch hitting /api/context/gmail/sent-emails.`
);

// ============================================================
// Step 7: /api/sync → /api/context/sync (the manual-sync trigger)
// ============================================================
log("Step 7: /api/sync URL retarget...");

strReplace(
  ctxInspectorPath,
  `      const res = await fetch(\`\${base}api/sync\`, {`,
  `      const res = await fetch(\`\${base}api/context/sync\`, {`,
  "ctx-inspector: /api/sync → /api/context/sync",
  `\${base}api/context/sync`
);

// ============================================================
// Step 8: Global field renames — doctrine → context labels
// ============================================================
log("Step 8: Global field renames...");

globalStrReplace(
  ctxInspectorPath,
  `hasDoctrineLabel`,
  `hasContextLabel`,
  "ctx-inspector: hasDoctrineLabel → hasContextLabel",
  `hasContextLabel`
);

globalStrReplace(
  ctxInspectorPath,
  `matchedDoctrineLabels`,
  `matchedContextLabels`,
  "ctx-inspector: matchedDoctrineLabels → matchedContextLabels",
  `matchedContextLabels`
);

globalStrReplace(
  ctxInspectorPath,
  `withDoctrineLabel`,
  `withContextLabel`,
  "ctx-inspector: withDoctrineLabel → withContextLabel",
  `withContextLabel`
);

// ============================================================
// Step 9: User-facing string renames
// ============================================================
log("Step 9: User-facing string renames...");

strReplace(
  ctxInspectorPath,
  `["Doctrine label", email.hasContextLabel]`,
  `["Context label", email.hasContextLabel]`,
  "ctx-inspector: \"Doctrine label\" → \"Context label\" (detection panel)",
  `["Context label", email.hasContextLabel]`
);

strReplace(
  ctxInspectorPath,
  `{ label: "DOCTRINE LABELED", value: meta.withContextLabel }`,
  `{ label: "CONTEXT LABELED", value: meta.withContextLabel }`,
  "ctx-inspector: \"DOCTRINE LABELED\" → \"CONTEXT LABELED\" (stat pill)",
  `{ label: "CONTEXT LABELED", value: meta.withContextLabel }`
);

// ============================================================
// Step 10: Title text "Email Inspector" → "Context Email Inspector"
// ============================================================
log("Step 10: Title text...");

strReplace(
  ctxInspectorPath,
  `<h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>Email Inspector</h1>`,
  `<h1 style={{ fontSize: "20px", fontWeight: 600, letterSpacing: "-0.02em" }}>Context Email Inspector</h1>`,
  "ctx-inspector: title text",
  `>Context Email Inspector</h1>`
);

// ============================================================
// Step 11: Self-verify
// ============================================================
log("Step 11: Self-verify...");

function expectInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (!content.includes(needle)) fail(`Verify "${label}": needle not found`);
  log(`  [OK] ${label}`);
}

function expectNotInFile(path, needle, label) {
  const content = readFileOrFail(path);
  if (content.includes(needle)) fail(`Verify "${label}": needle should be absent but is present`);
  log(`  [OK] ${label}`);
}

// Identity
expectInFile(ctxInspectorPath, `// Phase 7h: ContextEmailInspector — clone of email-inspector.tsx retargeted to`, "V1  Header comment present");
expectInFile(ctxInspectorPath, `export default function ContextEmailInspector()`, "V2  ContextEmailInspector default export");
expectInFile(ctxInspectorPath, `>Context Email Inspector</h1>`, "V3  Title text");

// Raw fetches landed
expectInFile(ctxInspectorPath, `// Phase 7h: useGetThread → raw fetch.`, "V4  ThreadView raw fetch");
expectInFile(ctxInspectorPath, `// Phase 7h: useGetGmailAccounts → raw fetch.`, "V5  Accounts raw fetch");
expectInFile(ctxInspectorPath, `// Phase 7h: useGetSentEmails → raw fetch hitting /api/context/gmail/sent-emails.`, "V6  Sent-emails raw fetch");
expectInFile(ctxInspectorPath, `const refetch = useCallback(() => setRefetchTrigger((t) => t + 1), []);`, "V7  refetch via callback");

// URL retargets
expectInFile(ctxInspectorPath, `\${base}api/context/gmail/sent-emails`, "V8  /context/gmail/sent-emails URL");
expectInFile(ctxInspectorPath, `\${base}api/context/sync`, "V9  /context/sync URL");
expectInFile(ctxInspectorPath, `\${base}api/gmail/thread/`, "V10 /gmail/thread URL stays shared");
expectInFile(ctxInspectorPath, `\${base}api/gmail/accounts`, "V11 /gmail/accounts URL stays shared");

// Field renames
expectInFile(ctxInspectorPath, `hasContextLabel`, "V12 hasContextLabel present");
expectInFile(ctxInspectorPath, `matchedContextLabels`, "V13 matchedContextLabels present");
expectInFile(ctxInspectorPath, `withContextLabel`, "V14 withContextLabel present");
expectInFile(ctxInspectorPath, `["Context label", email.hasContextLabel]`, "V15 \"Context label\" detection-panel string");
expectInFile(ctxInspectorPath, `{ label: "CONTEXT LABELED", value: meta.withContextLabel }`, "V16 \"CONTEXT LABELED\" stat-pill string");

// Things that MUST be absent (regression)
expectNotInFile(ctxInspectorPath, `useGetSentEmails(`, "V17 useGetSentEmails() call removed");
expectNotInFile(ctxInspectorPath, `useGetThread(`, "V18 useGetThread() call removed");
expectNotInFile(ctxInspectorPath, `useGetGmailAccounts(`, "V19 useGetGmailAccounts() call removed");
expectNotInFile(ctxInspectorPath, `from "@workspace/api-client-react"`, "V20 api-client-react import removed");
expectNotInFile(ctxInspectorPath, `hasDoctrineLabel`, "V21 hasDoctrineLabel renamed everywhere");
expectNotInFile(ctxInspectorPath, `matchedDoctrineLabels`, "V22 matchedDoctrineLabels renamed everywhere");
expectNotInFile(ctxInspectorPath, `withDoctrineLabel`, "V23 withDoctrineLabel renamed everywhere");
expectNotInFile(ctxInspectorPath, `"Doctrine label"`, "V24 \"Doctrine label\" string gone");
expectNotInFile(ctxInspectorPath, `"DOCTRINE LABELED"`, "V25 \"DOCTRINE LABELED\" string gone");
expectNotInFile(ctxInspectorPath, `function EmailInspector()`, "V26 EmailInspector default-export gone");
expectNotInFile(ctxInspectorPath, `Email Inspector UI ships in Phase 7f`, "V27 Placeholder marker gone");
expectNotInFile(ctxInspectorPath, `\${base}api/sync\``, "V28 /api/sync (doctrine) URL gone");

log("All verifications passed.");
log("");
log("================================================================");
log("Batch 7h patch applied. dashboard ContextEmailInspector is the");
log("real Email Inspector clone, hitting /api/context/gmail/sent-emails");
log("for sent emails and /api/context/sync for manual sync. Thread and");
log("accounts endpoints stay shared.");
log("================================================================");
