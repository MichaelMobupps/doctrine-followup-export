# Batch B9b.1 — AntiGhosting Marking UI

**Scope.** Ship the dashboard surface that lets the operator mark Gmail threads as AntiGhosting candidates. With this in place, the full AntiGhosting pipeline (mark → F1 schedule → live thread re-read → 3-call generator → review/send) is exercisable through the dashboard without curl, DB pokes, or admin endpoints.

This is the third-product UI parallel to Doctrine's Pipeline and Context's Pipeline, scoped MINIMUM-viable: candidate list + one-click mark. Future batches will add per-prospect drill-down (inspector), the active-followup queue view, and AntiGhosting Settings parity.

## What ships

### New file: `dashboard/src/pages/anti-ghosting.tsx`

The marking page (~520 lines). Driven by two endpoints:
- `GET /api/anti-ghosting/candidates?email=...` — returns label-tagged threads with per-thread validator preview.
- `POST /api/anti-ghosting/mark` — commits a candidate as an AntiGhosting prospect with cycle=1, stage=1, status="queued".

Page structure:
- Header with the AntiGhosting logo, title, subtitle, and a Refresh button.
- Auth gate (covered by the existing `ApiKeyGate` higher up; the page also guards against missing `apiKey` or `user` defensively).
- Setup help card (shown when the API returns `note` — no matching Gmail label exists yet, with step-by-step instructions to create one).
- Empty state (when no candidates but the label exists).
- Candidate cards (one per Gmail thread). Each card shows:
  - Days-since-seed badge with tier color (`lt_30d` neutral, `30d_to_6mo` amber, `gt_6mo` red).
  - Prospect name + email + company.
  - Subject + Gmail snippet preview (line-clamp 2).
  - Three validator chips with check/X icons (most recent is outbound, thread has inbound, not already in followups).
  - "Mark" button when all three pass; failure reason text when one fails.
  - Success state after marking: cyan-tinted card with F1 scheduledAt and prospect ID.

State management uses tanstack-query (already provided by the existing `QueryClientProvider` in `App.tsx`). The mark mutation invalidates the candidates query after a 1.5-second debounce so the marked thread drops off the list.

### New file: `dashboard/src/assets/anti-ghosting-logo.svg`

Vertical wordmark version. Transparent background. Blue gradient `#6db4ff` → `#3b82f6` on the refresh arrow. White ghost with simple round eyes and smile. Three sparkle marks for the attention/notification element. Sized 280×300.

### New file: `dashboard/src/assets/anti-ghosting-mark.svg`

Glyph-only mark (no wordmark). Sized 140×140. For use in the picker tile, eventual sidebar nav, and favicon contexts.

The pages do NOT import these SVG files directly — they inline the SVG markup as React components (`AntiGhostingLogo`, `AntiGhostingMark`) to avoid depending on the host's Vite asset-pipeline TypeScript configuration. The standalone .svg files ship for design-system reuse and any future tooling (favicon generation, marketing materials, etc.).

### Modified file: `dashboard/src/pages/picker.tsx` (full replacement)

The product picker grows from 2 tiles (Doctrine, Context) to 3 (Doctrine, Context, AntiGhosting). Layout changes:
- Grid columns: `md:grid-cols-2` → `md:grid-cols-3`.
- Max width: `max-w-3xl` → `max-w-5xl` to give three cards reasonable breathing room.
- The `choose` function's product union widens to `"doctrine" | "context" | "anti_ghosting"`; the new branch navigates to `/anti-ghosting`.
- The third tile uses cyan `#06b6d4` as the accent (distinct from Doctrine's blue `#3b82f6` and Context's amber `#f59e0b`), and embeds the glyph mark as the tile icon.

Shipped as a full file replacement (the source is 185 lines and the changes touch six different spots — file replacement is lower-risk than six anchored edits).

### Modified file: `dashboard/src/App.tsx` (two anchored edits via patch script)

1. Import: `import AntiGhosting from "@/pages/anti-ghosting";` appended after the Context page imports.
2. Route: `<Route path="/anti-ghosting" component={AntiGhosting} />` added inside the Switch after the Context routes, before the catch-all NotFound.

## Patch helper generalization (committed as promised)

The patch script's `patch_file` helper now correctly handles the NEW-is-substring-of-OLD trap that bit B9c.1 (exclusion-filter deletion) and B9c.2 (`getGmailForUser` import). The check before the existing OLD-vs-NEW branch:

```python
new_is_in_old = bool(new and old and new in old)
if new == "" or new_is_in_old:
    # use OLD-presence to decide — NEW would trivially match
```

This generalizes the deletion case to cover any edit where NEW is a substring of OLD (i.e., we're inserting alongside OLD rather than replacing it). Future batches inherit this helper.

## Risk surface

1. **No tsc check ran in the sandbox.** The dashboard's TS sandbox would need a React + wouter + tanstack-query + lucide-react setup that I don't have built out. Mitigation: every type in the page is explicit (`Candidate`, `MarkResponse`, `ValidatorResults` mirror the route handler's response shape verbatim), hooks (`useApiKey`, `useCurrentUser`) match the inferred contracts I read from the source files, tanstack-query v5 syntax used throughout (`isPending` not `isLoading`, `variables` on the mutation object). The dashboard's pnpm typecheck will surface any drift immediately on deploy.

2. **JSX braces balanced.** Sandbox check: 205/205 in anti-ghosting.tsx, 69/69 in picker.tsx. Not a substitute for tsc but rules out the gross structural breakage classes.

3. **Inline SVG vs asset import.** Trade-off: inline SVG adds ~25 lines per file but eliminates a Vite-config dependency. Files in the assets/ directory still ship for non-page consumers.

4. **No new backend changes.** Both endpoints exist from B9b/B9c.1; this batch only adds a UI client.

5. **No schema, no scheduler, no generator changes.**

## Validation

- Sandbox test on the App.tsx patch: 2 FIX on first run, 2 SKIP on second run, both edits idempotent.
- The page renders correctly across three states (visualized inline before bundling): candidate ready to mark, candidate freshly marked, candidate failing a validator.
- No new tests in this batch — the page is pure presentation + two fetch calls. Unit tests would mock the API client and aren't a meaningful safety net at this layer. Smoke-testing through the UI itself is the validation step.

## Layout

```
batch-b9b1-anti-ghosting-ui/
|-- README.md
|-- dashboard/
|   |-- pages/
|   |   |-- anti-ghosting.tsx       (new)
|   |   `-- picker.tsx              (full replacement)
|   `-- assets/
|       |-- anti-ghosting-logo.svg  (new)
|       `-- anti-ghosting-mark.svg  (new)
`-- scripts/
    `-- apply-b9b1.py               (App.tsx patch)
```

Mirror sync IS needed (new + modified dashboard files). Dashboard build + restart IS needed (the bundled JS needs a fresh build to include the new route + page).

## Deferred

- **AntiGhosting Pipeline page** (queue management for marked prospects in flight) — own batch, sibling of `/pipeline` and `/context/pipeline`.
- **AntiGhosting Email Inspector** (per-prospect drill-down) — own batch.
- **AntiGhosting Activity Log** — own batch.
- **Layout nav scope for /anti-ghosting/** — when the Pipeline/Inspector/Activity pages exist, add the nav scope similar to `onContext`.
- **Settings parity** (stage timing card, max followups, label config, weekly digest scope) — B9e.
- **Pause + renewal + notifications** — B9d.

## Smoke test path

After ship + restart:
1. Navigate to `/picker`. Verify three tiles render with correct accents (blue, amber, cyan).
2. Click Anti-Ghosting tile → lands on `/anti-ghosting`.
3. If you don't have the `AntiGhosting Followuper` label in Gmail yet, the setup help card renders with the three-step instructions.
4. Create the label in Gmail, apply it to a ghosted thread, refresh the page → the candidate appears.
5. Verify the validator chips match the thread shape (e.g., if you're testing on a thread where the last message was theirs, the first chip shows red).
6. On a passing candidate, click Mark → expect the cyan success card with F1 scheduledAt.
7. Wait the configured cadence (or trigger a force-dispatch) → the generated F1 lands in the existing pipeline review/draft flow.
