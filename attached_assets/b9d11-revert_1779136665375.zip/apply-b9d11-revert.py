#!/usr/bin/env python3
"""
B9d.11-revert - pull 3D cursor-tracked tilt from Card entirely.

After B9d.11 + B9d.11-fix tuning to 3deg / 1500 perspective, the
visual distortion on wide tables (Admin Activity Recent Events, etc.)
still bothers more than the tilt impresses. Pulling the mechanism.

Card returns to its B9d.8 state:
  - motion.div with cardVariants for stagger entrance (preserved)
  - whileHover={{ y: -1 }} for the simple lift (preserved)
  - No cursor tracking, no perspective, no rotateX/rotateY
  - No useMotionValue/useSpring/useTransform/useReducedMotion hooks
    needed in ui.tsx (they were ONLY used for the tilt)

Skeleton + SkeletonList (B9d.13a) are untouched - they sit after Card
and use different code paths.

Two anchors:
  A1: framer-motion import - drop the 4 hooks added by B9d.11
  A2: Card definition - replace tilt mechanism with simple whileHover

Idempotent.
"""

from __future__ import annotations
import sys
from pathlib import Path

WORKSPACE = Path.cwd()
UI = WORKSPACE / "artifacts/dashboard/src/components/ui.tsx"


def fail(msg):
    print(f"[FAIL] {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg):
    print(f"[ok]   {msg}")


def skip(msg):
    print(f"[skip] {msg}")


def replace_unique(text, old, new, label, marker_after):
    if marker_after in text and old not in text:
        skip(f"{label}: already reverted")
        return text, False
    count = text.count(old)
    if count == 0:
        fail(f"{label}: anchor not found")
    if count > 1:
        fail(f"{label}: anchor appears {count} times; expected 1")
    ok(f"{label}: reverted")
    return text.replace(old, new, 1), True


# ====================================================================
# A1: framer-motion import - drop the 4 hooks
# ====================================================================
A1_OLD = '''// B9d.11: 3D tilt requires useMotionValue, useSpring, useTransform; reduced-motion via useReducedMotion.
import {
  AnimatePresence,
  motion,
  useMotionValue,
  useSpring,
  useTransform,
  useReducedMotion,
} from "framer-motion";'''

A1_NEW = '''import { AnimatePresence, motion } from "framer-motion";'''


# ====================================================================
# A2: Card definition - revert to B9d.8 simple whileHover.
# Includes B9d.11-fix's tuned values (TILT_MAX_DEG = 3, perspective 1500)
# since fix landed cleanly. After revert, all of that goes away.
# ====================================================================
A2_OLD = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + hover lift for modern fintech feel.
// B9d.8: motion-converted with variants - inherits hidden/visible state
// from the page motion.div for staggered entrance.
// B9d.11: cursor-tracked 3D tilt replaces flat whileHover. As the mouse
// moves over the card, springs drive rotateX/rotateY toward the cursor
// (max 5deg per axis). Reduced-motion users skip the tilt entirely.
const cardVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2, ease: "easeOut" as const } },
};

const TILT_MAX_DEG = 3; // B9d.11-fix: reduced from 5 to soften tilt on wide cards.

export const Card = ({
  className,
  onMouseMove,
  onMouseLeave,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => {
  const reduceMotion = useReducedMotion();
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springConfig = { stiffness: 300, damping: 25 } as const;
  const springX = useSpring(x, springConfig);
  const springY = useSpring(y, springConfig);
  // Y-axis mouse movement rotates around X-axis (top tips back), and vice versa.
  const rotateY = useTransform(springX, [-0.5, 0.5], [-TILT_MAX_DEG, TILT_MAX_DEG]);
  const rotateX = useTransform(springY, [-0.5, 0.5], [TILT_MAX_DEG, -TILT_MAX_DEG]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!reduceMotion) {
      const rect = e.currentTarget.getBoundingClientRect();
      x.set((e.clientX - rect.left) / rect.width - 0.5);
      y.set((e.clientY - rect.top) / rect.height - 0.5);
    }
    onMouseMove?.(e);
  };

  const handleMouseLeave = (e: React.MouseEvent<HTMLDivElement>) => {
    x.set(0);
    y.set(0);
    onMouseLeave?.(e);
  };

  return (
    <motion.div
      variants={cardVariants}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={cn(
        "rounded-xl shadow-sm",
        "transition-shadow duration-300 ease-out",
        "hover:shadow-md",
        className
      )}
      style={{
        background: "var(--bg-secondary)",
        border: "1px solid var(--border-default)",
        rotateX: reduceMotion ? 0 : rotateX,
        rotateY: reduceMotion ? 0 : rotateY,
        transformPerspective: 1500, // B9d.11-fix: 1000 -> 1500 to reduce foreshortening.
      }}
      {...(props as any)}
    />
  );
};'''

A2_NEW = '''// B9d.3: subtle shadow for depth - visible on AG white bg, near-invisible on dark themes.
// B9d.6: rounded-xl + always-on subtle hover lift.
// B9d.8: motion-converted with variants - inherits hidden/visible state from
// the App.tsx page motion.div, cascading in via staggerChildren. Hover-lift
// moved from CSS to whileHover to avoid clash with variant-driven transform.
// B9d.11-revert: 3D cursor-tracked tilt removed. Visual distortion on wide
// content cards (table-heavy pages) outweighed the premium feel. Back to
// flat whileHover lift.
const cardVariants = {
  hidden: { opacity: 0, y: 8 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.2, ease: "easeOut" as const } },
};

export const Card = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <motion.div
    variants={cardVariants}
    whileHover={{ y: -1 }}
    transition={{ type: "spring", stiffness: 400, damping: 30 }}
    className={cn(
      "rounded-xl shadow-sm",
      "transition-shadow duration-300 ease-out",
      "hover:shadow-md",
      className
    )}
    style={{ background: "var(--bg-secondary)", border: "1px solid var(--border-default)" }}
    {...(props as any)}
  />
);'''


def main():
    if not UI.exists():
        fail(f"ui.tsx not found: {UI}")
    text = UI.read_text(encoding="utf-8")
    original = text

    text, _ = replace_unique(
        text, A1_OLD, A1_NEW,
        "A1: drop 4 framer-motion tilt hooks",
        marker_after="B9d.11-revert",
    )
    text, _ = replace_unique(
        text, A2_OLD, A2_NEW,
        "A2: Card back to whileHover y:-1",
        marker_after="B9d.11-revert: 3D cursor-tracked tilt removed",
    )

    if text != original:
        UI.write_text(text, encoding="utf-8")
        ok(f"wrote {UI.relative_to(WORKSPACE)}")
    else:
        skip("ui.tsx already at reverted state")

    print()
    print("B9d.11-revert applied. Card no longer tilts on hover.")


if __name__ == "__main__":
    main()
